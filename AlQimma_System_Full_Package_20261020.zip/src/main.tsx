// منظومة معهد القمة — v3.0
import { createRoot } from 'react-dom/client';
import { ThemeProvider } from 'next-themes';
import { AppWrapper } from './components/common/PageMeta';
import { AuthProvider } from './contexts/AuthContext';
import App from './App';
import './index.css';

// إجبار الوضع الفاتح فوراً — يمنع الشاشة السوداء
(function forceLight() {
  const html = document.documentElement;
  html.classList.remove('dark');
  html.classList.add('light');
  try {
    localStorage.removeItem('theme');
    localStorage.removeItem('vite-ui-theme');
  } catch (_) { /* تجاهل */ }
})();

const container = document.getElementById('root');
if (!container) {
  document.body.innerHTML = '<div style="padding:40px;font-family:Cairo,sans-serif;direction:rtl;color:#c00">خطأ: عنصر #root غير موجود</div>';
} else {
  createRoot(container).render(
    <ThemeProvider attribute="class" defaultTheme="light" enableSystem={false} forcedTheme="light">
      <AppWrapper>
        <AuthProvider>
          <App />
        </AuthProvider>
      </AppWrapper>
    </ThemeProvider>
  );
}
