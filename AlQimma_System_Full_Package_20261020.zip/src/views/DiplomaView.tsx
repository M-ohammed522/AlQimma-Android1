// سجل معاملات الدبلوم (العالي والمتوسط) — منظومة معهد القمة
import { useEffect, useState, useMemo, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ChevronRight, RefreshCw, Printer, FileSpreadsheet,
  FileDown, Search, X, BookOpen, Hash,
  DollarSign, Receipt as ReceiptIcon, Calendar, TrendingUp,
} from 'lucide-react';
import { toast } from 'sonner';
import * as XLSX from 'xlsx';
import { triggerDownload } from '@/lib/printUtils';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { getAllReceiptsUnpaged } from '@/lib/api';
import { matchSearch } from '@/lib/searchUtils';
import type { Receipt } from '@/types/index';

type FullReceipt = Receipt & {
  student_name: string;
  student_national_id: string;
  student_diploma: string;
  student_specialization: string;
  student_phone: string | null;
};

const LOGO_URL = 'https://miaoda-conversation-file.s3cdn.medo.dev/user-cim4m3x63pxc/app-f6avantw6h35/20261018/FB_IMG_1780949707596.jpg';

function fmtDate(iso: string) {
  return new Date(iso).toLocaleDateString('ar-LY', { year: 'numeric', month: '2-digit', day: '2-digit' });
}
function fmtMoney(n: number) {
  return n.toLocaleString('ar-LY', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// ── مكوّن التاب الواحد ──
interface TabPanelProps {
  allData: FullReceipt[];
  loading: boolean;
  diplomaType: 'عالي' | 'متوسط';
  accentColor: string;
  badgeClass: string;
}

function DiplomaTabPanel({ allData, loading, diplomaType, accentColor, badgeClass }: TabPanelProps) {
  const [search, setSearch]           = useState('');
  const [monthFilter, setMonthFilter] = useState('');

  // فلترة بحسب نوع الدبلوم
  const typeData = useMemo(
    () => allData.filter(r => r.student_diploma === diplomaType),
    [allData, diplomaType],
  );

  const rows = useMemo(() => {
    let list = [...typeData].sort((a, b) => {
      const na = parseInt(a.supply_order_number ?? '0', 10);
      const nb = parseInt(b.supply_order_number ?? '0', 10);
      return na - nb;
    });
    if (monthFilter) list = list.filter(r => r.paid_at.startsWith(monthFilter));
    if (search.trim()) {
      list = list.filter(r =>
        matchSearch(r.student_name, search) ||
        matchSearch(r.supply_order_number, search) ||
        matchSearch(r.receipt_number, search) ||
        matchSearch(r.student_national_id, search),
      );
    }
    return list;
  }, [typeData, search, monthFilter]);

  const totalAmount = useMemo(() => rows.reduce((s, r) => s + r.amount, 0), [rows]);

  const availableMonths = useMemo(() => {
    const months = new Set<string>();
    typeData.forEach(r => { if (r.paid_at) months.add(r.paid_at.slice(0, 7)); });
    return [...months].sort().reverse();
  }, [typeData]);

  const label = diplomaType === 'عالي' ? 'الدبلوم العالي' : 'الدبلوم المتوسط';

  // ── طباعة هذا التاب فقط ──
  const handlePrint = () => {
    const win = window.open('', '_blank', 'width=1100,height=800');
    if (!win) return;
    win.document.write(`
      <html dir="rtl"><head><meta charset="utf-8">
      <title>سجل معاملات ${label}</title>
      <style>
        *{box-sizing:border-box;margin:0;padding:0;font-family:'Segoe UI',Tahoma,Arial,sans-serif}
        body{background:#fff;color:#111;font-size:10.5px;direction:rtl}
        .page{width:100%;padding:10mm 12mm}
        .hdr{display:flex;align-items:center;gap:12px;border-bottom:3px solid ${accentColor};padding-bottom:10px;margin-bottom:14px}
        .hdr-logo{width:58px;height:58px;border-radius:50%;overflow:hidden;border:2px solid ${accentColor};flex-shrink:0}
        .hdr-logo img{width:100%;height:100%;object-fit:cover}
        .hdr-text{flex:1}
        .hdr-text h1{font-size:15px;font-weight:900;color:${accentColor};margin-bottom:2px}
        .hdr-text p{font-size:9.5px;color:#666;margin:1px 0}
        .hdr-meta{text-align:left;font-size:9px;color:#888;line-height:1.7}
        .badge{display:inline-block;padding:2px 10px;border-radius:20px;font-size:10px;font-weight:700}
        ${badgeClass}
        table{width:100%;border-collapse:collapse;margin-bottom:14px}
        thead tr{background:${accentColor}}
        th{color:#fff;padding:7px 8px;font-size:9.5px;font-weight:700;white-space:nowrap;text-align:center}
        td{padding:5.5px 8px;border-bottom:1px solid #e9edf2;font-size:10px;text-align:center;white-space:nowrap}
        tr:nth-child(even) td{background:#f8fafc}
        .total-row td{background:#e8f4ff;font-weight:800;border-top:2px solid ${accentColor};font-size:11px}
        .footer{margin-top:14px;display:flex;justify-content:space-between;align-items:center;border-top:1px solid #e5e7eb;padding-top:8px;font-size:9px;color:#aaa}
        .sig-row{display:flex;gap:40px}
        .sig-box{text-align:center}
        .sig-line{border-bottom:1px solid #bbb;width:130px;height:22px;margin-bottom:4px}
        .sig-label{font-size:9px;color:#888;font-weight:600}
        @media print{@page{size:A4 landscape;margin:8mm}body{margin:0}}
      </style></head><body>
      <div class="page">
        <div class="hdr">
          <div class="hdr-logo"><img src="${LOGO_URL}" alt="شعار" /></div>
          <div class="hdr-text">
            <h1>معهد القمة للعلوم الطبية والإدارية</h1>
            <p>سجل معاملات ${label}${monthFilter ? ` — ${monthFilter}` : ' — جميع الأشهر'}</p>
            <p>إجمالي المعاملات: <b style="color:${accentColor}">${rows.length}</b> &nbsp;|&nbsp; إجمالي المبالغ: <b style="color:#15803d">${fmtMoney(totalAmount)} د.ل</b></p>
          </div>
          <div class="hdr-meta">
            <div>تاريخ الطباعة: <b>${new Date().toLocaleDateString('ar-LY')}</b></div>
            <div>الوقت: <b>${new Date().toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit' })}</b></div>
          </div>
        </div>
        <table>
          <thead><tr>
            <th>م</th><th>رقم المعاملة</th><th>التاريخ</th>
            <th>يورد إلى</th><th>الاسم رباعي</th><th>المبلغ (د.ل)</th><th>رقم الإيصال</th>
          </tr></thead>
          <tbody>
            ${rows.map((r, i) => `
              <tr>
                <td>${i + 1}</td>
                <td>${r.supply_order_number ?? '—'}</td>
                <td>${fmtDate(r.paid_at)}</td>
                <td>إدارة المعهد</td>
                <td style="text-align:right">${r.student_name}</td>
                <td style="color:#15803d;font-weight:700">${fmtMoney(r.amount)}</td>
                <td>${r.receipt_number}</td>
              </tr>
            `).join('')}
            <tr class="total-row">
              <td colspan="5" style="text-align:right;padding-right:12px">الإجمالي</td>
              <td style="color:${accentColor};font-size:12px">${fmtMoney(totalAmount)}</td>
              <td>${rows.length} معاملة</td>
            </tr>
          </tbody>
        </table>
        <div class="footer">
          <div class="sig-row">
            <div class="sig-box"><div class="sig-line"></div><div class="sig-label">توقيع المحاسب المسؤول</div></div>
            <div class="sig-box"><div class="sig-line"></div><div class="sig-label">اعتماد المدير</div></div>
          </div>
          <div style="text-align:left">
            <p>معهد القمة للعلوم الطبية والإدارية</p>
            <p>جميع الحقوق محفوظة © ${new Date().getFullYear()}</p>
          </div>
        </div>
      </div>
      </body></html>
    `);
    win.document.close();
    win.focus();
    setTimeout(() => { win.print(); win.close(); }, 400);
  };

  // ── تصدير Excel ──
  const handleExcel = () => {
    const wsData = [
      ['م', 'رقم المعاملة', 'التاريخ', 'يورد إلى', 'الاسم رباعي', 'المبلغ (د.ل)', 'رقم الإيصال'],
      ...rows.map((r, i) => [
        i + 1,
        r.supply_order_number ?? '—',
        fmtDate(r.paid_at),
        'إدارة المعهد',
        r.student_name,
        r.amount,
        r.receipt_number,
      ]),
      ['', '', '', '', 'الإجمالي', totalAmount, `${rows.length} معاملة`],
    ];
    const ws = XLSX.utils.aoa_to_sheet(wsData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, `سجل ${label}`);
    const wbOut = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    triggerDownload(
      new Blob([wbOut], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }),
      `سجل_معاملات_${diplomaType === 'عالي' ? 'الدبلوم_العالي' : 'الدبلوم_المتوسط'}_${monthFilter || 'الكل'}.xlsx`
    );
    toast.success('تم تصدير الملف بنجاح');
  };

  // ── تصدير PDF (طباعة HTML) ──
  const handlePdf = () => handlePrint();

  return (
    <div className="space-y-4">

      {/* ── بطاقات الإحصاء ── */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {[
          {
            label: 'إجمالي المعاملات',
            value: loading ? '—' : `${rows.length}`,
            sub: 'معاملة',
            gradient: diplomaType === 'عالي' ? 'from-[#1a3c5e] to-blue-700' : 'from-emerald-700 to-teal-700',
            Icon: Hash,
          },
          {
            label: 'إجمالي المبالغ',
            value: loading ? '—' : fmtMoney(totalAmount),
            sub: 'دينار ليبي',
            gradient: 'from-emerald-500 to-emerald-700',
            Icon: DollarSign,
          },
          {
            label: 'عدد الطلاب',
            value: loading ? '—' : `${new Set(typeData.map(r => r.student_name)).size}`,
            sub: `طالب ${label}`,
            gradient: diplomaType === 'عالي' ? 'from-indigo-500 to-indigo-700' : 'from-teal-500 to-teal-700',
            Icon: TrendingUp,
          },
        ].map(card => (
          <div key={card.label}
            className={`relative rounded-2xl p-4 bg-gradient-to-br ${card.gradient} text-white shadow-md ring-1 ring-white/10 overflow-hidden`}>
            <div className="absolute -bottom-2 -left-2 opacity-[0.12]">
              <card.Icon className="w-16 h-16" />
            </div>
            <p className="text-[10px] font-semibold text-white/70 leading-tight uppercase tracking-wide">{card.label}</p>
            {loading
              ? <div className="h-8 w-16 bg-white/20 rounded-lg mt-2 animate-pulse" />
              : <p className="text-2xl font-black leading-none mt-1.5 tabular-nums">{card.value}</p>
            }
            <p className="text-[10px] text-white/55 mt-1">{card.sub}</p>
          </div>
        ))}
      </div>

      {/* ── شريط الفلاتر + أزرار التصدير ── */}
      <div className="flex flex-col md:flex-row gap-2 items-start md:items-center">
        {/* بحث */}
        <div className="relative flex-1 min-w-0">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
          <Input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="بحث باسم الطالب أو رقم المعاملة أو رقم الإيصال..."
            className="pr-9 h-9 text-sm rounded-xl border-border/60"
          />
          {search && (
            <button onClick={() => setSearch('')}
              className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground hover:text-foreground transition-colors">
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* فلتر الشهر */}
        <div className="relative shrink-0">
          <Calendar className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
          <select
            value={monthFilter}
            onChange={e => setMonthFilter(e.target.value)}
            className="h-9 pr-9 pl-3 rounded-xl border border-border/60 bg-background text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 min-w-[160px]"
          >
            <option value="">كل الأشهر</option>
            {availableMonths.map(m => (
              <option key={m} value={m}>{m}</option>
            ))}
          </select>
        </div>

        {/* إعادة تعيين */}
        {(search || monthFilter) && (
          <button
            onClick={() => { setSearch(''); setMonthFilter(''); }}
            className="inline-flex items-center gap-1.5 h-9 px-3 rounded-xl text-xs font-semibold text-muted-foreground border border-border/50 hover:bg-muted transition-all shrink-0">
            <X className="w-3.5 h-3.5" /> إعادة تعيين
          </button>
        )}

        {/* فاصل */}
        <div className="hidden md:block h-7 w-px bg-border/50 shrink-0" />

        {/* أزرار تصدير خاصة بهذا التاب */}
        <div className="flex gap-2 shrink-0">
          <Button size="sm" onClick={handlePrint} disabled={loading || rows.length === 0}
            className="bg-slate-600 text-white hover:bg-slate-700 gap-1.5 h-9 rounded-xl text-[12px] font-semibold shadow-sm">
            <Printer className="w-3.5 h-3.5" /> طباعة
          </Button>
          <Button size="sm" onClick={handleExcel} disabled={loading || rows.length === 0}
            className="bg-emerald-600 text-white hover:bg-emerald-700 gap-1.5 h-9 rounded-xl text-[12px] font-semibold shadow-sm">
            <FileSpreadsheet className="w-3.5 h-3.5" /> Excel
          </Button>
          <Button size="sm" onClick={handlePdf} disabled={loading || rows.length === 0}
            className="bg-rose-600 text-white hover:bg-rose-700 gap-1.5 h-9 rounded-xl text-[12px] font-semibold shadow-sm">
            <FileDown className="w-3.5 h-3.5" /> PDF
          </Button>
        </div>
      </div>

      {/* ── الجدول ── */}
      <div className="rounded-2xl border border-border/50 bg-card shadow-sm overflow-hidden">
        {/* رأس الجدول */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-border/40 bg-muted/20">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl flex items-center justify-center"
              style={{ backgroundColor: `${accentColor}18` }}>
              <ReceiptIcon className="w-4 h-4" style={{ color: accentColor }} />
            </div>
            <div>
              <p className="text-sm font-bold text-foreground">سجل معاملات {label}</p>
              <p className="text-[10px] text-muted-foreground">
                {loading ? '...' : `${rows.length} معاملة`}{monthFilter ? ` — ${monthFilter}` : ''}
              </p>
            </div>
          </div>
          {!loading && rows.length > 0 && (
            <div className="text-left">
              <p className="text-[10px] text-muted-foreground">إجمالي المبالغ</p>
              <p className="text-sm font-black text-emerald-700 tabular-nums">{fmtMoney(totalAmount)} د.ل</p>
            </div>
          )}
        </div>

        {/* الجدول */}
        <div className="w-full overflow-x-auto">
          <table className="w-full min-w-[700px] text-sm">
            <thead>
              <tr style={{ backgroundColor: accentColor }}>
                {['م', 'رقم المعاملة', 'التاريخ', 'يورد إلى', 'الاسم رباعي', 'المبلغ (د.ل)', 'رقم الإيصال'].map(h => (
                  <th key={h} className="px-3 py-2.5 text-center text-[11px] font-bold text-white whitespace-nowrap">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                Array(6).fill(0).map((_, i) => (
                  <tr key={i} className={i % 2 === 0 ? 'bg-background' : 'bg-muted/20'}>
                    {Array(7).fill(0).map((_, j) => (
                      <td key={j} className="px-3 py-3">
                        <Skeleton className="h-3.5 w-full rounded" />
                      </td>
                    ))}
                  </tr>
                ))
              ) : rows.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-16 text-center">
                    <div className="flex flex-col items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-muted flex items-center justify-center">
                        <ReceiptIcon className="w-6 h-6 text-muted-foreground/40" />
                      </div>
                      <p className="text-sm text-muted-foreground font-medium">لا توجد معاملات</p>
                      <p className="text-xs text-muted-foreground/60">جرّب تغيير فلاتر البحث</p>
                    </div>
                  </td>
                </tr>
              ) : (
                <>
                  {rows.map((r, i) => (
                    <tr key={r.id}
                      className={`group transition-colors ${i % 2 === 0 ? 'bg-background hover:bg-muted/20' : 'bg-muted/15 hover:bg-muted/30'}`}>
                      {/* م */}
                      <td className="px-3 py-2.5 text-center">
                        <span className="inline-flex items-center justify-center w-6 h-6 rounded-full text-[11px] font-black"
                          style={{ backgroundColor: `${accentColor}14`, color: accentColor }}>
                          {i + 1}
                        </span>
                      </td>
                      {/* رقم المعاملة */}
                      <td className="px-3 py-2.5 text-center whitespace-nowrap">
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-foreground/80 bg-muted/50 px-2 py-0.5 rounded-lg">
                          <Hash className="w-3 h-3 text-muted-foreground" />
                          {r.supply_order_number ?? '—'}
                        </span>
                      </td>
                      {/* التاريخ */}
                      <td className="px-3 py-2.5 text-center whitespace-nowrap text-[12px] text-muted-foreground">
                        {fmtDate(r.paid_at)}
                      </td>
                      {/* يورد إلى */}
                      <td className="px-3 py-2.5 text-center whitespace-nowrap">
                        <span className="text-[11px] font-semibold" style={{ color: `${accentColor}cc` }}>
                          إدارة المعهد
                        </span>
                      </td>
                      {/* الاسم رباعي */}
                      <td className="px-3 py-2.5 text-right whitespace-nowrap">
                        <span className="text-[12px] font-semibold text-foreground">{r.student_name}</span>
                      </td>
                      {/* المبلغ */}
                      <td className="px-3 py-2.5 text-center whitespace-nowrap">
                        <span className="text-[12px] font-black text-emerald-700 tabular-nums">
                          {fmtMoney(r.amount)}
                        </span>
                      </td>
                      {/* رقم الإيصال */}
                      <td className="px-3 py-2.5 text-center whitespace-nowrap">
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-blue-700 bg-blue-50 border border-blue-200 px-2 py-0.5 rounded-lg">
                          <ReceiptIcon className="w-3 h-3" />
                          {r.receipt_number}
                        </span>
                      </td>
                    </tr>
                  ))}
                  {/* صف الإجمالي */}
                  <tr className="border-t-2" style={{ borderColor: `${accentColor}30`, backgroundColor: `${accentColor}08` }}>
                    <td colSpan={5} className="px-3 py-3 text-left">
                      <span className="text-[12px] font-black" style={{ color: accentColor }}>
                        الإجمالي — {rows.length} معاملة
                      </span>
                    </td>
                    <td className="px-3 py-3 text-center">
                      <span className="text-[13px] font-black text-emerald-700 tabular-nums">
                        {fmtMoney(totalAmount)} د.ل
                      </span>
                    </td>
                    <td />
                  </tr>
                </>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ── الصفحة الرئيسية ──
export default function DiplomaRegistryPage() {
  const navigate = useNavigate();
  const [all, setAll]         = useState<FullReceipt[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'high' | 'mid'>('high');

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const data = await getAllReceiptsUnpaged();
      setAll(data);
    } catch {
      toast.error('فشل تحميل بيانات السجل');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const highCount = useMemo(() => all.filter(r => r.student_diploma === 'عالي').length, [all]);
  const midCount  = useMemo(() => all.filter(r => r.student_diploma === 'متوسط').length, [all]);

  return (
    <MainLayout>
      <div className="space-y-4" dir="rtl">

        {/* ── الترويسة ── */}
        <div className="relative rounded-2xl overflow-hidden shadow-lg">
          <div className="absolute inset-0 bg-gradient-to-br from-[#1a3c5e]/95 via-[#1a3c5e]/85 to-blue-700/75" />
          <div className="absolute inset-0 opacity-[0.06]"
            style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '24px 24px' }} />
          <div className="relative px-5 py-4 md:px-7 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <button onClick={() => navigate('/supply-orders')}
                className="w-9 h-9 rounded-xl bg-white/15 border border-white/20 flex items-center justify-center shrink-0 hover:bg-white/25 transition-colors">
                <ChevronRight className="w-4 h-4 text-white" />
              </button>
              <div className="w-10 h-10 rounded-xl bg-white/15 border border-white/20 flex items-center justify-center shrink-0">
                <BookOpen className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-white text-balance">سجلات معاملات الدبلوم</h1>
                <p className="text-white/60 text-xs mt-0.5">
                  {loading ? 'جاري التحميل...' : `عالٍ: ${highCount} معاملة  •  متوسط: ${midCount} معاملة`}
                </p>
              </div>
            </div>
            <Button size="sm" onClick={fetchData} disabled={loading}
              className="bg-white/15 text-white hover:bg-white/25 border border-white/20 gap-1.5 h-9 rounded-xl text-[12px] font-semibold shrink-0">
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} /> تحديث
            </Button>
          </div>
        </div>

        {/* ── التابات ── */}
        <Tabs value={activeTab} onValueChange={v => setActiveTab(v as 'high' | 'mid')} dir="rtl">
          <TabsList className="w-full md:w-auto grid grid-cols-2 md:inline-flex h-11 rounded-xl bg-muted/60 p-1 gap-1">
            {/* تاب العالي */}
            <TabsTrigger
              value="high"
              className="rounded-lg text-sm font-bold gap-2 data-[state=active]:bg-[#1a3c5e] data-[state=active]:text-white data-[state=active]:shadow-sm"
            >
              <BookOpen className="w-4 h-4" />
              الدبلوم العالي
              {!loading && (
                <span className="ml-1 px-1.5 py-0.5 rounded-md text-[10px] font-black bg-blue-100 text-blue-700 data-[state=active]:bg-white/20 data-[state=active]:text-white">
                  {highCount}
                </span>
              )}
            </TabsTrigger>
            {/* تاب المتوسط */}
            <TabsTrigger
              value="mid"
              className="rounded-lg text-sm font-bold gap-2 data-[state=active]:bg-emerald-700 data-[state=active]:text-white data-[state=active]:shadow-sm"
            >
              <BookOpen className="w-4 h-4" />
              الدبلوم المتوسط
              {!loading && (
                <span className="ml-1 px-1.5 py-0.5 rounded-md text-[10px] font-black bg-emerald-100 text-emerald-700 data-[state=active]:bg-white/20 data-[state=active]:text-white">
                  {midCount}
                </span>
              )}
            </TabsTrigger>
          </TabsList>

          {/* محتوى تاب العالي */}
          <TabsContent value="high" className="mt-4">
            <DiplomaTabPanel
              allData={all}
              loading={loading}
              diplomaType="عالي"
              accentColor="#1a3c5e"
              badgeClass=".badge{background:#dbeafe;color:#1d4ed8;border:1px solid #93c5fd}"
            />
          </TabsContent>

          {/* محتوى تاب المتوسط */}
          <TabsContent value="mid" className="mt-4">
            <DiplomaTabPanel
              allData={all}
              loading={loading}
              diplomaType="متوسط"
              accentColor="#065f46"
              badgeClass=".badge{background:#d1fae5;color:#065f46;border:1px solid #6ee7b7}"
            />
          </TabsContent>
        </Tabs>

      </div>
    </MainLayout>
  );
}
