// تخطيط الصفحة الرئيسي - منظومة معهد القمة
import { useState, useEffect, useRef } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  UserPlus,
  GraduationCap,
  BarChart3,
  Settings,
  Menu,
  Users,
  DollarSign,
  Receipt,
  ClipboardList,
  Archive,
  ChevronUp,
  BookMarked,
  TrendingUp,
  MessageSquare,
  X,
  Laptop,
  Sparkles,
} from 'lucide-react';
import { WelcomeTransitionModal } from '@/components/common/WelcomeTransitionModal';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent } from '@/components/ui/sheet';
import { cn } from '@/lib/utils';
import { useDeviceRole } from '@/contexts/DeviceRoleContext';

const navGroups = [
  {
    label: 'الرئيسية',
    items: [
      { path: '/',         label: 'لوحة التحكم',  icon: LayoutDashboard },
      { path: '/students', label: 'إدارة الطلاب', icon: Users },
    ],
  },
  {
    label: 'الشؤون المالية',
    items: [
      { path: '/finance',          label: 'الإدارة المالية',        icon: DollarSign },
      { path: '/receipts',         label: 'إيصالات الدفع',          icon: Receipt },
      { path: '/supply-orders',    label: 'أوامر التوريد',           icon: ClipboardList },
      { path: '/diploma-registry', label: 'سجلات الدبلوم',          icon: BookMarked },
      { path: '/financial-report', label: 'الأرباح والتحصيل',       icon: TrendingUp },
    ],
  },
  {
    label: 'الأكاديمي',
    items: [
      { path: '/register',         label: 'تسجيل طالب جديد',  icon: UserPlus },
      { path: '/promotion',        label: 'ترحيل الطلاب',      icon: ChevronUp },
      { path: '/projects',         label: 'مشاريع التخرج',     icon: GraduationCap },
      { path: '/specializations',  label: 'التخصصات والتقارير', icon: BarChart3 },
      { path: '/archive',          label: 'الأرشيف',           icon: Archive },
    ],
  },
  {
    label: 'التواصل',
    items: [
      { path: '/whatsapp', label: 'رسائل واتساب', icon: MessageSquare },
    ],
  },
  {
    label: 'الإعدادات',
    items: [
      { path: '/settings', label: 'إعدادات النظام', icon: Settings },
    ],
  },
];

const LOGO = 'https://miaoda-conversation-file.s3cdn.medo.dev/user-cim4m3x63pxc/app-f6avantw6h35/20261018/FB_IMG_1780949707596.jpg';

// ألوان accent لكل مجموعة
const GROUP_ACCENT: Record<string, string> = {
  'الرئيسية':        'hsl(var(--sidebar-primary))',
  'الشؤون المالية': '#10B981',
  'الأكاديمي':      '#6366F1',
  'التواصل':        '#25D366',
  'الإعدادات':      '#94A3B8',
};

function SidebarContent({ onClose, onOpenWelcome }: { onClose?: () => void; onOpenWelcome?: () => void }) {
  const location = useLocation();
  const { canViewPath, currentRole } = useDeviceRole();

  // تصفية المجموعات والعناصر المعروضة وفق صلاحيات وظيفة الجهاز الحالية
  const filteredNavGroups = navGroups.map((group) => ({
    ...group,
    items: group.items.filter((item) => {
      // زر الإعدادات دائماً ظاهر في جميع الوظائف كما طلب المستخدم
      if (item.path === '/settings') return true;
      return canViewPath(item.path);
    }),
  })).filter((group) => group.items.length > 0);

  return (
    <div
      className="flex flex-col h-full overflow-hidden bg-[#0d1e33] text-white"
      style={{ background: 'var(--gradient-sidebar, linear-gradient(180deg, #0d1e33 0%, #132a45 40%, #0d1e33 100%))' }}
    >

      {/* ══ رأس المعهد ══════════════════════════════════════════════════════════ */}
      <div className="relative shrink-0 overflow-hidden">
        {/* خلفية تدرّجية */}
        <div className="absolute inset-0 pointer-events-none"
          style={{ background: 'linear-gradient(180deg, rgba(255,255,255,0.08) 0%, transparent 100%)' }} />
        {/* نقاط ديكورية */}
        <div className="absolute inset-0 opacity-[0.05] pointer-events-none"
          style={{ backgroundImage: 'radial-gradient(circle, white 1.5px, transparent 1.5px)', backgroundSize: '20px 20px' }} />

        <div className="relative flex flex-col items-center gap-2 pt-6 pb-4 px-4">
          {/* شعار المعهد مع إمكانية النقر لعرض شاشة الترحيب الاحترافية */}
          <button
            type="button"
            onClick={onOpenWelcome}
            title="انقر لعرض الشاشة الترحيبية الاحترافية والصلاحيات"
            className="w-20 h-20 rounded-2xl overflow-hidden border-2 border-white/30 shadow-[0_6px_20px_rgba(0,0,0,0.35)] bg-white p-1 hover:scale-105 transition-all group relative cursor-pointer"
          >
            <img src={LOGO} alt="شعار معهد القمة" className="w-full h-full object-contain rounded-xl" />
            <div className="absolute inset-0 bg-primary/20 opacity-0 group-hover:opacity-100 transition-opacity rounded-xl flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-amber-300 drop-shadow" />
            </div>
          </button>

          {/* الاسم */}
          <div className="text-center mt-1">
            <p className="text-[17px] font-extrabold text-white tracking-wide leading-tight">
              معهد القمة
            </p>
            <p className="text-[11px] text-white/70 mt-1 leading-tight font-medium">
              للعلوم الطبية والإدارية
            </p>
          </div>

          {/* فاصل */}
          <div className="w-full h-px mt-2" style={{ background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.18), transparent)' }} />
        </div>
      </div>

      {/* ══ التنقل ══════════════════════════════════════════════════════════════ */}
      <nav className="flex-1 overflow-y-auto px-3 py-3 space-y-5">
        {filteredNavGroups.map((group) => {
          const accent = GROUP_ACCENT[group.label] ?? '#38bdf8';
          return (
            <div key={group.label}>
              {/* عنوان المجموعة */}
              <div className="flex items-center gap-2 px-1 mb-2">
                <div className="w-1.5 h-3 rounded-full" style={{ background: accent }} />
                <p className="text-[11px] font-bold tracking-wider uppercase select-none text-white/90">
                  {group.label}
                </p>
              </div>

              {/* عناصر المجموعة */}
              <div className="space-y-1">
                {group.items.map((item) => {
                  const Icon   = item.icon;
                  const active = location.pathname === item.path;
                  return (
                    <Link
                      key={item.path}
                      to={item.path}
                      onClick={onClose}
                      className={cn(
                        'group relative flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200 overflow-hidden',
                        active
                          ? 'shadow-md font-bold text-white'
                          : 'text-white/75 hover:text-white hover:bg-white/10',
                      )}
                      style={active ? {
                        background: `linear-gradient(135deg, ${accent}33 0%, ${accent}18 100%)`,
                        border: `1px solid ${accent}55`,
                        color: '#ffffff',
                      } : {}}
                    >
                      {/* شريط نشاط يساري */}
                      {active && (
                        <span className="absolute right-0 top-1/2 -translate-y-1/2 w-[3px] h-6 rounded-l-full"
                          style={{ background: accent, boxShadow: `0 0 10px ${accent}` }} />
                      )}

                      {/* أيقونة */}
                      <div
                        className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0 transition-all duration-200"
                        style={active
                          ? { background: `${accent}40`, color: '#ffffff' }
                          : { background: 'rgba(255,255,255,0.08)', color: 'rgba(255,255,255,0.85)' }
                        }
                      >
                        <Icon className="w-[17px] h-[17px]" />
                      </div>

                      {/* اسم الصفحة */}
                      <span className="text-[14px] font-semibold truncate flex-1 leading-tight">
                        {item.label}
                      </span>

                      {/* نقطة نشاط */}
                      {active && (
                        <span className="w-2 h-2 rounded-full shrink-0 mr-auto"
                          style={{ background: accent, boxShadow: `0 0 6px ${accent}` }} />
                      )}
                    </Link>
                  );
                })}
              </div>
            </div>
          );
        })}
      </nav>

      {/* ══ تذييل مع معلومات وظيفة الجهاز ═════════════════════════════════════ */}
      <div className="shrink-0 px-3 py-3 border-t border-white/10 bg-black/25 space-y-2">
        <Link
          to="/settings"
          onClick={onClose}
          className="flex items-center gap-2 p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 transition-colors"
          title="انقر للانتقال إلى إعدادات وظيفة الجهاز"
        >
          <div className="w-7 h-7 rounded-lg bg-primary/25 flex items-center justify-center shrink-0 border border-primary/40">
            <Laptop className="w-3.5 h-3.5 text-primary" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-[10px] text-white/50 leading-tight">وظيفة هذا الجهاز:</p>
            <p className="text-xs font-bold text-white truncate leading-tight mt-0.5">
              {currentRole ? currentRole.name : 'المدير العام'}
            </p>
          </div>
          <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0 shadow-[0_0_6px_#34d399]" title="نشط" />
        </Link>

        <div className="flex items-center justify-between px-1">
          <button
            type="button"
            onClick={onOpenWelcome}
            className="flex items-center gap-1.5 text-[10px] text-amber-300/80 hover:text-amber-200 bg-white/5 hover:bg-white/10 px-2 py-1 rounded-lg transition-colors border border-white/10"
          >
            <Sparkles className="w-3 h-3 text-amber-300" />
            <span>شاشة الترحيب</span>
          </button>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full border border-white/15 bg-white/5 text-white/60">
            v3.0
          </span>
        </div>
      </div>
    </div>
  );
}

interface MainLayoutProps {
  children: React.ReactNode;
}

export function MainLayout({ children }: MainLayoutProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [showWelcomeModal, setShowWelcomeModal] = useState(false);
  const { currentRole } = useDeviceRole();
  const { pathname } = useLocation();
  const mainRef = useRef<HTMLElement>(null);

  useEffect(() => {
    if (mainRef.current) {
      mainRef.current.scrollTo({ top: 0, behavior: 'instant' });
    }
  }, [pathname]);

  return (
    <div className="flex min-h-screen w-full bg-background" dir="rtl">

      {/* ── شريط جانبي — سطح المكتب ── */}
      <aside className="hidden md:flex flex-col w-64 shrink-0 bg-[#0d1e33] border-l border-white/10 shadow-[2px_0_24px_rgba(0,0,0,0.15)]">
        <SidebarContent onOpenWelcome={() => setShowWelcomeModal(true)} />
      </aside>

      {/* ── شريط جانبي — الجوال ── */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="right" className="w-72 p-0 border-0 bg-[#0d1e33] text-white shadow-2xl overflow-hidden">
          <SidebarContent onClose={() => setMobileOpen(false)} onOpenWelcome={() => setShowWelcomeModal(true)} />
        </SheetContent>
      </Sheet>

      {/* ── المحتوى الرئيسي ── */}
      <div className="flex-1 min-w-0 flex flex-col overflow-x-hidden">

        {/* رأس الجوال */}
        <header className="md:hidden flex items-center justify-between px-4 py-3 border-b border-border/60 bg-card/95 sticky top-0 z-30 shadow-sm">
          <Button variant="ghost" size="icon" onClick={() => setMobileOpen(true)}
            className="w-9 h-9 rounded-xl hover:bg-muted">
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </Button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl overflow-hidden border border-primary/20 shadow-sm bg-white shrink-0">
              <img src={LOGO} alt="شعار معهد القمة" className="w-full h-full object-cover" />
            </div>
            <span className="text-[15px] font-bold text-foreground">معهد القمة للعلوم الطبية والإدارية</span>
          </div>
          <div className="w-9" />
        </header>

        <main ref={mainRef} className="flex-1 p-4 md:p-5 overflow-y-auto">
          {children}
        </main>
      </div>

      {/* الشاشة الترحيبية الاحترافية بكامل الصلاحيات */}
      <WelcomeTransitionModal
        open={showWelcomeModal}
        onClose={() => setShowWelcomeModal(false)}
        roleName={currentRole?.name || 'المدير العام'}
        isFullPermissions={true}
      />
    </div>
  );
}

