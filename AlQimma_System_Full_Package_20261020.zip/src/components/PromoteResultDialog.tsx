// مكون نتيجة الترحيل — يعرض تفاصيل الديون والنواقص بشكل احترافي
import { Dialog, DialogContent } from '@/components/ui/dialog';
import {
  CheckCircle2, XCircle, Loader2, AlertTriangle,
  GraduationCap, ChevronUp, DollarSign, FileText,
  BookOpen, Trophy, Star,
} from 'lucide-react';
import type { Student, SemesterCharge } from '@/types/index';
import { SEMESTER_LABELS } from '@/types/index';

// ── أنواع ──────────────────────────────────────────────────────────────────
export type PromoteResultStatus = 'success' | 'error' | 'skipped';

export interface PromoteResultItem {
  student: Student;
  status: PromoteResultStatus;
  message: string;
  newSemester?: number;           // الفصل الجديد بعد الترحيل
  charges?: SemesterCharge[];     // رسوم الفصل القديم (لعرض الديون بالتفصيل)
  missingDocs?: string[];         // نواقص الملف
  isArchived?: boolean;           // هل أُرشف كخريج؟
}

interface Props {
  open: boolean;
  onClose: () => void;
  promoting: boolean;
  progressDone: number;
  progressMax: number;
  results: PromoteResultItem[];
}

// ── الحساب ─────────────────────────────────────────────────────────────────
function calcDebtByCharge(charges: SemesterCharge[]) {
  return charges
    .filter(c => !c.is_cleared && !c.is_locked && c.remaining_amount > 0)
    .sort((a, b) => a.semester_number - b.semester_number);
}

// ── بطاقة نتيجة طالب واحد ──────────────────────────────────────────────────
function StudentResultCard({ r }: { r: PromoteResultItem }) {
  const debtCharges = r.charges ? calcDebtByCharge(r.charges) : [];
  const totalDebt   = debtCharges.reduce((s, c) => s + c.remaining_amount, 0);
  const hasMissing  = (r.missingDocs?.length ?? 0) > 0;
  const hasDebt     = totalDebt > 0;
  const isSuccess   = r.status === 'success';
  const isError     = r.status === 'error';

  return (
    <div className={`rounded-2xl border overflow-hidden transition-all ${
      r.isArchived
        ? 'border-emerald-300/60 bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-900/20 dark:to-teal-900/15 dark:border-emerald-500/30'
        : isSuccess
          ? 'border-blue-200/60 bg-gradient-to-br from-blue-50/60 to-indigo-50/40 dark:from-blue-900/15 dark:to-indigo-900/10 dark:border-blue-500/25'
          : 'border-destructive/30 bg-destructive/5'
    }`}>

      {/* ── رأس البطاقة ── */}
      <div className={`flex items-center gap-3 px-4 py-3 ${
        r.isArchived
          ? 'bg-emerald-500/10 border-b border-emerald-200/50 dark:border-emerald-500/20'
          : isSuccess
            ? 'bg-blue-500/8 border-b border-blue-200/40 dark:border-blue-500/15'
            : 'bg-destructive/8 border-b border-destructive/20'
      }`}>
        {/* أيقونة الحالة */}
        <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
          r.isArchived ? 'bg-emerald-500/20' : isSuccess ? 'bg-blue-500/15' : 'bg-destructive/15'
        }`}>
          {r.isArchived
            ? <Trophy className="w-4 h-4 text-emerald-600" />
            : isSuccess
              ? <CheckCircle2 className="w-4 h-4 text-blue-600" />
              : <XCircle className="w-4 h-4 text-destructive" />
          }
        </div>

        {/* بيانات الطالب */}
        <div className="flex-1 min-w-0">
          <p className="text-sm font-bold text-foreground truncate">{r.student.full_name}</p>
          <p className={`text-[11px] mt-0.5 font-medium ${
            r.isArchived ? 'text-emerald-600' : isSuccess ? 'text-blue-600' : 'text-destructive'
          }`}>{r.message}</p>
        </div>

        {/* شارة الفصل الجديد */}
        {isSuccess && !r.isArchived && r.newSemester && (
          <div className="shrink-0 flex flex-col items-center bg-blue-600 text-white rounded-xl px-3 py-1.5 shadow-sm">
            <span className="text-[9px] font-semibold opacity-75">الفصل</span>
            <span className="text-base font-black leading-none">{r.newSemester}</span>
          </div>
        )}
        {r.isArchived && (
          <div className="shrink-0 flex items-center gap-1 bg-emerald-600 text-white rounded-xl px-3 py-1.5 shadow-sm">
            <GraduationCap className="w-3.5 h-3.5" />
            <span className="text-[11px] font-bold">خريج</span>
          </div>
        )}
      </div>

      {/* ── تفاصيل الديون والنواقص ── */}
      {isSuccess && (hasDebt || hasMissing) && (
        <div className="px-4 py-3 space-y-3">

          {/* ديون بالتفصيل */}
          {hasDebt && (
            <div>
              <div className="flex items-center gap-2 mb-2">
                <div className="w-5 h-5 rounded-md bg-amber-500/15 flex items-center justify-center">
                  <DollarSign className="w-3 h-3 text-amber-600" />
                </div>
                <p className="text-[11px] font-bold text-amber-700 dark:text-amber-400">
                  مديونيات معلقة — إجمالي: {totalDebt.toFixed(2)} د.ل
                </p>
              </div>
              <div className="space-y-1.5 mr-7">
                {debtCharges.map((c, i) => (
                  <div key={i} className="flex items-center justify-between bg-amber-50 dark:bg-amber-900/20 border border-amber-200/60 dark:border-amber-500/25 rounded-xl px-3 py-2">
                    <div className="flex items-center gap-2">
                      <BookOpen className="w-3 h-3 text-amber-600 shrink-0" />
                      <span className="text-[11px] font-semibold text-amber-800 dark:text-amber-300">
                        {SEMESTER_LABELS[c.semester_number] ?? `الفصل ${c.semester_number}`}
                      </span>
                      <span className="text-[10px] text-amber-600/70 dark:text-amber-400/60 bg-amber-100 dark:bg-amber-900/30 px-1.5 py-0.5 rounded-md">
                        {c.charge_type}
                      </span>
                    </div>
                    <div className="text-left">
                      <span className="text-[12px] font-black text-amber-700 dark:text-amber-400">
                        {c.remaining_amount.toFixed(2)}
                      </span>
                      <span className="text-[10px] text-amber-600/70 mr-0.5">د.ل</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* نواقص الملف */}
          {hasMissing && (
            <div>
              <div className="flex items-center gap-2 mb-2">
                <div className="w-5 h-5 rounded-md bg-rose-500/15 flex items-center justify-center">
                  <FileText className="w-3 h-3 text-rose-600" />
                </div>
                <p className="text-[11px] font-bold text-rose-700 dark:text-rose-400">
                  نواقص الملف ({r.missingDocs!.length})
                </p>
              </div>
              <div className="flex flex-wrap gap-1.5 mr-7">
                {r.missingDocs!.map((doc, i) => (
                  <span key={i} className="inline-flex items-center gap-1 bg-rose-50 dark:bg-rose-900/20 border border-rose-200/60 dark:border-rose-500/25 text-rose-700 dark:text-rose-400 text-[10px] font-semibold px-2.5 py-1 rounded-lg">
                    <AlertTriangle className="w-2.5 h-2.5" />
                    {doc}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* مستوفٍ لجميع المتطلبات */}
      {isSuccess && !hasDebt && !hasMissing && !r.isArchived && (
        <div className="px-4 py-2.5 flex items-center gap-2">
          <Star className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
          <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold">
            مستوفٍ لجميع الرسوم والوثائق ✓
          </p>
        </div>
      )}
    </div>
  );
}

// ── المكون الرئيسي ──────────────────────────────────────────────────────────
export function PromoteResultDialog({ open, onClose, promoting, progressDone, progressMax, results }: Props) {
  const progressPct   = progressMax > 0 ? Math.round((progressDone / progressMax) * 100) : 0;
  const successCount  = results.filter(r => r.status === 'success').length;
  const errorCount    = results.filter(r => r.status === 'error').length;
  const archivedCount = results.filter(r => r.isArchived).length;
  const debtCount     = results.filter(r => {
    const d = r.charges ? calcDebtByCharge(r.charges) : [];
    return d.length > 0;
  }).length;
  const missingCount = results.filter(r => (r.missingDocs?.length ?? 0) > 0).length;

  return (
    <Dialog open={open} onOpenChange={o => { if (!o && !promoting) onClose(); }}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg max-h-[90dvh] overflow-hidden flex flex-col p-0 rounded-2xl" dir="rtl">

        {/* ── رأس النافذة ── */}
        <div className={`relative px-5 py-4 rounded-t-2xl shrink-0 overflow-hidden ${
          promoting
            ? 'bg-gradient-to-br from-indigo-600 to-blue-700'
            : successCount > 0
              ? 'bg-gradient-to-br from-indigo-700 via-indigo-600 to-blue-600'
              : 'bg-gradient-to-br from-rose-600 to-red-700'
        }`}>
          {/* نقاط ديكورية */}
          <div className="absolute inset-0 opacity-10"
            style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '20px 20px' }} />

          <div className="relative flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 border border-white/30 flex items-center justify-center shrink-0">
              {promoting
                ? <Loader2 className="w-5 h-5 text-white animate-spin" />
                : <ChevronUp className="w-5 h-5 text-white" />
              }
            </div>
            <div>
              <p className="text-white font-black text-base flex items-center gap-2">
                <span>{promoting ? 'جاري ترحيل الطلاب...' : 'نتائج الترحيل'}</span>
                {promoting && (
                  <span className="text-[10px] font-bold bg-white/20 text-white px-2 py-0.5 rounded-full border border-white/20 animate-pulse">
                    دفعات متوازية فائقة السرعة ⚡
                  </span>
                )}
              </p>
              {promoting ? (
                <p className="text-white/80 text-[11px] mt-0.5">
                  تتم المعالجة عبر دفعات متزامنة لتسريع ترحيل المجموعات الكبيرة (100+ طالب)
                </p>
              ) : results.length > 0 && (
                <p className="text-white/70 text-[11px] mt-0.5">
                  {progressMax} طالب — {successCount} نجح
                  {errorCount > 0 ? ` · ${errorCount} فشل` : ''}
                </p>
              )}
            </div>
          </div>

          {/* شريط التقدم */}
          {(promoting || progressMax > 0) && (
            <div className="relative mt-4">
              <div className="flex justify-between items-center mb-1.5">
                <span className="text-white/70 text-[11px]">{progressDone} / {progressMax} طالب</span>
                <span className="text-white font-black text-[11px]">{progressPct}%</span>
              </div>
              <div className="h-2.5 bg-white/20 rounded-full overflow-hidden">
                <div
                  className="h-full bg-white rounded-full transition-all duration-500 ease-out"
                  style={{ width: `${progressPct}%` }}
                />
              </div>
            </div>
          )}
        </div>

        {/* ── ملخص الإحصاءات (بعد الانتهاء) ── */}
        {!promoting && results.length > 0 && (
          <div className="px-4 py-3 bg-muted/20 border-b border-border/40 shrink-0">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {[
                { icon: CheckCircle2, label: 'تم الترحيل', value: successCount - archivedCount, color: 'text-blue-600', bg: 'bg-blue-50 dark:bg-blue-900/20', border: 'border-blue-200/60 dark:border-blue-500/25' },
                { icon: GraduationCap, label: 'تخرج (أرشفة)', value: archivedCount, color: 'text-emerald-600', bg: 'bg-emerald-50 dark:bg-emerald-900/20', border: 'border-emerald-200/60 dark:border-emerald-500/25' },
                { icon: AlertTriangle, label: 'بديون معلقة', value: debtCount, color: 'text-amber-600', bg: 'bg-amber-50 dark:bg-amber-900/20', border: 'border-amber-200/60 dark:border-amber-500/25' },
                { icon: FileText, label: 'نواقص ملف', value: missingCount, color: 'text-rose-600', bg: 'bg-rose-50 dark:bg-rose-900/20', border: 'border-rose-200/60 dark:border-rose-500/25' },
              ].map(stat => (
                <div key={stat.label} className={`flex items-center gap-2 rounded-xl px-3 py-2 border ${stat.bg} ${stat.border}`}>
                  <stat.icon className={`w-3.5 h-3.5 shrink-0 ${stat.color}`} />
                  <div>
                    <p className={`text-base font-black leading-none ${stat.color}`}>{stat.value}</p>
                    <p className="text-[9px] text-muted-foreground mt-0.5 leading-tight">{stat.label}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── قائمة النتائج ── */}
        <div className="flex-1 overflow-y-auto min-h-0 p-4 space-y-3">
          {results.length === 0 && promoting ? (
            <div className="flex flex-col items-center py-12 gap-3">
              <div className="w-16 h-16 rounded-2xl bg-indigo-500/10 flex items-center justify-center">
                <Loader2 className="w-8 h-8 text-indigo-500 animate-spin" />
              </div>
              <p className="text-sm font-semibold text-muted-foreground">جاري معالجة الطلاب...</p>
              <p className="text-xs text-muted-foreground/60">يرجى الانتظار حتى اكتمال العملية</p>
            </div>
          ) : (
            <>
              {results.map((r, i) => (
                <StudentResultCard key={i} r={r} />
              ))}
              {/* مؤشر المعالجة الجارية */}
              {promoting && progressDone < progressMax && (
                <div className="flex items-center gap-3 bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-200/50 dark:border-indigo-500/25 rounded-2xl px-4 py-3 animate-pulse">
                  <div className="w-8 h-8 rounded-xl bg-indigo-500/15 flex items-center justify-center shrink-0">
                    <Loader2 className="w-4 h-4 text-indigo-600 animate-spin" />
                  </div>
                  <p className="text-sm text-indigo-600 dark:text-indigo-400 font-medium">جاري معالجة الطالب التالي...</p>
                </div>
              )}
            </>
          )}
        </div>

        {/* ── زر الإغلاق ── */}
        {!promoting && (
          <div className="px-4 py-4 border-t border-border/40 shrink-0 bg-muted/10">
            <button
              onClick={onClose}
              className="w-full h-11 rounded-xl text-[14px] font-bold bg-gradient-to-r from-indigo-600 to-blue-600 text-white hover:from-indigo-700 hover:to-blue-700 transition-all shadow-md shadow-indigo-500/20 flex items-center justify-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              إغلاق
            </button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
