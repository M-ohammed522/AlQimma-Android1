// نافذة الملف الشامل للطالب — تنبثق عند الضغط على بطاقة الطالب في الإدارة المالية
import React, { useEffect, useState, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useNavigate } from 'react-router-dom';
import {
  X, User, Phone, MapPin, GraduationCap, BookOpen, Calendar,
  Banknote, CheckCircle2, AlertTriangle, ChevronDown, Printer,
  Plus, CheckCheck, MessageCircle, ExternalLink, Receipt as ReceiptIcon, RefreshCw,
  Pencil, Trash2, RotateCcw, ChevronUp, Hash, Scissors, Archive, FileText,
  Sparkles, ArrowLeft, Check, ClipboardList,
} from 'lucide-react';
import { printSupplyOrder, FullReceipt } from '@/pages/SupplyOrdersPage';
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  getReceipts, getSemesterCharges, processPayment,
  peekCurrentReceiptNumber, deleteReceipt, updateReceipt, resetStudentBalance,
  promoteStudent, archiveStudent, getSettings, recalculateStudentFinances,
  getStudentById, applyDiscount, MAX_SEMESTERS, createSemesterCharge,
  compareReceipts,
} from '@/lib/api';
import { supabase } from '@/db/supabase';
import type { Student, Receipt, SemesterCharge } from '@/types/index';
import { SEMESTER_LABELS, SETTINGS_KEYS } from '@/types/index';
import { StudentAvatar } from '@/components/ui/StudentAvatar';
import { SmartDateInput } from '@/components/ui/SmartDateInput';
import { printReceipt } from '@/lib/printReceipt';



// ── قسم أقساط قابل للطي ──
function SemesterSection({ label, charges }: { label: string; charges: SemesterCharge[] }) {
  const [open, setOpen] = useState(false);
  // الإجمالي الفعلي = الأصلي − التخفيض
  const total   = charges.reduce((s, c) => s + (c.charge_amount - (c.discount_amount ?? 0)), 0);
  const paid    = charges.reduce((s, c) => s + c.paid_amount, 0);
  const cleared = charges.every(c => c.is_cleared);

  return (
    <div className="border border-border/40 rounded-xl overflow-hidden">
      <button
        onClick={() => setOpen(v => !v)}
        className="w-full flex items-start justify-between gap-2 px-3 py-2.5 text-right bg-muted/20 hover:bg-muted/35 transition-colors"
      >
        {/* يسار: اسم الفصل + الحالة */}
        <div className="flex items-center gap-2 flex-1 min-w-0">
          <BookOpen className="w-3.5 h-3.5 text-muted-foreground shrink-0 mt-px" />
          <span className="text-[12px] font-bold text-foreground leading-tight break-words">{label}</span>
          {cleared
            ? <span className="text-[10px] font-bold text-chart-2 bg-chart-2/10 px-1.5 py-0.5 rounded-full border border-chart-2/20 shrink-0">مسدد</span>
            : <span className="text-[10px] font-bold text-amber-600 bg-amber-500/10 px-1.5 py-0.5 rounded-full border border-amber-400/20 shrink-0">معلق</span>
          }
        </div>
        {/* يمين: أرقام + سهم */}
        <div className="flex flex-col items-end gap-0.5 shrink-0">
          <span className="text-[11px] text-muted-foreground whitespace-nowrap">رسوم: <span className="font-semibold text-foreground">{total.toFixed(0)}</span> د.ل</span>
          <span className="text-[11px] text-chart-2 font-semibold whitespace-nowrap">مدفوع: {paid.toFixed(0)} د.ل</span>
        </div>
        <ChevronDown className={`w-3.5 h-3.5 text-muted-foreground transition-transform duration-200 shrink-0 mt-1 ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && (
        <div className="px-3 pb-3 pt-2 bg-background">
          <div className="overflow-x-auto">
            <table className="w-full text-right min-w-[320px]">
              <thead>
                <tr className="bg-muted/30 text-[10px] text-muted-foreground">
                  <th className="px-2 py-1.5 font-semibold whitespace-nowrap rounded-r-md">نوع الرسوم</th>
                  <th className="px-2 py-1.5 font-semibold whitespace-nowrap text-center">الإجمالي</th>
                  <th className="px-2 py-1.5 font-semibold whitespace-nowrap text-center">المدفوع</th>
                  <th className="px-2 py-1.5 font-semibold whitespace-nowrap text-center">المتبقي</th>
                  <th className="px-2 py-1.5 font-semibold whitespace-nowrap text-center rounded-l-md">الحالة</th>
                </tr>
              </thead>
              <tbody>
                {charges.map((ch, i) => {
                  const effective = ch.charge_amount - (ch.discount_amount ?? 0);
                  const hasDiscount = (ch.discount_amount ?? 0) > 0;
                  return (
                    <tr key={ch.id} className={`border-t border-border/25 ${i % 2 !== 0 ? 'bg-muted/10' : ''}`}>
                      <td className="px-2 py-1.5 text-[11px] font-medium whitespace-nowrap">{ch.charge_type}</td>
                      <td className="px-2 py-1.5 text-[11px] font-mono whitespace-nowrap text-center">
                        {hasDiscount ? (
                          <span className="flex flex-col items-center gap-0.5">
                            <span className="line-through text-muted-foreground text-[10px]">{ch.charge_amount.toFixed(0)}</span>
                            <span className="font-bold text-amber-600">{effective.toFixed(0)}</span>
                          </span>
                        ) : (
                          effective.toFixed(0)
                        )}
                      </td>
                      <td className="px-2 py-1.5 text-[11px] font-mono text-chart-2 font-bold whitespace-nowrap text-center">{ch.paid_amount.toFixed(0)}</td>
                      <td className={`px-2 py-1.5 text-[11px] font-mono font-bold whitespace-nowrap text-center ${ch.remaining_amount > 0 ? 'text-destructive' : 'text-chart-2'}`}>
                        {ch.remaining_amount > 0 ? ch.remaining_amount.toFixed(0) : '—'}
                      </td>
                      <td className="px-2 py-1.5 whitespace-nowrap text-center">
                        {ch.is_cleared
                          ? <span className="text-[10px] font-bold text-chart-2 bg-chart-2/10 px-1.5 py-0.5 rounded">✓ مسدد</span>
                          : <span className="text-[10px] font-bold text-amber-600 bg-amber-500/10 px-1.5 py-0.5 rounded">معلق</span>
                        }
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════
// المكوّن الرئيسي
// ══════════════════════════════════════════════
interface StudentProfileDialogProps {
  student: Student | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onDataChange?: () => void;
}

export default function StudentProfileDialog({
  student,
  open,
  onOpenChange,
  onDataChange,
}: StudentProfileDialogProps) {
  const navigate = useNavigate();
  // نسخة محلية من بيانات الطالب تُحدَّث فور أي عملية مالية دون انتظار الوالد
  const [localStudent, setLocalStudent] = useState<Student | null>(student);
  const [charges, setCharges] = useState<SemesterCharge[]>([]);
  const [receipts, setReceipts] = useState<Receipt[]>([]);
  const [loadingDetails, setLoadingDetails] = useState(false);
  const [showAll, setShowAll] = useState(false);

  // دفعة جديدة
  const [showPayDialog, setShowPayDialog] = useState(false);
  const [payAmount, setPayAmount] = useState('');
  const [payNotes, setPayNotes] = useState('');
  const [payReceiptNum, setPayReceiptNum] = useState('');
  const [payDate, setPayDate] = useState('');
  const [payMethod, setPayMethod] = useState<'كاش' | 'بطاقة' | 'شيك'>('كاش');
  const [paying, setPaying] = useState(false);
  // وميض زر الطباعة بعد تسجيل الدفعة
  const [flashPrint, setFlashPrint] = useState(false);
  const [lastPaidReceipt, setLastPaidReceipt] = useState<Receipt | null>(null);

  // تعديل وصل
  const [editTarget, setEditTarget] = useState<Receipt | null>(null);
  const [editAmount, setEditAmount] = useState('');
  const [editSemesterTarget, setEditSemesterTarget] = useState('');
  const [editNotes, setEditNotes] = useState('');
  const [saving, setSaving] = useState(false);

  // حذف وصل
  const [deleteTarget, setDeleteTarget] = useState<Receipt | null>(null);
  const [deleting, setDeleting] = useState(false);

  // تخفيض الرسوم — التصميم الجديد بشبكة الفصول
  const [showDiscountDialog, setShowDiscountDialog] = useState(false);
  const [applyingDiscount, setApplyingDiscount] = useState(false);
  // تخفيض رسوم التسجيل
  const [discRegAmount, setDiscRegAmount] = useState('');
  const [discRegReason, setDiscRegReason] = useState('');
  // تخفيض الفصول: Record<charge_id OR "virtual-N", {enabled, finalAmount, reason, virtualSem?}>
  const [semChargeDiscounts, setSemChargeDiscounts] = useState<Record<string, { enabled: boolean; finalAmount: string; reason: string; virtualSem?: number }>>({});
  // حفظ كافتراضي — محذوف: التخفيضات خاصة بكل فصل ولا تنتقل عند الترحيل
  // إعدادات الرسوم (مُحمَّلة مع بيانات الطالب)
  const [settings, setSettings] = useState<Record<string, string>>({});

  const openDiscountDialog = () => {
    if (!localStudent) return;
    const regCh = charges.find(c => c.charge_type === 'تسجيل' || c.charge_type === 'معادلة');
    const regAlreadyDiscounted = regCh && (regCh.discount_amount ?? 0) > 0;
    setDiscRegAmount(regAlreadyDiscounted ? '' : (regCh ? String(regCh.charge_amount) : ''));
    setDiscRegReason(regAlreadyDiscounted ? '' : (regCh?.discount_reason ?? ''));

    // قيمة الفصل الأساسية من الإعدادات
    const baseFee = localStudent.diploma_type === 'عالي'
      ? parseFloat(settings[SETTINGS_KEYS.HIGH_DIPLOMA_FEE] ?? '600')
      : parseFloat(settings[SETTINGS_KEYS.MID_DIPLOMA_FEE] ?? '550');

    // بناء شبكة جميع الفصول (1 → maxSem)
    const maxSem = MAX_SEMESTERS[localStudent.diploma_type] ?? 6;
    const initSem: Record<string, { enabled: boolean; finalAmount: string; reason: string; virtualSem?: number }> = {};

    for (let sem = 1; sem <= maxSem; sem++) {
      const existingCharge = charges.find(c => c.charge_type === 'فصلي' && c.semester_number === sem);
      if (existingCharge) {
        // فصل موجود ومقفل (مجدول) — يظهر كـ "مجدول" في القراءة فقط
        if (existingCharge.is_locked) continue;
        // فصل موجود مخفَّض مسبقاً — يظهر في قسم "تم التطبيق"
        if ((existingCharge.discount_amount ?? 0) > 0) continue;
        // فصل قابل للتخفيض
        initSem[existingCharge.id] = { enabled: false, finalAmount: String(existingCharge.charge_amount), reason: '' };
      } else {
        // فصل مستقبلي غير موجود بعد
        initSem[`virtual-${sem}`] = {
          enabled: false, finalAmount: String(baseFee), reason: '', virtualSem: sem,
        };
      }
    }

    // مشروع التخرج إن وُجد ولم يُخفَّض
    const projectCharge = charges.find(c => c.charge_type === 'مشروع تخرج');
    if (projectCharge && !((projectCharge.discount_amount ?? 0) > 0) && !projectCharge.is_locked) {
      initSem[projectCharge.id] = { enabled: false, finalAmount: String(projectCharge.charge_amount), reason: '' };
    }

    setSemChargeDiscounts(initSem);
    setShowDiscountDialog(true);
  };

  const closeDiscountDialog = () => {
    setShowDiscountDialog(false);
    setDiscRegAmount(''); setDiscRegReason('');
    setSemChargeDiscounts({});
  };

  // تصفير رصيد الطالب
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [resetting, setResetting] = useState(false);

  // ترحيل الطالب
  const [showPromoteConfirm, setShowPromoteConfirm] = useState(false);
  const [promoting, setPromoting] = useState(false);
  const [promoteStep, setPromoteStep] = useState<'idle' | 'animating' | 'success'>('idle');
  const [promoteProgress, setPromoteProgress] = useState(0);
  const [promoteStatusText, setPromoteStatusText] = useState('');

  // عداد تنازلي للأرشفة التلقائية
  const [archiveCountdown, setArchiveCountdown] = useState<string | null>(null);
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // احسب الوقت المتبقي حتى الأرشفة التلقائية (24 ساعة من final_paid_at)
  const computeCountdown = useCallback((finalPaidAt: string) => {
    const autoAt = new Date(finalPaidAt).getTime() + 24 * 60 * 60 * 1000;
    const diff = autoAt - Date.now();
    if (diff <= 0) return 'الأرشفة التلقائية متأخرة…';
    const h = Math.floor(diff / 3600000);
    const m = Math.floor((diff % 3600000) / 60000);
    const s = Math.floor((diff % 60000) / 1000);
    return `${h}س ${m}د ${s}ث`;
  }, []);

  const loadDetails = useCallback(async () => {
    if (!student) return;
    setLoadingDetails(true);
    try {
      const studentId = student.id;
      const [r, c, fresh, s] = await Promise.all([
        getReceipts(studentId),
        getSemesterCharges(studentId),
        getStudentById(studentId),
        getSettings(),
      ]);
      setReceipts(r);
      setCharges(c);
      setSettings(s);
      if (fresh) setLocalStudent(fresh);
    } catch (err) {
      console.error('loadDetails error:', err);
      toast.error('خطأ في تحميل بيانات الطالب');
    } finally { setLoadingDetails(false); }
  }, [student]);

  // مزامنة localStudent عند تغيير الطالب المُمرَّر من الوالد
  useEffect(() => { setLocalStudent(student); }, [student]);

  useEffect(() => {
    if (open && student) { loadDetails(); setShowAll(false); }
  }, [open, student, loadDetails]);

  // تشغيل / إيقاف العداد التنازلي حسب final_paid_at
  useEffect(() => {
    if (countdownRef.current) clearInterval(countdownRef.current);
    const fp = localStudent?.final_paid_at;
    if (!fp) { setArchiveCountdown(null); return; }
    setArchiveCountdown(computeCountdown(fp));
    countdownRef.current = setInterval(() => {
      setArchiveCountdown(computeCountdown(fp));
    }, 1000);
    return () => { if (countdownRef.current) clearInterval(countdownRef.current); };
  }, [localStudent?.final_paid_at, computeCountdown]);

  // تأخير قصير لضمان انتشار التغييرات في قاعدة البيانات قبل القراءة
  const loadDetailsWithDelay = useCallback(async (ms = 350) => {
    await new Promise(r => setTimeout(r, ms));
    await loadDetails();
  }, [loadDetails]);

  const handlePay = async () => {
    if (!localStudent) return;
    const amt = parseFloat(payAmount);
    if (!amt || amt <= 0) { toast.error('أدخل مبلغاً صحيحاً'); return; }
    if (!payReceiptNum.trim()) { toast.error('أدخل رقم الإيصال'); return; }
    // ─── التحقق: لا يجوز الدفع أكثر من المبلغ المتبقي ───────────────────────
    const currentDebt = localStudent.total_charged - localStudent.total_paid;
    if (currentDebt > 0 && amt > currentDebt) {
      toast.error(`المبلغ المدخل (${amt} د.ل) يتجاوز المبلغ المتبقي (${currentDebt.toFixed(2)} د.ل)`);
      return;
    }
    setPaying(true);
    try {
      // ─── احفظ حالة رسوم المشروع قبل الدفعة ─────────────────────────────
      const chargesBefore  = await getSemesterCharges(localStudent.id);
      const projectBefore  = chargesBefore.find(c => c.charge_type === 'مشروع تخرج');
      const wasProjectClearedBefore = projectBefore?.is_cleared ?? false;

      const paidAt = payDate ? new Date(payDate).toISOString() : new Date().toISOString();
      const { receipts: recs } = await processPayment({
        studentId: localStudent!.id,
        amount: amt,
        receiptNumber: payReceiptNum.trim(),
        notes: payNotes || undefined,
        paidAt,
        paymentMethod: payMethod,
      });
      const soNum = recs[0]?.supply_order_number;
      toast.success(soNum ? `تم تسجيل دفعة ${amt} د.ل وإصدار أمر توريد #${soNum}` : `تم تسجيل دفعة ${amt} د.ل`);
      setShowPayDialog(false);
      setPayAmount(''); setPayNotes('');
      await loadDetailsWithDelay();
      onDataChange?.();
      // ─── وميض زر الطباعة + طباعة تلقائية ─────────────────────────────────
      const updatedReceipts = await getReceipts(localStudent.id);
      const newest = updatedReceipts.sort((a, b) =>
        new Date(b.paid_at).getTime() - new Date(a.paid_at).getTime()
      )[0] ?? null;
      if (newest) {
        setLastPaidReceipt(newest);
        setFlashPrint(true);
        setTimeout(() => { printReceipt(localStudent, newest); }, 400);
        setTimeout(() => setFlashPrint(false), 3000);
      }
      // ─── فحص اكتمال السداد وتسجيل final_paid_at (لا أرشفة فورية) ─────────
      const updatedCharges = await getSemesterCharges(localStudent.id);
      const { data: freshStudent } = await supabase.from('students').select('*').eq('id', localStudent.id).single();
      if (!freshStudent) { return; }

      const totalDebt = updatedCharges.reduce((sum, c) => {
        const effective = (c.charge_amount ?? 0) - (c.discount_amount ?? 0);
        return sum + Math.max(0, effective - (c.paid_amount ?? 0));
      }, 0);

      const isLastSem  = freshStudent.current_semester >= (MAX_SEMESTERS[freshStudent.diploma_type] ?? 6);
      const isHighProject = freshStudent.diploma_type === 'عالي' && !wasProjectClearedBefore &&
        updatedCharges.find(c => c.charge_type === 'مشروع تخرج')?.is_cleared;
      const isMediumFull  = freshStudent.diploma_type === 'متوسط' && freshStudent.current_semester >= 6;

      // عند اكتمال السداد → سجّل final_paid_at إن لم يكن مسجلاً ليبدأ عداد 24 ساعة
      if (isLastSem && totalDebt <= 0.01 && (isHighProject !== undefined ? isHighProject : isMediumFull)) {
        if (!freshStudent.final_paid_at) {
          await supabase.from('students')
            .update({ final_paid_at: new Date().toISOString() })
            .eq('id', freshStudent.id);
          toast.success(`✅ اكتمل السداد لـ ${freshStudent.full_name} — ستتوفر الأرشفة بعد 24 ساعة`);
          await loadDetailsWithDelay(300);
          onDataChange?.();
        } else {
          toast.info(`✅ السداد مكتمل — الأرشفة متاحة بعد انتهاء فترة الانتظار`);
        }
      } else if (isLastSem && totalDebt > 0.01) {
        toast.info(`✅ تم تسجيل الدفعة — يبقى رصيد ${totalDebt.toFixed(2)} دينار للأرشفة النهائية`);
      }
    } catch { toast.error('فشل تسجيل الدفعة'); }
    finally { setPaying(false); }
  };

  // فتح نافذة الدفع مع تهيئة القيم الافتراضية
  const openPayDialog = async () => {
    if (!localStudent) return;
    setPayAmount(''); setPayNotes('');
    setPayDate(new Date().toISOString().slice(0, 10));
    setPayMethod('كاش');
    try {
      // استخدام معاينة الرقم peekCurrentReceiptNumber فقط لمنع استهلاك العداد قبل السداد الفعلي
      const num = await peekCurrentReceiptNumber(localStudent!.diploma_type);
      setPayReceiptNum(num);
    } catch { setPayReceiptNum(''); }
    setShowPayDialog(true);
  };

  const handleEditSave = async () => {
    if (!editTarget || !student) return;
    const amt = parseFloat(editAmount);
    if (!amt || amt <= 0) { toast.error('أدخل مبلغاً صحيحاً'); return; }
    setSaving(true);
    try {
      await updateReceipt(editTarget.id, {
        amount: amt,
        semester_target: editSemesterTarget.trim() || null,
        notes: editNotes || null,
      });
      await recalculateStudentFinances(localStudent!.id);
      toast.success('تم تعديل الوصل وإعادة احتساب الرصيد');
      setEditTarget(null);
      await loadDetailsWithDelay();
      onDataChange?.();
    } catch { toast.error('فشل تعديل الوصل'); }
    finally { setSaving(false); }
  };

  const handleDeleteConfirm = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await deleteReceipt(deleteTarget.id);
      toast.success(`تم حذف الوصل #${deleteTarget.receipt_number}`);
      setDeleteTarget(null);
      await loadDetailsWithDelay();
      onDataChange?.();
    } catch { toast.error('فشل حذف الوصل'); }
    finally { setDeleting(false); }
  };

  const handleResetBalance = async () => {
    if (!localStudent) return;
    setResetting(true);
    try {
      await resetStudentBalance(localStudent!.id);
      toast.success(`تم تصفير رصيد ${localStudent!.full_name} بنجاح`);
      setShowResetConfirm(false);
      await loadDetailsWithDelay(500);
      onDataChange?.();
    } catch { toast.error('فشل تصفير الرصيد'); }
    finally { setResetting(false); }
  };

  const handlePromote = async () => {
    if (!localStudent) return;
    setPromoting(true);
    try {
      const studentMaxSem = MAX_SEMESTERS[localStudent.diploma_type] ?? 6;
      // أعلى فصل فصلي مسجل أو مسدد بالكامل
      const maxSemesterWithCharge = charges
        .filter(c => c.charge_type === 'فصلي')
        .reduce((max, c) => Math.max(max, c.semester_number), 0);
      const activeSem = Math.max(localStudent.current_semester, maxSemesterWithCharge, 1);
      const targetSem = activeSem + 1;
      const atFinal = activeSem >= studentMaxSem;

      if (atFinal) {
        // ── فحص: لا أرشفة إلا بسداد جميع الأقساط ───────────────────────────
        const latestCharges = await getSemesterCharges(localStudent.id);
        const totalDebt = latestCharges.reduce((sum, c) => {
          const effective = (c.charge_amount ?? 0) - (c.discount_amount ?? 0);
          return sum + Math.max(0, effective - (c.paid_amount ?? 0));
        }, 0);
        if (totalDebt > 0.01) {
          toast.error(`لا يمكن الأرشفة — يوجد رصيد متبقٍ: ${totalDebt.toFixed(2)} دينار. يجب سداد جميع الأقساط أولاً`);
          return;
        }
        setPromoteStep('animating');
        setPromoteProgress(25);
        setPromoteStatusText('فحص براءة الذمة واستيفاء متطلبات التخرج...');
        await new Promise(r => setTimeout(r, 450));
        setPromoteProgress(65);
        setPromoteStatusText('نقل الطالب إلى سجل الخريجين والأرشفة...');
        const { data: freshForArchive } = await supabase
          .from('students').select('*').eq('id', localStudent.id).single();
        await archiveStudent(freshForArchive ?? localStudent);
        setPromoteProgress(100);
        setPromoteStatusText('اكتملت أرشفة الخريج بنجاح!');
        await new Promise(r => setTimeout(r, 350));
        setPromoteStep('success');
        toast.success(`🎓 تهانينا! تمت أرشفة ${localStudent.full_name} كخريج بنجاح`);
      } else {
        // ترحيل للفصل التالي مع حركة بصرية احترافية
        setPromoteStep('animating');
        setPromoteProgress(25);
        setPromoteStatusText(`التحقق من براءة ذمة ${SEMESTER_LABELS[activeSem] ?? `الفصل ${activeSem}`} ومطابقة الرسوم...`);
        await new Promise(r => setTimeout(r, 450));

        setPromoteProgress(65);
        setPromoteStatusText(`نقل السجل إلى ${SEMESTER_LABELS[targetSem] ?? `الفصل ${targetSem}`} واعتماد مستحقات الفصل...`);
        const settings = await getSettings();
        await promoteStudent(localStudent, settings, targetSem);

        setPromoteProgress(100);
        setPromoteStatusText(`اكتمل الترحيل بنجاح إلى ${SEMESTER_LABELS[targetSem] ?? `الفصل ${targetSem}`}!`);
        await new Promise(r => setTimeout(r, 350));
        setPromoteStep('success');
        toast.success(`تم ترحيل ${localStudent.full_name} إلى ${SEMESTER_LABELS[targetSem] ?? `الفصل ${targetSem}`} بنجاح`);
      }

      await loadDetailsWithDelay(500);
      onDataChange?.();
    } catch (err: any) {
      toast.error(err?.message ?? (isAtFinalSemester ? 'فشلت أرشفة الطالب' : 'فشل ترحيل الطالب'));
      setPromoteStep('idle');
    } finally {
      setPromoting(false);
    }
  };

  const handleApplyDiscount = async () => {
    if (!localStudent) return;
    const hasReg = discRegAmount !== '';
    const enabledSems = Object.entries(semChargeDiscounts).filter(([, v]) => v.enabled);
    if (!hasReg && enabledSems.length === 0) { toast.error('لم تُفعِّل أي تخفيض'); return; }
    setApplyingDiscount(true);
    try {
      const baseFee = localStudent.diploma_type === 'عالي'
        ? parseFloat(settings[SETTINGS_KEYS.HIGH_DIPLOMA_FEE] ?? '600')
        : parseFloat(settings[SETTINGS_KEYS.MID_DIPLOMA_FEE] ?? '550');

      // تخفيض رسوم التسجيل
      if (hasReg) {
        const regCh = charges.find(c => c.charge_type === 'تسجيل' || c.charge_type === 'معادلة');
        if (regCh) {
          const finalAmt = Math.max(0, Math.min(parseFloat(discRegAmount) || 0, regCh.charge_amount));
          await applyDiscount(regCh.id, localStudent.id, regCh.charge_amount - finalAmt, discRegReason.trim());
        }
      }
      // تخفيض كل فصل مُفعَّل
      for (const [id, entry] of enabledSems) {
        const isVirtual = id.startsWith('virtual-');
        if (isVirtual) {
          // فصل مستقبلي — أنشئ قيداً مسبقاً بـ is_locked=true مع التخفيض
          const sem = entry.virtualSem!;
          const finalAmt = Math.max(0, Math.min(parseFloat(entry.finalAmount) || 0, baseFee));
          const discAmt = baseFee - finalAmt;
          await createSemesterCharge({
            student_id: localStudent.id,
            semester_number: sem,
            charge_amount: baseFee,
            paid_amount: 0,
            charge_type: 'فصلي',
            is_cleared: false,
            is_locked: true,
            ...(discAmt > 0 ? { discount_amount: discAmt, discount_reason: entry.reason.trim() || null } : {}),
          } as Parameters<typeof createSemesterCharge>[0]);
        } else {
          // فصل موجود — طبّق التخفيض مباشرة
          const ch = charges.find(c => c.id === id);
          if (!ch) continue;
          const finalAmt = Math.max(0, Math.min(parseFloat(entry.finalAmount) || 0, ch.charge_amount));
          await applyDiscount(id, localStudent.id, ch.charge_amount - finalAmt, entry.reason.trim());
        }
      }
      toast.success('تم تطبيق التخفيضات بنجاح');
      closeDiscountDialog();
      await loadDetailsWithDelay(400);
      onDataChange?.();
    } catch (e) { console.error(e); toast.error('فشل تطبيق التخفيض'); }
    finally { setApplyingDiscount(false); }
  };

  if (!localStudent) return null;
  // استخدام النسخة المحلية المُحدَّثة طوال دورة الرسم
  const st = localStudent;

  const debt = st.total_charged - st.total_paid;
  // تحديد الفصل الدراسي الفعلي: أعلى فصل مسجل أو مدفوع للطالب
  const maxSemesterWithCharge = charges
    .filter(c => c.charge_type === 'فصلي')
    .reduce((max, c) => Math.max(max, c.semester_number), 0);
  const currentSemesterNum = Math.max(st.current_semester, maxSemesterWithCharge, 1);
  const nextSemesterNum = currentSemesterNum + 1;

  const currentSemesterCharges = charges.filter(c => c.semester_number === currentSemesterNum);
  // الإجمالي الفعلي للفصل = الأصلي − التخفيض
  const semesterTotal = currentSemesterCharges.reduce((s, c) => s + (c.charge_amount - (c.discount_amount ?? 0)), 0);
  const semesterPaid  = currentSemesterCharges.reduce((s, c) => s + c.paid_amount, 0);
  const semesterDebt  = semesterTotal - semesterPaid;
  const paidPct = semesterTotal > 0 ? Math.min(100, Math.round((semesterPaid / semesterTotal) * 100)) : 0;

  // مؤهل للترحيل: رسوم التسجيل + رسوم الفصل الحالي مسددة بالكامل
  const registrationCharges = charges.filter(c => c.semester_number === -1);
  const registrationCleared = registrationCharges.length === 0 || registrationCharges.every(c => c.is_cleared);
  const currentSemesterCleared = currentSemesterCharges.length > 0 && currentSemesterCharges.every(c => c.is_cleared);
  const isEligibleForPromotion = registrationCleared && currentSemesterCleared;

  // هل الطالب في الفصل النهائي؟ → عند الضغط على "ترحيل" سيُؤرشَف بدلاً من الترحيل
  const maxSem = MAX_SEMESTERS[st.diploma_type] ?? 6;
  const isAtFinalSemester = currentSemesterNum >= maxSem;
  // مؤهل للأرشفة: الفصل النهائي + بدون ديون + جميع رسوم الفصل مسددة
  const isEligibleForArchive = isAtFinalSemester && debt <= 0 && isEligibleForPromotion;

  // تجميع الأقساط بالفصول
  const grouped = new Map<number, SemesterCharge[]>();
  for (const ch of charges) {
    if (!grouped.has(ch.semester_number)) grouped.set(ch.semester_number, []);
    grouped.get(ch.semester_number)!.push(ch);
  }
  const sortedSemesters = [...grouped.entries()].sort(([a], [b]) => a - b);

  // ترتيب الإيصالات: تسجيل → فصل 1 → فصل 2 → ... → فصل 6
  const sortedReceipts = [...receipts].sort(compareReceipts);
  const displayedReceipts = showAll ? sortedReceipts : sortedReceipts.slice(0, 5);

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent
          className="max-w-[calc(100%-1rem)] md:max-w-2xl lg:max-w-3xl max-h-[92dvh] overflow-y-auto p-0 [&>button]:hidden"
          dir="rtl"
        >
          {/* ── رأس النافذة ── */}
          <div className="relative rounded-t-xl overflow-hidden shrink-0">
            <div className="absolute inset-0 bg-gradient-to-br from-[#1a3c5e]/95 via-[#1a3c5e]/85 to-blue-700/75" />
            <div className="absolute inset-0 opacity-[0.06]"
              style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '24px 24px' }} />
            <div className="relative px-5 py-4 flex items-start gap-4">
              {/* أفاتار */}
              <StudentAvatar
                photoUrl={st.photo_url}
                name={st.full_name}
                size="lg"
                variant="rounded"
              />
              {/* بيانات رئيسية */}
              <div className="flex-1 min-w-0 text-white">
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="text-base md:text-lg font-bold text-white text-balance">{st.full_name}</h2>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border shrink-0 ${
                    st.status === 'نشط'
                      ? 'bg-emerald-500/25 text-emerald-100 border-emerald-400/30'
                      : 'bg-amber-500/25 text-amber-100 border-amber-400/30'
                  }`}>{st.status}</span>
                </div>
                <p className="font-mono text-[12px] text-white/60 mt-0.5">{st.national_id}</p>
                <div className="flex flex-wrap gap-x-3 gap-y-0.5 mt-1.5">
                  <span className="text-[11px] text-white/75 flex items-center gap-1">
                    <GraduationCap className="w-3 h-3" />{st.diploma_type} — {st.specialization}
                  </span>
                  <span className="text-[11px] text-white/75 flex items-center gap-1">
                    <BookOpen className="w-3 h-3" />{SEMESTER_LABELS[st.current_semester] ?? `الفصل ${st.current_semester}`}
                  </span>
                  {/* شارة نوع الطالب */}
                  <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full border ${
                    st.is_exam_only
                      ? 'bg-purple-500/25 text-purple-100 border-purple-400/40'
                      : 'bg-sky-500/20 text-sky-100 border-sky-400/30'
                  }`}>
                    {st.is_exam_only ? 'طالب 100' : 'نظامي'}
                  </span>
                  {st.phone && (
                    <span className="text-[11px] text-white/75 flex items-center gap-1">
                      <Phone className="w-3 h-3" />{st.phone}
                    </span>
                  )}
                </div>
                {/* مؤشر مالي */}
                <div className={`mt-2 inline-flex items-center gap-1.5 text-[10px] px-2 py-0.5 rounded-full border ${
                  debt > 0 ? 'bg-red-500/20 border-red-300/25 text-red-100' : 'bg-emerald-500/20 border-emerald-300/25 text-emerald-100'
                }`}>
                  {debt > 0 ? <AlertTriangle className="w-2.5 h-2.5" /> : <CheckCircle2 className="w-2.5 h-2.5" />}
                  {debt > 0 ? `مديونية: ${debt.toFixed(0)} د.ل` : 'الحساب مسدد بالكامل'}
                </div>
              </div>
              {/* أزرار رأس */}
              <div className="flex items-center gap-1.5 shrink-0">
                {st.phone && (
                  <a href={`https://wa.me/218${st.phone.replace(/^(\+218|00218|0)/, '')}`} target="_blank" rel="noreferrer"
                    className="w-8 h-8 rounded-lg bg-white/15 border border-white/20 flex items-center justify-center hover:bg-white/25 transition-colors"
                    title="واتساب">
                    <MessageCircle className="w-4 h-4 text-white" />
                  </a>
                )}
                <button onClick={() => onOpenChange(false)}
                  className="w-8 h-8 rounded-lg bg-white/15 border border-white/20 flex items-center justify-center hover:bg-white/25 transition-colors">
                  <X className="w-4 h-4 text-white" />
                </button>
              </div>
            </div>
          </div>

          {/* ── محتوى النافذة ── */}
          <div className="px-4 pb-5 pt-4 space-y-4">

            {loadingDetails ? (
              <div className="space-y-2">{Array(4).fill(0).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}</div>
            ) : (
              <>
                {/* ── البيانات الشخصية والأكاديمية ── */}
                <div className="bg-card border border-border/50 rounded-xl p-3.5">
                  <h3 className="text-[11px] font-bold text-muted-foreground uppercase tracking-wide mb-3">البيانات الشخصية والأكاديمية</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6">
                    <div className="space-y-1">
                      <Row label="نوع الدبلوم" value={st.diploma_type} />
                      <Row label="التخصص" value={st.specialization} />
                      <Row label="الفصل الحالي" value={SEMESTER_LABELS[st.current_semester] ?? `الفصل ${st.current_semester}`} />
                      <div className="flex items-start justify-between gap-2 py-1 border-b border-border/30">
                        <span className="text-[11px] text-muted-foreground shrink-0">نوع الطالب</span>
                        <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full border ${
                          st.is_exam_only
                            ? 'bg-purple-100 text-purple-700 border-purple-300'
                            : 'bg-sky-100 text-sky-700 border-sky-300'
                        }`}>
                          {st.is_exam_only ? 'طالب 100' : 'نظامي'}
                        </span>
                      </div>
                      {st.phone && <Row label="رقم الهاتف" value={st.phone} />}
                      <Row label="الجنسية" value={st.nationality || 'ليبي'} />
                    </div>
                    <div className="space-y-1">
                      {st.address && <Row label="العنوان" value={st.address} />}
                      <Row label="تاريخ التسجيل" value={st.created_at ? new Date(st.created_at).toLocaleDateString('ar-LY') : '—'} />
                      {/* موقف الأوراق */}
                      <div className="flex items-start justify-between gap-2 py-1 border-b border-border/30">
                        <span className="text-[11px] text-muted-foreground shrink-0">موقف الأوراق الثبوتية</span>
                        <div className="flex flex-col items-end gap-0.5">
                          {st.has_birth_certificate && <span className="text-[10px] text-chart-2">✓ شهادة الميلاد</span>}
                          {st.has_registration_certificate && <span className="text-[10px] text-chart-2">✓ شهادة التسجيل</span>}
                          <span className="text-[10px] text-foreground/70">الصور ({st.photos_received}/{st.photos_required})</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* ── الملخص المالي للفصل الحالي ── */}
                <div className="bg-card border border-border/50 rounded-xl p-3.5">
                  <h3 className="text-[11px] font-bold text-muted-foreground uppercase tracking-wide mb-3">
                    الملخص المالي — {SEMESTER_LABELS[st.current_semester] ?? `الفصل ${st.current_semester}`}
                  </h3>
                  <div className="grid grid-cols-3 gap-2 mb-3">
                    <div className="text-center p-2 bg-muted/30 rounded-lg border border-border/40">
                      <p className="text-[10px] text-muted-foreground">إجمالي الرسوم</p>
                      <p className="text-base font-black text-foreground">{semesterTotal.toFixed(0)}</p>
                      <p className="text-[9px] text-muted-foreground">د.ل</p>
                    </div>
                    <div className="text-center p-2 bg-chart-2/8 rounded-lg border border-chart-2/20">
                      <p className="text-[10px] text-muted-foreground">المدفوع</p>
                      <p className="text-base font-black text-chart-2">{semesterPaid.toFixed(0)}</p>
                      <p className="text-[9px] text-chart-2/60">د.ل</p>
                    </div>
                    <div className={`text-center p-2 rounded-lg border ${semesterDebt > 0 ? 'bg-destructive/8 border-destructive/20' : 'bg-chart-2/8 border-chart-2/20'}`}>
                      <p className="text-[10px] text-muted-foreground">المتبقي</p>
                      <p className={`text-base font-black ${semesterDebt > 0 ? 'text-destructive' : 'text-chart-2'}`}>
                        {semesterDebt > 0 ? semesterDebt.toFixed(0) : '0'}
                      </p>
                      <p className="text-[9px] text-muted-foreground">د.ل</p>
                    </div>
                  </div>
                  {/* شريط التقدم */}
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-2 bg-muted/50 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${paidPct >= 100 ? 'bg-chart-2' : paidPct >= 60 ? 'bg-primary' : paidPct >= 30 ? 'bg-amber-500' : 'bg-destructive'}`}
                        style={{ width: `${paidPct}%` }}
                      />
                    </div>
                    <span className="text-[11px] font-bold text-muted-foreground shrink-0">نسبة السداد {paidPct}%</span>
                  </div>
                </div>

                {/* ── تفاصيل الأقساط بالفصول ── */}
                {sortedSemesters.length > 0 && (
                  <div className="bg-card border border-border/50 rounded-xl p-3.5">
                    <h3 className="text-[11px] font-bold text-muted-foreground uppercase tracking-wide mb-3">تفاصيل الأقساط بالفصل</h3>
                    <div className="space-y-2">
                      {sortedSemesters.map(([sem, chs]) => (
                        <SemesterSection
                          key={sem}
                          label={sem === -1 ? 'رسوم التسجيل' : SEMESTER_LABELS[sem] ?? `الفصل ${sem}`}
                          charges={chs}
                        />
                      ))}
                    </div>
                    {charges.every(c => c.is_cleared) && (
                      <div className="mt-3 text-center py-2 bg-chart-2/8 rounded-lg border border-chart-2/20">
                        <p className="text-[11px] text-chart-2 font-bold flex items-center justify-center gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          تمت تسوية جميع أقساط {SEMESTER_LABELS[st.current_semester] ?? `الفصل ${st.current_semester}`} بالكامل
                        </p>
                      </div>
                    )}
                  </div>
                )}

                {/* ── سجل الوصلات ── */}
                {receipts.length > 0 && (
                  <div className="bg-card border border-border/50 rounded-xl overflow-hidden">
                    <div className="flex items-center gap-2 px-3.5 py-2.5 border-b border-border/40">
                      <ReceiptIcon className="w-3.5 h-3.5 text-chart-2 shrink-0" />
                      <p className="text-[11px] font-bold">سجل الواصلات ({receipts.length})</p>
                      <div className="mr-auto flex items-center gap-2">
                        {receipts.length > 5 && (
                          <button onClick={() => setShowAll(v => !v)}
                            className="text-[10px] font-bold text-primary hover:underline">
                            {showAll ? 'إخفاء' : `عرض الكل (${receipts.length})`}
                          </button>
                        )}
                        {sortedReceipts[0] && (
                          <button onClick={() => printReceipt(st, sortedReceipts[0])}
                            className="inline-flex items-center gap-1 h-6 px-2 rounded-lg text-[10px] font-bold bg-muted border border-border/40 text-muted-foreground hover:bg-muted/80 transition-colors">
                            <Printer className="w-2.5 h-2.5" /> طباعة الكل
                          </button>
                        )}
                      </div>
                    </div>
                    <div className="divide-y divide-border/30">
                      {displayedReceipts.map(r => (
                        <div key={r.id} className="flex items-start gap-3 px-3.5 py-3 hover:bg-muted/15 transition-colors">
                          {/* أيقونة الوصل */}
                          <div className="w-9 h-9 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0 mt-0.5">
                            <ReceiptIcon className="w-4 h-4 text-primary" />
                          </div>
                          {/* بيانات الوصل */}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-mono text-[13px] font-black text-primary">#{r.receipt_number}</span>
                              <span className="text-[11px] text-muted-foreground/70 bg-muted/40 px-1.5 py-0.5 rounded-md border border-border/30">{r.payment_type}</span>
                              {r.supply_order_number && (
                                <span className="text-[11px] font-bold text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-700/50 px-1.5 py-0.5 rounded-md flex items-center gap-1">
                                  <ClipboardList className="w-3 h-3" />
                                  <span>أمر توريد #{r.supply_order_number}</span>
                                </span>
                              )}
                            </div>
                            {r.semester_target && (
                              <p className="text-[12px] text-foreground/80 font-medium mt-1 leading-snug">{r.semester_target}</p>
                            )}
                            <p className="text-[11px] text-muted-foreground mt-0.5">
                              {new Date(r.paid_at).toLocaleDateString('ar-LY', { day: 'numeric', month: 'long', year: 'numeric' })}
                            </p>
                            {r.notes && (
                              r.notes.startsWith('تخفيض:')
                                ? <p className="text-[10px] font-semibold text-blue-600 bg-blue-50 dark:bg-blue-950/40 dark:text-blue-400 border border-blue-200 dark:border-blue-800/50 px-1.5 py-0.5 rounded-md mt-1 inline-block">
                                    🔵 {r.notes}
                                  </p>
                                : <p className="text-[10px] text-muted-foreground/60 mt-0.5 italic">{r.notes}</p>
                            )}
                          </div>
                          {/* المبلغ والأزرار */}
                          <div className="flex flex-col items-end gap-2 shrink-0">
                            <span className="text-base font-black text-chart-2 font-mono leading-none">
                              {r.amount.toFixed(0)}<span className="text-[10px] font-normal text-chart-2/60 mr-0.5">د.ل</span>
                            </span>
                            <div className="flex items-center gap-1">
                              {r.supply_order_number && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    printSupplyOrder({
                                      ...r,
                                      student_name: st.full_name,
                                      student_national_id: st.national_id,
                                      student_diploma: st.diploma_type,
                                      student_specialization: st.specialization,
                                      student_phone: st.phone,
                                      payment_method: r.payment_method ?? 'كاش',
                                    } as FullReceipt);
                                  }}
                                  title={`طباعة أمر التوريد #${r.supply_order_number}`}
                                  className="inline-flex items-center justify-center h-7 px-2 rounded-lg text-[10px] font-bold bg-amber-500/10 text-amber-700 dark:text-amber-300 hover:bg-amber-500 hover:text-white transition-all border border-amber-400/25 gap-1">
                                  <ClipboardList className="w-3.5 h-3.5" />
                                  <span className="hidden sm:inline">أمر #{r.supply_order_number}</span>
                                </button>
                              )}
                              <button onClick={() => printReceipt(st, r)}
                                title="طباعة"
                                className={`inline-flex items-center justify-center w-7 h-7 rounded-lg transition-all border ${
                                  flashPrint && lastPaidReceipt?.id === r.id
                                    ? 'bg-emerald-500 text-white border-emerald-400 animate-pulse shadow-lg shadow-emerald-500/40 scale-110'
                                    : 'bg-slate-500/10 text-slate-600 hover:bg-slate-600 hover:text-white border-slate-400/20'
                                }`}>
                                <Printer className="w-3.5 h-3.5" />
                              </button>
                              <button
                                title="تعديل"
                                onClick={() => { setEditTarget(r); setEditAmount(r.amount.toString()); setEditSemesterTarget(r.semester_target ?? ''); setEditNotes(r.notes ?? ''); }}
                                className="inline-flex items-center justify-center w-7 h-7 rounded-lg bg-amber-500/10 text-amber-600 hover:bg-amber-500 hover:text-white transition-all border border-amber-400/25">
                                <Pencil className="w-3.5 h-3.5" />
                              </button>
                              <button
                                title="حذف"
                                onClick={() => setDeleteTarget(r)}
                                className="inline-flex items-center justify-center w-7 h-7 rounded-lg bg-destructive/10 text-destructive hover:bg-destructive hover:text-white transition-all border border-destructive/25">
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                    {charges.every(c => c.is_cleared) && (
                      <div className="px-3.5 py-2 bg-chart-2/5 border-t border-chart-2/15 text-center">
                        <p className="text-[10px] text-chart-2 font-semibold">تم سداد جميع الأقساط حتى {SEMESTER_LABELS[st.current_semester] ?? `الفصل ${st.current_semester}`} بالكامل</p>
                      </div>
                    )}
                  </div>
                )}

                {/* ── أزرار الإجراءات ── */}
                <div className="pt-3 border-t border-border/50 mt-1 space-y-2">
                  {/* الصف الأول: الإجراءات الأساسية */}
                  <div className="grid grid-cols-3 gap-2">
                    {/* تسجيل دفعة — رمادي معطّل عند الصفر، ذهبي-أخضر نابض عند وجود دين */}
                    <motion.button
                      onClick={debt > 0 ? openPayDialog : undefined}
                      disabled={debt <= 0}
                      whileTap={debt > 0 ? { scale: 0.92 } : {}}
                      whileHover={debt > 0 ? { y: -2 } : {}}
                      transition={{ type: 'spring', stiffness: 400, damping: 20 }}
                      className={`group relative overflow-hidden flex flex-col items-center justify-center gap-1 py-2.5 px-2 rounded-2xl font-bold text-[11px] shadow-lg
                        ${debt > 0
                          ? 'text-white shadow-emerald-500/30 animate-pay-pulse cursor-pointer'
                          : 'text-slate-400 shadow-none cursor-not-allowed opacity-60'
                        }`}
                      style={{
                        background: debt > 0
                          ? 'linear-gradient(135deg, #10b981 0%, #059669 50%, #047857 100%)'
                          : 'linear-gradient(135deg, #94a3b8 0%, #64748b 50%, #475569 100%)',
                      }}
                    >
                      {/* طبقة hover فقط عند وجود دين */}
                      {debt > 0 && (
                        <div className="absolute inset-0 bg-white/0 group-hover:bg-white/10 transition-all duration-300 rounded-2xl" />
                      )}
                      {/* حلقة ping خارجية عند المديونية */}
                      {debt > 0 && (
                        <span className="absolute inset-0 rounded-2xl border-2 border-emerald-300/60 animate-ping pointer-events-none" style={{ animationDuration: '1.8s' }} />
                      )}
                      <div className={`relative w-8 h-8 rounded-xl flex items-center justify-center mb-0.5 transition-transform duration-300
                        ${debt > 0 ? 'bg-white/20 group-hover:scale-110' : 'bg-white/10'}`}>
                        {debt > 0
                          ? <Plus className="w-4 h-4 text-white" />
                          : <CheckCheck className="w-4 h-4 text-slate-300" />
                        }
                      </div>
                      <span className="relative">{debt > 0 ? 'تسجيل دفعة' : 'مسدد بالكامل'}</span>
                      {debt > 0 && (
                        <span className="relative text-[9px] font-semibold text-emerald-100/80 -mt-0.5">{debt.toFixed(0)} د.ل</span>
                      )}
                    </motion.button>

                    {/* ترحيل / أرشفة */}
                    {(currentSemesterNum < maxSem || isAtFinalSemester) ? (
                      <div className="flex flex-col items-center gap-1">
                        <motion.button
                          onClick={() => {
                            setPromoteStep('idle');
                            setPromoteProgress(0);
                            setPromoteStatusText('');
                            setShowPromoteConfirm(true);
                          }}
                          whileTap={{ scale: 0.92 }}
                          whileHover={{ y: -2 }}
                          transition={{ type: 'spring', stiffness: 400, damping: 20 }}
                          className={`group relative overflow-hidden w-full flex flex-col items-center justify-center gap-1 py-2.5 px-2 rounded-2xl text-white font-bold text-[11px] shadow-lg
                            ${isAtFinalSemester
                              ? isEligibleForArchive
                                ? 'shadow-emerald-600/40 animate-archive-pulse'
                                : 'shadow-emerald-600/20'
                              : isEligibleForPromotion
                                ? 'shadow-blue-500/30 animate-promote-pulse'
                                : 'shadow-blue-500/20'
                            }`}
                          style={{
                            background: isAtFinalSemester
                              ? 'linear-gradient(135deg, #059669 0%, #047857 50%, #065f46 100%)'
                              : 'linear-gradient(135deg, #3b82f6 0%, #2563eb 50%, #1d4ed8 100%)'
                          }}>
                          <div className="absolute inset-0 bg-white/0 group-hover:bg-white/10 transition-all duration-300 rounded-2xl" />

                          {/* حلقات ping متعددة عند الأهلية للأرشفة */}
                          {isEligibleForArchive && (
                            <>
                              <span className="absolute inset-0 rounded-2xl border-2 border-emerald-300/60 pointer-events-none animate-ping" style={{ animationDuration: '1.4s' }} />
                              <span className="absolute inset-[-4px] rounded-2xl border border-emerald-400/30 pointer-events-none animate-ping" style={{ animationDuration: '2s', animationDelay: '0.4s' }} />
                            </>
                          )}
                          {/* حلقة واحدة للترحيل */}
                          {!isAtFinalSemester && isEligibleForPromotion && (
                            <span className="absolute inset-0 rounded-2xl border-2 border-blue-300/50 pointer-events-none animate-ping" style={{ animationDuration: '2s' }} />
                          )}

                          <div className="relative w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center mb-0.5 group-hover:scale-110 transition-transform duration-300">
                            {isAtFinalSemester ? <Archive className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
                          </div>
                          <span className="relative">{isAtFinalSemester ? 'أرشفة' : 'ترحيل'}</span>

                          {/* عداد تنازلي صغير داخل الزر عند وجود final_paid_at */}
                          {isAtFinalSemester && st.final_paid_at && archiveCountdown && (
                            <span className="relative text-[8px] font-mono text-emerald-100/80 -mt-0.5 tabular-nums leading-none">
                              {archiveCountdown}
                            </span>
                          )}
                        </motion.button>

                        {/* شارة الحالة أسفل الزر */}
                        {isAtFinalSemester && st.final_paid_at ? (
                          <span className="inline-flex items-center gap-0.5 text-[9px] font-semibold text-emerald-600 dark:text-emerald-400">
                            <CheckCircle2 className="w-2.5 h-2.5" />
                            جاهز للأرشفة
                          </span>
                        ) : (isEligibleForArchive || isEligibleForPromotion) ? (
                          <span className="inline-flex items-center gap-0.5 text-[9px] font-semibold text-emerald-600 dark:text-emerald-400">
                            <CheckCircle2 className="w-2.5 h-2.5" />
                            {isAtFinalSemester ? 'مؤهل للتخرج' : `→ ${SEMESTER_LABELS[st.current_semester + 1] ?? `الفصل ${st.current_semester + 1}`}`}
                          </span>
                        ) : null}
                      </div>
                    ) : (
                      <div /> /* فراغ إذا لا يوجد ترحيل */
                    )}

                    {/* الملف الكامل */}
                    <motion.button
                      onClick={() => { onOpenChange(false); navigate(`/student/${st.id}`); }}
                      whileTap={{ scale: 0.92 }}
                      whileHover={{ y: -2 }}
                      transition={{ type: 'spring', stiffness: 400, damping: 20 }}
                      className="group relative overflow-hidden flex flex-col items-center justify-center gap-1 py-2.5 px-2 rounded-2xl text-white font-bold text-[11px] shadow-lg shadow-primary/25"
                      style={{ background: 'linear-gradient(135deg, hsl(var(--primary) / 0.9) 0%, hsl(var(--primary)) 100%)' }}>
                      <div className="absolute inset-0 bg-white/0 group-hover:bg-white/10 transition-all duration-300 rounded-2xl" />
                      <div className="relative w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center mb-0.5 group-hover:scale-110 transition-transform duration-300">
                        <ExternalLink className="w-4 h-4" />
                      </div>
                      <span className="relative">الملف الكامل</span>
                    </motion.button>
                  </div>

                  {/* الصف الثاني: إجراءات ثانوية */}
                  <div className="grid grid-cols-2 gap-2">
                    {/* تخفيض الرسوم */}
                    <motion.button
                      onClick={openDiscountDialog}
                      whileTap={{ scale: 0.92 }}
                      whileHover={{ y: -2 }}
                      transition={{ type: 'spring', stiffness: 400, damping: 20 }}
                      className="group relative overflow-hidden flex flex-col items-center justify-center gap-1 py-2.5 px-2 rounded-2xl font-bold text-[11px] shadow-md shadow-amber-400/25"
                      style={{ background: 'linear-gradient(135deg, #f59e0b 0%, #d97706 50%, #b45309 100%)' }}>
                      <div className="absolute inset-0 bg-white/0 group-hover:bg-white/10 transition-all duration-300 rounded-2xl" />
                      <div className="absolute -bottom-3 -left-3 w-12 h-12 rounded-full bg-white/10 blur-xl group-hover:w-16 group-hover:h-16 transition-all duration-500" />
                      <div className="relative w-7 h-7 rounded-xl bg-white/20 flex items-center justify-center mb-0.5 group-hover:scale-110 group-hover:rotate-[-8deg] transition-transform duration-300">
                        <Scissors className="w-3.5 h-3.5 text-white" />
                      </div>
                      <span className="relative text-white">تخفيض الرسوم</span>
                    </motion.button>

                    {/* تصفير الرصيد */}
                    <motion.button
                      onClick={() => setShowResetConfirm(true)}
                      whileTap={{ scale: 0.92 }}
                      whileHover={{ y: -2 }}
                      transition={{ type: 'spring', stiffness: 400, damping: 20 }}
                      className="group relative overflow-hidden flex flex-col items-center justify-center gap-1 py-2.5 px-2 rounded-2xl font-bold text-[11px] shadow-md shadow-rose-500/20"
                      style={{ background: 'linear-gradient(135deg, #f43f5e 0%, #e11d48 50%, #be123c 100%)' }}>
                      <div className="absolute inset-0 bg-white/0 group-hover:bg-white/10 transition-all duration-300 rounded-2xl" />
                      <div className="absolute -bottom-3 -right-3 w-12 h-12 rounded-full bg-white/10 blur-xl group-hover:w-16 group-hover:h-16 transition-all duration-500" />
                      <div className="relative w-7 h-7 rounded-xl bg-white/20 flex items-center justify-center mb-0.5 group-hover:scale-110 transition-transform duration-300">
                        <RotateCcw className="w-3.5 h-3.5 text-white group-hover:rotate-180 transition-transform duration-500" />
                      </div>
                      <span className="relative text-white">تصفير الرصيد</span>
                    </motion.button>
                  </div>
                </div>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* ── نافذة تخفيض الرسوم ── */}
      <Dialog open={showDiscountDialog} onOpenChange={o => { if (!o) closeDiscountDialog(); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg p-0 overflow-hidden [&>button]:hidden" dir="rtl">
          <DialogTitle className="sr-only">تخفيض الرسوم</DialogTitle>
          {/* رأس */}
          <div className="relative bg-gradient-to-br from-amber-600 via-amber-500 to-orange-500 px-5 py-4">
            <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '20px 20px' }} />
            <div className="relative flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-white">تخفيض الرسوم</h3>
                <p className="text-[11px] text-white/70 mt-0.5">{localStudent?.full_name}</p>
              </div>
              <button onClick={closeDiscountDialog} className="w-8 h-8 rounded-lg bg-white/15 border border-white/20 flex items-center justify-center hover:bg-white/25 transition-colors">
                <X className="w-4 h-4 text-white" />
              </button>
            </div>
          </div>

          {/* جسم النافذة */}
          <div className="max-h-[72vh] overflow-y-auto">
            <div className="p-5 space-y-5">

              {/* ── رسوم التسجيل ── */}
              {(() => {
                const regCh = charges.find(c => c.charge_type === 'تسجيل' || c.charge_type === 'معادلة');
                if (!regCh) return null;
                const alreadyDiscounted = (regCh.discount_amount ?? 0) > 0;
                if (alreadyDiscounted) {
                  const effective = regCh.charge_amount - (regCh.discount_amount ?? 0);
                  return (
                    <div className="rounded-xl border border-chart-2/30 bg-chart-2/5 p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <FileText className="w-4 h-4 text-chart-2 shrink-0" />
                          <span className="text-sm font-semibold text-chart-2">رسوم التسجيل</span>
                        </div>
                        <span className="text-xs font-medium text-chart-2 bg-chart-2/10 border border-chart-2/20 px-2 py-0.5 rounded-full">مُطبَّق</span>
                      </div>
                      <div className="flex items-center gap-3 mt-2 text-sm font-mono">
                        <span className="line-through text-muted-foreground">{regCh.charge_amount} د.ل</span>
                        <span className="font-bold text-chart-2">{effective} د.ل</span>
                      </div>
                      {regCh.discount_reason && <p className="text-xs text-muted-foreground mt-1">{regCh.discount_reason}</p>}
                    </div>
                  );
                }
                const enteredFinal = discRegAmount !== '' ? Math.max(0, parseFloat(discRegAmount) || 0) : regCh.charge_amount;
                const finalClamped = Math.min(enteredFinal, regCh.charge_amount);
                const discountPreview = regCh.charge_amount - finalClamped;
                return (
                  <div className="rounded-xl border border-border bg-card p-4 space-y-3">
                    {/* عنوان */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-lg bg-amber-100 flex items-center justify-center shrink-0">
                          <FileText className="w-3.5 h-3.5 text-amber-600" />
                        </div>
                        <span className="text-sm font-semibold text-foreground">رسوم التسجيل</span>
                      </div>
                      <span className="text-xs font-mono text-muted-foreground">{regCh.charge_amount} د.ل</span>
                    </div>
                    {/* حقول */}
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium text-muted-foreground">المبلغ النهائي (د.ل)</Label>
                        <Input type="text" inputMode="decimal"
                          value={discRegAmount}
                          placeholder={String(regCh.charge_amount)}
                          onChange={e => setDiscRegAmount(e.target.value.replace(/[^\d.]/g, ''))}
                          className={`h-9 text-sm font-mono font-bold ${discountPreview > 0 ? 'border-amber-400 bg-amber-50/40' : ''}`} />
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium text-muted-foreground">سبب التخفيض</Label>
                        <Input placeholder="اختياري" value={discRegReason}
                          onChange={e => setDiscRegReason(e.target.value)}
                          className="h-9 text-sm" />
                      </div>
                    </div>
                    {/* أزرار سريعة */}
                    <div className="flex gap-2 flex-wrap">
                      {[0, Math.round(regCh.charge_amount * 0.5), regCh.charge_amount].map(v => (
                        <button key={v} type="button" onClick={() => setDiscRegAmount(String(v))}
                          className={`h-7 px-3 text-xs font-semibold rounded-lg border transition-colors
                            ${parseFloat(discRegAmount) === v
                              ? 'bg-amber-500 text-white border-amber-500'
                              : 'bg-background text-amber-700 border-amber-300/70 hover:bg-amber-500 hover:text-white'}`}>
                          {v === 0 ? 'إعفاء كامل' : v === regCh.charge_amount ? 'بدون تخفيض' : `${v} د.ل`}
                        </button>
                      ))}
                    </div>
                    {/* معاينة */}
                    {discountPreview > 0 && (
                      <div className="flex items-center gap-2 text-xs text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-2">
                        <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                        <span>تخفيض قدره <strong className="font-mono">{discountPreview.toFixed(0)} د.ل</strong></span>
                        {finalClamped === 0 && <span className="text-chart-2 font-semibold mr-1">— إعفاء كامل</span>}
                      </div>
                    )}
                  </div>
                );
              })()}

              {/* ── فاصل قسم الفصول ── */}
              <div className="flex items-center gap-3">
                <div className="flex-1 h-px bg-border" />
                <span className="text-xs font-semibold text-muted-foreground">الفصول الدراسية</span>
                <div className="flex-1 h-px bg-border" />
              </div>

              {/* ── شبكة الفصول ── */}
              {(() => {
                if (!localStudent) return null;
                const baseFeeVal = localStudent.diploma_type === 'عالي'
                  ? parseFloat(settings[SETTINGS_KEYS.HIGH_DIPLOMA_FEE] ?? '600')
                  : parseFloat(settings[SETTINGS_KEYS.MID_DIPLOMA_FEE] ?? '550');

                const discountedChs = charges.filter(
                  c => (c.charge_type === 'فصلي' || c.charge_type === 'مشروع تخرج')
                    && (c.discount_amount ?? 0) > 0 && !c.is_locked
                );
                const scheduledChs = charges.filter(c => c.charge_type === 'فصلي' && c.is_locked);
                const eligibleKeys = Object.keys(semChargeDiscounts);
                const hasEligible = eligibleKeys.length > 0;
                const allEnabled = hasEligible && eligibleKeys.every(k => semChargeDiscounts[k]?.enabled);

                const setSemField = (id: string, field: 'enabled' | 'finalAmount' | 'reason', value: boolean | string) =>
                  setSemChargeDiscounts(prev => ({ ...prev, [id]: { ...prev[id], [field]: value } }));
                const getLabel = (ch: SemesterCharge) =>
                  ch.charge_type === 'مشروع تخرج' ? 'مشروع التخرج' : (SEMESTER_LABELS[ch.semester_number] ?? `الفصل ${ch.semester_number}`);
                const getVirtualLabel = (sem: number) => SEMESTER_LABELS[sem] ?? `الفصل ${sem}`;

                return (
                  <div className="space-y-4">
                    {/* مُطبَّق مسبقاً */}
                    {discountedChs.length > 0 && (
                      <div className="space-y-2">
                        <p className="text-xs font-semibold text-muted-foreground">تم تطبيق التخفيض</p>
                        <div className="grid grid-cols-2 gap-2">
                          {discountedChs.map(ch => {
                            const effective = ch.charge_amount - (ch.discount_amount ?? 0);
                            return (
                              <div key={ch.id} className="rounded-lg border border-chart-2/30 bg-chart-2/5 p-3">
                                <div className="flex items-center justify-between mb-1.5">
                                  <span className="text-xs font-semibold text-chart-2 truncate">{getLabel(ch)}</span>
                                  <CheckCircle2 className="w-3.5 h-3.5 text-chart-2 shrink-0" />
                                </div>
                                <div className="flex items-center gap-2 text-xs font-mono">
                                  <span className="line-through text-muted-foreground">{ch.charge_amount}</span>
                                  <span className="font-bold text-chart-2">{effective} د.ل</span>
                                </div>
                                {ch.discount_reason && (
                                  <p className="text-xs text-muted-foreground mt-1 truncate">{ch.discount_reason}</p>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* مجدول */}
                    {scheduledChs.length > 0 && (
                      <div className="space-y-2">
                        <p className="text-xs font-semibold text-blue-600">تخفيض مجدول للفصول القادمة</p>
                        <div className="grid grid-cols-2 gap-2">
                          {scheduledChs.map(ch => {
                            const effective = ch.charge_amount - (ch.discount_amount ?? 0);
                            return (
                              <div key={ch.id} className="rounded-lg border border-blue-200 bg-blue-50/60 dark:bg-blue-950/30 dark:border-blue-800/50 p-3">
                                <div className="flex items-center justify-between mb-1.5">
                                  <span className="text-xs font-semibold text-blue-700 dark:text-blue-400 truncate">{getLabel(ch)}</span>
                                  <Calendar className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                                </div>
                                <div className="flex items-center gap-2 text-xs font-mono">
                                  <span className="line-through text-muted-foreground">{ch.charge_amount}</span>
                                  <span className="font-bold text-blue-600">{effective} د.ل</span>
                                </div>
                                {ch.discount_reason && (
                                  <p className="text-xs text-muted-foreground mt-1 truncate">{ch.discount_reason}</p>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* قابل للتخفيض */}
                    {hasEligible && (
                      <div className="space-y-3">
                        {(discountedChs.length > 0 || scheduledChs.length > 0) && (
                          <p className="text-xs font-semibold text-muted-foreground">اختر فصولاً للتخفيض</p>
                        )}
                        <div className="flex items-center justify-between">
                          <p className="text-sm font-semibold text-foreground">الفصول المتاحة</p>
                          <div className="flex items-center gap-3 text-xs">
                            <button type="button" onClick={() => setSemChargeDiscounts(prev => {
                              const next = { ...prev };
                              eligibleKeys.forEach(k => { next[k] = { ...next[k], enabled: true }; });
                              return next;
                            })} className="font-semibold text-primary hover:underline">تحديد الكل</button>
                            <span className="text-border">|</span>
                            <button type="button" onClick={() => setSemChargeDiscounts(prev => {
                              const next = { ...prev };
                              eligibleKeys.forEach(k => { next[k] = { ...next[k], enabled: false }; });
                              return next;
                            })} className={`font-semibold hover:underline ${allEnabled ? 'text-muted-foreground' : 'text-muted-foreground/40'}`}>إلغاء الكل</button>
                          </div>
                        </div>
                        {/* بطاقات الفصول — عمودي واحد لوضوح العنوان */}
                        <div className="space-y-2">
                          {eligibleKeys.map(key => {
                            const entry = semChargeDiscounts[key];
                            const isVirtual = key.startsWith('virtual-');
                            const ch = isVirtual ? null : charges.find(c => c.id === key);
                            const chargeAmt = isVirtual ? baseFeeVal : (ch?.charge_amount ?? 0);
                            const fa = parseFloat(entry.finalAmount);
                            const disc = isNaN(fa) ? 0 : Math.max(0, chargeAmt - Math.min(fa, chargeAmt));
                            const label = isVirtual ? getVirtualLabel(entry.virtualSem!) : (ch ? getLabel(ch) : key);
                            const isProject = ch?.charge_type === 'مشروع تخرج';
                            return (
                              <div key={key}
                                className={`rounded-xl border-2 overflow-hidden transition-all duration-200
                                  ${entry.enabled
                                    ? 'border-amber-400 shadow-md shadow-amber-100'
                                    : 'border-border/60 hover:border-amber-200'}`}>
                                {/* رأس البطاقة — عنوان الفصل بارز */}
                                <button
                                  type="button"
                                  onClick={() => setSemField(key, 'enabled', !entry.enabled)}
                                  className={`w-full flex items-center gap-3 px-4 py-3 transition-colors
                                    ${entry.enabled ? 'bg-amber-50 dark:bg-amber-950/30' : 'bg-muted/30 hover:bg-muted/50'}`}>
                                  {/* Checkbox مخصص */}
                                  <div className={`w-5 h-5 rounded-md border-2 flex items-center justify-center shrink-0 transition-all
                                    ${entry.enabled ? 'bg-amber-500 border-amber-500' : 'border-border bg-background'}`}>
                                    {entry.enabled && <CheckCircle2 className="w-3 h-3 text-white" />}
                                  </div>
                                  {/* أيقونة الفصل */}
                                  <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0
                                    ${entry.enabled ? 'bg-amber-500' : 'bg-muted'}`}>
                                    {isProject
                                      ? <GraduationCap className={`w-3.5 h-3.5 ${entry.enabled ? 'text-white' : 'text-muted-foreground'}`} />
                                      : <BookOpen className={`w-3.5 h-3.5 ${entry.enabled ? 'text-white' : 'text-muted-foreground'}`} />
                                    }
                                  </div>
                                  {/* اسم الفصل — واضح وكبير */}
                                  <div className="flex-1 text-right">
                                    <p className={`text-sm font-bold ${entry.enabled ? 'text-amber-800 dark:text-amber-300' : 'text-foreground'}`}>
                                      {label}
                                    </p>
                                    <p className="text-[11px] text-muted-foreground font-mono">{chargeAmt} د.ل</p>
                                  </div>
                                  {/* حالة التخفيض */}
                                  <div className="shrink-0 flex items-center gap-1.5">
                                    {isVirtual && (
                                      <span className="text-[10px] font-semibold text-blue-600 bg-blue-50 border border-blue-200 px-1.5 py-0.5 rounded-full">قادم</span>
                                    )}
                                    {disc > 0 && entry.enabled && (
                                      <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full font-mono">−{disc.toFixed(0)}</span>
                                    )}
                                  </div>
                                </button>

                                {/* حقول التخفيض — تظهر عند التفعيل */}
                                {entry.enabled && (
                                  <div className="px-4 py-3 bg-amber-50/40 dark:bg-amber-950/10 border-t border-amber-200/60 space-y-3">
                                    <div className="grid grid-cols-2 gap-3">
                                      <div className="space-y-1">
                                        <Label className="text-xs font-medium text-muted-foreground">المبلغ النهائي (د.ل)</Label>
                                        <Input type="text" inputMode="decimal"
                                          value={entry.finalAmount}
                                          onChange={e => setSemField(key, 'finalAmount', e.target.value.replace(/[^\d.]/g, ''))}
                                          placeholder={String(chargeAmt)}
                                          className="h-9 text-sm font-mono font-bold border-amber-300 focus:border-amber-500" />
                                      </div>
                                      <div className="space-y-1">
                                        <Label className="text-xs font-medium text-muted-foreground">سبب التخفيض</Label>
                                        <Input value={entry.reason}
                                          onChange={e => setSemField(key, 'reason', e.target.value)}
                                          placeholder="اختياري"
                                          className="h-9 text-xs border-amber-300 focus:border-amber-500" />
                                      </div>
                                    </div>
                                    <div className="flex gap-2">
                                      <button type="button" onClick={() => setSemField(key, 'finalAmount', '0')}
                                        className="h-7 px-3 text-xs font-semibold rounded-lg border border-amber-300/70 bg-white text-amber-700 hover:bg-amber-500 hover:text-white transition-colors">
                                        إعفاء كامل
                                      </button>
                                      <button type="button" onClick={() => setSemField(key, 'finalAmount', String(chargeAmt))}
                                        className="h-7 px-3 text-xs font-semibold rounded-lg border border-amber-300/70 bg-white text-amber-700 hover:bg-amber-500 hover:text-white transition-colors font-mono">
                                        {chargeAmt} د.ل
                                      </button>
                                    </div>
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* لا يوجد ما يمكن تخفيضه */}
                    {!hasEligible && discountedChs.length === 0 && scheduledChs.length === 0 && (
                      <p className="text-sm text-muted-foreground text-center py-4">لا توجد فصول متاحة للتخفيض</p>
                    )}
                    {!hasEligible && (discountedChs.length > 0 || scheduledChs.length > 0) && (
                      <div className="flex items-center gap-2 text-xs text-chart-2 bg-chart-2/5 border border-chart-2/20 rounded-lg px-3 py-2">
                        <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                        <span>جميع الفصول المتاحة مشمولة بتخفيض أو جدولة مسبقة.</span>
                      </div>
                    )}
                  </div>
                );
              })()}

              {/* ── ملخص التخفيضات ── */}
              {(() => {
                const regCh = charges.find(c => c.charge_type === 'تسجيل' || c.charge_type === 'معادلة');
                const regDisc = regCh && discRegAmount !== ''
                  ? regCh.charge_amount - Math.min(Math.max(0, parseFloat(discRegAmount) || 0), regCh.charge_amount)
                  : 0;
                const baseFeeVal = localStudent
                  ? (localStudent.diploma_type === 'عالي'
                    ? parseFloat(settings[SETTINGS_KEYS.HIGH_DIPLOMA_FEE] ?? '600')
                    : parseFloat(settings[SETTINGS_KEYS.MID_DIPLOMA_FEE] ?? '550'))
                  : 0;
                const semLines = Object.entries(semChargeDiscounts)
                  .filter(([, v]) => v.enabled)
                  .map(([id, v]) => {
                    const isVirtual = id.startsWith('virtual-');
                    const ch = isVirtual ? null : charges.find(c => c.id === id);
                    const chargeAmt = isVirtual ? baseFeeVal : (ch?.charge_amount ?? 0);
                    const fa = parseFloat(v.finalAmount);
                    const d = isNaN(fa) ? 0 : Math.max(0, chargeAmt - Math.min(fa, chargeAmt));
                    if (!d) return null;
                    const lbl = isVirtual
                      ? (SEMESTER_LABELS[v.virtualSem!] ?? `الفصل ${v.virtualSem}`)
                      : (ch?.charge_type === 'مشروع تخرج' ? 'مشروع التخرج' : (SEMESTER_LABELS[ch!.semester_number] ?? `الفصل ${ch!.semester_number}`));
                    return { id, lbl, d, isVirtual };
                  })
                  .filter(Boolean) as { id: string; lbl: string; d: number; isVirtual: boolean }[];
                const total = regDisc + semLines.reduce((s, l) => s + l.d, 0);
                if (total === 0) return null;
                return (
                  <div className="rounded-xl border border-amber-200 bg-amber-50/60 p-4 space-y-2">
                    <p className="text-sm font-semibold text-amber-800">ملخص التخفيضات</p>
                    {regDisc > 0 && (
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-muted-foreground">رسوم التسجيل</span>
                        <span className="font-mono font-bold text-chart-2">−{regDisc.toFixed(0)} د.ل</span>
                      </div>
                    )}
                    {semLines.map(({ id, lbl, d, isVirtual }) => (
                      <div key={id} className="flex items-center justify-between text-xs">
                        <span className="text-muted-foreground flex items-center gap-1.5">
                          {lbl}
                          {isVirtual && <span className="text-blue-500 font-medium">(مجدول)</span>}
                        </span>
                        <span className="font-mono font-bold text-chart-2">−{d.toFixed(0)} د.ل</span>
                      </div>
                    ))}
                    <div className="flex items-center justify-between pt-2 border-t border-amber-200/60">
                      <span className="text-sm font-bold text-amber-800">إجمالي الإعفاء</span>
                      <span className="font-mono font-bold text-lg text-amber-700">{total.toFixed(0)} د.ل</span>
                    </div>
                  </div>
                );
              })()}

            </div>

            {/* ── شريط الإجراءات ── */}
            <div className="sticky bottom-0 bg-background border-t border-border px-5 py-3 flex gap-3">
              <Button variant="outline" onClick={closeDiscountDialog} className="flex-1 h-9">إلغاء</Button>
              <Button onClick={handleApplyDiscount} disabled={applyingDiscount}
                className="flex-1 h-9 bg-amber-500 hover:bg-amber-600 text-white gap-2">
                <Scissors className="w-3.5 h-3.5" />
                {applyingDiscount ? 'جاري الحفظ...' : 'حفظ التخفيضات'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── نافذة تسجيل دفعة ── */}
      <Dialog open={showPayDialog} onOpenChange={setShowPayDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm p-0 overflow-hidden rounded-2xl shadow-2xl [&>button]:hidden" dir="rtl">
          <DialogTitle className="sr-only">تسجيل دفعة مالية</DialogTitle>

          {/* ── رأس متدرج ── */}
          <div className="relative overflow-hidden" style={{ background: 'linear-gradient(145deg,#064e3b 0%,#065f46 40%,#047857 100%)' }}>
            {/* نقاط خلفية خفيفة */}
            <div className="absolute inset-0 opacity-[0.06]" style={{ backgroundImage: 'radial-gradient(circle,white 1px,transparent 1px)', backgroundSize: '18px 18px' }} />
            {/* خط سفلي ناعم */}
            <div className="absolute bottom-0 inset-x-0 h-px" style={{ background: 'linear-gradient(90deg,transparent,rgba(255,255,255,.18),transparent)' }} />

            <div className="relative px-5 py-4 flex items-center gap-3">
              {/* أيقونة */}
              <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: 'rgba(255,255,255,.12)', border: '1px solid rgba(255,255,255,.2)' }}>
                <Banknote className="w-5 h-5 text-white" />
              </div>
              {/* اسم + عنوان */}
              <div className="flex-1 min-w-0">
                <p className="text-white font-bold text-[13px] leading-tight">تسجيل دفعة مالية</p>
                <p className="text-emerald-200/70 text-[11px] truncate mt-0.5">{student?.full_name}</p>
              </div>
              {/* شارة المتبقي */}
              <div className="shrink-0 flex items-center gap-2">
                <div className="text-center rounded-xl px-3 py-1.5" style={{ background: 'rgba(0,0,0,.2)', border: '1px solid rgba(255,255,255,.12)' }}>
                  <p className="text-emerald-300/60 text-[9px] font-semibold tracking-widest">المتبقي</p>
                  <p className={`font-black text-[13px] leading-tight ${debt <= 0 ? 'text-emerald-200' : 'text-rose-300'}`}>
                    {debt <= 0 ? 'مسدد ✓' : `${debt.toFixed(0)} د.ل`}
                  </p>
                </div>
                <button onClick={() => setShowPayDialog(false)}
                  className="w-7 h-7 rounded-lg flex items-center justify-center transition-all hover:scale-110 active:scale-90"
                  style={{ background: 'rgba(255,255,255,.1)', border: '1px solid rgba(255,255,255,.18)' }}>
                  <X className="w-3.5 h-3.5 text-white" />
                </button>
              </div>
            </div>
          </div>

          {/* ── جسم النموذج ── */}
          <div className="bg-card px-5 pt-5 pb-4 space-y-4">

            {/* ── الصف: رقم الإيصال + التاريخ ── */}
            <div className="grid grid-cols-2 gap-3">
              {/* رقم الإيصال */}
              <div className="space-y-1.5">
                <label className="flex items-center gap-1 text-[11px] font-semibold text-muted-foreground">
                  <Hash className="w-3 h-3" />رقم الإيصال
                </label>
                <Input
                  value={payReceiptNum}
                  onChange={e => setPayReceiptNum(e.target.value)}
                  placeholder="1001"
                  inputMode="numeric"
                  className="h-10 rounded-lg text-center font-mono text-sm font-bold bg-muted/40 border-border/50 focus-visible:ring-emerald-500/40 focus-visible:border-emerald-500/60" />
              </div>
              {/* التاريخ */}
              <div className="space-y-1.5">
                <label className="flex items-center justify-between text-[11px] font-semibold text-muted-foreground">
                  <span className="flex items-center gap-1"><Calendar className="w-3 h-3" />التاريخ</span>
                  {payDate && payDate !== new Date().toISOString().slice(0, 10) && (
                    <button type="button" onClick={() => setPayDate(new Date().toISOString().slice(0, 10))}
                      className="text-[10px] text-emerald-600 font-bold hover:underline">← اليوم</button>
                  )}
                </label>
                <SmartDateInput value={payDate} onChange={setPayDate} />
              </div>
            </div>

            {payDate && payDate !== new Date().toISOString().slice(0, 10) && (
              <div className="flex items-center gap-2 text-[11px] text-amber-600 font-medium bg-amber-500/8 border border-amber-500/20 rounded-lg px-3 py-1.5 -mt-1">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0" />
                تاريخ مخصص — سيُسجَّل الإيصال بهذا التاريخ
              </div>
            )}

            {/* ── المبلغ ── */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="flex items-center gap-1 text-[11px] font-semibold text-muted-foreground">
                  <Banknote className="w-3 h-3" />المبلغ
                </label>
                {debt > 0 && (
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-500/10 border border-emerald-500/20 rounded-full px-2 py-0.5">
                    الحد الأقصى {debt.toFixed(0)} د.ل
                  </span>
                )}
              </div>
              <div className="relative">
                <Input
                  type="number" min="0.5" step="0.5" placeholder="0.00"
                  max={debt > 0 ? debt : undefined}
                  value={payAmount}
                  onChange={e => {
                    const val = e.target.value;
                    const num = parseFloat(val);
                    if (debt > 0 && num > debt) { setPayAmount(debt.toFixed(2)); }
                    else { setPayAmount(val); }
                  }}
                  className={`h-12 rounded-lg text-center font-mono text-xl font-black pl-14 bg-muted/40 border-border/50 focus-visible:ring-emerald-500/40 focus-visible:border-emerald-500/60 transition-colors ${
                    parseFloat(payAmount) > debt && debt > 0 ? 'border-destructive/60 ring-1 ring-destructive/20 bg-destructive/5' : ''
                  }`} />
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-xs font-bold text-muted-foreground/50 pointer-events-none">د.ل</span>
              </div>
              {parseFloat(payAmount) > debt && debt > 0 ? (
                <p className="flex items-center gap-1.5 text-[11px] text-destructive font-medium">
                  <AlertTriangle className="w-3 h-3 shrink-0" />
                  يتجاوز المتبقي ({debt.toFixed(0)} د.ل)
                </p>
              ) : debt > 0 && payAmount !== debt.toFixed(2) ? (
                <button type="button" onClick={() => setPayAmount(debt.toFixed(2))}
                  className="text-[11px] text-emerald-600 font-semibold hover:underline">
                  ← تسديد الكامل ({debt.toFixed(0)} د.ل)
                </button>
              ) : null}
            </div>

            {/* ── طريقة الدفع ── */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-semibold text-muted-foreground">طريقة الدفع</label>
              <div className="grid grid-cols-3 gap-2">
                {([
                  { key: 'كاش',  icon: '💵', label: 'كاش'   },
                  { key: 'بطاقة', icon: '💳', label: 'بطاقة' },
                  { key: 'شيك',  icon: '🧾', label: 'شيك'   },
                ] as const).map(({ key, icon, label }) => (
                  <button key={key} type="button" onClick={() => setPayMethod(key)}
                    className={`h-10 rounded-lg text-xs font-bold border transition-all active:scale-95 ${
                      payMethod === key
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                        : 'bg-muted/40 text-muted-foreground border-border/50 hover:border-emerald-500/50 hover:text-foreground'
                    }`}>
                    {icon} {label}
                  </button>
                ))}
              </div>
            </div>

            {/* ── ملاحظات ── */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-semibold text-muted-foreground">
                ملاحظات <span className="font-normal opacity-50">(اختياري)</span>
              </label>
              <Textarea
                placeholder="أي ملاحظة على الدفعة..."
                value={payNotes}
                onChange={e => setPayNotes(e.target.value)}
                rows={2}
                className="rounded-lg text-right text-sm resize-none bg-muted/40 border-border/50 focus-visible:ring-emerald-500/40 focus-visible:border-emerald-500/60 min-h-[64px]" />
            </div>

            {/* ── فاصل ── */}
            <div className="h-px bg-border/50" />

            {/* ── أزرار الإجراء ── */}
            <div className="flex items-center gap-2.5 pb-1">
              <button type="button" onClick={() => setShowPayDialog(false)}
                className="flex-1 h-10 rounded-lg text-sm font-semibold border border-border/60 text-muted-foreground hover:bg-muted/60 transition-all active:scale-95">
                إلغاء
              </button>
              <button type="button" onClick={handlePay}
                disabled={paying || !payAmount || !payReceiptNum || (debt > 0 && parseFloat(payAmount) > debt)}
                className="flex-[2] h-10 rounded-lg text-sm font-bold text-white flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed shadow-lg shadow-emerald-900/30"
                style={{ background: paying ? '#047857' : 'linear-gradient(135deg,#10b981 0%,#059669 50%,#047857 100%)' }}>
                {paying
                  ? <><RefreshCw className="w-3.5 h-3.5 animate-spin" />جاري التسجيل...</>
                  : <><Plus className="w-3.5 h-3.5" />تسجيل الدفعة</>}
              </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── نافذة تعديل وصل ── */}
      <Dialog open={!!editTarget} onOpenChange={o => { if (!o) setEditTarget(null); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-sm">
              <Pencil className="w-4 h-4 text-amber-500" />
              تعديل الوصل #{editTarget?.receipt_number}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1">
              <Label className="text-xs">المبلغ (دينار)</Label>
              <Input type="number" min="0.5" step="0.5" placeholder="0.00"
                value={editAmount} onChange={e => setEditAmount(e.target.value)}
                className="text-right font-mono text-base" />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">البيان</Label>
              <Input
                placeholder="مثال: سداد رسوم الفصل 2 بالكامل..."
                value={editSemesterTarget}
                readOnly
                className="text-right text-sm bg-muted/40 cursor-not-allowed text-muted-foreground select-none"
              />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">ملاحظات (اختياري)</Label>
              <Textarea placeholder="أي ملاحظة على الوصل..." value={editNotes}
                onChange={e => setEditNotes(e.target.value)}
                className="text-right text-sm resize-none" rows={2} />
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-1">
            <Button variant="outline" size="sm" onClick={() => setEditTarget(null)}>إلغاء</Button>
            <Button size="sm" onClick={handleEditSave} disabled={saving || !editAmount}
              className="bg-amber-500 text-white hover:bg-amber-600 gap-1.5">
              {saving ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Pencil className="w-3.5 h-3.5" />}
              حفظ التعديل
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── تأكيد حذف وصل ── */}
      <AlertDialog open={!!deleteTarget} onOpenChange={o => { if (!o) setDeleteTarget(null); }}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm" dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-right text-sm flex items-center gap-2">
              <Trash2 className="w-4 h-4 text-destructive" />
              تأكيد حذف الوصل
            </AlertDialogTitle>
            <AlertDialogDescription className="text-right text-xs">
              هل أنت متأكد من حذف الوصل{' '}
              <span className="font-bold text-foreground">#{deleteTarget?.receipt_number}</span>
              {' '}بمبلغ{' '}
              <span className="font-bold text-destructive">{deleteTarget?.amount.toFixed(0)} د.ل</span>؟
              لا يمكن التراجع عن هذا الإجراء.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-row-reverse gap-2">
            <AlertDialogCancel className="mt-0">إلغاء</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteConfirm}
              disabled={deleting}
              className="bg-destructive text-white hover:bg-destructive/85 gap-1.5">
              {deleting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
              حذف الوصل
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ── تأكيد تصفير الرصيد ── */}
      <AlertDialog open={showResetConfirm} onOpenChange={o => { if (!o) setShowResetConfirm(false); }}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm" dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-right text-sm flex items-center gap-2">
              <RotateCcw className="w-4 h-4 text-destructive" />
              تأكيد تصفير رصيد الطالب
            </AlertDialogTitle>
            <AlertDialogDescription className="text-right text-xs">
              سيتم تصفير رصيد الطالب{' '}
              <span className="font-bold text-foreground">{student?.full_name}</span>
              {' '}بالكامل:
              <br />
              • حذف جميع الأقساط والإيصالات نهائياً
              <br />
              • إعادة الطالب إلى <span className="font-bold text-foreground">الفصل الأول</span>
              <br />
              • إعادة إنشاء رسوم التسجيل ورسوم الفصل الأول تلقائياً
              <br />
              <span className="text-destructive font-semibold">لا يمكن التراجع عن هذا الإجراء.</span>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-row-reverse gap-2">
            <AlertDialogCancel className="mt-0">إلغاء</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleResetBalance}
              disabled={resetting}
              className="bg-destructive text-white hover:bg-destructive/85 gap-1.5">
              {resetting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <RotateCcw className="w-3.5 h-3.5" />}
              تصفير الرصيد
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ── تأكيد ترحيل / أرشفة الطالب ── */}
      <AlertDialog open={showPromoteConfirm} onOpenChange={o => {
        if (!o && !promoting) {
          setShowPromoteConfirm(false);
          setPromoteStep('idle');
        }
      }}>
        <AlertDialogContent className="max-w-[calc(100%-1.5rem)] sm:max-w-md p-0 overflow-hidden rounded-2xl shadow-2xl border border-border/60" dir="rtl">
          {promoteStep === 'animating' ? (
            /* ── شاشة الحركة الاحترافية أثناء الترحيل ── */
            <div className="p-6 text-center space-y-6 bg-gradient-to-b from-blue-950/40 via-background to-background">
              {/* أيقونة المسار المتحركة */}
              <div className="relative py-4 flex items-center justify-center gap-4">
                <motion.div
                  initial={{ scale: 0.9, opacity: 0.8 }}
                  animate={{ scale: [0.95, 1.05, 0.95], opacity: 1 }}
                  transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
                  className="px-3.5 py-2.5 rounded-xl bg-blue-500/10 border border-blue-500/30 text-blue-600 dark:text-blue-400 font-bold text-xs">
                  {SEMESTER_LABELS[currentSemesterNum] ?? `الفصل ${currentSemesterNum}`}
                </motion.div>

                {/* مؤشر النقل الموجه */}
                <div className="relative flex items-center justify-center w-14">
                  <motion.div
                    animate={{ x: [-15, 15, -15], opacity: [0.3, 1, 0.3] }}
                    transition={{ repeat: Infinity, duration: 1.5, ease: "easeInOut" }}
                    className="flex items-center text-blue-500">
                    <ArrowLeft className="w-5 h-5 animate-pulse" />
                  </motion.div>
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <span className="w-2 h-2 rounded-full bg-blue-500 animate-ping" />
                  </div>
                </div>

                <motion.div
                  initial={{ scale: 0.9, opacity: 0.8 }}
                  animate={{ scale: [1, 1.08, 1], borderColor: ['rgba(59,130,246,0.3)', 'rgba(16,185,129,0.8)', 'rgba(59,130,246,0.3)'] }}
                  transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
                  className="px-3.5 py-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/40 text-emerald-600 dark:text-emerald-400 font-bold text-xs ring-2 ring-emerald-500/20">
                  {isAtFinalSemester ? 'الأرشيف (خريج)' : (SEMESTER_LABELS[nextSemesterNum] ?? `الفصل ${nextSemesterNum}`)}
                </motion.div>
              </div>

              {/* دائرة التحميل المتقدمة */}
              <div className="flex flex-col items-center gap-3">
                <div className="relative w-16 h-16 rounded-full bg-blue-500/10 flex items-center justify-center border border-blue-500/20">
                  <RefreshCw className="w-8 h-8 text-blue-500 animate-spin" />
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ repeat: Infinity, duration: 4, ease: "linear" }}
                    className="absolute inset-[-4px] rounded-full border-2 border-dashed border-blue-400/40 pointer-events-none"
                  />
                </div>
                <div className="space-y-1">
                  <h4 className="text-sm font-bold text-foreground">
                    {isAtFinalSemester ? 'جاري اعتماد التخرج والأرشفة...' : 'جاري ترحيل الطالب إلى الفصل الجديد...'}
                  </h4>
                  <p className="text-xs text-blue-500 dark:text-blue-400 font-medium h-5">
                    {promoteStatusText || 'التحقق من البيانات والمطابقة...'}
                  </p>
                </div>
              </div>

              {/* شريط التقدم التفاعلي */}
              <div className="space-y-1.5 px-2">
                <div className="flex justify-between text-[11px] text-muted-foreground font-semibold">
                  <span>التقدم</span>
                  <span>{promoteProgress}%</span>
                </div>
                <div className="w-full h-2.5 bg-muted rounded-full overflow-hidden p-0.5 border border-border/50">
                  <motion.div
                    className="h-full bg-gradient-to-r from-blue-600 via-indigo-600 to-emerald-500 rounded-full"
                    initial={{ width: '5%' }}
                    animate={{ width: `${promoteProgress}%` }}
                    transition={{ duration: 0.3 }}
                  />
                </div>
              </div>
            </div>
          ) : promoteStep === 'success' ? (
            /* ── شاشة الاحتفال بالنجاح ── */
            <div className="p-6 text-center space-y-5 bg-gradient-to-b from-emerald-950/30 via-background to-background">
              {/* أيقونة النجاح والشرارات */}
              <div className="relative mx-auto w-16 h-16 rounded-full bg-emerald-500/15 border-2 border-emerald-500/40 flex items-center justify-center">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: [0, 1.25, 1] }}
                  transition={{ type: "spring", stiffness: 300, damping: 15 }}>
                  <CheckCircle2 className="w-9 h-9 text-emerald-500" />
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, scale: 0.5 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="absolute -top-1 -right-1 text-amber-400">
                  <Sparkles className="w-5 h-5 animate-pulse" />
                </motion.div>
              </div>

              <div className="space-y-1">
                <h3 className="text-base font-black text-foreground">
                  {isAtFinalSemester ? '🎓 تهانينا! تمت الأرشفة بنجاح' : '🎉 تم ترحيل الطالب بنجاح!'}
                </h3>
                <p className="text-xs text-muted-foreground">
                  {isAtFinalSemester
                    ? `أصبح الطالب ${st.full_name} مسجلاً كخريج معتمد في الأرشيف`
                    : `أصبح الطالب ${st.full_name} مقيداً رسمياً في ${SEMESTER_LABELS[nextSemesterNum] ?? `الفصل ${nextSemesterNum}`}`}
                </p>
              </div>

              {/* ملخص الإنجاز */}
              <div className="rounded-xl p-3.5 bg-emerald-50/60 dark:bg-emerald-950/20 border border-emerald-200/60 dark:border-emerald-500/20 text-right space-y-2 text-xs">
                <div className="flex items-center justify-between py-0.5 border-b border-emerald-200/40 dark:border-emerald-500/10">
                  <span className="text-muted-foreground">اسم الطالب:</span>
                  <span className="font-bold text-foreground">{st.full_name}</span>
                </div>
                <div className="flex items-center justify-between py-0.5 border-b border-emerald-200/40 dark:border-emerald-500/10">
                  <span className="text-muted-foreground">رقم القيد:</span>
                  <span className="font-mono font-bold text-foreground">{st.registration_number || 'غير محدد'}</span>
                </div>
                <div className="flex items-center justify-between py-0.5 border-b border-emerald-200/40 dark:border-emerald-500/10">
                  <span className="text-muted-foreground">الفصل السابق:</span>
                  <span className="font-bold text-foreground">{SEMESTER_LABELS[currentSemesterNum] ?? `الفصل ${currentSemesterNum}`}</span>
                </div>
                <div className="flex items-center justify-between py-0.5">
                  <span className="text-muted-foreground">الفصل الحالي المعتمد:</span>
                  <span className="font-black text-emerald-600 dark:text-emerald-400">
                    {isAtFinalSemester ? 'خريج (أرشيف)' : (SEMESTER_LABELS[nextSemesterNum] ?? `الفصل ${nextSemesterNum}`)}
                  </span>
                </div>
              </div>

              <Button
                onClick={() => {
                  setShowPromoteConfirm(false);
                  setPromoteStep('idle');
                }}
                className="w-full h-11 rounded-xl text-sm font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg shadow-emerald-600/20 transition-all active:scale-95">
                <Check className="w-4 h-4 ml-2" />
                تم ومتابعة
              </Button>
            </div>
          ) : (
            /* ── شاشة المعاينة والتأكيد (المظهر الاحترافي المتناسق مع الهاتف) ── */
            <>
              {/* رأس النافذة */}
              <div className={`relative px-4 py-4 md:px-5 md:py-5 ${isAtFinalSemester
                ? 'bg-gradient-to-br from-emerald-600 via-emerald-500 to-teal-600'
                : 'bg-gradient-to-br from-blue-600 via-blue-500 to-indigo-600'}`}>
                <div className="absolute inset-0 opacity-10"
                  style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '16px 16px' }} />
                
                <div className="relative flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-9 h-9 md:w-10 md:h-10 rounded-xl bg-white/20 border border-white/30 flex items-center justify-center shrink-0 shadow-sm">
                      {isAtFinalSemester
                        ? <Archive className="w-4 h-4 md:w-5 md:h-5 text-white" />
                        : <GraduationCap className="w-4 h-4 md:w-5 md:h-5 text-white" />}
                    </div>
                    <div className="min-w-0">
                      <p className="text-white font-bold text-sm leading-tight">
                        {isAtFinalSemester ? 'أرشفة الطالب — تخرج نهائي' : 'ترحيل الطالب'}
                      </p>
                      <p className="text-blue-100/90 text-xs truncate mt-0.5 font-medium">{st.full_name}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => setShowPromoteConfirm(false)}
                    className="w-8 h-8 rounded-xl bg-white/15 border border-white/25 flex items-center justify-center hover:bg-white/30 transition-all shrink-0 active:scale-90"
                    aria-label="إغلاق">
                    <X className="w-4 h-4 text-white" />
                  </button>
                </div>

                {/* مسار الترحيل بالبطاقات المرنة للهاتف */}
                <div className="relative mt-3.5 flex items-center justify-center gap-2">
                  {isAtFinalSemester ? (
                    <div className="flex-1 bg-white/20 border border-white/35 rounded-xl px-3 py-2.5 text-center shadow-inner">
                      <p className="text-emerald-100 text-[10px] mb-0.5">إتمام مرحلة دراسية</p>
                      <p className="text-white font-black text-sm">
                        {SEMESTER_LABELS[currentSemesterNum] ?? `الفصل ${currentSemesterNum}`}
                      </p>
                      <p className="text-emerald-100 text-[10px] mt-0.5 font-medium">← سيُنقل إلى الأرشيف كخريج</p>
                    </div>
                  ) : (
                    <>
                      {/* الفصل المصدر (الحالي المسدد) */}
                      <div className="flex-1 bg-white/15 border border-white/25 rounded-xl px-2.5 py-2 text-center shadow-inner">
                        <p className="text-blue-100 text-[10px] mb-0.5 font-semibold">من</p>
                        <p className="text-white font-black text-xs md:text-sm truncate">
                          {SEMESTER_LABELS[currentSemesterNum] ?? `الفصل ${currentSemesterNum}`}
                        </p>
                      </div>

                      {/* سهم الانتقال المتحرك */}
                      <div className="flex flex-col items-center shrink-0">
                        <div className="w-8 h-8 rounded-full bg-white/20 border border-white/30 flex items-center justify-center shadow-md animate-pulse">
                          <ChevronUp className="w-4 h-4 text-white rotate-0" />
                        </div>
                      </div>

                      {/* الفصل المستهدف التالي */}
                      <div className="flex-1 bg-white/25 border border-white/40 rounded-xl px-2.5 py-2 text-center ring-2 ring-white/40 shadow-lg">
                        <p className="text-blue-100 text-[10px] mb-0.5 font-semibold">إلى</p>
                        <p className="text-white font-black text-xs md:text-sm truncate">
                          {SEMESTER_LABELS[nextSemesterNum] ?? `الفصل ${nextSemesterNum}`}
                        </p>
                      </div>
                    </>
                  )}
                </div>
              </div>

              {/* محتوى التفاصيل مع مراعاة شاشات الهواتف */}
              <div className="px-4 py-3.5 space-y-3 overflow-y-auto max-h-[50vh] text-right">
                {(() => {
                  const unpaidCharges = charges
                    .filter(c => !c.is_cleared && c.remaining_amount > 0)
                    .sort((a, b) => a.semester_number - b.semester_number);
                  const totalDebt = unpaidCharges.reduce((s, c) => s + c.remaining_amount, 0);

                  // نواقص الملف
                  const missingDocs: string[] = [];
                  if ((st.photos_received ?? 0) < (st.photos_required ?? 0))
                    missingDocs.push(`${(st.photos_required ?? 0) - (st.photos_received ?? 0)} صور شخصية`);
                  if (!st.has_birth_certificate) missingDocs.push('شهادة ميلاد');
                  if (!st.has_registration_certificate) missingDocs.push('شهادة التسجيل');
                  if (!st.has_suspended_file) missingDocs.push('ملف معلق');

                  return (
                    <>
                      {/* بطاقة براءة الذمة / المديونيات */}
                      {totalDebt > 0 ? (
                        <div className="rounded-xl border border-amber-300/70 dark:border-amber-500/30 overflow-hidden shadow-sm">
                          <div className="flex items-center gap-2 px-3 py-2.5 bg-amber-50 dark:bg-amber-500/10 border-b border-amber-200/50 dark:border-amber-500/20">
                            <div className="w-6 h-6 rounded-lg bg-amber-500/20 flex items-center justify-center shrink-0">
                              <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-bold text-amber-700 dark:text-amber-400">مديونيات معلقة</p>
                              <p className="text-[10px] text-amber-600/80">ستنتقل مع الطالب إلى الفصل الجديد</p>
                            </div>
                            <span className="shrink-0 text-xs font-black text-amber-700 dark:text-amber-400 font-mono">
                              {totalDebt.toFixed(2)} <span className="text-[10px] font-semibold">د.ل</span>
                            </span>
                          </div>
                          <div className="divide-y divide-amber-100/70 dark:divide-amber-500/10 max-h-28 overflow-y-auto">
                            {unpaidCharges.map((c, i) => (
                              <div key={i} className="flex items-center justify-between px-3 py-1.5 bg-amber-50/40 dark:bg-amber-900/10">
                                <div className="flex items-center gap-1.5 text-xs">
                                  <BookOpen className="w-3 h-3 text-amber-500 shrink-0" />
                                  <span className="font-semibold text-amber-800 dark:text-amber-300 text-[11px]">
                                    {SEMESTER_LABELS[c.semester_number] ?? `الفصل ${c.semester_number}`}
                                  </span>
                                  <span className="text-[9px] bg-amber-100 dark:bg-amber-900/40 text-amber-600 dark:text-amber-400 px-1.5 py-0.2 rounded font-medium">
                                    {c.charge_type}
                                  </span>
                                </div>
                                <span className="text-[11px] font-black text-amber-700 dark:text-amber-400 font-mono">
                                  {c.remaining_amount.toFixed(2)} د.ل
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-center gap-3 bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200/70 dark:border-emerald-500/25 rounded-xl px-3.5 py-2.5 shadow-sm">
                          <div className="w-8 h-8 rounded-xl bg-emerald-500/15 flex items-center justify-center shrink-0">
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                          </div>
                          <div>
                            <p className="text-xs font-bold text-emerald-700 dark:text-emerald-400">
                              {isAtFinalSemester ? '🎓 الطالب أتمّ جميع الفصول وسدّد كامل الرسوم' : 'مستوفٍ لجميع الرسوم ✓'}
                            </p>
                            <p className="text-[10px] text-muted-foreground mt-0.5">
                              {isAtFinalSemester
                                ? 'سيُنقل إلى الأرشيف بحالة خريج معتمد'
                                : `الطالب مسدد بالكامل ومؤهل للترحيل إلى ${SEMESTER_LABELS[nextSemesterNum] ?? `الفصل ${nextSemesterNum}`}`}
                            </p>
                          </div>
                        </div>
                      )}

                      {/* نواقص الملف والوثائق */}
                      {missingDocs.length > 0 && (
                        <div className="rounded-xl border border-rose-200/70 dark:border-rose-500/25 overflow-hidden shadow-sm">
                          <div className="flex items-center gap-2 px-3 py-2 bg-rose-50 dark:bg-rose-500/10 border-b border-rose-200/40 dark:border-rose-500/15">
                            <div className="w-6 h-6 rounded-lg bg-rose-500/15 flex items-center justify-center shrink-0">
                              <FileText className="w-3.5 h-3.5 text-rose-600" />
                            </div>
                            <div>
                              <p className="text-xs font-bold text-rose-700 dark:text-rose-400">نواقص الملف ({missingDocs.length})</p>
                              <p className="text-[10px] text-rose-500/70">يُنصح باستيفاء الوثائق المطلوبة</p>
                            </div>
                          </div>
                          <div className="p-2.5 bg-rose-50/30 dark:bg-rose-900/10 flex flex-wrap gap-1.5">
                            {missingDocs.map((doc, i) => (
                              <span key={i} className="inline-flex items-center gap-1 bg-rose-100 dark:bg-rose-900/30 border border-rose-200/70 dark:border-rose-500/20 text-rose-700 dark:text-rose-400 text-[10px] font-semibold px-2 py-0.5 rounded-md">
                                <AlertTriangle className="w-2.5 h-2.5" />
                                {doc}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </>
                  );
                })()}

                {/* ملاحظة توجيهية */}
                <p className="text-muted-foreground text-[11px] text-center pt-0.5 leading-relaxed">
                  {isAtFinalSemester
                    ? 'بعد الأرشفة ستتم أرشفة الطالب كخريج ويمكن مراجعة سجله في قسم الأرشيف.'
                    : `سيتم اعتماد القيد ونقل الطالب من ${SEMESTER_LABELS[currentSemesterNum] ?? `الفصل ${currentSemesterNum}`} إلى ${SEMESTER_LABELS[nextSemesterNum] ?? `الفصل ${nextSemesterNum}`}.`}
                </p>
              </div>

              {/* أزرار الإجراءات المتناسقة مع الهاتف (ارتفاع مريح للمس) */}
              <div className="flex items-center gap-2.5 px-4 pb-4 pt-1">
                <Button
                  variant="outline"
                  onClick={() => setShowPromoteConfirm(false)}
                  className="flex-1 h-11 rounded-xl text-xs font-bold border-border text-muted-foreground hover:bg-muted active:scale-95 transition-all">
                  إلغاء
                </Button>
                <Button
                  onClick={handlePromote}
                  disabled={promoting}
                  className={`flex-1 h-11 rounded-xl text-xs font-bold text-white shadow-md active:scale-95 transition-all flex items-center justify-center gap-2
                    ${isAtFinalSemester
                      ? 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-500/25'
                      : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 shadow-blue-500/25'}`}>
                  {promoting ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin ml-1" />
                      {isAtFinalSemester ? 'جاري الأرشفة...' : 'جاري الترحيل...'}
                    </>
                  ) : isAtFinalSemester ? (
                    <>
                      <Archive className="w-4 h-4 ml-1" />
                      تأكيد الأرشفة
                    </>
                  ) : (
                    <>
                      <ChevronUp className="w-4 h-4 ml-1 animate-bounce" />
                      تأكيد الترحيل
                    </>
                  )}
                </Button>
              </div>
            </>
          )}
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

// ── صف بيانات مساعد ──
function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-2 py-1 border-b border-border/30 last:border-0">
      <span className="text-[11px] text-muted-foreground shrink-0">{label}</span>
      <span className="text-[11px] font-semibold text-foreground text-left">{value}</span>
    </div>
  );
}
