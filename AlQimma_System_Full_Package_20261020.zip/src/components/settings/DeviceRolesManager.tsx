import React, { useState, useMemo } from 'react';
import { normalizeArabicNumerals } from '@/components/ui/numeric-input';
import {
  Laptop, Shield, Plus, Edit2, Trash2, Check, X,
  CheckCircle2, AlertTriangle, KeyRound, RotateCcw,
  Sliders, Eye, EyeOff, ShieldCheck, Info, Users, DollarSign,
  GraduationCap, Archive, Settings, MessageSquare,
  Printer, FileDown, Layers, Zap, Sparkles, Filter,
  Building2, CheckSquare, Square, Key, Lock, ArrowLeft,
  ChevronDown, ChevronUp,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { useDeviceRole } from '@/contexts/DeviceRoleContext';
import type { DeviceRole, DeviceRolePermissions } from '@/types/index';
import { SYSTEM_PASSWORD } from '@/types/index';
import { toast } from 'sonner';

// نوع الإجراء لتطبيق التنسيق البصري المتناسق
type ActionKind = 'view' | 'add' | 'edit' | 'delete' | 'print' | 'export' | 'custom';

interface ActionItem {
  key: string;
  label: string;
  kind: ActionKind;
}

interface ModuleConfig {
  id: string;
  label: string;
  description: string;
  category: 'students' | 'finance' | 'academic' | 'archive' | 'system';
  actions: ActionItem[];
}

// تصنيف الأقسام والمجموعات مع أيقونات وهوية بصرية موحدة
export const PERMISSION_CATEGORIES = [
  {
    id: 'all',
    label: 'جميع الأقسام',
    icon: Layers,
    color: 'text-primary',
    bg: 'bg-primary/10',
    border: 'border-primary/20',
  },
  {
    id: 'students',
    label: 'الطلاب والتسجيل',
    icon: Users,
    color: 'text-blue-600 dark:text-blue-400',
    bg: 'bg-blue-500/10',
    border: 'border-blue-500/30',
  },
  {
    id: 'finance',
    label: 'المالية والإيرادات',
    icon: DollarSign,
    color: 'text-emerald-600 dark:text-emerald-400',
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/30',
  },
  {
    id: 'academic',
    label: 'الدراسة والامتحانات',
    icon: GraduationCap,
    color: 'text-violet-600 dark:text-violet-400',
    bg: 'bg-violet-500/10',
    border: 'border-violet-500/30',
  },
  {
    id: 'archive',
    label: 'الأرشيف والاتصالات',
    icon: Archive,
    color: 'text-amber-600 dark:text-amber-400',
    bg: 'bg-amber-500/10',
    border: 'border-amber-500/30',
  },
  {
    id: 'system',
    label: 'النظام والأجهزة',
    icon: Settings,
    color: 'text-rose-600 dark:text-rose-400',
    bg: 'bg-rose-500/10',
    border: 'border-rose-500/30',
  },
] as const;

// تعريف الموديولات والعمليات
export const PERMISSION_MODULES_CONFIG: ModuleConfig[] = [
  {
    id: 'students',
    label: 'إدارة الطلاب',
    description: 'قائمة الطلاب، البحث، التصفية، والعمليات الإدارية',
    category: 'students',
    actions: [
      { key: 'view', label: 'عرض القائمة', kind: 'view' },
      { key: 'add', label: 'إضافة طالب', kind: 'add' },
      { key: 'edit', label: 'تعديل البيانات', kind: 'edit' },
      { key: 'delete', label: 'حذف طالب', kind: 'delete' },
      { key: 'print', label: 'طباعة القوائم', kind: 'print' },
      { key: 'export', label: 'تصدير إكسيل', kind: 'export' },
    ],
  },
  {
    id: 'registration',
    label: 'تسجيل طالب جديد',
    description: 'شاشة إدخال بيانات وقبول الطلاب الجدد ونواقص الملفات',
    category: 'students',
    actions: [
      { key: 'view', label: 'فتح شاشة التسجيل', kind: 'view' },
      { key: 'register_student', label: 'اعتماد التسجيل', kind: 'add' },
      { key: 'initial_payment', label: 'تحصيل الدفعة الأولى', kind: 'custom' },
    ],
  },
  {
    id: 'student_profile',
    label: 'الملف الشامل للطالب',
    description: 'عرض بيانات الطالب والوثائق والتعريف وتعديل الملف',
    category: 'students',
    actions: [
      { key: 'view', label: 'عرض الملف الشامل', kind: 'view' },
      { key: 'edit', label: 'تعديل بيانات الملف', kind: 'edit' },
      { key: 'delete', label: 'حذف ملف الطالب', kind: 'delete' },
      { key: 'manage_reg_num', label: 'إدارة رقم القيد', kind: 'edit' },
      { key: 'print', label: 'طباعة الملف والتعريف', kind: 'print' },
    ],
  },
  {
    id: 'student_finance',
    label: 'الرسوم والمالية',
    description: 'سجل المدفوعات والديون والرسوم الدراسية للطالب',
    category: 'finance',
    actions: [
      { key: 'view', label: 'عرض السجل المالي', kind: 'view' },
      { key: 'add_payment', label: 'تسجيل دفعة مالية', kind: 'add' },
      { key: 'delete_payment', label: 'حذف دفعة مسجلة', kind: 'delete' },
      { key: 'print_receipt', label: 'طباعة الإيصال المالي', kind: 'print' },
      { key: 'edit_fees', label: 'تعديل رسوم وفصول', kind: 'edit' },
    ],
  },
  {
    id: 'receipts',
    label: 'إيصالات القبض',
    description: 'سجل تدقيق جميع إيصالات القبض الصادرة بالمنظومة',
    category: 'finance',
    actions: [
      { key: 'view', label: 'عرض سجل الإيصالات', kind: 'view' },
      { key: 'print', label: 'إعادة طباعة الإيصال', kind: 'print' },
      { key: 'delete', label: 'إلغاء أو حذف إيصال', kind: 'delete' },
    ],
  },
  {
    id: 'supply_orders',
    label: 'أوامر التوريد',
    description: 'إدارة وتتبع أوامر التوريد للمصرف وأذونات التوريد',
    category: 'finance',
    actions: [
      { key: 'view', label: 'عرض أوامر التوريد', kind: 'view' },
      { key: 'add', label: 'إنشاء أمر توريد', kind: 'add' },
      { key: 'edit', label: 'تعديل أمر توريد', kind: 'edit' },
      { key: 'delete', label: 'حذف أمر التوريد', kind: 'delete' },
    ],
  },
  {
    id: 'financial_report',
    label: 'التقرير المالي والأرباح',
    description: 'تقارير الإيرادات والمصروفات والتحصيل الشامل',
    category: 'finance',
    actions: [
      { key: 'view', label: 'عرض التقرير المالي', kind: 'view' },
      { key: 'print', label: 'طباعة التقرير', kind: 'print' },
      { key: 'export', label: 'تصدير إكسيل للتقرير', kind: 'export' },
    ],
  },
  {
    id: 'dashboard',
    label: 'لوحة التحكم والإحصائيات',
    description: 'الإحصائيات العامة ومؤشرات الطلاب والأقسام والمخططات',
    category: 'academic',
    actions: [
      { key: 'view', label: 'عرض لوحة التحكم', kind: 'view' },
    ],
  },
  {
    id: 'graduation_projects',
    label: 'مشاريع التخرج',
    description: 'متابعة مشاريع تخرج طلاب الفصل السادس والرسوم والفرق',
    category: 'academic',
    actions: [
      { key: 'view', label: 'عرض مشاريع التخرج', kind: 'view' },
      { key: 'edit', label: 'إضافة وتعديل المشاريع', kind: 'edit' },
      { key: 'print', label: 'طباعة كشوفات المشاريع', kind: 'print' },
      { key: 'export', label: 'تصدير بيانات المشاريع', kind: 'export' },
    ],
  },
  {
    id: 'specialization_report',
    label: 'تقرير التخصصات',
    description: 'توزيع الطلاب حسب التخصص والإحصائيات التخصصية',
    category: 'academic',
    actions: [
      { key: 'view', label: 'عرض تقرير التخصصات', kind: 'view' },
      { key: 'print', label: 'طباعة الكشوفات', kind: 'print' },
      { key: 'export', label: 'تصدير ملف إكسيل', kind: 'export' },
    ],
  },
  {
    id: 'diploma_registry',
    label: 'سجلات الدبلوم',
    description: 'كشوفات الخريجين وسجلات الدبلوم العالي والمتوسط',
    category: 'academic',
    actions: [
      { key: 'view', label: 'عرض سجلات الدبلوم', kind: 'view' },
      { key: 'print', label: 'طباعة السجل', kind: 'print' },
      { key: 'export', label: 'تصدير السجل', kind: 'export' },
    ],
  },
  {
    id: 'archive',
    label: 'الأرشيف العام',
    description: 'سجلات أكثر من 100,000 طالب مؤرشف والبحث السريع',
    category: 'archive',
    actions: [
      { key: 'view', label: 'عرض الأرشيف', kind: 'view' },
      { key: 'restore', label: 'إلغاء الأرشفة واسترجاع', kind: 'edit' },
      { key: 'print', label: 'طباعة كشوفات الأرشيف', kind: 'print' },
      { key: 'export', label: 'تصدير إكسيل للأرشيف', kind: 'export' },
    ],
  },
  {
    id: 'whatsapp',
    label: 'رسائل واتساب',
    description: 'إرسال إشعارات ومطالبات للطلاب وأولياء الأمور',
    category: 'archive',
    actions: [
      { key: 'view', label: 'عرض نافذة واتساب', kind: 'view' },
      { key: 'send', label: 'إرسال رسائل ومطالبات', kind: 'custom' },
    ],
  },
  {
    id: 'system_settings',
    label: 'إعدادات النظام والأجهزة',
    description: 'الإعدادات العامة، الرسوم، إدارة وظائف الأجهزة والصلاحيات',
    category: 'system',
    actions: [
      { key: 'view', label: 'عرض صفحة الإعدادات', kind: 'view' },
      { key: 'edit_settings', label: 'تعديل الإعدادات والرسوم', kind: 'edit' },
      { key: 'manage_roles', label: 'إدارة وظائف الأجهزة', kind: 'custom' },
      { key: 'reset_device', label: 'إعادة تعيين الجهاز', kind: 'custom' },
    ],
  },
];

// دالة لجلب أيقونة وسمات بصرية متقدمة بالألوان لكل وظيفة
function getRoleVisuals(roleId: string, isSelected: boolean) {
  if (roleId === 'general_manager') {
    return {
      icon: Building2,
      border: isSelected
        ? 'border-amber-500 ring-2 ring-amber-500/30 bg-gradient-to-b from-amber-500/15 via-amber-500/5 to-card'
        : 'border-amber-500/30 hover:border-amber-500/60 bg-gradient-to-b from-amber-500/5 to-card',
      color: 'text-amber-600 dark:text-amber-400',
      badge: 'إشراف كامل وشامل',
      badgeColor: 'bg-amber-500/20 text-amber-800 dark:text-amber-200 border border-amber-500/40 font-black',
      iconBg: 'bg-gradient-to-tr from-amber-500 to-amber-600 text-slate-950 shadow-md',
      accentColor: '#d97706',
    };
  }
  if (roleId === 'admin_finance' || roleId.includes('finance')) {
    return {
      icon: DollarSign,
      border: isSelected
        ? 'border-emerald-500 ring-2 ring-emerald-500/30 bg-gradient-to-b from-emerald-500/15 via-emerald-500/5 to-card'
        : 'border-emerald-500/30 hover:border-emerald-500/60 bg-gradient-to-b from-emerald-500/5 to-card',
      color: 'text-emerald-600 dark:text-emerald-400',
      badge: 'الشؤون المالية والإدارة',
      badgeColor: 'bg-emerald-500/20 text-emerald-800 dark:text-emerald-200 border border-emerald-500/40 font-black',
      iconBg: 'bg-gradient-to-tr from-emerald-500 to-teal-600 text-white shadow-md',
      accentColor: '#059669',
    };
  }
  if (roleId === 'study_exams' || roleId.includes('exam')) {
    return {
      icon: GraduationCap,
      border: isSelected
        ? 'border-purple-500 ring-2 ring-purple-500/30 bg-gradient-to-b from-purple-500/15 via-purple-500/5 to-card'
        : 'border-purple-500/30 hover:border-purple-500/60 bg-gradient-to-b from-purple-500/5 to-card',
      color: 'text-purple-600 dark:text-purple-400',
      badge: 'الدراسة والامتحانات',
      badgeColor: 'bg-purple-500/20 text-purple-800 dark:text-purple-200 border border-purple-500/40 font-black',
      iconBg: 'bg-gradient-to-tr from-purple-500 to-indigo-600 text-white shadow-md',
      accentColor: '#7c3aed',
    };
  }
  if (roleId === 'general_registrar' || roleId.includes('reg') || roleId.includes('student')) {
    return {
      icon: Users,
      border: isSelected
        ? 'border-sky-500 ring-2 ring-sky-500/30 bg-gradient-to-b from-sky-500/15 via-sky-500/5 to-card'
        : 'border-sky-500/30 hover:border-sky-500/60 bg-gradient-to-b from-sky-500/5 to-card',
      color: 'text-sky-600 dark:text-sky-400',
      badge: 'القبول وشؤون الطلاب',
      badgeColor: 'bg-sky-500/20 text-sky-800 dark:text-sky-200 border border-sky-500/40 font-black',
      iconBg: 'bg-gradient-to-tr from-sky-500 to-blue-600 text-white shadow-md',
      accentColor: '#0284c7',
    };
  }
  return {
    icon: Shield,
    border: isSelected
      ? 'border-rose-500 ring-2 ring-rose-500/30 bg-gradient-to-b from-rose-500/15 via-rose-500/5 to-card'
      : 'border-rose-500/30 hover:border-rose-500/60 bg-gradient-to-b from-rose-500/5 to-card',
    color: 'text-rose-600 dark:text-rose-400',
    badge: 'وظيفة مخصصة',
    badgeColor: 'bg-rose-500/20 text-rose-800 dark:text-rose-200 border border-rose-500/40 font-black',
    iconBg: 'bg-gradient-to-tr from-rose-500 to-pink-600 text-white shadow-md',
    accentColor: '#e11d48',
  };
}

// دالة مساعدة لتنسيق شارات الأزرار والإجراءات بألوان احترافية ومتباينة
function getActionStyle(kind: ActionKind, isChecked: boolean) {
  if (!isChecked) {
    switch (kind) {
      case 'view':
        return 'bg-sky-500/5 text-sky-700 dark:text-sky-300 border-sky-400/30 hover:bg-sky-500/15 font-bold';
      case 'add':
        return 'bg-emerald-500/5 text-emerald-700 dark:text-emerald-300 border-emerald-400/30 hover:bg-emerald-500/15 font-bold';
      case 'edit':
        return 'bg-amber-500/5 text-amber-800 dark:text-amber-200 border-amber-400/30 hover:bg-amber-500/15 font-bold';
      case 'delete':
        return 'bg-rose-500/5 text-rose-700 dark:text-rose-300 border-rose-400/30 hover:bg-rose-500/15 font-bold';
      case 'print':
        return 'bg-purple-500/5 text-purple-700 dark:text-purple-300 border-purple-400/30 hover:bg-purple-500/15 font-bold';
      case 'export':
        return 'bg-teal-500/5 text-teal-700 dark:text-teal-300 border-teal-400/30 hover:bg-teal-500/15 font-bold';
      default:
        return 'bg-card text-muted-foreground border-border/80 hover:bg-muted/40 font-bold';
    }
  }

  switch (kind) {
    case 'view':
      return 'bg-gradient-to-r from-sky-500 to-blue-600 text-white border-sky-600 shadow-md font-black';
    case 'add':
      return 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white border-emerald-600 shadow-md font-black';
    case 'edit':
      return 'bg-gradient-to-r from-amber-500 to-orange-500 text-white border-amber-600 shadow-md font-black';
    case 'delete':
      return 'bg-gradient-to-r from-rose-600 to-red-600 text-white border-rose-700 shadow-md font-black';
    case 'print':
      return 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white border-purple-700 shadow-md font-black';
    case 'export':
      return 'bg-gradient-to-r from-teal-500 to-cyan-600 text-white border-teal-600 shadow-md font-black';
    default:
      return 'bg-gradient-to-r from-primary to-blue-600 text-white border-primary shadow-md font-black';
  }
}

// دالة لحساب عدد الصلاحيات الممنوحة
function countRolePermissions(perms?: DeviceRolePermissions) {
  if (!perms || !perms.pages) return { total: 0, granted: 0, percent: 0 };
  let total = 0;
  let granted = 0;

  PERMISSION_MODULES_CONFIG.forEach(mod => {
    mod.actions.forEach(act => {
      total++;
      if (perms.pages[mod.id]?.[act.key]) {
        granted++;
      }
    });
  });

  const percent = total > 0 ? Math.round((granted / total) * 100) : 0;
  return { total, granted, percent };
}

export default function DeviceRolesManager() {
  const {
    currentRoleId,
    currentRole,
    roles,
    setDeviceRole,
    resetDeviceRole,
    saveRole,
    removeRole,
  } = useDeviceRole();

  // حالة تعيين وظيفة الجهاز
  const [selectedRoleForThisDevice, setSelectedRoleForThisDevice] = useState<string>(() => currentRoleId || 'general_manager');
  const [devicePin, setDevicePin] = useState('');
  const [showDevicePin, setShowDevicePin] = useState(false);
  const [assigningDevice, setAssigningDevice] = useState(false);

  // حالة إعادة تعيين الجهاز
  const [showResetModal, setShowResetModal] = useState(false);
  const [resetPin, setResetPin] = useState('');
  const [resetting, setResetting] = useState(false);

  // حالة تعديل/إنشاء وظيفة
  const [editingRole, setEditingRole] = useState<DeviceRole | null>(null);
  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [roleFormName, setRoleFormName] = useState('');
  const [roleFormDesc, setRoleFormDesc] = useState('');
  const [roleFormId, setRoleFormId] = useState('');
  const [roleFormPerms, setRoleFormPerms] = useState<DeviceRolePermissions>({ pages: {} as any });
  const [roleFormPasscode, setRoleFormPasscode] = useState('');
  const [showRolePasscode, setShowRolePasscode] = useState(false);
  const [roleFormActive, setRoleFormActive] = useState(true);
  const [rolePin, setRolePin] = useState('');
  const [savingRole, setSavingRole] = useState(false);
  const [showRoleDetailsAccordion, setShowRoleDetailsAccordion] = useState(false);

  // نافذة سريعة لإعادة تعيين رمز المرور لوظيفة معينة
  const [roleForPasscodeChange, setRoleForPasscodeChange] = useState<DeviceRole | null>(null);
  const [newPasscode, setNewPasscode] = useState('');
  const [passcodeAdminPin, setPasscodeAdminPin] = useState('');
  const [updatingPasscode, setUpdatingPasscode] = useState(false);

  // تبويب الأقسام داخل المودال
  const [activeCategoryTab, setActiveCategoryTab] = useState<string>('all');

  // حالة حذف وظيفة
  const [roleToDelete, setRoleToDelete] = useState<DeviceRole | null>(null);
  const [deletePin, setDeletePin] = useState('');
  const [deletingRole, setDeletingRole] = useState(false);

  // تصفية الموديولات حسب التبويب النشط
  const filteredModules = useMemo(() => {
    if (activeCategoryTab === 'all') return PERMISSION_MODULES_CONFIG;
    return PERMISSION_MODULES_CONFIG.filter(m => m.category === activeCategoryTab);
  }, [activeCategoryTab]);

  const editingPermStats = useMemo(() => {
    return countRolePermissions(roleFormPerms);
  }, [roleFormPerms]);

  const targetSelectedRole = roles.find(r => r.id === selectedRoleForThisDevice) || roles[0];

  // تعيين وظيفة هذا الجهاز
  const handleAssignDeviceRole = async (targetRoleId?: string) => {
    const roleId = targetRoleId || selectedRoleForThisDevice;
    const roleObj = roles.find(r => r.id === roleId);

    if (!devicePin.trim()) {
      toast.error(`يرجى إدخال رمز المرور الخاص بـ (${roleObj?.name || 'الوظيفة'})`);
      return;
    }
    setAssigningDevice(true);
    try {
      const res = await setDeviceRole(roleId, devicePin);
      if (res.success) {
        toast.success(`تم تثبيت وظيفة (${roleObj?.name}) على هذا الجهاز بنجاح محلياً وبشكل دائم`);
        setDevicePin('');
      } else {
        toast.error(res.message || 'رمز المرور غير صحيح');
      }
    } catch {
      toast.error('حدث خطأ أثناء تثبيت وظيفة الجهاز');
    } finally {
      setAssigningDevice(false);
    }
  };

  // إعادة تعيين وظيفة الجهاز
  const handleConfirmResetDevice = async () => {
    if (!resetPin.trim()) {
      toast.error('يرجى إدخال رمز الأمان للوظيفة الحالية أو الرمز العام (5224410)');
      return;
    }
    setResetting(true);
    try {
      const res = await resetDeviceRole(resetPin);
      if (res.success) {
        toast.success('تمت إعادة تعيين وظيفة الجهاز بنجاح');
        setShowResetModal(false);
        setResetPin('');
      } else {
        toast.error(res.message || 'رمز الأمان غير صحيح');
      }
    } catch {
      toast.error('حدث خطأ أثناء إعادة تعيين الجهاز');
    } finally {
      setResetting(false);
    }
  };

  // فتح نافذة إنشاء وظيفة جديدة
  const handleOpenCreateRole = () => {
    setIsCreatingNew(true);
    setRoleFormId(`role_${Date.now()}`);
    setRoleFormName('');
    setRoleFormDesc('');
    setRoleFormActive(true);
    setRoleFormPasscode('');
    setShowRolePasscode(false);
    setRolePin('');
    setActiveCategoryTab('all');
    setShowRoleDetailsAccordion(true);

    const defaultPages: Record<string, Record<string, boolean>> = {};
    PERMISSION_MODULES_CONFIG.forEach(m => {
      defaultPages[m.id] = { view: false };
    });
    defaultPages.system_settings = { view: true };
    setRoleFormPerms({ pages: defaultPages as any });
    setEditingRole({
      id: `role_${Date.now()}`,
      name: '',
      description: null,
      is_system: false,
      is_active: true,
      permissions: { pages: defaultPages as any },
    });
  };

  // فتح نافذة تعديل وظيفة
  const handleOpenEditRole = (role: DeviceRole) => {
    setIsCreatingNew(false);
    setRoleFormId(role.id);
    setRoleFormName(role.name);
    setRoleFormDesc(role.description || '');
    setRoleFormActive(role.is_active);
    setRoleFormPasscode(role.passcode || '');
    setShowRolePasscode(false);
    setRolePin('');
    setActiveCategoryTab('all');
    setShowRoleDetailsAccordion(false);
    setRoleFormPerms(JSON.parse(JSON.stringify(role.permissions)));
    setEditingRole(role);
  };

  // تبديل صلاحية مفردة
  const handleTogglePerm = (moduleId: string, actionKey: string) => {
    setRoleFormPerms(prev => {
      const pages = { ...prev.pages };
      const currentMod = { ...(pages[moduleId] || {}) };
      currentMod[actionKey] = !currentMod[actionKey];

      if (actionKey !== 'view' && currentMod[actionKey] && !currentMod.view) {
        currentMod.view = true;
      }

      pages[moduleId] = currentMod;
      return { ...prev, pages };
    });
  };

  // تفعيل كافة صلاحيات موديول محدد
  const handleToggleModuleAll = (moduleId: string, enable: boolean) => {
    const mod = PERMISSION_MODULES_CONFIG.find(m => m.id === moduleId);
    if (!mod) return;

    setRoleFormPerms(prev => {
      const pages = { ...prev.pages };
      const currentMod = { ...(pages[moduleId] || {}) };
      mod.actions.forEach(a => {
        currentMod[a.key] = enable;
      });
      if (moduleId === 'system_settings' && !enable) {
        currentMod.view = true;
      }
      pages[moduleId] = currentMod;
      return { ...prev, pages };
    });
  };

  // تفعيل كافة موديولات القسم النشط
  const handleToggleCategoryAll = (catId: string, enable: boolean) => {
    const targetModules = catId === 'all'
      ? PERMISSION_MODULES_CONFIG
      : PERMISSION_MODULES_CONFIG.filter(m => m.category === catId);

    setRoleFormPerms(prev => {
      const pages = { ...prev.pages };
      targetModules.forEach(mod => {
        const currentMod = { ...(pages[mod.id] || {}) };
        mod.actions.forEach(a => {
          currentMod[a.key] = enable;
        });
        if (mod.id === 'system_settings' && !enable) {
          currentMod.view = true;
        }
        pages[mod.id] = currentMod;
      });
      return { ...prev, pages };
    });
  };

  // منح كامل الصلاحيات
  const handleGrantAll = () => {
    const allPages: Record<string, Record<string, boolean>> = {};
    PERMISSION_MODULES_CONFIG.forEach(m => {
      allPages[m.id] = {};
      m.actions.forEach(a => {
        allPages[m.id][a.key] = true;
      });
    });
    setRoleFormPerms({ pages: allPages as any });
    toast.success('تم تفعيل كامل الصلاحيات');
  };

  // تفعيل صلاحيات القراءة والعرض فقط
  const handleGrantReadOnly = () => {
    const readOnlyPages: Record<string, Record<string, boolean>> = {};
    PERMISSION_MODULES_CONFIG.forEach(m => {
      readOnlyPages[m.id] = {};
      m.actions.forEach(a => {
        if (a.kind === 'view' || a.kind === 'print' || a.kind === 'export') {
          readOnlyPages[m.id][a.key] = true;
        } else {
          readOnlyPages[m.id][a.key] = false;
        }
      });
    });
    readOnlyPages.system_settings = { view: true };
    setRoleFormPerms({ pages: readOnlyPages as any });
    toast.info('تم ضبط الصلاحيات على وضع القراءة والعرض والطباعة فقط');
  };

  // سحب كل الصلاحيات
  const handleRevokeAll = () => {
    const emptyPages: Record<string, Record<string, boolean>> = {};
    PERMISSION_MODULES_CONFIG.forEach(m => {
      emptyPages[m.id] = {};
      m.actions.forEach(a => {
        emptyPages[m.id][a.key] = false;
      });
    });
    emptyPages.system_settings = { view: true };
    setRoleFormPerms({ pages: emptyPages as any });
    toast.warning('تم سحب كافة الصلاحيات');
  };

  // حفظ الوظيفة والصلاحيات
  const handleSaveRoleSubmit = async () => {
    if (!roleFormName.trim()) {
      toast.error('يرجى كتابة اسم الوظيفة');
      return;
    }
    if (!rolePin.trim()) {
      toast.error('يرجى إدخال رمز الأمان للمدير العام (5224410) لتأكيد الحفظ');
      return;
    }

    setSavingRole(true);
    try {
      const res = await saveRole({
        id: roleFormId,
        name: roleFormName.trim(),
        description: roleFormDesc.trim() || null,
        permissions: roleFormPerms,
        passcode: roleFormPasscode.trim() || null,
        is_active: roleFormActive,
      }, rolePin);

      if (res.success) {
        toast.success(isCreatingNew ? 'تم إنشاء الوظيفة بنجاح' : 'تم حفظ الصلاحيات ورمز المرور بنجاح');
        setEditingRole(null);
      } else {
        toast.error(res.message || 'رمز الأمان غير صحيح');
      }
    } catch {
      toast.error('حدث خطأ أثناء حفظ الوظيفة');
    } finally {
      setSavingRole(false);
    }
  };

  // حفظ التعديل السريع لرمز مرور الوظيفة
  const handleQuickUpdatePasscode = async () => {
    if (!roleForPasscodeChange) return;
    if (!newPasscode.trim()) {
      toast.error('يرجى إدخال رمز المرور الجديد');
      return;
    }
    if (!passcodeAdminPin.trim()) {
      toast.error('يرجى إدخال رمز الأمان للمدير العام (5224410)');
      return;
    }

    setUpdatingPasscode(true);
    try {
      const res = await saveRole({
        ...roleForPasscodeChange,
        passcode: newPasscode.trim(),
      }, passcodeAdminPin);

      if (res.success) {
        toast.success(`تم تحديث رمز مرور وظيفة (${roleForPasscodeChange.name}) بنجاح`);
        setRoleForPasscodeChange(null);
        setNewPasscode('');
        setPasscodeAdminPin('');
      } else {
        toast.error(res.message || 'رمز الأمان غير صحيح');
      }
    } catch {
      toast.error('حدث خطأ أثناء تحديث رمز المرور');
    } finally {
      setUpdatingPasscode(false);
    }
  };

  // تأكيد حذف وظيفة
  const handleConfirmDeleteRole = async () => {
    if (!roleToDelete) return;
    if (!deletePin.trim()) {
      toast.error('يرجى إدخال رمز الأمان للمدير العام (5224410)');
      return;
    }

    setDeletingRole(true);
    try {
      const res = await removeRole(roleToDelete.id, deletePin);
      if (res.success) {
        toast.success('تم حذف الوظيفة بنجاح');
        setRoleToDelete(null);
        setDeletePin('');
      } else {
        toast.error(res.message || 'رمز الأمان غير صحيح');
      }
    } catch {
      toast.error('حدث خطأ أثناء حذف الوظيفة');
    } finally {
      setDeletingRole(false);
    }
  };

  return (
    <div className="space-y-6" dir="rtl">
      {/* ── البطاقة العلوية: تحديد وظيفة هذا الجهاز ───────────────────────── */}
      <Card className="border-2 border-primary/20 bg-card shadow-md overflow-hidden rounded-2xl transition-all">
        <div className="bg-gradient-to-r from-primary/15 via-primary/5 to-transparent p-4 sm:p-5 border-b border-border/60">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-primary/20 border border-primary/30 flex items-center justify-center shrink-0 shadow-inner">
                <Laptop className="w-5 h-5 text-primary" />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-base sm:text-lg font-black text-foreground">تحديد وظيفة هذا الجهاز</h3>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-primary/15 text-primary border border-primary/25">
                    حفظ دائم بالجهاز
                  </span>
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">
                  تُحفظ وظيفة هذا الجهاز محلياً حتى بعد إغلاق المتصفح أو إعادة تشغيل الحاسوب
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 self-start sm:self-center bg-card/80 border border-border/80 px-3 py-1.5 rounded-xl shadow-xs">
              <span className="text-[11px] font-bold text-muted-foreground">الوظيفة الفعالة:</span>
              <span className="px-2.5 py-0.5 rounded-lg text-xs font-black bg-primary text-primary-foreground shadow-xs flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                {currentRole ? currentRole.name : 'المدير العام'}
              </span>
            </div>
          </div>
        </div>

        <CardContent className="p-4 sm:p-5 space-y-5">
          {/* شبكة اختيار الوظيفة بصرياً بنقرة واحدة */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <Label className="text-xs font-black text-foreground flex items-center gap-1.5">
                <Shield className="w-4 h-4 text-primary" />
                <span>اختر الوظيفة المراد تثبيتها لهذا الجهاز:</span>
              </Label>
              <span className="text-[11px] text-muted-foreground font-medium">
                (اضغط لاختيار الوظيفة وتفعيلها)
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
              {roles.filter(r => r.is_active).map(r => {
                const isSelected = selectedRoleForThisDevice === r.id;
                const isThisCurrent = currentRoleId === r.id;
                const stats = countRolePermissions(r.permissions);
                const visual = getRoleVisuals(r.id, isSelected);
                const IconComponent = visual.icon;

                return (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => {
                      setSelectedRoleForThisDevice(r.id);
                      setDevicePin('');
                    }}
                    className={`text-right p-4 rounded-2xl border-2 transition-all relative flex flex-col justify-between select-none active:scale-[0.98] shadow-xs hover:shadow-md ${
                      visual.border
                    }`}
                  >
                    <div>
                      <div className="flex items-start justify-between gap-1.5 mb-2.5">
                        <div className="flex items-center gap-2.5">
                          <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${visual.iconBg}`}>
                            <IconComponent className="w-4 h-4 stroke-[2.5]" />
                          </div>
                          <div>
                            <span className="text-xs font-black block leading-tight text-foreground">
                              {r.name}
                            </span>
                            <span className={`text-[9px] px-2 py-0.5 rounded-full inline-block mt-1 ${visual.badgeColor}`}>
                              {visual.badge}
                            </span>
                          </div>
                        </div>

                        {isThisCurrent && (
                          <span className="text-[9px] font-black px-2 py-0.5 rounded-full bg-emerald-500 text-white shadow-xs shrink-0 animate-pulse">
                            مُثبّت بالجهاز
                          </span>
                        )}
                      </div>

                      <p className="text-[11px] text-muted-foreground line-clamp-2 leading-relaxed">
                        {r.description || 'صلاحيات مخصصة للنظام وفق مسؤوليات هذا القسم.'}
                      </p>
                    </div>

                    <div className="mt-3 pt-2.5 border-t border-border/60 flex items-center justify-between text-[10px]">
                      <span className="text-muted-foreground font-semibold">
                        {stats.granted} من {stats.total} صلاحية
                      </span>
                      <span className="font-black font-mono text-xs px-1.5 py-0.5 rounded-md bg-muted text-foreground" style={{ color: visual.accentColor }}>
                        {stats.percent}%
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* صف تأكيد الحفظ برمز المرور الخاص بالوظيفة */}
          <div className="bg-muted/40 border-2 border-border/80 rounded-2xl p-4 sm:p-5 space-y-3.5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
              <Label className="text-xs font-black text-foreground flex items-center gap-1.5">
                <KeyRound className="w-4 h-4 text-primary" />
                <span>رمز المرور الخاص بوظيفة ({targetSelectedRole?.name}):</span>
              </Label>
              <span className="text-[11px] text-muted-foreground">
                (الرمز الافتراضي أو رمز المدير العام: 5224410)
              </span>
            </div>

            <div className="relative">
              <Input
                type={showDevicePin ? 'text' : 'password'}
                inputMode="numeric"
                pattern="[0-9]*"
                autoComplete="one-time-code"
                placeholder="أدخل رمز المرور لتثبيت الوظيفة..."
                value={devicePin}
                onChange={(e) => setDevicePin(normalizeArabicNumerals(e.target.value).replace(/\D/g, ''))}
                className="h-11 font-mono tracking-widest text-center text-base bg-background border-2 border-primary/30 focus-visible:border-primary shadow-xs pl-11"
                dir="ltr"
              />
              <button
                type="button"
                onClick={() => setShowDevicePin(v => !v)}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground p-1 transition-colors"
                title={showDevicePin ? 'إخفاء الرمز' : 'إظهار الرمز'}
              >
                {showDevicePin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>

            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
              <Button
                onClick={() => handleAssignDeviceRole()}
                disabled={assigningDevice || !devicePin.trim()}
                className="h-11 font-black gap-2 shadow-lg bg-gradient-to-r from-blue-600 via-primary to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white text-sm flex-1 sm:flex-initial px-7 border-0"
              >
                <CheckCircle2 className="w-4 h-4" />
                {assigningDevice ? 'جاري التحقق والتثبيت...' : 'تثبيت وظيفة هذا الجهاز'}
              </Button>

              <Button
                variant="outline"
                onClick={() => setShowResetModal(true)}
                className="h-11 border-rose-500/40 text-rose-600 dark:text-rose-400 bg-rose-500/5 hover:bg-rose-500/20 font-bold gap-1.5 text-xs self-stretch sm:self-auto"
                title="إعادة تعيين وظيفة الجهاز لإعادته إلى شاشة الاختيار الأولية"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                إعادة تعيين وظيفة الجهاز
              </Button>
            </div>
          </div>

          <div className="bg-primary/5 border border-primary/20 rounded-xl p-3 flex items-start gap-2.5 text-xs text-muted-foreground">
            <Info className="w-4 h-4 text-primary shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              <strong>حفظ محلي ودائم:</strong> يتم حفظ وظيفة الجهاز في التخزين المحلي وملفات تعريف الارتباط الخاصة بالمتصفح، مما يضمن بقاء الجهاز مهيأً دائماً عند فتحه دون الحاجة لتكرار تسجيل الدخول.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* ── البطاقة السفلية: إدارة وتخصيص الوظائف والصلاحيات ─────────────── */}
      <Card className="border border-border/80 shadow-sm rounded-2xl overflow-hidden">
        <CardHeader className="pb-3 pt-4 px-4 sm:px-5 border-b border-border/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-muted/20">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <CardTitle className="text-sm sm:text-base font-black">إدارة الوظائف ورموز المرور والصلاحيات</CardTitle>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20">
                  {roles.length} وظائف معرفة
                </span>
              </div>
              <p className="text-xs text-muted-foreground mt-0.5">
                تخصيص دقيق ومفصل لكل صفحة وإجراء، مع تعيين رمز مرور مستقل لكل وظيفة
              </p>
            </div>
          </div>

          <Button onClick={handleOpenCreateRole} className="h-9 font-black gap-2 bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm self-start sm:self-auto">
            <Plus className="w-4 h-4" />
            إنشاء وظيفة جديدة
          </Button>
        </CardHeader>

        <CardContent className="p-4 sm:p-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {roles.map((role) => {
              const isCurrent = role.id === currentRoleId;
              const stats = countRolePermissions(role.permissions);
              const visual = getRoleVisuals(role.id, isCurrent);
              const IconComp = visual.icon;

              return (
                <div
                  key={role.id}
                  className={`border-2 rounded-2xl p-4 transition-all relative flex flex-col justify-between shadow-xs hover:shadow-md ${
                    isCurrent
                      ? visual.border + ' shadow-sm'
                      : 'border-border/80 hover:border-border bg-card'
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-start gap-2.5 min-w-0">
                        <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${visual.iconBg}`}>
                          <IconComp className="w-4 h-4 stroke-[2.5]" />
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <h4 className="text-sm font-black text-foreground">{role.name}</h4>
                            <span className={`text-[10px] px-2 py-0.5 rounded-full ${visual.badgeColor}`}>
                              {visual.badge}
                            </span>
                            {isCurrent && (
                              <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-500 text-white shadow-xs flex items-center gap-1">
                                <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                                جهازك الحالي
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground mt-1 line-clamp-2 min-h-[32px] leading-relaxed">
                            {role.description || 'لا يوجد وصف محدد لهذه الوظيفة.'}
                          </p>
                        </div>
                      </div>

                      <span className={`text-[10px] font-black px-2 py-0.5 rounded-md border shrink-0 ${
                        role.is_active
                          ? 'text-emerald-700 dark:text-emerald-300 bg-emerald-500/15 border-emerald-500/40'
                          : 'text-muted-foreground bg-muted border-border'
                      }`}>
                        {role.is_active ? 'نشطة' : 'معطلة'}
                      </span>
                    </div>

                    <div className="bg-muted/40 rounded-xl p-3 border border-border/60 space-y-2">
                      <div className="flex items-center justify-between text-xs font-semibold">
                        <span className="text-muted-foreground text-[11px] flex items-center gap-1">
                          <Sliders className="w-3.5 h-3.5 text-primary" />
                          مستوى الصلاحيات:
                        </span>
                        <span className="font-black font-mono text-[11px]" style={{ color: visual.accentColor }}>
                          {stats.granted} من {stats.total} إجراء ({stats.percent}%)
                        </span>
                      </div>
                      <div className="w-full bg-border/50 h-2 rounded-full overflow-hidden">
                        <div
                          className="h-full transition-all duration-300 rounded-full"
                          style={{
                            width: `${stats.percent}%`,
                            background: `linear-gradient(90deg, ${visual.accentColor}, #2563eb)`
                          }}
                        />
                      </div>

                      <div className="pt-1.5 flex items-center justify-between text-[11px] border-t border-border/40">
                        <span className="text-muted-foreground flex items-center gap-1">
                          <KeyRound className="w-3 h-3 text-amber-500" />
                          رمز مرور الوظيفة:
                        </span>
                        <span className="font-mono font-black text-foreground">
                          {role.passcode ? '••••••' : 'افتراضي (معين)'}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-3 mt-3 border-t border-border/50 grid grid-cols-2 gap-2">
                    <Button
                      variant="default"
                      size="sm"
                      onClick={() => handleOpenEditRole(role)}
                      className="gap-1.5 text-xs font-black h-9 bg-gradient-to-r from-primary to-blue-600 hover:from-primary/90 hover:to-blue-700 text-white shadow-md border-0"
                    >
                      <Sliders className="w-3.5 h-3.5" />
                      تخصيص الصلاحيات
                    </Button>

                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setRoleForPasscodeChange(role);
                        setNewPasscode(role.passcode || '');
                        setPasscodeAdminPin('');
                      }}
                      className="gap-1 text-xs font-black h-9 bg-amber-500/10 border-amber-500/40 text-amber-700 dark:text-amber-300 hover:bg-amber-500/20"
                      title="إعادة تعيين أو تعديل رمز المرور لهذه الوظيفة"
                    >
                      <Key className="w-3.5 h-3.5 text-amber-500" />
                      تعديل الرمز
                    </Button>

                    {!isCurrent && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setSelectedRoleForThisDevice(role.id);
                          toast.info(`تم اختيار ${role.name}. أدخل رمز المرور بالأعلى لتثبيتها على هذا الجهاز`);
                        }}
                        className="text-xs font-black h-9 bg-sky-500/10 border-sky-500/40 text-sky-700 dark:text-sky-300 hover:bg-sky-500/20 col-span-2"
                        title="اختيار هذه الوظيفة لتثبيتها على هذا الجهاز"
                      >
                        <Laptop className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400" />
                        اختيار لتثبيتها على هذا الجهاز
                      </Button>
                    )}

                    {!role.is_system && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => { setRoleToDelete(role); setDeletePin(''); }}
                        className="text-rose-600 dark:text-rose-400 hover:bg-rose-500/15 border border-rose-500/20 text-xs font-bold h-9 col-span-2"
                        title="حذف الوظيفة المخصصة"
                      >
                        <Trash2 className="w-3.5 h-3.5 mr-1" />
                        حذف هذه الوظيفة
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* ── نافذة تخصيص الصلاحيات المتجاوبة بالكامل مع الهواتف الذكية ───────── */}
      {editingRole && (
        <Dialog open={Boolean(editingRole)} onOpenChange={(val) => { if (!val) setEditingRole(null); }}>
          <DialogContent
            className="max-w-[calc(100%-1rem)] sm:max-w-4xl h-[94dvh] max-h-[94dvh] p-0 gap-0 rounded-2xl shadow-2xl flex flex-col overflow-hidden border-2 border-primary/30"
            dir="rtl"
          >
            {/* 1. رأس النافذة الثابت المدمج والمثالي للموبايل والديسكتوب */}
            <div className="bg-gradient-to-r from-primary via-primary/95 to-primary/90 text-primary-foreground px-4 py-3 shrink-0 border-b border-primary/40 shadow-xs">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  <div className="w-8 h-8 rounded-xl bg-white/15 border border-white/20 flex items-center justify-center shrink-0">
                    <Sliders className="w-4 h-4 text-white" />
                  </div>
                  <div className="min-w-0">
                    <DialogTitle className="text-sm sm:text-base font-black text-white truncate">
                      {isCreatingNew ? 'إنشاء وظيفة وتخصيص صلاحياتها' : `تخصيص: ${editingRole.name}`}
                    </DialogTitle>
                    <div className="flex items-center gap-2 text-[11px] text-white/80">
                      <span>المفعل:</span>
                      <strong className="text-white font-mono">{editingPermStats.granted}/{editingPermStats.total}</strong>
                      <span className="bg-white/20 px-1.5 py-0.2 rounded font-mono text-[10px] text-white font-black">
                        {editingPermStats.percent}%
                      </span>
                    </div>
                  </div>
                </div>

                {/* أزرار الإجراء السريع الملونة والبارزة */}
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={handleGrantAll}
                    className="h-8 px-2.5 sm:px-3 text-xs font-black rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white flex items-center gap-1.5 active:scale-95 transition-all shadow-md"
                    title="تفعيل كافة الصلاحيات"
                  >
                    <Zap className="w-3.5 h-3.5 text-amber-300" />
                    <span className="hidden xs:inline">منح</span> الكل
                  </button>
                  <button
                    type="button"
                    onClick={handleGrantReadOnly}
                    className="h-8 px-2.5 sm:px-3 text-xs font-black rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 text-white flex items-center gap-1.5 active:scale-95 transition-all shadow-md"
                    title="قراءة وعرض فقط"
                  >
                    <Eye className="w-3.5 h-3.5 text-sky-200" />
                    <span className="hidden sm:inline">قراءة</span> فقط
                  </button>
                  <button
                    type="button"
                    onClick={handleRevokeAll}
                    className="h-8 px-2.5 text-xs font-black rounded-xl bg-rose-500/25 hover:bg-rose-500/35 border border-rose-400/50 text-white flex items-center gap-1.5 active:scale-95 transition-all shadow-xs"
                    title="سحب كافة الصلاحيات"
                  >
                    <X className="w-3.5 h-3.5 text-rose-300" />
                    سحب
                  </button>
                </div>
              </div>
            </div>

            {/* 2. شريط التبويبات الملونة القابل للتمرير السلس */}
            <div className="bg-muted/40 border-b border-border/80 px-3 py-2.5 shrink-0 flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none flex-1 py-0.5">
                {PERMISSION_CATEGORIES.map(cat => {
                  const Icon = cat.icon;
                  const isActive = activeCategoryTab === cat.id;
                  const catModules = cat.id === 'all'
                    ? PERMISSION_MODULES_CONFIG
                    : PERMISSION_MODULES_CONFIG.filter(m => m.category === cat.id);

                  let catGranted = 0;
                  let catTotal = 0;
                  catModules.forEach(m => {
                    m.actions.forEach(a => {
                      catTotal++;
                      if (roleFormPerms.pages?.[m.id]?.[a.key]) catGranted++;
                    });
                  });

                  // توليد ألوان مخصصة لكل تبويب
                  let tabColorClass = 'bg-background text-muted-foreground border-border/70 hover:bg-muted hover:text-foreground';
                  if (isActive) {
                    switch (cat.id) {
                      case 'students':
                        tabColorClass = 'bg-gradient-to-r from-sky-600 to-blue-600 text-white border-sky-600 shadow-sm';
                        break;
                      case 'finance':
                        tabColorClass = 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white border-emerald-600 shadow-sm';
                        break;
                      case 'academic':
                        tabColorClass = 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white border-purple-600 shadow-sm';
                        break;
                      case 'archive':
                        tabColorClass = 'bg-gradient-to-r from-cyan-600 to-sky-700 text-white border-cyan-600 shadow-sm';
                        break;
                      case 'system':
                        tabColorClass = 'bg-gradient-to-r from-rose-600 to-red-600 text-white border-rose-600 shadow-sm';
                        break;
                      default:
                        tabColorClass = 'bg-gradient-to-r from-slate-700 to-slate-900 text-white border-slate-700 shadow-sm';
                    }
                  } else {
                    switch (cat.id) {
                      case 'students':
                        tabColorClass = 'bg-sky-500/10 text-sky-800 dark:text-sky-200 border-sky-500/30 hover:bg-sky-500/20';
                        break;
                      case 'finance':
                        tabColorClass = 'bg-emerald-500/10 text-emerald-800 dark:text-emerald-200 border-emerald-500/30 hover:bg-emerald-500/20';
                        break;
                      case 'academic':
                        tabColorClass = 'bg-purple-500/10 text-purple-800 dark:text-purple-200 border-purple-500/30 hover:bg-purple-500/20';
                        break;
                      case 'archive':
                        tabColorClass = 'bg-cyan-500/10 text-cyan-800 dark:text-cyan-200 border-cyan-500/30 hover:bg-cyan-500/20';
                        break;
                      case 'system':
                        tabColorClass = 'bg-rose-500/10 text-rose-800 dark:text-rose-200 border-rose-500/30 hover:bg-rose-500/20';
                        break;
                      default:
                        tabColorClass = 'bg-card text-foreground border-border/70 hover:bg-muted';
                    }
                  }

                  return (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setActiveCategoryTab(cat.id)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black transition-all shrink-0 border select-none active:scale-95 ${tabColorClass}`}
                    >
                      <Icon className="w-3.5 h-3.5 shrink-0" />
                      <span className="whitespace-nowrap">{cat.label}</span>
                      <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-black ${
                        isActive ? 'bg-white/25 text-white' : 'bg-muted/80 text-foreground'
                      }`}>
                        {catGranted}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* أزرار سريعة للقسم المفتوح */}
              <div className="hidden sm:flex items-center gap-1.5 shrink-0">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => handleToggleCategoryAll(activeCategoryTab, true)}
                  className="h-8 text-xs font-black px-2.5 bg-primary/10 border-primary/40 text-primary hover:bg-primary/20"
                >
                  تفعيل القسم
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => handleToggleCategoryAll(activeCategoryTab, false)}
                  className="h-8 text-xs font-black px-2.5 bg-muted/60 border-border text-muted-foreground hover:bg-muted"
                >
                  إلغاء القسم
                </Button>
              </div>
            </div>

            {/* 3. جسم النافذة القابل للتمرير والمصمم خصيصاً للموبايل */}
            <div className="flex-1 overflow-y-auto min-h-0 p-3 sm:p-5 space-y-3">
              {/* قسم قابل للطي: بيانات الوظيفة ورمز المرور لعدم حجب مساحة الشاشة على الهاتف */}
              <div className="bg-muted/30 border border-border/80 rounded-2xl overflow-hidden shadow-2xs">
                <button
                  type="button"
                  onClick={() => setShowRoleDetailsAccordion(v => !v)}
                  className="w-full p-3 flex items-center justify-between text-right hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-primary" />
                    <span className="text-xs font-black text-foreground">بيانات الوظيفة ورمز المرور المستقل:</span>
                    <span className="text-[10px] font-bold text-muted-foreground font-mono bg-muted px-1.5 py-0.5 rounded">
                      {roleFormName || 'بدون اسم'}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 text-[11px] text-primary font-bold">
                    <span>{showRoleDetailsAccordion ? 'إخفاء التفاصيل' : 'تعديل البيانات والرمز'}</span>
                    {showRoleDetailsAccordion ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </div>
                </button>

                {showRoleDetailsAccordion && (
                  <div className="p-3 pt-0 border-t border-border/60 grid grid-cols-1 sm:grid-cols-3 gap-2.5 mt-2">
                    <div className="space-y-1">
                      <Label className="text-[11px] font-bold text-foreground">اسم الوظيفة:</Label>
                      <Input
                        placeholder="اسم الوظيفة..."
                        value={roleFormName}
                        onChange={(e) => setRoleFormName(e.target.value)}
                        className="h-9 text-xs font-bold bg-background"
                        required
                      />
                    </div>

                    <div className="space-y-1">
                      <Label className="text-[11px] font-bold text-foreground">نطاق المسؤوليات:</Label>
                      <Input
                        placeholder="وصف مختصر..."
                        value={roleFormDesc}
                        onChange={(e) => setRoleFormDesc(e.target.value)}
                        className="h-9 text-xs bg-background"
                      />
                    </div>

                    <div className="space-y-1">
                      <Label className="text-[11px] font-bold text-foreground flex items-center justify-between">
                        <span>رمز المرور المستقل:</span>
                        <span className="text-[10px] text-muted-foreground font-mono">(Passcode)</span>
                      </Label>
                      <div className="relative">
                        <Input
                          type={showRolePasscode ? 'text' : 'password'}
                          inputMode="numeric"
                          pattern="[0-9]*"
                          autoComplete="one-time-code"
                          placeholder="رمز مرور الوظيفة..."
                          value={roleFormPasscode}
                          onChange={(e) => setRoleFormPasscode(normalizeArabicNumerals(e.target.value).replace(/\D/g, ''))}
                          className="h-9 text-xs font-mono tracking-wider pl-8 bg-background border-amber-500/30"
                          dir="ltr"
                        />
                        <button
                          type="button"
                          onClick={() => setShowRolePasscode(v => !v)}
                          className="absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground p-1"
                        >
                          {showRolePasscode ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* أزرار سريعة للتحكم بالقسم المفتوح تظهر على الجوال */}
              <div className="flex sm:hidden items-center justify-between gap-2 px-1">
                <span className="text-[11px] font-black text-muted-foreground">
                  الموديولات المعروضة: ({filteredModules.length})
                </span>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => handleToggleCategoryAll(activeCategoryTab, true)}
                    className="text-[11px] font-black px-2.5 py-1 rounded-lg border border-primary/30 text-primary bg-primary/5 active:scale-95"
                  >
                    تفعيل القسم
                  </button>
                  <button
                    type="button"
                    onClick={() => handleToggleCategoryAll(activeCategoryTab, false)}
                    className="text-[11px] font-black px-2.5 py-1 rounded-lg border border-border text-muted-foreground bg-muted/40 active:scale-95"
                  >
                    إلغاء القسم
                  </button>
                </div>
              </div>

              {/* موديولات الصلاحيات بتصميم شبكي فائق التناسق على الموبايل */}
              <div className="space-y-2.5">
                {filteredModules.map((mod) => {
                  const modPerms = roleFormPerms.pages?.[mod.id] || {};
                  const isViewActive = Boolean(modPerms.view);
                  const modGrantedCount = mod.actions.filter(a => Boolean(modPerms[a.key])).length;
                  const isAllActiveInMod = modGrantedCount === mod.actions.length;

                  return (
                    <div
                      key={mod.id}
                      className={`border-2 rounded-2xl p-3 sm:p-4 transition-all duration-150 ${
                        isViewActive
                          ? 'border-primary/40 bg-card shadow-xs'
                          : 'border-border/60 bg-muted/20 opacity-80'
                      }`}
                    >
                      {/* رأس الموديول */}
                      <div className="flex items-center justify-between gap-2 pb-2.5 mb-2.5 border-b border-border/50">
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="text-xs sm:text-sm font-black text-foreground">{mod.label}</span>
                            <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded-md border ${
                              isAllActiveInMod
                                ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30'
                                : modGrantedCount > 0
                                ? 'bg-blue-500/15 text-blue-700 dark:text-blue-300 border-blue-500/30'
                                : 'bg-muted text-muted-foreground border-border'
                            }`}>
                              {modGrantedCount}/{mod.actions.length}
                            </span>
                          </div>
                          <p className="text-[11px] text-muted-foreground line-clamp-1 mt-0.5">
                            {mod.description}
                          </p>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleToggleModuleAll(mod.id, !isAllActiveInMod)}
                          className={`text-[10px] sm:text-xs font-black px-2.5 py-1 rounded-lg border transition-all shrink-0 active:scale-95 ${
                            isAllActiveInMod
                              ? 'bg-muted text-muted-foreground border-border'
                              : 'bg-primary/10 text-primary border-primary/30 hover:bg-primary/20'
                          }`}
                        >
                          {isAllActiveInMod ? 'إلغاء الكل' : 'تفعيل الكل'}
                        </button>
                      </div>

                      {/* أزرار الإجراءات المتجاوبة: شبكة من عمودين على الجوال وشبكة مرنة على الشاشات الكبيرة */}
                      <div className="grid grid-cols-2 sm:flex sm:flex-wrap gap-2">
                        {mod.actions.map((act) => {
                          const isChecked = Boolean(modPerms[act.key]);
                          const styleClass = getActionStyle(act.kind, isChecked);

                          return (
                            <button
                              key={act.key}
                              type="button"
                              onClick={() => handleTogglePerm(mod.id, act.key)}
                              className={`h-10 px-2.5 sm:px-3 rounded-xl text-xs flex items-center justify-between sm:justify-start gap-1.5 transition-all border-2 active:scale-95 select-none shadow-2xs ${styleClass}`}
                            >
                              <span className="truncate text-right font-bold text-[11px] sm:text-xs">
                                {act.label}
                              </span>
                              <div className={`w-4 h-4 rounded-md flex items-center justify-center shrink-0 border ${
                                isChecked ? 'bg-primary text-primary-foreground border-primary' : 'border-border/80 bg-background/50'
                              }`}>
                                {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 4. شريط الحفظ والتأكيد الثابت أسفل النافذة (دائماً ظاهر على الجوال دون الحاجة للتمرير) */}
            <div className="bg-card border-t-2 border-border/80 p-3 sm:p-4 shrink-0 shadow-lg">
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
                {/* حقل رمز المدير العام */}
                <div className="flex items-center gap-2 flex-1 min-w-0">
                  <KeyRound className="w-4 h-4 text-amber-500 shrink-0" />
                  <Input
                    type="password"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    autoComplete="one-time-code"
                    placeholder="رمز المدير العام (5224410) لتأكيد الحفظ..."
                    value={rolePin}
                    onChange={(e) => setRolePin(normalizeArabicNumerals(e.target.value).replace(/\D/g, ''))}
                    className="h-10 font-mono tracking-widest text-center text-xs sm:text-sm bg-muted/40 border-2 border-amber-500/40 focus-visible:border-amber-500"
                    dir="ltr"
                  />
                </div>

                {/* أزرار الإجراء */}
                <div className="flex items-center gap-2 shrink-0">
                  <Button
                    variant="outline"
                    onClick={() => setEditingRole(null)}
                    disabled={savingRole}
                    className="h-10 px-3.5 text-xs font-bold border-border"
                  >
                    إلغاء
                  </Button>
                  <Button
                    onClick={handleSaveRoleSubmit}
                    disabled={savingRole || !rolePin.trim()}
                    className="h-10 px-6 text-xs sm:text-sm font-black gap-2 bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white shadow-lg border-0 flex-1 sm:flex-initial"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    {savingRole ? 'جاري الحفظ...' : 'حفظ واعتماد الصلاحيات'}
                  </Button>
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* ── حوار التعديل السريع لرمز مرور الوظيفة ───────────────────────── */}
      {roleForPasscodeChange && (
        <Dialog open={Boolean(roleForPasscodeChange)} onOpenChange={(val) => { if (!val) setRoleForPasscodeChange(null); }}>
          <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md rounded-2xl" dir="rtl">
            <DialogHeader>
              <div className="w-12 h-12 rounded-2xl bg-amber-500/15 text-amber-600 flex items-center justify-center mb-2 mx-auto">
                <Key className="w-6 h-6" />
              </div>
              <DialogTitle className="text-center font-black text-lg">
                إعادة تعيين رمز مرور: {roleForPasscodeChange.name}
              </DialogTitle>
              <DialogDescription className="text-center text-xs leading-relaxed text-muted-foreground">
                حدد رمز المرور الذي سيطلبه الجهاز عند اختيار هذه الوظيفة.
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-3.5 py-3">
              <div className="space-y-1">
                <Label className="text-xs font-bold">رمز المرور الجديد لهذه الوظيفة:</Label>
                <Input
                  type="text"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  autoComplete="one-time-code"
                  placeholder="أدخل رمز المرور الجديد..."
                  value={newPasscode}
                  onChange={(e) => setNewPasscode(normalizeArabicNumerals(e.target.value).replace(/\D/g, ''))}
                  className="font-mono text-center tracking-widest text-base h-10 border-2"
                  dir="ltr"
                  autoFocus
                />
              </div>

              <div className="space-y-1">
                <Label className="text-xs font-bold flex items-center gap-1.5">
                  <KeyRound className="w-3.5 h-3.5 text-primary" />
                  <span>رمز الأمان للمدير العام (5224410):</span>
                </Label>
                <Input
                  type="password"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  autoComplete="one-time-code"
                  placeholder="أدخل رمز المدير العام لتأكيد التغيير..."
                  value={passcodeAdminPin}
                  onChange={(e) => setPasscodeAdminPin(normalizeArabicNumerals(e.target.value).replace(/\D/g, ''))}
                  className="font-mono text-center tracking-widest text-base h-10"
                  dir="ltr"
                />
              </div>
            </div>

            <DialogFooter className="gap-2">
              <Button variant="outline" onClick={() => setRoleForPasscodeChange(null)} disabled={updatingPasscode}>
                إلغاء
              </Button>
              <Button
                onClick={handleQuickUpdatePasscode}
                disabled={updatingPasscode || !newPasscode.trim() || !passcodeAdminPin.trim()}
                className="font-bold gap-1.5 bg-primary text-primary-foreground"
              >
                {updatingPasscode ? 'جاري التحديث...' : 'حفظ رمز المرور الجديد'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* ── حوار تأكيد إعادة تعيين الجهاز ─────────────────────────────────── */}
      {showResetModal && (
        <Dialog open={showResetModal} onOpenChange={setShowResetModal}>
          <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md rounded-2xl" dir="rtl">
            <DialogHeader>
              <div className="w-12 h-12 rounded-2xl bg-destructive/10 text-destructive flex items-center justify-center mb-2 mx-auto">
                <RotateCcw className="w-6 h-6 animate-spin-reverse" />
              </div>
              <DialogTitle className="text-center font-black text-lg">
                تأكيد إعادة تعيين وظيفة هذا الجهاز
              </DialogTitle>
              <DialogDescription className="text-center text-xs leading-relaxed text-muted-foreground">
                سيتم إزالة تعيين الوظيفة من الذاكرة المحلية لهذا الجهاز وإعادته إلى شاشة اختيار الوظيفة الأولية.
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-3 py-3">
              <Label className="text-xs font-bold flex items-center gap-1.5">
                <KeyRound className="w-3.5 h-3.5 text-primary" />
                <span>رمز المرور (رمز الوظيفة الحالية أو رمز المدير العام 5224410):</span>
              </Label>
              <Input
                type="password"
                inputMode="numeric"
                pattern="[0-9]*"
                autoComplete="one-time-code"
                placeholder="أدخل رمز المرور..."
                value={resetPin}
                onChange={(e) => setResetPin(normalizeArabicNumerals(e.target.value).replace(/\D/g, ''))}
                className="font-mono text-center tracking-widest text-base h-10"
                dir="ltr"
              />
            </div>

            <DialogFooter className="gap-2">
              <Button variant="outline" onClick={() => setShowResetModal(false)} disabled={resetting}>
                إلغاء
              </Button>
              <Button
                variant="destructive"
                onClick={handleConfirmResetDevice}
                disabled={resetting || !resetPin.trim()}
                className="font-bold gap-1.5"
              >
                {resetting ? 'جاري إعادة التعيين...' : 'تأكيد إعادة التعيين'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* ── حوار تأكيد حذف وظيفة مخصصة ───────────────────────────────────── */}
      {roleToDelete && (
        <Dialog open={Boolean(roleToDelete)} onOpenChange={(val) => { if (!val) setRoleToDelete(null); }}>
          <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md rounded-2xl" dir="rtl">
            <DialogHeader>
              <div className="w-12 h-12 rounded-2xl bg-destructive/10 text-destructive flex items-center justify-center mb-2 mx-auto">
                <Trash2 className="w-6 h-6" />
              </div>
              <DialogTitle className="text-center font-black text-lg">
                تأكيد حذف الوظيفة: {roleToDelete.name}
              </DialogTitle>
              <DialogDescription className="text-center text-xs leading-relaxed text-muted-foreground">
                سيتم حذف هذه الوظيفة نهائياً من النظام. الأجهزة التي كانت تستخدمها ستفقد صلاحياتها إلى حين تعيين وظيفة جديدة لها.
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-3 py-3">
              <Label className="text-xs font-bold flex items-center gap-1.5">
                <KeyRound className="w-3.5 h-3.5 text-primary" />
                <span>رمز الأمان للمدير العام (5224410):</span>
              </Label>
              <Input
                type="password"
                inputMode="numeric"
                pattern="[0-9]*"
                autoComplete="one-time-code"
                placeholder="أدخل رمز الأمان..."
                value={deletePin}
                onChange={(e) => setDeletePin(normalizeArabicNumerals(e.target.value).replace(/\D/g, ''))}
                className="font-mono text-center tracking-widest text-base h-10"
                dir="ltr"
              />
            </div>

            <DialogFooter className="gap-2">
              <Button variant="outline" onClick={() => setRoleToDelete(null)} disabled={deletingRole}>
                إلغاء
              </Button>
              <Button
                variant="destructive"
                onClick={handleConfirmDeleteRole}
                disabled={deletingRole || !deletePin.trim()}
                className="font-bold gap-1.5"
              >
                {deletingRole ? 'جاري الحذف...' : 'حذف الوظيفة نهائياً'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
