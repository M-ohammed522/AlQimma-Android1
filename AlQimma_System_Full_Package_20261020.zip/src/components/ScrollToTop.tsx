// مكوّن ScrollToTop — يُعيد التمرير إلى أعلى الصفحة عند كل تنقّل
import { useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';

export function ScrollToTop() {
  const { pathname } = useLocation();
  const mainRef = useRef<Element | null>(null);

  useEffect(() => {
    // محاولة 1: العنصر <main> داخل MainLayout (overflow-y-auto)
    if (!mainRef.current) {
      mainRef.current = document.querySelector('main');
    }
    if (mainRef.current) {
      mainRef.current.scrollTo({ top: 0, behavior: 'instant' });
    }
    // محاولة 2: نافذة المتصفح (للصفحات خارج MainLayout)
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [pathname]);

  return null;
}
