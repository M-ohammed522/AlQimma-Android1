import React, { useState, useEffect, useRef } from 'react';
import {
  ShieldCheck, Sparkles, Check, ArrowLeft,
  GraduationCap, Landmark, FileText, Lock
} from 'lucide-react';
import { Button } from '@/components/ui/button';

export const INSTITUTE_LOGO = 'https://miaoda-conversation-file.s3cdn.medo.dev/user-cim4m3x63pxc/app-f6avantw6h35/20261018/FB_IMG_1780949707596.jpg';

interface WelcomeTransitionModalProps {
  open: boolean;
  onClose: () => void;
  roleName?: string;
  isFullPermissions?: boolean;
}

interface StageItem {
  threshold: number;
  label: string;
  sub: string;
  icon: React.ComponentType<{ className?: string }>;
}

const STAGES: StageItem[] = [
  {
    threshold: 25,
    label: 'التحقق الأمني المشدد من صلاحيات وهوية الجهاز...',
    sub: 'مراجعة البصمة الأمنية وقفل الإعدادات المعتمد',
    icon: Lock,
  },
  {
    threshold: 55,
    label: 'مزامنة السجلات الأكاديمية وملفات الطلاب...',
    sub: 'تحديث بيانات القيود والأرشيف والتخصصات',
    icon: GraduationCap,
  },
  {
    threshold: 85,
    label: 'تهيئة الحسابات والمعاملات المالية...',
    sub: 'تجهيز قيود الإيصالات وأوامر التوريد والتقارير',
    icon: Landmark,
  },
  {
    threshold: 100,
    label: 'اكتملت التهيئة بنجاح! جاري فتح المنظومة...',
    sub: 'أهلاً بك في بيئة العمل المتكاملة لمعهد القمة',
    icon: FileText,
  },
];

export function WelcomeTransitionModal({
  open,
  onClose,
  roleName = 'المدير العام',
}: WelcomeTransitionModalProps) {
  const [progress, setProgress] = useState(0);
  const [stageIndex, setStageIndex] = useState(0);
  const [isClosing, setIsClosing] = useState(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (!open) {
      setProgress(0);
      setStageIndex(0);
      setIsClosing(false);
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    setIsClosing(false);
    setProgress(4);

    timerRef.current = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          if (timerRef.current) clearInterval(timerRef.current);
          setTimeout(() => {
            setIsClosing(true);
            setTimeout(() => {
              onClose();
            }, 450);
          }, 350);
          return 100;
        }

        const step = prev < 30 ? 5 : prev < 70 ? 4 : prev < 90 ? 3 : 2;
        const next = Math.min(100, prev + step);

        if (next >= 85) setStageIndex(3);
        else if (next >= 55) setStageIndex(2);
        else if (next >= 25) setStageIndex(1);
        else setStageIndex(0);

        return next;
      });
    }, 70);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [open, onClose]);

  const handleFastSkip = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    setProgress(100);
    setIsClosing(true);
    setTimeout(() => {
      onClose();
    }, 300);
  };

  if (!open) return null;

  const currentStage = STAGES[stageIndex];
  // حسابات محيط الدائرة لشريط التحميل الدائري حول الشعار
  const radius = 64;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  return (
    <div
      dir="rtl"
      className={`fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6 transition-all duration-500 ease-out ${
        isClosing ? 'opacity-0 scale-95 pointer-events-none' : 'opacity-100 scale-100'
      }`}
    >
      {/* ── خلفية زجاجية شفافة فائقة النقاء تتيح رؤية واجهات النظام بالخلفية ── */}
      <div
        onClick={handleFastSkip}
        className="absolute inset-0 bg-slate-900/25 dark:bg-black/45 backdrop-blur-xl transition-opacity duration-500"
      />

      {/* ── كرات ضوئية ناعمة متباعدة تعطي تدرج لوني ساحر وانكساراً بصرياً حقيقياً للزجاج ── */}
      <div className="absolute top-1/4 -right-12 w-80 h-80 rounded-full bg-blue-500/20 blur-3xl pointer-events-none animate-glass-pulse-glow" />
      <div className="absolute bottom-1/4 -left-12 w-80 h-80 rounded-full bg-emerald-400/20 blur-3xl pointer-events-none animate-glass-pulse-glow" style={{ animationDelay: '1.5s' }} />
      <div className="absolute -top-16 left-1/2 -translate-x-1/2 w-96 h-96 rounded-full bg-amber-400/15 blur-3xl pointer-events-none" />

      {/* ── لوح الزجاج المصنفر فائق الشفافية (Ultra-Transparent Acrylic Glass Plate) ── */}
      <div
        className="relative z-10 w-full max-w-lg rounded-[36px] p-6 sm:p-8 text-center text-white overflow-hidden
          bg-white/10 dark:bg-slate-950/25 backdrop-blur-3xl
          border border-white/35 dark:border-white/15
          shadow-[0_25px_80px_rgba(0,0,0,0.35),inset_0_1px_2px_rgba(255,255,255,0.6)]
          transition-all duration-300"
      >
        {/* انعكاس ضوئي زجاجي انسيابي في أعلى اللوح */}
        <div className="absolute -top-20 left-1/2 -translate-x-1/2 w-[130%] h-32 bg-gradient-to-b from-white/25 via-white/5 to-transparent rounded-[100%] pointer-events-none blur-sm" />

        {/* ── الشارة الرسمية للمعهد مع لمعة ذهبية ناعمة ── */}
        <div className="relative z-10 inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-white/15 border border-white/25 text-[11px] font-bold text-amber-200 backdrop-blur-md mb-5 shadow-sm">
          <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-spin" style={{ animationDuration: '9s' }} />
          <span>معهد القمة للعلوم الطبية والإدارية — سوق السبت، ليبيا</span>
        </div>

        {/* ══ منظومة التحميل الدائرية الليزرية الفاخرة حول الشعار الرسمي ══ */}
        <div className="relative z-10 mx-auto w-40 h-40 sm:w-44 sm:h-44 mb-5 flex items-center justify-center">
          {/* 1. الحلقة المدارية الخارجية الدوارة ببطء مع ليزر أزرق وأزرق سماوي */}
          <div className="absolute inset-0 rounded-full border border-dashed border-white/20 animate-glass-spin-slow pointer-events-none" />

          {/* 2. حلقة ليزرية عكسية الاتجاه ذات توهج ناعم */}
          <div className="absolute inset-1.5 rounded-full border border-transparent border-t-cyan-400/80 border-r-blue-400/40 animate-glass-spin-reverse pointer-events-none shadow-[0_0_15px_rgba(56,189,248,0.4)]" />

          {/* 3. عداد التحميل الدائري SVG المحيط بالشعار بدقة 0-100% */}
          <svg className="absolute inset-0 w-full h-full -rotate-90 pointer-events-none" viewBox="0 0 160 160">
            <defs>
              <linearGradient id="welcome-meter-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#38bdf8" />
                <stop offset="50%" stopColor="#3b82f6" />
                <stop offset="100%" stopColor="#10b981" />
              </linearGradient>
            </defs>
            {/* مسار الخلفية الشفاف */}
            <circle
              cx="80"
              cy="80"
              r={radius}
              fill="none"
              stroke="rgba(255, 255, 255, 0.12)"
              strokeWidth="5"
            />
            {/* مسار التقدم التفاعلي المتدرج والمضيء */}
            <circle
              cx="80"
              cy="80"
              r={radius}
              fill="none"
              stroke="url(#welcome-meter-gradient)"
              strokeWidth="5"
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              className="transition-all duration-150 ease-out"
              style={{ filter: 'drop-shadow(0 0 8px rgba(56, 189, 248, 0.7))' }}
            />
          </svg>

          {/* 4. قرص الشعار الأكريليكي الزجاجي المركزي */}
          <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-full p-2 bg-gradient-to-b from-white/30 via-white/15 to-white/5 border border-white/40 shadow-2xl backdrop-blur-2xl flex items-center justify-center transition-transform duration-300 hover:scale-105">
            <div className="w-full h-full rounded-full overflow-hidden bg-white/95 p-2 shadow-inner flex items-center justify-center">
              <img
                src={INSTITUTE_LOGO}
                alt="شعار معهد القمة"
                className="w-full h-full object-contain filter drop-shadow-sm"
              />
            </div>

            {/* شارة التحقق الأمني المضيئة في أسفل يمين القرص */}
            <div className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow-lg border-2 border-white/90">
              <ShieldCheck className="w-4 h-4 stroke-[2.5]" />
            </div>
          </div>
        </div>

        {/* ── العناوين وهوية الصلاحيات المفعلة ── */}
        <div className="relative z-10 space-y-2 mb-5">
          <h2 className="text-xl sm:text-2xl font-black text-white tracking-wide drop-shadow-sm">
            مرحباً بك في المنظومة
          </h2>

          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/15 border border-emerald-400/35 text-emerald-300 text-xs sm:text-sm font-bold shadow-inner backdrop-blur-md">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping shrink-0" />
            <span>تم التحقق وتفعيل الصلاحيات: <b>{roleName}</b></span>
          </div>

          <p className="text-xs text-white/80 max-w-sm mx-auto leading-relaxed pt-1">
            جاهزية كاملة لكافة العمليات الأكاديمية، والمنظومة المالية، واستخراج التقارير والشهادات الرسمية.
          </p>
        </div>

        {/* ══ لوحة شريط التقدم الليزري والمراحل الذكية ══ */}
        <div className="relative z-10 w-full bg-white/10 dark:bg-white/5 border border-white/15 rounded-2xl p-4 backdrop-blur-2xl space-y-3 mb-4 shadow-inner">
          <div className="flex items-center justify-between text-xs font-bold">
            <div className="flex items-center gap-2 min-w-0 text-white/95">
              <div className="w-6 h-6 rounded-lg bg-white/15 flex items-center justify-center shrink-0 border border-white/20">
                {React.createElement(currentStage.icon, { className: 'w-3.5 h-3.5 text-amber-300' })}
              </div>
              <span className="truncate text-xs font-semibold">{currentStage.label}</span>
            </div>
            <span className="font-mono text-cyan-300 text-sm font-black shrink-0 tabular-nums drop-shadow-[0_0_8px_rgba(34,211,238,0.5)]">
              {progress}%
            </span>
          </div>

          {/* شريط التقدم الليزري مع وميض متحرك (Shimmer) */}
          <div className="w-full h-2.5 rounded-full bg-black/35 border border-white/15 overflow-hidden p-0.5 relative">
            <div
              className="h-full rounded-full bg-gradient-to-r from-cyan-400 via-blue-500 to-emerald-400 transition-all duration-150 ease-out shadow-[0_0_12px_rgba(56,189,248,0.8)] relative overflow-hidden"
              style={{ width: `${progress}%` }}
            >
              {/* وميض ضوئي متحرك يجري فوق شريط التقدم */}
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent animate-glass-shimmer" />
            </div>
          </div>

          {/* محطات ومراحل التهيئة الأربعة كبطاقات زجاجية تفاعلية */}
          <div className="grid grid-cols-4 gap-1.5 pt-1 text-[10px]">
            {[
              { title: 'الأمان', done: progress >= 25 },
              { title: 'الطلاب', done: progress >= 55 },
              { title: 'المالية', done: progress >= 85 },
              { title: 'المنظومة', done: progress >= 98 },
            ].map((step, idx) => (
              <div
                key={idx}
                className={`py-1.5 px-1 rounded-xl border text-center transition-all duration-300 backdrop-blur-md ${
                  step.done
                    ? 'bg-emerald-500/25 border-emerald-400/60 text-emerald-300 font-bold shadow-[0_0_10px_rgba(52,211,153,0.3)]'
                    : 'bg-white/5 border-white/10 text-white/45'
                }`}
              >
                <div className="flex items-center justify-center gap-1">
                  {step.done ? (
                    <Check className="w-3 h-3 stroke-[3]" />
                  ) : (
                    <span className="w-1.5 h-1.5 rounded-full bg-white/25" />
                  )}
                  <span>{step.title}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ── زر الدخول المباشر الزجاجي الأنيق ── */}
        <div className="relative z-10 w-full pt-1 flex items-center justify-center">
          <Button
            type="button"
            variant="ghost"
            onClick={handleFastSkip}
            className="text-xs text-white/90 hover:text-white bg-white/15 hover:bg-white/25 border border-white/25 h-9 px-5 rounded-xl font-bold gap-2 backdrop-blur-xl shadow-md transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            <span>الدخول المباشر للمنظومة الآن</span>
            <ArrowLeft className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
