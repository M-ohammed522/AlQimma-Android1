import { Link } from 'react-router-dom';
import { ShieldAlert, ArrowRight, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useDeviceRole } from '@/contexts/DeviceRoleContext';

interface AccessDeniedViewProps {
  message?: string;
  subMessage?: string;
}

export default function AccessDeniedView({
  message = 'غير مصرح لك بالوصول إلى هذه الصفحة',
  subMessage = 'وظيفة هذا الجهاز لا تمتلك الصلاحية الكافية لعرض هذه البيانات أو تنفيذ هذه العملية. يرجى مراجعة المدير العام لتحديث الصلاحيات إذا لزم الأمر.',
}: AccessDeniedViewProps) {
  const { currentRole } = useDeviceRole();

  return (
    <div className="flex flex-col items-center justify-center min-h-[65vh] p-6 text-center select-none" dir="rtl">
      {/* أيقونة الحماية الكبيرة */}
      <div className="relative mb-6">
        <div className="w-24 h-24 rounded-3xl bg-destructive/10 border-2 border-destructive/20 flex items-center justify-center shadow-xl shadow-destructive/5">
          <ShieldAlert className="w-12 h-12 text-destructive animate-pulse" />
        </div>
        <div className="absolute -top-1 -right-1 w-6 h-6 rounded-full bg-destructive flex items-center justify-center text-white text-xs font-black shadow-md">
          ✕
        </div>
      </div>

      {/* الرسالة المطلوبة نصاً */}
      <h2 className="text-2xl md:text-3xl font-black text-foreground mb-3 tracking-tight">
        {message}
      </h2>

      {/* الشرح التوضيحي الأمني */}
      <p className="text-muted-foreground text-sm max-w-md leading-relaxed mb-6 font-medium">
        {subMessage}
      </p>

      {/* بطاقة معلومات وظيفة الجهاز الحالية */}
      <div className="bg-card border border-border/70 rounded-2xl p-4 max-w-sm w-full mb-8 shadow-sm">
        <div className="flex items-center justify-between text-xs text-muted-foreground mb-1">
          <span>وظيفة هذا الجهاز الحالية:</span>
          <span className="font-mono text-[11px] bg-muted px-2 py-0.5 rounded">الجهاز الحالي</span>
        </div>
        <p className="text-base font-bold text-foreground">
          {currentRole ? currentRole.name : 'غير محددة (صلاحية كاملة مؤقتة)'}
        </p>
        {currentRole?.description && (
          <p className="text-[11px] text-muted-foreground mt-1 line-clamp-2">
            {currentRole.description}
          </p>
        )}
      </div>

      {/* أزرار العودة والتنقل */}
      <div className="flex flex-wrap items-center justify-center gap-3">
        <Button asChild variant="default" className="gap-2 font-bold shadow-md">
          <Link to="/">
            <ArrowRight className="w-4 h-4" />
            العودة للوحة التحكم
          </Link>
        </Button>
        <Button asChild variant="outline" className="gap-2 font-bold">
          <Link to="/settings">
            <Settings className="w-4 h-4" />
            إعدادات وظيفة الجهاز
          </Link>
        </Button>
      </div>
    </div>
  );
}
