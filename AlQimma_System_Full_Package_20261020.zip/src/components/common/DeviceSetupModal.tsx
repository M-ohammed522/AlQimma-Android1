import React, { useState } from 'react';
import { normalizeArabicNumerals } from '@/components/ui/numeric-input';
import { WelcomeTransitionModal, INSTITUTE_LOGO } from '@/components/common/WelcomeTransitionModal';
import {
  Shield, Laptop, CheckCircle2, Lock, ArrowLeft,
  KeyRound, Users, DollarSign, GraduationCap, Building2,
  Eye, EyeOff, Sparkles, Check, AlertCircle,
} from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useDeviceRole } from '@/contexts/DeviceRoleContext';
import { toast } from 'sonner';

interface DeviceSetupModalProps {
  forceOpen?: boolean;
  onClose?: () => void;
}

// دالة لجلب أيقونة وسمات بصرية مناسبة لكل وظيفة بألوان غنية واحترافية
function getRoleVisuals(roleId: string, isSelected: boolean) {
  if (roleId === 'general_manager') {
    return {
      icon: Building2,
      border: isSelected
        ? 'border-amber-500 ring-2 ring-amber-500/30 bg-gradient-to-b from-amber-500/15 via-amber-500/5 to-card shadow-sm'
        : 'border-amber-500/30 hover:border-amber-500/60 bg-gradient-to-b from-amber-500/5 to-card',
      color: 'text-amber-600 dark:text-amber-400',
      badge: 'المدير العام',
      badgeColor: 'bg-amber-500/20 text-amber-800 dark:text-amber-200 border border-amber-500/40 font-black',
      iconBg: 'bg-gradient-to-tr from-amber-500 to-amber-600 text-slate-950 shadow-md',
      accentColor: '#d97706',
    };
  }
  if (roleId === 'admin_finance' || roleId.includes('finance')) {
    return {
      icon: DollarSign,
      border: isSelected
        ? 'border-emerald-500 ring-2 ring-emerald-500/30 bg-gradient-to-b from-emerald-500/15 via-emerald-500/5 to-card shadow-sm'
        : 'border-emerald-500/30 hover:border-emerald-500/60 bg-gradient-to-b from-emerald-500/5 to-card',
      color: 'text-emerald-600 dark:text-emerald-400',
      badge: 'المالية والإدارة',
      badgeColor: 'bg-emerald-500/20 text-emerald-800 dark:text-emerald-200 border border-emerald-500/40 font-black',
      iconBg: 'bg-gradient-to-tr from-emerald-500 to-teal-600 text-white shadow-md',
      accentColor: '#059669',
    };
  }
  if (roleId === 'study_exams' || roleId.includes('exam')) {
    return {
      icon: GraduationCap,
      border: isSelected
        ? 'border-purple-500 ring-2 ring-purple-500/30 bg-gradient-to-b from-purple-500/15 via-purple-500/5 to-card shadow-sm'
        : 'border-purple-500/30 hover:border-purple-500/60 bg-gradient-to-b from-purple-500/5 to-card',
      color: 'text-purple-600 dark:text-purple-400',
      badge: 'الدراسة والامتحانات',
      badgeColor: 'bg-purple-500/20 text-purple-800 dark:text-purple-200 border border-purple-500/40 font-black',
      iconBg: 'bg-gradient-to-tr from-purple-500 to-indigo-600 text-white shadow-md',
      accentColor: '#7c3aed',
    };
  }
  return {
    icon: Users,
    border: isSelected
      ? 'border-sky-500 ring-2 ring-sky-500/30 bg-gradient-to-b from-sky-500/15 via-sky-500/5 to-card shadow-sm'
      : 'border-sky-500/30 hover:border-sky-500/60 bg-gradient-to-b from-sky-500/5 to-card',
    color: 'text-sky-600 dark:text-sky-400',
    badge: 'شؤون الطلاب والتسجيل',
    badgeColor: 'bg-sky-500/20 text-sky-800 dark:text-sky-200 border border-sky-500/40 font-black',
    iconBg: 'bg-gradient-to-tr from-sky-500 to-blue-600 text-white shadow-md',
    accentColor: '#0284c7',
  };
}

export default function DeviceSetupModal({ forceOpen = false, onClose }: DeviceSetupModalProps) {
  const { roles, loading, isConfigured, setDeviceRole, currentRoleId } = useDeviceRole();
  const [selectedRole, setSelectedRole] = useState<string>(() => currentRoleId || 'admin_finance');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [showWelcomeTransition, setShowWelcomeTransition] = useState(false);

  // يظهر إذا لم يكن الجهاز مهيئاً أو إذا تم طلبه صراحة (من الإعدادات)
  const open = forceOpen || (!loading && !isConfigured);

  const targetRole = roles.find(r => r.id === selectedRole) || roles[0];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRole) {
      toast.error('يرجى اختيار وظيفة لهذا الجهاز');
      return;
    }
    if (!password.trim()) {
      toast.error(`يرجى إدخال رمز المرور الخاص بوظيفة (${targetRole?.name || 'المختارة'})`);
      return;
    }

    setSubmitting(true);
    try {
      const res = await setDeviceRole(selectedRole, password);
      if (res.success) {
        toast.success(`تم تثبيت وظيفة (${targetRole?.name}) على هذا الجهاز بنجاح وبشكل دائم`);
        sessionStorage.setItem('welcome_splash_shown_v1', 'true');
        setPassword('');
        // إطلاق الشاشة الترحيبية الاحترافية فوراً
        setShowWelcomeTransition(true);
      } else {
        toast.error(res.message || 'رمز المرور غير صحيح');
      }
    } catch {
      toast.error('حدث خطأ أثناء حفظ وظيفة الجهاز');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(val) => { if (!val && forceOpen && onClose) onClose(); }}>
      <DialogContent className="max-w-[calc(100%-1.5rem)] md:max-w-2xl max-h-[92dvh] overflow-y-auto p-0 gap-0 border-2 border-primary/30 rounded-2xl shadow-2xl" dir="rtl">
        {/* رأس النافذة الأنيق والمتجاوب */}
        <div className="bg-gradient-to-r from-primary via-primary/95 to-primary/90 text-primary-foreground p-5 sm:p-6 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-48 h-48 bg-white/5 rounded-full -translate-x-16 -translate-y-16 pointer-events-none" />
          <div className="flex items-center gap-3.5 relative z-10">
            <div className="w-12 h-12 rounded-2xl bg-white p-1 border border-white/25 flex items-center justify-center shrink-0 shadow-md overflow-hidden">
              <img src={INSTITUTE_LOGO} alt="شعار المعهد" className="w-full h-full object-contain" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <DialogTitle className="text-lg sm:text-xl font-black text-white">
                  تهيئة وتحديد وظيفة هذا الجهاز
                </DialogTitle>
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-white/20 text-white border border-white/30 backdrop-blur-xs">
                  حفظ دائم بالجهاز
                </span>
              </div>
              <DialogDescription className="text-white/85 text-xs mt-1 leading-relaxed">
                لكل وظيفة رمز مرور مستقل لتأكيدها. تُحفظ الوظيفة محلياً على هذا الجهاز ولا تتطلب تسجيل دخول يومي.
              </DialogDescription>
            </div>
          </div>
        </div>

        {/* محتوى النموذج */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-5">
          {/* قسم اختيار الوظيفة */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <Label className="text-xs font-black text-foreground flex items-center gap-1.5">
                <Shield className="w-4 h-4 text-primary" />
                <span>اختر الوظيفة المخصصة لهذا الجهاز:</span>
              </Label>
              <span className="text-[11px] text-muted-foreground font-medium">
                (اضغط لاختيار الوظيفة)
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {roles.filter(r => r.is_active).map((role) => {
                const isSelected = selectedRole === role.id;
                const visual = getRoleVisuals(role.id, isSelected);
                const IconComponent = visual.icon;

                return (
                  <div
                    key={role.id}
                    onClick={() => {
                      setSelectedRole(role.id);
                      setPassword('');
                    }}
                    className={`relative p-3.5 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between select-none active:scale-[0.98] ${visual.border}`}
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2.5">
                          <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${visual.iconBg}`}>
                            <IconComponent className="w-4 h-4 stroke-[2.5]" />
                          </div>
                          <div>
                            <span className="text-xs font-black text-foreground block leading-tight">{role.name}</span>
                            <span className={`text-[9px] px-2 py-0.5 rounded-full inline-block mt-1 ${visual.badgeColor}`}>
                              {visual.badge}
                            </span>
                          </div>
                        </div>

                        <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${
                          isSelected ? 'border-primary bg-primary text-primary-foreground shadow-xs' : 'border-border'
                        }`}>
                          {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                        </div>
                      </div>

                      <p className="text-[11px] text-muted-foreground line-clamp-2 leading-relaxed">
                        {role.description || 'صلاحيات مخصصة للنظام بحسب مسؤوليات هذا القسم.'}
                      </p>
                    </div>

                    <div className="mt-2.5 pt-2 border-t border-border/40 flex items-center justify-between text-[10px]">
                      <span className="text-muted-foreground font-medium">رمز المرور:</span>
                      <span className="font-bold text-foreground bg-muted/60 px-1.5 py-0.5 rounded border border-border/50">
                        مطلوب للتأكيد
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* حقل إدخال رمز المرور الخاص بالوظيفة المختارة */}
          <div className="bg-muted/40 border-2 border-border/80 rounded-2xl p-4 sm:p-5 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
              <Label className="text-xs font-black text-foreground flex items-center gap-1.5">
                <KeyRound className="w-4 h-4 text-primary" />
                <span>رمز المرور الخاص بوظيفة ({targetRole?.name}):</span>
              </Label>
              <span className="text-[10px] font-bold text-primary bg-primary/10 px-2 py-0.5 rounded-full border border-primary/20 self-start sm:self-auto">
                رمز أمان مستقل
              </span>
            </div>

            <div className="relative">
              <Input
                type={showPassword ? 'text' : 'password'}
                inputMode="numeric"
                pattern="[0-9]*"
                autoComplete="one-time-code"
                value={password}
                onChange={(e) => setPassword(normalizeArabicNumerals(e.target.value).replace(/\D/g, ''))}
                placeholder="أدخل رمز المرور..."
                className="h-11 font-mono text-center tracking-widest text-base pr-4 pl-11 bg-background border-2 border-primary/30 focus-visible:border-primary shadow-xs"
                dir="ltr"
                required
                autoFocus
              />
              <button
                type="button"
                onClick={() => setShowPassword(v => !v)}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors p-1"
                title={showPassword ? 'إخفاء الرمز' : 'إظهار الرمز'}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>

            <div className="bg-background/80 border border-border/60 rounded-xl p-2.5 flex items-start gap-2 text-[11px] text-muted-foreground">
              <AlertCircle className="w-3.5 h-3.5 text-primary shrink-0 mt-0.5" />
              <div className="leading-relaxed">
                <span>يمكن استخدام رمز المرور المخصص للوظيفة، كما يمكن للمدير العام استخدام الرمز الرئيسي <strong>(5224410)</strong> في أي وقت.</span>
              </div>
            </div>
          </div>

          {/* أزرار الإجراء البارزة والواضحة والمتجاوبة بالكامل على الموبايل */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 pt-2">
            {forceOpen && onClose ? (
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={submitting}
                className="h-11 px-5 font-bold border-border hover:bg-muted text-xs order-2 sm:order-1"
              >
                إلغاء
              </Button>
            ) : (
              <div className="text-[11px] text-muted-foreground hidden sm:block order-1">
                اختر الوظيفة وأدخل رمز المرور للمتابعة
              </div>
            )}

            <Button
              type="submit"
              disabled={submitting || !password.trim()}
              className="h-11 px-6 font-black gap-2 shadow-md bg-primary text-primary-foreground hover:bg-primary/90 text-sm flex-1 sm:flex-initial order-1 sm:order-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              {submitting ? 'جاري التحقق والتثبيت...' : 'تثبيت وظيفة هذا الجهاز'}
              <ArrowLeft className="w-4 h-4 mr-1" />
            </Button>
          </div>
        </form>
      </DialogContent>

      {/* الشاشة الترحيبية الاحترافية عند اعتماد وتأكيد الصلاحيات بنجاح */}
      <WelcomeTransitionModal
        open={showWelcomeTransition}
        onClose={() => {
          setShowWelcomeTransition(false);
          if (onClose) onClose();
        }}
        roleName={targetRole?.name || 'المدير العام'}
        isFullPermissions={true}
      />
    </Dialog>
  );
}
