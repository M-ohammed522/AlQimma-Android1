// مكوّن أفاتار الطالب — يُعرض في كامل المنظومة
import React from 'react';
import { User } from 'lucide-react';

export type AvatarSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';
export type AvatarVariant = 'circle' | 'rounded' | 'square';

interface StudentAvatarProps {
  photoUrl?: string | null;
  name: string;
  size?: AvatarSize;
  variant?: AvatarVariant;
  /** تُستخدم لتلوين الحافة والخلفية عند غياب الصورة */
  colorSeed?: string;
  className?: string;
  /** عرض شارة صغيرة في الزاوية */
  badge?: React.ReactNode;
}

const SIZE_MAP: Record<AvatarSize, { outer: string; text: string; icon: string; badge: string }> = {
  xs: { outer: 'w-7 h-7',   text: 'text-[11px]', icon: 'w-3.5 h-3.5', badge: 'w-2.5 h-2.5 -bottom-0.5 -left-0.5' },
  sm: { outer: 'w-9 h-9',   text: 'text-sm',     icon: 'w-4 h-4',     badge: 'w-3 h-3 -bottom-0.5 -left-0.5' },
  md: { outer: 'w-11 h-11', text: 'text-base',   icon: 'w-5 h-5',     badge: 'w-3.5 h-3.5 -bottom-1 -left-1' },
  lg: { outer: 'w-14 h-14', text: 'text-lg',     icon: 'w-6 h-6',     badge: 'w-4 h-4 -bottom-1 -left-1' },
  xl: { outer: 'w-20 h-20', text: 'text-2xl',    icon: 'w-8 h-8',     badge: 'w-5 h-5 -bottom-1 -left-1' },
};

const VARIANT_MAP: Record<AvatarVariant, string> = {
  circle:  'rounded-full',
  rounded: 'rounded-xl',
  square:  'rounded-lg',
};

// ألوان الأفاتار — 8 ألوان دوّارة بناءً على أحرف الاسم
const COLOR_PALETTES = [
  { bg: 'bg-blue-500/15',    text: 'text-blue-700',    border: 'border-blue-400/40',    ring: 'ring-blue-300/30'    },
  { bg: 'bg-violet-500/15',  text: 'text-violet-700',  border: 'border-violet-400/40',  ring: 'ring-violet-300/30'  },
  { bg: 'bg-emerald-500/15', text: 'text-emerald-700', border: 'border-emerald-400/40', ring: 'ring-emerald-300/30' },
  { bg: 'bg-amber-500/15',   text: 'text-amber-700',   border: 'border-amber-400/40',   ring: 'ring-amber-300/30'   },
  { bg: 'bg-rose-500/15',    text: 'text-rose-700',    border: 'border-rose-400/40',    ring: 'ring-rose-300/30'    },
  { bg: 'bg-teal-500/15',    text: 'text-teal-700',    border: 'border-teal-400/40',    ring: 'ring-teal-300/30'    },
  { bg: 'bg-indigo-500/15',  text: 'text-indigo-700',  border: 'border-indigo-400/40',  ring: 'ring-indigo-300/30'  },
  { bg: 'bg-orange-500/15',  text: 'text-orange-700',  border: 'border-orange-400/40',  ring: 'ring-orange-300/30'  },
];

function getPalette(seed: string) {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) hash = seed.charCodeAt(i) + ((hash << 5) - hash);
  return COLOR_PALETTES[Math.abs(hash) % COLOR_PALETTES.length];
}

function getInitials(name: string) {
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0].charAt(0);
  return parts[0].charAt(0) + parts[1].charAt(0);
}

export function StudentAvatar({
  photoUrl,
  name,
  size = 'md',
  variant = 'rounded',
  colorSeed,
  className = '',
  badge,
}: StudentAvatarProps) {
  const s = SIZE_MAP[size];
  const r = VARIANT_MAP[variant];
  const pal = getPalette(colorSeed ?? name);

  return (
    <div className={`relative shrink-0 ${className}`}>
      <div className={`
        ${s.outer} ${r}
        flex items-center justify-center overflow-hidden
        border-2 select-none
        ${photoUrl ? 'border-white/20 bg-muted' : `${pal.bg} ${pal.border}`}
        shadow-sm
      `}>
        {photoUrl ? (
          <img
            src={photoUrl}
            alt={name}
            className="w-full h-full object-cover"
            onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }}
          />
        ) : (
          name ? (
            <span className={`font-black leading-none ${s.text} ${pal.text}`}>
              {getInitials(name)}
            </span>
          ) : (
            <User className={`${s.icon} text-muted-foreground/50`} />
          )
        )}
      </div>
      {badge && (
        <div className={`absolute ${s.badge} flex items-center justify-center`}>
          {badge}
        </div>
      )}
    </div>
  );
}

export default StudentAvatar;
