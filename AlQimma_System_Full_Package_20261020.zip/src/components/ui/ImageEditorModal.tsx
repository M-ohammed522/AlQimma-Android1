/**
 * ImageEditorModal — محرر صور احترافي بالكامل بدون مكتبات خارجية
 * يدعم: قص حر بالسحب باللمس والماوس | تحديد الأبعاد | إضاءة | تباين | تشبع | تدوير
 */
import { useEffect, useRef, useState, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import {
  Crop, RotateCcw, RotateCw, Sun, Contrast,
  Droplets, FlipHorizontal, Check, X, ZoomIn, ZoomOut,
} from 'lucide-react';

// ── أنواع ──────────────────────────────────────────────────────
interface Rect { x: number; y: number; w: number; h: number }
type Handle = 'tl'|'tr'|'bl'|'br'|'t'|'b'|'l'|'r'|'move'|null;

export interface ImageEditorModalProps {
  open: boolean;
  imageSrc: string;
  aspectRatio?: number | null; // null=حر | 1=مربع | 4/3 …
  title?: string;
  onConfirm: (file: File, preview: string) => void;
  onCancel: () => void;
}

// ── تحميل صورة ────────────────────────────────────────────────
function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((res, rej) => {
    const img = new Image();
    img.onload  = () => res(img);
    img.onerror = rej;
    img.src = src;
  });
}

// ── مساعد: clamp ───────────────────────────────────────────────
const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));

// ── شريط ضبط ──────────────────────────────────────────────────
function AdjustRow({
  icon: Icon, label, value, min, max,
  onChange,
}: {
  icon: React.FC<React.SVGProps<SVGSVGElement>>;
  label: string; value: number; min: number; max: number;
  onChange: (v: number) => void;
}) {
  return (
    <div className="flex items-center gap-2">
      <Icon className="w-4 h-4 text-muted-foreground shrink-0" />
      <span className="text-xs text-muted-foreground w-14 shrink-0">{label}</span>
      <Slider dir="ltr" min={min} max={max} step={1} value={[value]}
        onValueChange={([v]) => onChange(v)} className="flex-1" />
      <span className="text-xs font-mono w-8 text-right shrink-0 text-muted-foreground">{value}</span>
    </div>
  );
}

// ── المكوّن الرئيسي ─────────────────────────────────────────────
export default function ImageEditorModal({
  open, imageSrc, aspectRatio = 1, title = 'تعديل الصورة',
  onConfirm, onCancel,
}: ImageEditorModalProps) {

  const canvasRef   = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const imgRef      = useRef<HTMLImageElement | null>(null);

  // تحويلات الصورة
  const [zoom,       setZoom]       = useState(1);
  const [rotation,   setRotation]   = useState(0);
  const [flip,       setFlip]       = useState(false);
  const [brightness, setBrightness] = useState(100);
  const [contrast,   setContrast]   = useState(100);
  const [saturation, setSaturation] = useState(100);
  const [processing, setProcessing] = useState(false);
  const [aspect,     setAspect]     = useState<number | null>(
    aspectRatio === null ? null : (aspectRatio ?? 1),
  );

  // إزاحة الصورة
  const [imgOffset, setImgOffset] = useState({ x: 0, y: 0 });

  // مستطيل القص (بنسب Canvas العرضية)
  const [cropRect, setCropRect] = useState<Rect>({ x: 20, y: 20, w: 260, h: 260 });

  // حالة السحب
  const dragRef = useRef<{
    type: Handle;
    startX: number; startY: number;
    origRect: Rect;
    origOffset: { x: number; y: number };
  } | null>(null);

  // أبعاد Canvas المعروضة
  const CANVAS_W = 340;
  const CANVAS_H = 280;

  // ── تحميل الصورة عند الفتح ────────────────────────────────────
  useEffect(() => {
    if (!open || !imageSrc) return;
    setZoom(1); setRotation(0); setFlip(false);
    setBrightness(100); setContrast(100); setSaturation(100);
    setImgOffset({ x: 0, y: 0 });
    setAspect(aspectRatio === null ? null : (aspectRatio ?? 1));

    loadImage(imageSrc).then(img => {
      imgRef.current = img;
      // حساب مستطيل القص الأولي
      const scale = Math.min(CANVAS_W / img.width, CANVAS_H / img.height) * 0.9;
      const iw = img.width  * scale;
      const ih = img.height * scale;
      const ox = (CANVAS_W - iw) / 2;
      const oy = (CANVAS_H - ih) / 2;
      if (aspectRatio !== null) {
        const ar = aspectRatio ?? 1;
        const cw = Math.min(iw * 0.85, ih * ar * 0.85);
        const ch = cw / ar;
        setCropRect({
          x: ox + (iw - cw) / 2,
          y: oy + (ih - ch) / 2,
          w: cw, h: ch,
        });
      } else {
        setCropRect({ x: ox + iw * 0.08, y: oy + ih * 0.08, w: iw * 0.84, h: ih * 0.84 });
      }
    });
  }, [open, imageSrc, aspectRatio]);

  // ── رسم Canvas ────────────────────────────────────────────────
  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    const img    = imgRef.current;
    if (!canvas || !img) return;
    const ctx = canvas.getContext('2d')!;
    ctx.clearRect(0, 0, CANVAS_W, CANVAS_H);

    // خلفية داكنة
    ctx.fillStyle = '#111';
    ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);

    // رسم الصورة مع التحويلات
    const scale = Math.min(CANVAS_W / img.width, CANVAS_H / img.height) * zoom;
    const iw = img.width  * scale;
    const ih = img.height * scale;
    const cx = CANVAS_W / 2 + imgOffset.x;
    const cy = CANVAS_H / 2 + imgOffset.y;

    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate((rotation * Math.PI) / 180);
    if (flip) ctx.scale(-1, 1);
    ctx.filter = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%)`;
    ctx.drawImage(img, -iw / 2, -ih / 2, iw, ih);
    ctx.filter = 'none';
    ctx.restore();

    // تعتيم خارج منطقة القص
    const { x, y, w, h } = cropRect;
    ctx.fillStyle = 'rgba(0,0,0,0.50)';
    ctx.fillRect(0, 0, CANVAS_W, y);                         // أعلى
    ctx.fillRect(0, y + h, CANVAS_W, CANVAS_H - y - h);      // أسفل
    ctx.fillRect(0, y, x, h);                                 // يسار
    ctx.fillRect(x + w, y, CANVAS_W - x - w, h);             // يمين

    // إطار القص
    ctx.strokeStyle = '#fff';
    ctx.lineWidth   = 1.5;
    ctx.strokeRect(x, y, w, h);

    // خطوط ثلثية (Rule of Thirds)
    ctx.strokeStyle = 'rgba(255,255,255,0.25)';
    ctx.lineWidth   = 0.5;
    for (let i = 1; i <= 2; i++) {
      ctx.beginPath(); ctx.moveTo(x + (w * i) / 3, y); ctx.lineTo(x + (w * i) / 3, y + h); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(x, y + (h * i) / 3); ctx.lineTo(x + w, y + (h * i) / 3); ctx.stroke();
    }

    // مقابض الزوايا والحواف
    const handles: { hx: number; hy: number }[] = [
      { hx: x,         hy: y         }, // tl
      { hx: x + w,     hy: y         }, // tr
      { hx: x,         hy: y + h     }, // bl
      { hx: x + w,     hy: y + h     }, // br
      { hx: x + w / 2, hy: y         }, // t
      { hx: x + w / 2, hy: y + h     }, // b
      { hx: x,         hy: y + h / 2 }, // l
      { hx: x + w,     hy: y + h / 2 }, // r
    ];
    handles.forEach(({ hx, hy }) => {
      ctx.fillStyle = '#fff';
      ctx.beginPath();
      ctx.arc(hx, hy, 5, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,0.4)';
      ctx.lineWidth = 1;
      ctx.stroke();
    });

    // حجم المحصول (px)
    ctx.fillStyle = 'rgba(0,0,0,0.55)';
    ctx.fillRect(x + 2, y + h - 18, 70, 16);
    ctx.fillStyle = '#fff';
    ctx.font = '10px monospace';
    ctx.textAlign = 'left';
    ctx.fillText(`${Math.round(w)}×${Math.round(h)}`, x + 5, y + h - 5);
  }, [cropRect, zoom, rotation, flip, brightness, contrast, saturation, imgOffset]);

  useEffect(() => { draw(); }, [draw]);

  // ── تحديد المقبض المُضغوط ─────────────────────────────────────
  const getHandle = (px: number, py: number): Handle => {
    const { x, y, w, h } = cropRect;
    const R = 12;
    const pts: { id: Handle; hx: number; hy: number }[] = [
      { id: 'tl', hx: x,         hy: y         },
      { id: 'tr', hx: x + w,     hy: y         },
      { id: 'bl', hx: x,         hy: y + h     },
      { id: 'br', hx: x + w,     hy: y + h     },
      { id: 't',  hx: x + w / 2, hy: y         },
      { id: 'b',  hx: x + w / 2, hy: y + h     },
      { id: 'l',  hx: x,         hy: y + h / 2 },
      { id: 'r',  hx: x + w,     hy: y + h / 2 },
    ];
    for (const p of pts) {
      if (Math.hypot(px - p.hx, py - p.hy) <= R) return p.id;
    }
    if (px >= x && px <= x + w && py >= y && py <= y + h) return 'move';
    return null;
  };

  // ── إحداثيات Canvas من event ──────────────────────────────────
  const getCanvasPos = (e: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current!;
    const rect   = canvas.getBoundingClientRect();
    const scaleX = CANVAS_W / rect.width;
    const scaleY = CANVAS_H / rect.height;
    let cx: number, cy: number;
    if ('touches' in e) {
      cx = (e.touches[0].clientX - rect.left) * scaleX;
      cy = (e.touches[0].clientY - rect.top)  * scaleY;
    } else {
      cx = (e.clientX - rect.left) * scaleX;
      cy = (e.clientY - rect.top)  * scaleY;
    }
    return { cx, cy };
  };

  // ── بداية السحب ───────────────────────────────────────────────
  const onPointerDown = (e: React.MouseEvent | React.TouchEvent) => {
    const { cx, cy } = getCanvasPos(e);
    const handle = getHandle(cx, cy);
    if (!handle) return;
    e.preventDefault();
    dragRef.current = {
      type: handle,
      startX: cx, startY: cy,
      origRect: { ...cropRect },
      origOffset: { ...imgOffset },
    };
  };

  // ── أثناء السحب ───────────────────────────────────────────────
  const onPointerMove = useCallback((e: MouseEvent | TouchEvent) => {
    if (!dragRef.current) return;
    e.preventDefault();
    const canvas = canvasRef.current!;
    const rect   = canvas.getBoundingClientRect();
    const scaleX = CANVAS_W / rect.width;
    const scaleY = CANVAS_H / rect.height;
    let cx: number, cy: number;
    if ('touches' in e) {
      cx = (e.touches[0].clientX - rect.left) * scaleX;
      cy = (e.touches[0].clientY - rect.top)  * scaleY;
    } else {
      cx = ((e as MouseEvent).clientX - rect.left) * scaleX;
      cy = ((e as MouseEvent).clientY - rect.top)  * scaleY;
    }

    const { type, startX, startY, origRect } = dragRef.current;
    const dx = cx - startX;
    const dy = cy - startY;
    const MIN = 40;

    if (type === 'move') {
      // تحريك مستطيل القص
      setCropRect(r => ({
        ...r,
        x: clamp(origRect.x + dx, 0, CANVAS_W - r.w),
        y: clamp(origRect.y + dy, 0, CANVAS_H - r.h),
      }));
      return;
    }

    // تغيير حجم المستطيل
    let { x, y, w, h } = origRect;

    if (type === 'tl' || type === 'l' || type === 'bl') {
      const nx = clamp(x + dx, 0, x + w - MIN);
      w += x - nx; x = nx;
    }
    if (type === 'tr' || type === 'r' || type === 'br') {
      w = clamp(w + dx, MIN, CANVAS_W - x);
    }
    if (type === 'tl' || type === 't' || type === 'tr') {
      const ny = clamp(y + dy, 0, y + h - MIN);
      h += y - ny; y = ny;
    }
    if (type === 'bl' || type === 'b' || type === 'br') {
      h = clamp(h + dy, MIN, CANVAS_H - y);
    }

    // تطبيق نسبة الأبعاد إن وُجدت
    if (aspect !== null) {
      if (type === 'l' || type === 'r') h = w / aspect;
      else if (type === 't' || type === 'b') w = h * aspect;
      else {
        // زوايا: الحجم الأكبر يحكم
        const byW = w;
        const byH = h * aspect;
        if (byW < byH) { w = byW; h = w / aspect; }
        else            { h = byH / aspect * aspect; w = h * aspect; }
      }
      // إعادة clamp بعد تصحيح النسبة
      w = clamp(w, MIN, CANVAS_W - x);
      h = clamp(h, MIN, CANVAS_H - y);
    }

    setCropRect({ x, y, w, h });
  }, [aspect]);

  const onPointerUp = useCallback(() => { dragRef.current = null; }, []);

  // تسجيل أحداث window
  useEffect(() => {
    window.addEventListener('mousemove',  onPointerMove, { passive: false });
    window.addEventListener('touchmove',  onPointerMove, { passive: false });
    window.addEventListener('mouseup',   onPointerUp);
    window.addEventListener('touchend',  onPointerUp);
    return () => {
      window.removeEventListener('mousemove',  onPointerMove);
      window.removeEventListener('touchmove',  onPointerMove);
      window.removeEventListener('mouseup',   onPointerUp);
      window.removeEventListener('touchend',  onPointerUp);
    };
  }, [onPointerMove, onPointerUp]);

  // cursor حسب الموضع
  const [cursor, setCursor] = useState('default');
  const onMouseMoveCanvas = (e: React.MouseEvent) => {
    const { cx, cy } = getCanvasPos(e);
    const h = getHandle(cx, cy);
    const map: Record<string, string> = {
      tl: 'nwse-resize', br: 'nwse-resize',
      tr: 'nesw-resize', bl: 'nesw-resize',
      t: 'ns-resize', b: 'ns-resize',
      l: 'ew-resize', r: 'ew-resize',
      move: 'move',
    };
    setCursor(h ? (map[h] ?? 'default') : 'default');
  };

  // ── تطبيق وحفظ ────────────────────────────────────────────────
  const handleConfirm = async () => {
    const img = imgRef.current;
    if (!img) return;
    setProcessing(true);
    try {
      const scale = Math.min(CANVAS_W / img.width, CANVAS_H / img.height) * zoom;
      const iw = img.width  * scale;
      const ih = img.height * scale;
      const cx = CANVAS_W / 2 + imgOffset.x;
      const cy = CANVAS_H / 2 + imgOffset.y;

      // إحداثيات مستطيل القص في فضاء الصورة الأصلية
      const { x: rx, y: ry, w: rw, h: rh } = cropRect;
      const imgX = (rx - (cx - iw / 2)) / scale;
      const imgY = (ry - (cy - ih / 2)) / scale;
      const imgW = rw / scale;
      const imgH = rh / scale;

      // رسم النتيجة
      const out  = document.createElement('canvas');
      out.width  = Math.round(imgW);
      out.height = Math.round(imgH);
      const octx = out.getContext('2d')!;
      octx.save();
      octx.translate(out.width / 2, out.height / 2);
      octx.rotate((rotation * Math.PI) / 180);
      if (flip) octx.scale(-1, 1);
      octx.filter = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%)`;
      octx.drawImage(img, -imgX - imgW / 2, -imgY - imgH / 2, img.width, img.height);
      octx.restore();

      const file = await new Promise<File>(res => {
        out.toBlob(b => res(new File([b!], 'edited.jpg', { type: 'image/jpeg' })), 'image/jpeg', 0.92);
      });
      const preview = URL.createObjectURL(file);
      onConfirm(file, preview);
    } finally { setProcessing(false); }
  };

  const resetAll = () => {
    setZoom(1); setRotation(0); setFlip(false);
    setBrightness(100); setContrast(100); setSaturation(100);
    setImgOffset({ x: 0, y: 0 });
  };

  // ── تغيير نسبة الأبعاد ────────────────────────────────────────
  const changeAspect = (val: number | null) => {
    setAspect(val);
    if (val !== null) {
      setCropRect(r => {
        const newW = r.w;
        const newH = newW / val;
        return { ...r, h: clamp(newH, 40, CANVAS_H - r.y) };
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={v => { if (!v) onCancel(); }}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg p-0 overflow-hidden" dir="rtl">
        <DialogHeader className="px-4 pt-4 pb-2 border-b border-border/40">
          <div className="flex items-center justify-between">
            <DialogTitle className="text-sm font-bold flex items-center gap-2">
              <Crop className="w-4 h-4 text-primary" />
              {title}
            </DialogTitle>
            <button onClick={onCancel} className="h-7 w-7 flex items-center justify-center rounded-lg hover:bg-muted">
              <X className="w-4 h-4" />
            </button>
          </div>
        </DialogHeader>

        {/* ── لوحة القص التفاعلية ── */}
        <div ref={containerRef} className="bg-[#111] flex items-center justify-center select-none"
          style={{ touchAction: 'none' }}>
          <canvas
            ref={canvasRef}
            width={CANVAS_W}
            height={CANVAS_H}
            style={{ width: '100%', maxWidth: CANVAS_W, cursor, touchAction: 'none' }}
            onMouseDown={onPointerDown}
            onTouchStart={onPointerDown}
            onMouseMove={onMouseMoveCanvas}
          />
        </div>

        {/* ── أدوات التحكم ── */}
        <div className="px-4 pt-3 pb-2 space-y-3 overflow-y-auto" style={{ maxHeight: 240 }}>

          {/* شريط أدوات سريعة */}
          <div className="flex flex-wrap items-center gap-1.5">
            {/* تكبير/تصغير */}
            <button onClick={() => setZoom(z => Math.max(0.5, z - 0.1))}
              className="h-8 w-8 rounded-lg border border-border hover:bg-muted flex items-center justify-center">
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="text-xs text-muted-foreground w-8 text-center">{zoom.toFixed(1)}×</span>
            <button onClick={() => setZoom(z => Math.min(4, z + 0.1))}
              className="h-8 w-8 rounded-lg border border-border hover:bg-muted flex items-center justify-center">
              <ZoomIn className="w-3.5 h-3.5" />
            </button>

            <div className="w-px h-6 bg-border mx-0.5" />

            {/* تدوير */}
            <button onClick={() => setRotation(r => r - 90)}
              className="h-8 w-8 rounded-lg border border-border hover:bg-muted flex items-center justify-center">
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
            <button onClick={() => setRotation(r => r + 90)}
              className="h-8 w-8 rounded-lg border border-border hover:bg-muted flex items-center justify-center">
              <RotateCw className="w-3.5 h-3.5" />
            </button>

            {/* قلب أفقي */}
            <button onClick={() => setFlip(f => !f)}
              className={`h-8 w-8 rounded-lg border flex items-center justify-center transition-colors ${
                flip ? 'bg-primary text-primary-foreground border-primary' : 'border-border hover:bg-muted'}`}>
              <FlipHorizontal className="w-3.5 h-3.5" />
            </button>

            <div className="w-px h-6 bg-border mx-0.5" />

            {/* نسبة الأبعاد */}
            {([
              { label: 'حر',  val: null },
              { label: '1:1', val: 1    },
              { label: '4:3', val: 4/3  },
              { label: '3:4', val: 3/4  },
              { label: '16:9',val: 16/9 },
            ] as { label: string; val: number | null }[]).map(({ label, val }) => (
              <button key={label}
                onClick={() => changeAspect(val)}
                className={`h-8 px-2 rounded-lg border text-xs font-semibold transition-colors ${
                  aspect === val
                    ? 'bg-primary text-primary-foreground border-primary'
                    : 'border-border hover:bg-muted text-muted-foreground'}`}>
                {label}
              </button>
            ))}

            <button onClick={resetAll}
              className="h-8 px-2.5 rounded-lg border border-border hover:bg-muted text-xs text-muted-foreground mr-auto">
              إعادة
            </button>
          </div>

          {/* أشرطة التعديل */}
          <div className="space-y-2.5 border border-border/40 rounded-xl p-3 bg-muted/20">
            <AdjustRow icon={Sun}      label="الإضاءة" value={brightness} min={50}  max={200} onChange={setBrightness} />
            <AdjustRow icon={Contrast as React.FC<React.SVGProps<SVGSVGElement>>} label="التباين"  value={contrast}   min={50}  max={200} onChange={setContrast} />
            <AdjustRow icon={Droplets} label="التشبع"   value={saturation} min={0}   max={200} onChange={setSaturation} />
          </div>

          {/* أبعاد مستطيل القص اليدوية */}
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span>العرض</span>
            <input type="number" min={40} max={CANVAS_W}
              value={Math.round(cropRect.w)}
              onChange={e => {
                const nw = clamp(+e.target.value, 40, CANVAS_W - cropRect.x);
                setCropRect(r => ({
                  ...r, w: nw,
                  h: aspect !== null ? nw / aspect : r.h,
                }));
              }}
              className="w-16 h-7 border border-border rounded px-1 text-center bg-background text-foreground text-xs"
            />
            <span>×</span>
            <span>الارتفاع</span>
            <input type="number" min={40} max={CANVAS_H}
              value={Math.round(cropRect.h)}
              onChange={e => {
                const nh = clamp(+e.target.value, 40, CANVAS_H - cropRect.y);
                setCropRect(r => ({
                  ...r, h: nh,
                  w: aspect !== null ? nh * aspect : r.w,
                }));
              }}
              className="w-16 h-7 border border-border rounded px-1 text-center bg-background text-foreground text-xs"
            />
            <span className="text-muted-foreground/60 text-[10px]">بكسل (نسبي)</span>
          </div>
        </div>

        {/* أزرار التأكيد */}
        <div className="flex items-center justify-between gap-3 px-4 py-3 border-t border-border/40 bg-muted/10">
          <Button variant="outline" size="sm" onClick={onCancel} disabled={processing}>إلغاء</Button>
          <Button size="sm" onClick={handleConfirm} disabled={processing} className="gap-1.5">
            <Check className="w-3.5 h-3.5" />
            {processing ? 'جارٍ المعالجة...' : 'تطبيق وحفظ'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
