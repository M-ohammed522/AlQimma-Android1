/**
 * SmartDateInput — إدخال تاريخ ذكي بتنسيق يوم/شهر/سنة
 * - يستخدم input[type=text] inputMode=numeric لمنع تقويم المتصفح تماماً
 * - كل قسم (يوم، شهر، سنة) يُعدَّل باستقلالية بأرقام فقط
 * - عند كتابة رقم يوم أحادي (4-9) يُضاف الصفر تلقائياً وينتقل للشهر
 * - عند كتابة رقم شهر أحادي (2-9) يُضاف الصفر تلقائياً وينتقل للسنة
 */
import React, { useRef, useState, useEffect, useCallback } from 'react';
import { Calendar } from 'lucide-react';

interface SmartDateInputProps {
  value: string;       // ISO: YYYY-MM-DD
  onChange: (iso: string) => void;
  className?: string;
}

type Segment = 'day' | 'month' | 'year';
const SEGMENTS: Segment[] = ['day', 'month', 'year'];

function clamp(v: number, min: number, max: number) { return Math.min(max, Math.max(min, v)); }

function parseISO(iso: string) {
  if (!iso) {
    const n = new Date();
    return { day: String(n.getDate()).padStart(2, '0'), month: String(n.getMonth() + 1).padStart(2, '0'), year: String(n.getFullYear()) };
  }
  const [y, m, d] = iso.split('-');
  return {
    day:   (d ?? '01').padStart(2, '0'),
    month: (m ?? '01').padStart(2, '0'),
    year:  (y ?? String(new Date().getFullYear())),
  };
}

export function SmartDateInput({ value, onChange, className = '' }: SmartDateInputProps) {
  const [parts, setParts] = useState(() => parseISO(value));
  const [buf, setBuf]     = useState('');
  const [active, setActive] = useState<Segment | null>(null);

  const dayRef   = useRef<HTMLInputElement>(null);
  const monthRef = useRef<HTMLInputElement>(null);
  const yearRef  = useRef<HTMLInputElement>(null);
  const refs: Record<Segment, React.RefObject<HTMLInputElement | null>> = { day: dayRef, month: monthRef, year: yearRef };

  useEffect(() => { setParts(parseISO(value)); }, [value]);

  const emit = useCallback((p: typeof parts) => {
    const y = p.year.padStart(4, '0');
    const m = p.month.padStart(2, '0');
    const d = p.day.padStart(2, '0');
    if (y.length === 4 && +y >= 1900) onChange(`${y}-${m}-${d}`);
  }, [onChange]);

  const focusSeg = useCallback((seg: Segment) => {
    setActive(seg);
    setBuf('');
    // select كل المحتوى عند التركيز
    setTimeout(() => { refs[seg].current?.select(); }, 0);
  }, []);

  const nextSeg = (seg: Segment) => {
    const idx = SEGMENTS.indexOf(seg);
    if (idx < SEGMENTS.length - 1) focusSeg(SEGMENTS[idx + 1]);
    else refs[seg].current?.blur();
  };
  const prevSeg = (seg: Segment) => {
    const idx = SEGMENTS.indexOf(seg);
    if (idx > 0) focusSeg(SEGMENTS[idx - 1]);
  };

  // منع إظهار التقويم على الموبايل والتحكم الكامل بالإدخال
  const handleKeyDown = (seg: Segment, e: React.KeyboardEvent<HTMLInputElement>) => {
    // نمنع السلوك الافتراضي دائماً لمنع أي picker
    e.preventDefault();

    if (e.key === 'ArrowRight' || e.key === 'Tab')  { nextSeg(seg); return; }
    if (e.key === 'ArrowLeft')                       { prevSeg(seg); return; }
    if (e.key === 'Backspace' || e.key === 'Delete') {
      const reset = seg === 'year' ? String(new Date().getFullYear()) : '01';
      const np = { ...parts, [seg]: reset };
      setParts(np); emit(np); setBuf(''); return;
    }
    if (!/^\d$/.test(e.key)) return;

    const digit = e.key;
    const newBuf = buf + digit;

    if (seg === 'day') {
      if (newBuf.length === 1) {
        if (+digit >= 4) {
          const d = String(clamp(+digit, 1, 31)).padStart(2, '0');
          const np = { ...parts, day: d };
          setParts(np); emit(np); setBuf(''); nextSeg(seg);
        } else {
          setBuf(newBuf);
          const np = { ...parts, day: '0' + digit };
          setParts(np); emit(np);
        }
      } else {
        const d = String(clamp(+newBuf, 1, 31)).padStart(2, '0');
        const np = { ...parts, day: d };
        setParts(np); emit(np); setBuf(''); nextSeg(seg);
      }
    } else if (seg === 'month') {
      if (newBuf.length === 1) {
        if (+digit >= 2) {
          const m = String(clamp(+digit, 1, 12)).padStart(2, '0');
          const np = { ...parts, month: m };
          setParts(np); emit(np); setBuf(''); nextSeg(seg);
        } else {
          setBuf(newBuf);
          const np = { ...parts, month: '0' + digit };
          setParts(np); emit(np);
        }
      } else {
        const m = String(clamp(+newBuf, 1, 12)).padStart(2, '0');
        const np = { ...parts, month: m };
        setParts(np); emit(np); setBuf(''); nextSeg(seg);
      }
    } else {
      // السنة 4 أرقام
      const nb = buf.length < 3 ? newBuf : buf.slice(1) + digit;
      setBuf(nb);
      const yr = nb.padStart(4, String(new Date().getFullYear())[0]);
      const np = { ...parts, year: yr };
      setParts(np);
      if (nb.length === 4) { emit(np); setBuf(''); }
    }
  };

  // منع الصق والتعديل المباشر وأي picker
  const handleChange = () => { /* نتحكم يدوياً بالقيمة */ };
  const handlePaste  = (e: React.ClipboardEvent) => { e.preventDefault(); };

  const segBase = 'bg-transparent border-none outline-none font-mono font-semibold text-xs text-center caret-transparent cursor-pointer p-0 leading-none';

  const segCls = (seg: Segment) => [
    segBase,
    seg === 'year' ? 'w-9' : 'w-6',
    active === seg ? 'text-emerald-600' : 'text-foreground',
  ].join(' ');

  return (
    <div
      className={[
        'flex items-center h-10 px-2.5 gap-0 rounded-lg border transition-all cursor-text overflow-hidden',
        active
          ? 'border-emerald-500/60 ring-1 ring-emerald-500/20 bg-background'
          : 'border-border/50 bg-muted/40',
        className,
      ].join(' ')}
      onClick={() => !active && focusSeg('day')}
    >
      <Calendar className="w-3 h-3 text-muted-foreground/40 shrink-0 mr-1.5" />

      {/* اليوم */}
      <input
        ref={dayRef} type="text" inputMode="numeric" pattern="\d*" autoComplete="off"
        value={parts.day} onChange={handleChange} onPaste={handlePaste}
        onFocus={() => focusSeg('day')} onBlur={() => setActive(null)}
        onKeyDown={e => handleKeyDown('day', e)}
        className={segCls('day')}
        style={{ background: active === 'day' ? 'hsl(var(--emerald-500,152 69% 60%) / 0.15)' : 'transparent', borderRadius: '4px' }}
      />
      <span className="text-muted-foreground/50 text-sm select-none leading-none mx-0.5">/</span>

      {/* الشهر */}
      <input
        ref={monthRef} type="text" inputMode="numeric" pattern="\d*" autoComplete="off"
        value={parts.month} onChange={handleChange} onPaste={handlePaste}
        onFocus={() => focusSeg('month')} onBlur={() => setActive(null)}
        onKeyDown={e => handleKeyDown('month', e)}
        className={segCls('month')}
        style={{ background: active === 'month' ? 'rgba(16,185,129,0.12)' : 'transparent', borderRadius: '4px' }}
      />
      <span className="text-muted-foreground/50 text-sm select-none leading-none mx-0.5">/</span>

      {/* السنة */}
      <input
        ref={yearRef} type="text" inputMode="numeric" pattern="\d*" autoComplete="off"
        value={parts.year} onChange={handleChange} onPaste={handlePaste}
        onFocus={() => focusSeg('year')} onBlur={() => setActive(null)}
        onKeyDown={e => handleKeyDown('year', e)}
        className={segCls('year')}
        style={{ background: active === 'year' ? 'rgba(16,185,129,0.12)' : 'transparent', borderRadius: '4px' }}
      />
    </div>
  );
}

export default SmartDateInput;


