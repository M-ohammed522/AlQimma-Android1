// زر التحديث الاحترافي — يُستخدم في كامل المنظومة
import React, { useState, useCallback } from 'react';
import { RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface RefreshButtonProps {
  /** دالة التحديث — تدعم async */
  onRefresh: () => void | Promise<void>;
  /** حالة تحميل خارجية (اختياري) */
  loading?: boolean;
  /** حجم الزر */
  size?: 'sm' | 'default';
  /** تصميم الزر */
  variant?: 'default' | 'ghost' | 'outline' | 'white' | 'dark';
  /** إخفاء النص وإظهار الأيقونة فقط */
  iconOnly?: boolean;
  /** نص الزر */
  label?: string;
  className?: string;
}

export function RefreshButton({
  onRefresh,
  loading: externalLoading,
  size = 'sm',
  variant = 'ghost',
  iconOnly = false,
  label = 'تحديث',
  className,
}: RefreshButtonProps) {
  const [internalLoading, setInternalLoading] = useState(false);
  const [justDone, setJustDone] = useState(false);

  const isLoading = externalLoading ?? internalLoading;

  const handleClick = useCallback(async () => {
    if (isLoading) return;
    setInternalLoading(true);
    setJustDone(false);
    try {
      await onRefresh();
    } finally {
      setInternalLoading(false);
      setJustDone(true);
      setTimeout(() => setJustDone(false), 600);
    }
  }, [isLoading, onRefresh]);

  // أنماط التصميم حسب الـ variant
  const variantClass = {
    default: 'bg-primary/10 text-primary hover:bg-primary/20 border border-primary/20',
    ghost:   'bg-transparent hover:bg-white/10 border border-white/20 text-white',
    outline: 'bg-transparent hover:bg-primary/5 border border-border text-foreground',
    white:   'bg-white/12 text-white hover:bg-white/22 border border-white/25',
    dark:    'bg-muted hover:bg-muted/80 border border-border text-foreground',
  }[variant];

  return (
    <Button
      size={size}
      onClick={handleClick}
      disabled={isLoading}
      className={cn(
        'gap-1.5 transition-colors duration-200 shrink-0',
        variantClass,
        className
      )}
    >
      <RefreshCw
        className={cn(
          'shrink-0',
          size === 'sm' ? 'w-3.5 h-3.5' : 'w-4 h-4',
          isLoading && 'animate-spin',
          justDone && 'text-emerald-400',
          'transition-colors duration-300'
        )}
      />
      {!iconOnly && (
        <span className={cn(
          'transition-opacity duration-200',
          isLoading ? 'opacity-50' : 'opacity-100'
        )}>
          {label}
        </span>
      )}
    </Button>
  );
}

export default RefreshButton;
