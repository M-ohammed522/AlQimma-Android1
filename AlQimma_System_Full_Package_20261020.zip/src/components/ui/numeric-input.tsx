import React from 'react';
import { Input } from '@/components/ui/input';

/**
 * تحويل الأرقام العربية المشرقية والفارسية (٠١٢٣٤٥٦٧٨٩) إلى أرقام لاتينية قياسية (0-9)
 */
export function normalizeArabicNumerals(input: string): string {
  if (!input) return '';
  return input
    .replace(/[٠۰]/g, '0')
    .replace(/[١۱]/g, '1')
    .replace(/[٢۲]/g, '2')
    .replace(/[٣۳]/g, '3')
    .replace(/[٤۴]/g, '4')
    .replace(/[٥۵]/g, '5')
    .replace(/[٦۶]/g, '6')
    .replace(/[٧۷]/g, '7')
    .replace(/[٨۸]/g, '8')
    .replace(/[٩۹]/g, '9')
    .replace(/[،,]/g, '.');
}

export interface NumericInputProps
  extends Omit<React.ComponentProps<typeof Input>, 'onChange'> {
  value?: string | number;
  onChange?: (value: string, e: React.ChangeEvent<HTMLInputElement>) => void;
  allowDecimal?: boolean;
  allowNegative?: boolean;
  maxLength?: number;
}

/**
 * مكون إدخال رقمي احترافي يجبر لوحة المفاتيح الرقمية (Numeric Keypad)
 * على الظهور بسلاسة في كافة الهواتف الذكية مع فلترة فورية للأحرف
 */
export const NumericInput = React.forwardRef<HTMLInputElement, NumericInputProps>(
  (
    {
      value = '',
      onChange,
      allowDecimal = false,
      allowNegative = false,
      maxLength,
      className = '',
      ...props
    },
    ref
  ) => {
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      let raw = normalizeArabicNumerals(e.target.value);

      if (allowDecimal) {
        // السماح بالأرقام ونقطة عشرية واحدة فقط
        raw = raw.replace(/[^0-9.-]/g, '');
        if (!allowNegative) {
          raw = raw.replace(/-/g, '');
        } else {
          // السماح بإشارة السالب في البداية فقط
          const isNeg = raw.startsWith('-');
          raw = (isNeg ? '-' : '') + raw.replace(/-/g, '');
        }

        // التأكد من وجود نقطة عشرية واحدة فقط
        const parts = raw.split('.');
        if (parts.length > 2) {
          raw = parts[0] + '.' + parts.slice(1).join('');
        }
      } else {
        // أرقام صحيحة فقط
        raw = raw.replace(/[^0-9-]/g, '');
        if (!allowNegative) {
          raw = raw.replace(/-/g, '');
        } else {
          const isNeg = raw.startsWith('-');
          raw = (isNeg ? '-' : '') + raw.replace(/-/g, '');
        }
      }

      if (maxLength && raw.length > maxLength) {
        raw = raw.slice(0, maxLength);
      }

      if (onChange) {
        onChange(raw, e);
      }
    };

    return (
      <Input
        ref={ref}
        type="text"
        inputMode={allowDecimal ? 'decimal' : 'numeric'}
        pattern={allowDecimal ? '[0-9]*[.,]?[0-9]*' : '[0-9]*'}
        value={value}
        onChange={handleChange}
        maxLength={maxLength}
        dir="ltr"
        className={`font-mono text-center tracking-wider ${className}`}
        {...props}
      />
    );
  }
);

NumericInput.displayName = 'NumericInput';
