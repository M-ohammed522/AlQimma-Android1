// مكون ترويسة الصفحة المشترك - منظومة معهد القمة
import React from 'react';
import { cn } from '@/lib/utils';

type HeaderVariant =
  | 'primary'    // أزرق مؤسسي — الداشبورد، الطلاب
  | 'finance'    // أخضر زمردي — المالية
  | 'indigo'     // نيلي — الإيصالات
  | 'teal'       // فيروزي — الأرشيف، الترحيل
  | 'purple'     // بنفسجي — المشاريع
  | 'slate'      // رمادي — الإعدادات
  | 'green';     // أخضر — السجلات

const GRADIENTS: Record<HeaderVariant, string> = {
  primary: 'from-[hsl(213,58%,20%)] via-[hsl(220,52%,27%)] to-[hsl(213,45%,32%)]',
  finance: 'from-emerald-800 via-emerald-700 to-teal-700',
  indigo:  'from-indigo-800 via-indigo-700 to-blue-700',
  teal:    'from-teal-800 via-teal-700 to-cyan-700',
  purple:  'from-purple-800 via-purple-700 to-indigo-700',
  slate:   'from-slate-700 via-slate-600 to-slate-500',
  green:   'from-green-800 via-green-700 to-emerald-600',
};

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  icon: React.ComponentType<{ className?: string }>;
  variant?: HeaderVariant;
  actions?: React.ReactNode;
  onBack?: () => void;
  className?: string;
}

export function PageHeader({
  title,
  subtitle,
  icon: Icon,
  variant = 'primary',
  actions,
  className,
}: PageHeaderProps) {
  const gradient = GRADIENTS[variant];

  return (
    <div
      className={cn('relative rounded-2xl overflow-hidden', className)}
      style={{ boxShadow: 'var(--shadow-lg)' }}
    >
      {/* خلفية التدرج */}
      <div className={cn('absolute inset-0 bg-gradient-to-br', gradient)} />
      {/* طبقة نقاط زخرفية */}
      <div
        className="absolute inset-0 opacity-[0.07]"
        style={{
          backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)',
          backgroundSize: '22px 22px',
        }}
      />
      {/* هالة ضوء */}
      <div className="absolute -top-14 -right-14 w-40 h-40 bg-white/6 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-8 -left-8 w-28 h-28 bg-black/10 rounded-full blur-2xl pointer-events-none" />

      {/* المحتوى */}
      <div className="relative px-5 py-4 md:px-6 flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* الجانب الأيسر — أيقونة + عنوان */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-white/14 border border-white/20 flex items-center justify-center shrink-0">
            <Icon className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-white leading-tight">{title}</h1>
            {subtitle && (
              <p className="text-white/55 text-xs mt-0.5 font-medium">{subtitle}</p>
            )}
          </div>
        </div>

        {/* الجانب الأيمن — إجراءات */}
        {actions && (
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            {actions}
          </div>
        )}
      </div>
    </div>
  );
}
