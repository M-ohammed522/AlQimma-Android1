// ─── Lazy imports لكل الصفحات ما عدا الصفحة الرئيسية لسرعة الفتح الفوري ───────
import { lazy, Suspense, type ReactElement } from 'react';
import { useLocation } from 'react-router-dom';
import DashboardPage from './pages/DashboardPage';
import { useDeviceRole } from '@/contexts/DeviceRoleContext';
import AccessDeniedView from '@/components/common/AccessDeniedView';

// باقي الصفحات: lazy components
const StudentManagementPage    = lazy(() => import('./pages/StudentManagementPage'));
const StudentFinancePage       = lazy(() => import('./pages/StudentFinancePage'));
const ReceiptsPage             = lazy(() => import('./pages/ReceiptsPage'));
const SupplyOrdersPage         = lazy(() => import('./pages/SupplyOrdersPage'));
const DiplomaRegistryPage      = lazy(() => import('./pages/DiplomaRegistryPage'));
const FinancialReportPage      = lazy(() => import('./pages/FinancialReportPage'));
const ArchivePage              = lazy(() => import('./pages/ArchivePage'));
const StudentPromotionPage     = lazy(() => import('./pages/StudentPromotionPage'));
const StudentRegistrationPage  = lazy(() => import('./pages/StudentRegistrationPage'));
const StudentProfilePage       = lazy(() => import('./pages/StudentProfilePage'));
const GraduationProjectsPage   = lazy(() => import('./pages/GraduationProjectsPage'));
const SpecializationReportPage = lazy(() => import('./pages/SpecializationReportPage'));
const SystemSettingsPage       = lazy(() => import('./pages/SystemSettingsPage'));
const WhatsAppPage             = lazy(() => import('./pages/WhatsAppPage'));

// preload تدريجي خفيف في الخلفية بعد استقرار الصفحة الرئيسية تماماً
// لتجنب اختناق اتصال الإنترنت أو شبكة 4G عند الإقلاع أو تحديث الصفحات
export function preloadAllPages() {
  const load = () => {
    // تحميل تدريجي للصفحات متباعداً لتفادي اختناق الشبكة وتسريع الاستجابة
    setTimeout(() => { import('./pages/StudentManagementPage'); }, 6000);
    setTimeout(() => { import('./pages/StudentFinancePage'); }, 10000);
    setTimeout(() => { import('./pages/SupplyOrdersPage'); }, 14000);
    setTimeout(() => { import('./pages/ReceiptsPage'); }, 18000);
    setTimeout(() => { import('./pages/FinancialReportPage'); }, 22000);
  };

  if (typeof window !== 'undefined' && 'requestIdleCallback' in window) {
    (window as any).requestIdleCallback(load, { timeout: 15000 });
  } else {
    setTimeout(load, 8000);
  }
}

// مؤشر تحميل لطيف واحترافي يحمل هوية معهد القمة
function PageLoader() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4 p-6 text-center select-none" dir="rtl">
      <div className="relative flex items-center justify-center">
        <div className="w-14 h-14 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center shadow-inner">
          <span className="text-2xl">🏛️</span>
        </div>
        <div className="absolute inset-0 w-14 h-14 border-2 border-primary/30 border-t-primary rounded-2xl animate-spin" />
      </div>
      <div className="space-y-1">
        <p className="text-sm font-bold text-foreground">معهد القمة للعلوم الطبية والإدارية</p>
        <p className="text-xs text-muted-foreground animate-pulse">جاري تحميل الصفحة...</p>
      </div>
    </div>
  );
}

// wrapper يلفّ كل صفحة بـ Suspense وحماية الصلاحيات
function wrap(element: ReactElement, path: string): ReactElement {
  return <ProtectedRouteWrapper element={<Suspense fallback={<PageLoader />}>{element}</Suspense>} path={path} />;
}

// ─── حارس الصلاحيات الفعلي للمسارات ──────────────────────────────────────────
export function ProtectedRouteWrapper({ element, path }: { element: ReactElement; path: string }) {
  const { canViewPath, loading } = useDeviceRole();
  const location = useLocation();

  if (loading) {
    return <PageLoader />;
  }

  // فحص ما إذا كان الجهاز مصرحاً له بعرض هذه الصفحة
  if (!canViewPath(location.pathname) && !canViewPath(path)) {
    return <AccessDeniedView />;
  }

  return element;
}

// ─── نوع المسار ──────────────────────────────────────────────────────────────
export interface RouteConfig {
  path: string;
  name: string;
  element: ReactElement;
}

// ─── قائمة المسارات ───────────────────────────────────────────────────────────
export const routes: RouteConfig[] = [
  { path: '/',                 name: 'لوحة التحكم',         element: <ProtectedRouteWrapper element={<DashboardPage />} path="/" /> },
  { path: '/students',         name: 'إدارة الطلاب',        element: wrap(<StudentManagementPage />, '/students') },
  { path: '/finance',          name: 'الإدارة المالية',     element: wrap(<StudentFinancePage />, '/finance') },
  { path: '/receipts',         name: 'إيصالات الدفع',       element: wrap(<ReceiptsPage />, '/receipts') },
  { path: '/supply-orders',    name: 'أوامر التوريد',       element: wrap(<SupplyOrdersPage />, '/supply-orders') },
  { path: '/diploma-registry', name: 'سجلات الدبلوم',      element: wrap(<DiplomaRegistryPage />, '/diploma-registry') },
  { path: '/financial-report', name: 'الأرباح والتحصيل',    element: wrap(<FinancialReportPage />, '/financial-report') },
  { path: '/archive',          name: 'الأرشيف',             element: wrap(<ArchivePage />, '/archive') },
  { path: '/promotion',        name: 'ترحيل الطلاب',        element: wrap(<StudentPromotionPage />, '/promotion') },
  { path: '/register',         name: 'تسجيل طالب',         element: wrap(<StudentRegistrationPage />, '/register') },
  { path: '/student/:id',      name: 'الملف الشامل',        element: wrap(<StudentProfilePage />, '/student/:id') },
  { path: '/projects',         name: 'مشاريع التخرج',       element: wrap(<GraduationProjectsPage />, '/projects') },
  { path: '/specializations',  name: 'التخصصات والتقارير',  element: wrap(<SpecializationReportPage />, '/specializations') },
  { path: '/settings',         name: 'إعدادات النظام',      element: wrap(<SystemSettingsPage />, '/settings') },
  { path: '/whatsapp',         name: 'رسائل واتساب',        element: wrap(<WhatsAppPage />, '/whatsapp') },
];
