import React, { Component, type ReactNode, useEffect, useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from '@/components/ui/sonner';
import { routes, preloadAllPages } from './routes';
import { ScrollToTop } from '@/components/ScrollToTop';
import { DeviceRoleProvider, useDeviceRole } from '@/contexts/DeviceRoleContext';
import DeviceSetupModal from '@/components/common/DeviceSetupModal';
import { WelcomeTransitionModal } from '@/components/common/WelcomeTransitionModal';


// ─── جدار حماية الأخطاء ─────────────────────────────────────────────────────
// يمنع الشاشة السوداء الكاملة عند أي استثناء غير متوقع في شجرة المكونات
class ErrorBoundary extends Component<
  { children: ReactNode },
  { crashed: boolean; message: string }
> {
  state = { crashed: false, message: '' };

  static getDerivedStateFromError(error: Error) {
    return { crashed: true, message: error.message };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error('[المنظومة] خطأ غير متوقع:', error.message, info.componentStack);
  }

  render() {
    if (this.state.crashed) {
      return (
        <div
          dir="rtl"
          style={{
            minHeight: '100vh',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '16px',
            padding: '32px',
            textAlign: 'center',
            background: '#f8fafc',
            fontFamily: 'Cairo, sans-serif',
          }}
        >
          <div style={{ fontSize: '48px' }}>⚠️</div>
          <h1 style={{ fontSize: '20px', fontWeight: 700, color: '#1e293b', margin: 0 }}>
            حدث خطأ أثناء تحميل الصفحة
          </h1>
          <p style={{ fontSize: '14px', color: '#64748b', maxWidth: '420px', margin: 0 }}>
            {this.state.message || 'تعذّر تحميل هذا المكوّن. يرجى إعادة التحديث.'}
          </p>
          <button
            style={{
              padding: '10px 24px',
              background: '#1e3a5f',
              color: '#fff',
              border: 'none',
              borderRadius: '8px',
              fontFamily: 'Cairo, sans-serif',
              fontWeight: 700,
              fontSize: '14px',
              cursor: 'pointer',
            }}
            onClick={() => {
              this.setState({ crashed: false, message: '' });
              window.location.reload();
            }}
          >
            إعادة تحديث المنظومة
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

// ─── المحتوى الرئيسي للتطبيق ────────────────────────────────────────────────
function AppContent() {
  const { currentRole, isConfigured, loading } = useDeviceRole();
  const [showWelcome, setShowWelcome] = useState(false);

  // إظهار الشاشة الترحيبية تلقائياً عند الدخول لأول مرة في الجلسة إذا كان الجهاز مهيأً
  useEffect(() => {
    if (!loading && isConfigured) {
      const hasShown = sessionStorage.getItem('welcome_splash_shown_v4');
      if (!hasShown) {
        sessionStorage.setItem('welcome_splash_shown_v4', 'true');
        setShowWelcome(true);
      }
    }
  }, [loading, isConfigured]);

  return (
    <BrowserRouter>
      <ScrollToTop />
      <DeviceSetupModal />
      <WelcomeTransitionModal
        open={showWelcome}
        onClose={() => setShowWelcome(false)}
        roleName={currentRole?.name || 'المدير العام'}
        isFullPermissions={true}
      />
      <Routes>
        {routes.map((r) => (
          <Route key={r.path} path={r.path} element={r.element} />
        ))}
        {/* /v/* → صفحة التحقق المستقلة في public/v/index.html — لا تُعالَج بـ React Router */}
        <Route path="/v" element={null} />
        <Route path="/v/*" element={null} />
        {/* أي مسار غير معروف → الصفحة الرئيسية */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>

      <Toaster position="top-center" richColors />
    </BrowserRouter>
  );
}

// ─── التطبيق الرئيسي ─────────────────────────────────────────────────────────
export default function App() {
  // preload كل الصفحات في الخلفية بعد تحميل الصفحة الرئيسية
  useEffect(() => { preloadAllPages(); }, []);

  return (
    <ErrorBoundary>
      <DeviceRoleProvider>
        <AppContent />
      </DeviceRoleProvider>
    </ErrorBoundary>
  );
}
