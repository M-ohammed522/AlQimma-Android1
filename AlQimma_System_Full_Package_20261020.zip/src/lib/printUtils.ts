// أدوات الطباعة والتصدير المشتركة — منظومة معهد القمة
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTableLib from 'jspdf-autotable';
const autoTable = (typeof autoTableLib === 'function' ? autoTableLib : (autoTableLib as any).default) as typeof autoTableLib;

// ── ثوابت المعهد ──────────────────────────────────────────────
export const INSTITUTE_NAME = 'معهد القمة للعلوم الطبية والإدارية';
export const LOGO_URL =
  'https://miaoda-conversation-file.s3cdn.medo.dev/user-cim4m3x63pxc/app-f6avantw6h35/20261018/FB_IMG_1780949707596.jpg';

// ── CSS المشترك للطباعة (محسَّن A4) ──────────────────────────
function baseStyle(accent = '#1a3c5e', landscape = true): string {
  return `
  *{box-sizing:border-box;margin:0;padding:0;font-family:'Segoe UI',Tahoma,Arial,sans-serif}
  html,body{background:#fff;color:#111;direction:rtl;width:100%}
  .page{padding:10mm 12mm}

  /* ── رأس الصفحة ── */
  .hdr{display:flex;align-items:center;gap:14px;
       background:linear-gradient(135deg,#0f2744 0%,${accent} 55%,#1e5a94 100%);
       border-radius:10px;padding:14px 18px;margin-bottom:12px;
       -webkit-print-color-adjust:exact;print-color-adjust:exact}
  .hdr-logo{width:64px;height:64px;border-radius:50%;overflow:hidden;
            border:2.5px solid rgba(255,255,255,0.85);flex-shrink:0;background:#fff;
            box-shadow:0 0 0 3px rgba(255,255,255,0.15)}
  .hdr-logo img{width:100%;height:100%;object-fit:cover}
  .hdr-text{flex:1}
  .hdr-text .inst-name{font-size:15px;font-weight:900;color:#fff;margin-bottom:3px;
                        text-shadow:0 1px 4px rgba(0,0,0,0.25)}
  .hdr-text .sub1{font-size:11px;color:rgba(200,230,255,0.9);font-weight:600;margin-bottom:2px}
  .hdr-text .sub2{font-size:10px;color:rgba(180,215,255,0.75)}
  .hdr-meta{text-align:left;font-size:10px;color:rgba(200,230,255,0.9);
            line-height:1.9;white-space:nowrap;flex-shrink:0}
  .hdr-meta b{color:#fff}

  /* ── عنوان الكشف ── */
  .kshf-title{font-size:17px;font-weight:900;color:${accent};
              text-align:center;margin:10px 0 6px;
              padding:8px 0;border-top:2px solid #e0e6f0;border-bottom:2px solid #e0e6f0;
              letter-spacing:0.5px}
  .kshf-sub{font-size:12px;color:#555;text-align:center;margin-bottom:10px;font-weight:600}

  /* ── الجدول ── */
  table{width:100%;border-collapse:collapse;margin-bottom:14px;table-layout:auto;
        border-radius:8px;overflow:hidden}
  thead tr{background:linear-gradient(90deg,#0f2744 0%,${accent} 55%,#1e5a94 100%);
           -webkit-print-color-adjust:exact;print-color-adjust:exact}
  th{color:#fff;padding:10px 11px;font-size:11px;font-weight:700;
     white-space:nowrap;text-align:right;
     border-left:1px solid rgba(255,255,255,0.12)}
  th:last-child{border-left:none}
  td{padding:8px 11px;border-bottom:1px solid #e8eef5;font-size:11.5px;
     text-align:right;white-space:nowrap}
  tr:nth-child(even) td{background:#f4f8ff}
  tr:last-child td{border-bottom:none}
  .total-row td{background:#e8f1ff;font-weight:800;border-top:2px solid ${accent};
                font-size:12px;-webkit-print-color-adjust:exact;print-color-adjust:exact}

  /* ── التذييل ── */
  .footer{margin-top:14px;display:flex;justify-content:space-between;align-items:flex-end;
          border-top:2px solid #e0e6f0;padding-top:12px}
  .sig-row{display:flex;gap:50px}
  .sig-box{text-align:center}
  .sig-line{border-bottom:1.5px solid #aaa;width:140px;height:30px;margin-bottom:5px}
  .sig-label{font-size:10px;color:#666;font-weight:700}
  .footer-copy{text-align:left;font-size:9px;color:#aaa;line-height:1.8}

  @media print{
    @page{size:A4 ${landscape ? 'landscape' : 'portrait'};margin:5mm}
    body{margin:0;-webkit-print-color-adjust:exact;print-color-adjust:exact}
    .hdr,thead tr,.total-row td,tr:nth-child(even) td{
      -webkit-print-color-adjust:exact;print-color-adjust:exact}
  }`;
}

function buildHeader(title: string, subtitle = '', totalInfo = '', accent = '#1a3c5e'): string {
  const now = new Date();
  return `
  <div class="hdr">
    <div class="hdr-logo"><img src="${LOGO_URL}" alt="شعار" crossorigin="anonymous"/></div>
    <div class="hdr-text">
      <div class="inst-name">${INSTITUTE_NAME}</div>
      ${totalInfo ? `<div class="sub1">${totalInfo}</div>` : ''}
    </div>
    <div class="hdr-meta">
      <div>تاريخ الطباعة: <b>${now.toLocaleDateString('ar-LY')}</b></div>
      <div>الوقت: <b>${now.toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit' })}</b></div>
    </div>
  </div>
  <div class="kshf-title">${title}</div>
  ${subtitle ? `<div class="kshf-sub">${subtitle}</div>` : ''}`;
}

function buildFooter(sig1 = 'توقيع المسؤول', sig2 = 'اعتماد المدير'): string {
  return `
  <div class="footer">
    <div class="sig-row">
      <div class="sig-box"><div class="sig-line"></div><div class="sig-label">${sig1}</div></div>
      <div class="sig-box"><div class="sig-line"></div><div class="sig-label">${sig2}</div></div>
    </div>
    <div class="footer-copy">
      <div style="font-weight:700;color:#1a3c5e;font-size:10px">${INSTITUTE_NAME}</div>
      <div>جميع الحقوق محفوظة © ${new Date().getFullYear()}</div>
    </div>
  </div>`;
}

// ── فتح نافذة طباعة مشتركة ────────────────────────────────────
function openPrintWindow(html: string, landscape = true): void {
  const win = window.open('about:blank', '_blank',
    `width=${landscape ? 1140 : 820},height=760,menubar=no,toolbar=no,location=no,status=no`
  );
  if (!win) {
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url  = URL.createObjectURL(blob);
    const a    = Object.assign(document.createElement('a'), { href: url, target: '_blank' });
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 10000);
    return;
  }
  win.document.open();
  win.document.write(html);
  win.document.close();
  win.onload = () => { setTimeout(() => { win.focus(); win.print(); }, 400); };
  setTimeout(() => { if (!win.closed) { win.focus(); win.print(); } }, 1400);
}

// ── طباعة جدول قياسي ─────────────────────────────────────────
export interface PrintTableOptions {
  title:       string;
  subtitle?:   string;
  totalInfo?:  string;
  accentColor?: string;
  columns:     string[];
  rows:        (string | number)[][];
  landscape?:  boolean;
  cellColor?:  Record<number, (val: string | number) => string>;
  hideSignatures?: boolean;
  totalRow?:   (string | number)[];
  sig1?: string;
  sig2?: string;
}

export function printTable(opts: PrintTableOptions): void {
  const accent    = opts.accentColor ?? '#1a3c5e';
  const landscape = opts.landscape    ?? true;

  const thead = `<tr>${opts.columns.map(c => `<th>${c}</th>`).join('')}</tr>`;
  const tbody = opts.rows.map(row => {
    const cells = row.map((cell, ci) => {
      const color = opts.cellColor?.[ci]?.(cell) ?? '';
      const style = color ? `style="color:${color};font-weight:700"` : '';
      return `<td ${style}>${cell}</td>`;
    }).join('');
    return `<tr>${cells}</tr>`;
  }).join('');
  const totalRowHtml = opts.totalRow
    ? `<tr class="total-row">${opts.totalRow.map(c => `<td>${c}</td>`).join('')}</tr>`
    : '';

  const html = `<!DOCTYPE html>
<html dir="rtl"><head><meta charset="utf-8">
<title>${opts.title}</title>
<style>${baseStyle(accent, landscape)}</style>
</head><body>
<div class="page">
  ${buildHeader(opts.title, opts.subtitle, opts.totalInfo, accent)}
  <table><thead>${thead}</thead><tbody>${tbody}${totalRowHtml}</tbody></table>
  ${opts.hideSignatures ? '' : buildFooter(opts.sig1, opts.sig2)}
</div>
</body></html>`;

  openPrintWindow(html, landscape);
}

// ── طباعة HTML مخصص بالكامل (للتقارير المعقدة) ──────────────
export interface PrintCustomOptions {
  title:      string;
  bodyHtml:   string;
  landscape?: boolean;
  accentColor?: string;
  extraCss?:  string;
  hideSignatures?: boolean;
  sig1?: string;
  sig2?: string;
}

export function printCustom(opts: PrintCustomOptions): void {
  const accent    = opts.accentColor ?? '#1a3c5e';
  const landscape = opts.landscape    ?? true;

  const html = `<!DOCTYPE html>
<html dir="rtl"><head><meta charset="utf-8">
<title>${opts.title}</title>
<style>
${baseStyle(accent, landscape)}
${opts.extraCss ?? ''}
</style>
</head><body>
<div class="page">
  ${opts.bodyHtml}
  ${opts.hideSignatures ? '' : buildFooter(opts.sig1, opts.sig2)}
</div>
</body></html>`;

  openPrintWindow(html, landscape);
}

// ── PDF بـ jsPDF + autoTable ──────────────────────────────────
export interface ExportPDFOptions {
  title:       string;
  subtitle?:   string;
  totalInfo?:  string;
  accentColor?: string;
  columns:     string[];
  rows:        (string | number)[][];
  filename:    string;
  landscape?:  boolean;
  totalRow?:   (string | number)[];
}

export function exportPDF(opts: ExportPDFOptions): void {
  const landscape = opts.landscape ?? true;
  const accent    = opts.accentColor ?? '#1a3c5e';
  const rgb       = hexToRgb(accent);
  const now       = new Date();

  const doc = new jsPDF({ orientation: landscape ? 'landscape' : 'portrait', unit: 'mm', format: 'a4' });
  const pageW = doc.internal.pageSize.width;
  const pageH = doc.internal.pageSize.height;

  const drawHeader = () => {
    // شريط رأس متدرج
    doc.setFillColor(rgb[0], rgb[1], rgb[2]);
    doc.rect(0, 0, pageW, 24, 'F');
    // اسم المعهد
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.text(INSTITUTE_NAME, pageW / 2, 9, { align: 'center' });
    // عنوان الكشف
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.text(opts.title, pageW / 2, 16, { align: 'center' });
    // تاريخ + معلومات إضافية
    doc.setFontSize(7.5);
    doc.setTextColor(210, 230, 250);
    const dateStr = `${now.toLocaleDateString('ar-LY')}  ${now.toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit' })}`;
    doc.text(dateStr, 8, 16);
    if (opts.totalInfo) doc.text(opts.totalInfo, pageW - 8, 16, { align: 'right' });
    doc.setTextColor(50, 50, 50);
  };

  drawHeader();

  const safeRows  = opts.rows.map(row => row.map(cell => String(cell ?? '')));
  const totalBody = opts.totalRow ? [opts.totalRow.map(c => String(c ?? ''))] : [];

  autoTable(doc, {
    head:  [opts.columns],
    body:  [...safeRows, ...totalBody],
    startY: 28,
    styles: {
      fontSize: 8.5, halign: 'right', cellPadding: { top: 3, right: 4, bottom: 3, left: 4 },
      lineColor: [220, 228, 236], lineWidth: 0.2,
    },
    headStyles:  { fillColor: rgb, textColor: 255, fontStyle: 'bold', fontSize: 9 },
    alternateRowStyles: { fillColor: [245, 249, 255] },
    bodyStyles: { valign: 'middle' },
    ...(totalBody.length > 0 ? {
      didParseCell: (data: any) => {
        if (data.section === 'body' && data.row.index === safeRows.length) {
          data.cell.styles.fillColor = [230, 240, 255];
          data.cell.styles.fontStyle = 'bold';
          data.cell.styles.fontSize  = 9;
        }
      },
    } : {}),
    margin: { top: 28, right: 7, left: 7, bottom: 14 },
    didDrawPage: (data: any) => {
      if (data.pageNumber > 1) drawHeader();
      const pages = (doc as any).internal.getNumberOfPages();
      // تذييل الصفحة
      doc.setFontSize(7.5);
      doc.setTextColor(160);
      doc.text(`صفحة ${data.pageNumber} من ${pages}`, pageW / 2, pageH - 5, { align: 'center' });
      doc.text(INSTITUTE_NAME, 8, pageH - 5);
    },
  });

  const fname = opts.filename.endsWith('.pdf') ? opts.filename : `${opts.filename}.pdf`;
  triggerDownload(doc.output('blob'), fname);
}

// ── Excel بـ xlsx (محسَّن بعناوين + أعرض الأعمدة) ─────────────
export interface ExportExcelOptions {
  title:     string;
  subtitle?: string;
  columns:   string[];
  rows:      (string | number)[][];
  filename:  string;
  sheetName?: string;
  totalRow?:  (string | number)[];
}

export function exportExcel(opts: ExportExcelOptions): void {
  const sheetName = opts.sheetName ?? 'البيانات';
  const now       = new Date();
  const dateStr   = now.toLocaleDateString('ar-LY');
  const timeStr   = now.toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit' });

  const data: (string | number)[][] = [
    [INSTITUTE_NAME],
    [opts.title, '', '', `تاريخ التصدير: ${dateStr}  الوقت: ${timeStr}`],
    ...(opts.subtitle ? [[opts.subtitle]] : []),
    [],
    opts.columns,
    ...opts.rows,
    ...(opts.totalRow ? [opts.totalRow] : []),
  ];

  const ws = XLSX.utils.aoa_to_sheet(data);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, sheetName);

  // دمج صف المعهد
  ws['!merges'] = [
    { s: { r: 0, c: 0 }, e: { r: 0, c: Math.max(opts.columns.length - 1, 3) } },
    { s: { r: 1, c: 0 }, e: { r: 1, c: 1 } },
  ];

  // عرض الأعمدة تلقائي
  ws['!cols'] = opts.columns.map((col, i) => {
    const maxLen = Math.max(
      col.length + 2,
      ...opts.rows.map(r => String(r[i] ?? '').length),
    );
    return { wch: Math.min(maxLen + 3, 45) };
  });

  const fname  = opts.filename.endsWith('.xlsx') ? opts.filename : `${opts.filename}.xlsx`;
  const wbOut  = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  const blob   = new Blob([wbOut], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  triggerDownload(blob, fname);
}

// ── Word بـ HTML → .doc ────────────────────────────────────────
export interface ExportWordOptions {
  title:       string;
  subtitle?:   string;
  columns:     string[];
  rows:        (string | number)[][];
  filename:    string;
  accentColor?: string;
  totalRow?:   (string | number)[];
}

export function exportWord(opts: ExportWordOptions): void {
  const accent  = opts.accentColor ?? '#1a3c5e';
  const now     = new Date();

  const thStyle = `background:${accent};color:#fff;padding:9px 12px;border:1px solid ${accent};text-align:right;font-size:11px;font-weight:700`;
  const thead = opts.columns.map(c => `<th style="${thStyle}">${c}</th>`).join('');

  const tbody = opts.rows.map((row, ri) => {
    const bg = ri % 2 === 0 ? '#ffffff' : '#f0f7ff';
    const cells = row.map(cell =>
      `<td style="padding:7px 11px;border:1px solid #e0e0e0;text-align:right;background:${bg};font-size:11px">${String(cell ?? '')}</td>`
    ).join('');
    return `<tr>${cells}</tr>`;
  }).join('');

  const totalRowHtml = opts.totalRow
    ? `<tr>${opts.totalRow.map(c =>
        `<td style="padding:8px 11px;border:1px solid ${accent};text-align:right;background:#dbeafe;font-weight:800;font-size:11.5px">${String(c ?? '')}</td>`
      ).join('')}</tr>`
    : '';

  const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office"
    xmlns:w="urn:schemas-microsoft-com:office:word" dir="rtl">
<head><meta charset="utf-8"><title>${opts.title}</title>
<style>
  body{font-family:'Segoe UI',Arial,sans-serif;direction:rtl;color:#111;margin:15mm 18mm}
  .hdr-tbl{width:100%;border-collapse:collapse;margin-bottom:16px;
           background:linear-gradient(135deg,#0f2744,${accent});border-radius:8px;padding:12px 16px}
  h1{font-size:15px;color:#fff;margin:0 0 4px 0;font-weight:900}
  .sub{font-size:10.5px;color:rgba(200,230,255,0.9);margin:0 0 2px 0}
  .date-td{vertical-align:top;text-align:left;font-size:10px;
           color:rgba(200,230,255,0.85);white-space:nowrap;padding-right:10px}
  .logo-td{width:64px;vertical-align:middle;padding-left:12px}
  table.data{width:100%;border-collapse:collapse;margin-bottom:14px}
  .footer{font-size:9.5px;color:#aaa;text-align:center;margin-top:12px;
          border-top:1.5px solid #ddd;padding-top:9px}
</style></head>
<body>
<table class="hdr-tbl">
  <tr>
    <td class="logo-td">
      <img src="${LOGO_URL}" width="56" height="56"
        style="border-radius:50%;border:2.5px solid rgba(255,255,255,0.85);object-fit:cover" />
    </td>
    <td style="vertical-align:middle">
      <h1>${INSTITUTE_NAME}</h1>
      <p class="sub">${opts.title}</p>
      ${opts.subtitle ? `<p class="sub">${opts.subtitle}</p>` : ''}
    </td>
    <td class="date-td">
      تاريخ الإصدار:<br/><b style="color:#fff">${now.toLocaleDateString('ar-LY')}</b><br/>
      الوقت:<br/><b style="color:#fff">${now.toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit' })}</b>
    </td>
  </tr>
</table>
<table class="data">
  <thead><tr>${thead}</tr></thead>
  <tbody>${tbody}${totalRowHtml}</tbody>
</table>
<div class="footer">${INSTITUTE_NAME} &nbsp;|&nbsp; جميع الحقوق محفوظة © ${now.getFullYear()}</div>
</body></html>`;

  const blob = new Blob(['\uFEFF' + html], { type: 'application/msword;charset=utf-8' });
  triggerDownload(blob, opts.filename.endsWith('.doc') ? opts.filename : `${opts.filename}.doc`);
}

// ── مساعد موحد للتنزيل (يعمل مع التنزيلات المتكررة) ──────────
function triggerDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a   = document.createElement('a');
  a.href     = url;
  a.download = filename;
  // يجب إلحاق العنصر بالـ DOM أولاً قبل النقر لضمان عمله في كل المتصفحات
  a.style.cssText = 'position:fixed;top:-9999px;left:-9999px;visibility:hidden';
  document.body.appendChild(a);
  // requestAnimationFrame يضمن أن الـ DOM استقر قبل النقر
  requestAnimationFrame(() => {
    a.click();
    // تأخير طويل قبل revoke لضمان اكتمال التنزيل حتى للملفات الكبيرة
    setTimeout(() => {
      try { document.body.removeChild(a); } catch { /* already removed */ }
      URL.revokeObjectURL(url);
    }, 60000);
  });
}

export { triggerDownload };
function hexToRgb(hex: string): [number, number, number] {
  const r = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return r ? [parseInt(r[1], 16), parseInt(r[2], 16), parseInt(r[3], 16)] : [26, 60, 94];
}
