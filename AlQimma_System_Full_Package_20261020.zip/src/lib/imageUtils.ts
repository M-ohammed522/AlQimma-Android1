// أداة ضغط الصور — تحويل إلى WEBP، حد أقصى 1080p، جودة 0.8 مع تراجع تلقائي
const MAX_SIZE_BYTES = 1024 * 1024; // 1 MB
const MAX_DIM = 1080;

export async function compressImageIfNeeded(file: File): Promise<{ file: File; compressed: boolean }> {
  if (file.size <= MAX_SIZE_BYTES) return { file, compressed: false };

  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = async () => {
      URL.revokeObjectURL(url);
      // احسب الأبعاد المناسبة مع الحفاظ على النسبة
      let { width, height } = img;
      if (width > MAX_DIM || height > MAX_DIM) {
        if (width >= height) { height = Math.round(height * MAX_DIM / width); width = MAX_DIM; }
        else                 { width  = Math.round(width  * MAX_DIM / height); height = MAX_DIM; }
      }
      const canvas = document.createElement('canvas');
      canvas.width  = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d')!;
      ctx.drawImage(img, 0, 0, width, height);

      // تراجع تلقائي في الجودة حتى نصل أقل من 1 MB
      let quality = 0.8;
      let blob: Blob | null = null;
      while (quality >= 0.3) {
        blob = await new Promise<Blob | null>(res =>
          canvas.toBlob(res, 'image/webp', quality)
        );
        if (blob && blob.size <= MAX_SIZE_BYTES) break;
        quality -= 0.1;
      }
      if (!blob) { reject(new Error('فشل ضغط الصورة')); return; }
      const compressed = new File([blob], `photo_${Date.now()}.webp`, { type: 'image/webp' });
      resolve({ file: compressed, compressed: true });
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('فشل تحميل الصورة')); };
    img.src = url;
  });
}

// ضبط معاينة URL محلي
export function createPreviewUrl(file: File): string {
  return URL.createObjectURL(file);
}
