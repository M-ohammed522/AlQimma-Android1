// مساعدات طباعة الإيصال — مفصولة في ملف .ts لتجنب تعارض HMR مع HTML strings
import type { Student, Receipt, SemesterCharge } from '@/types/index';
import { SEMESTER_LABELS } from '@/types/index';
import { compareReceipts } from '@/lib/api';

const LOGO_URL = 'https://miaoda-conversation-file.s3cdn.medo.dev/user-cim4m3x63pxc/app-f6avantw6h35/20261018/FB_IMG_1780949707596.jpg';

function fmtArabicDate(iso: string): string {
  return new Date(iso).toLocaleDateString('ar-LY', {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
  });
}
function fmtArabicTime(iso: string): string {
  return new Date(iso).toLocaleTimeString('ar-LY', { hour: '2-digit', minute: '2-digit' });
}

// ── طباعة إيصال قبض احترافي — 3 نسخ في A4 ──
export function printReceipt(student: Student, receipt: Receipt) {
  const win = window.open('', '_blank', 'width=820,height=1100');
  if (!win) return;

  const now           = new Date().toISOString();
  const payDate       = fmtArabicDate(receipt.paid_at);
  const payTime       = fmtArabicTime(receipt.paid_at);
  const printTime     = fmtArabicTime(now);
  const printDate     = fmtArabicDate(now);
  const diplLabel     = student.diploma_type === 'عالي' ? 'دبلوم عالٍ' : 'دبلوم متوسط';
  const studentTypeTxt = student.is_exam_only ? 'طالب 100' : 'نظامي';
  const currentSemLabel = SEMESTER_LABELS[student.current_semester] ?? `الفصل ${student.current_semester}`;
  const purposeLabel  = receipt.semester_target ?? SEMESTER_LABELS[student.current_semester] ?? receipt.payment_type;
  const amtInt        = Math.floor(receipt.amount);
  const amtFrac       = Math.round((receipt.amount - amtInt) * 1000);
  const payMethod     = (receipt as Receipt & { payment_method?: string }).payment_method ?? 'كاش';
  const receiptNo     = String(receipt.receipt_number).padStart(6, '0');

  // دالة بناء نسخة واحدة
  const buildCopy = (copyLabel: string, copyColor: string) => `
<div class="receipt-copy">
  <!-- ترويسة -->
  <div class="rc-header" style="background:${copyColor}">
    <img class="rc-logo" src="${LOGO_URL}" alt="شعار"/>
    <div class="rc-title">
      <div class="rc-inst">معهد القمة للعلوم الطبية والإدارية</div>
      <div class="rc-branch">إدارة الشؤون المالية والإدارية</div>
    </div>
    <div class="rc-badge">
      <div class="rc-copy-lbl">${copyLabel}</div>
      <div class="rc-receipt-lbl">إيصال قبض</div>
      <div class="rc-num">${receiptNo}</div>
    </div>
  </div>

  <!-- شريط التواريخ -->
  <div class="rc-datebar">
    <span>&#128197; تاريخ الدفع: <b>${payDate}</b> — الساعة <b>${payTime}</b></span>
    <span>&#128438; طُبع: <b>${printDate}</b> الساعة <b>${printTime}</b></span>
  </div>

  <!-- جسم الإيصال -->
  <div class="rc-body">

    <!-- بيانات الطالب -->
    <div class="rc-section">
      <div class="rc-sec-title">بيانات الطالب</div>
      <div class="rc-grid4">
        <div class="rc-field">
          <div class="rc-fk">الاسم الرباعي</div>
          <div class="rc-fv">${student.full_name}</div>
        </div>
        <div class="rc-field">
          <div class="rc-fk">الرقم الوطني</div>
          <div class="rc-fv ltr">${student.national_id}</div>
        </div>
        <div class="rc-field">
          <div class="rc-fk">نوع الدبلوم</div>
          <div class="rc-fv">${diplLabel}</div>
        </div>
        <div class="rc-field">
          <div class="rc-fk">التخصص</div>
          <div class="rc-fv">${student.specialization ?? '—'}</div>
        </div>
        <div class="rc-field">
          <div class="rc-fk">الفصل الدراسي</div>
          <div class="rc-fv">${currentSemLabel}</div>
        </div>
        <div class="rc-field">
          <div class="rc-fk">نوع الطالب</div>
          <div class="rc-fv">${studentTypeTxt}</div>
        </div>
        ${student.phone ? `<div class="rc-field">
          <div class="rc-fk">رقم الهاتف</div>
          <div class="rc-fv ltr">${student.phone}</div>
        </div>` : '<div class="rc-field"></div>'}
        <div class="rc-field rc-field-fill"></div>
      </div>
    </div>

    <!-- تفاصيل الدفعة والمبلغ جنباً إلى جنب -->
    <div class="rc-pay-row">
      <div class="rc-section rc-pay-details">
        <div class="rc-sec-title">تفاصيل الدفعة</div>
        <div class="rc-pay-item">
          <span class="rc-pk">البيان</span>
          <span class="rc-pv">${purposeLabel}</span>
        </div>
        <div class="rc-pay-item">
          <span class="rc-pk">طريقة الدفع</span>
          <span class="rc-pv">${payMethod}</span>
        </div>
        ${receipt.notes ? `<div class="rc-pay-item">
          <span class="rc-pk">ملاحظات</span>
          <span class="rc-pv rc-notes">${receipt.notes}</span>
        </div>` : ''}
      </div>

      <!-- صندوق المبلغ -->
      <div class="rc-amount-box">
        <div class="rc-amt-lbl">المبلغ المستلم</div>
        <div class="rc-amt-val">${amtInt.toLocaleString('ar-LY')}${amtFrac > 0 ? `<span class="rc-frac">.${String(amtFrac).padStart(3,'0')}</span>` : ''}</div>
        <div class="rc-amt-cur">دينار ليبي</div>
      </div>
    </div>

  </div>

  <!-- تذييل -->
  <div class="rc-footer">
    <span>معهد القمة للعلوم الطبية والإدارية</span>
    <span>إيصال رقم: <b>${receiptNo}</b></span>
    <span>هذا الإيصال وثيقة رسمية — احتفظ به</span>
  </div>
</div>`;

  const css = `
@import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{
  font-family:'Cairo',Tahoma,Arial,sans-serif;
  direction:rtl;background:#f0f4f8;color:#1a1a1a;
  -webkit-print-color-adjust:exact;print-color-adjust:exact;
}

/* ── صفحة A4 ── */
.page{
  width:210mm;min-height:297mm;margin:0 auto;
  padding:6mm;
  background:#f0f4f8;
  display:flex;flex-direction:column;gap:0;
}

/* ── نسخة الإيصال ── */
.receipt-copy{
  flex:1;
  border:2px solid #1a3a6e;
  border-radius:10px;
  overflow:hidden;
  background:#fff;
  box-shadow:0 2px 8px rgba(0,0,0,.12);
  display:flex;flex-direction:column;
}

/* ── خط القص ── */
.cut-line{
  height:10mm;
  display:flex;align-items:center;justify-content:center;gap:6px;
  background:#f0f4f8;
  position:relative;
}
.cut-line::before,.cut-line::after{
  content:'';flex:1;
  border-top:2px dashed #9ca3af;
  margin:0 8px;
}
.cut-line-inner{
  display:flex;align-items:center;gap:5px;
  background:#fff;
  border:1.5px solid #d1d5db;
  border-radius:20px;
  padding:3px 14px;
  font-size:11px;font-weight:700;color:#6b7280;
  white-space:nowrap;
}
.cut-scissors{font-size:14px;}

/* ── ترويسة الإيصال ── */
.rc-header{
  padding:8px 12px;
  display:flex;align-items:center;gap:10px;
  flex-shrink:0;
  -webkit-print-color-adjust:exact;print-color-adjust:exact;
}
.rc-logo{
  width:52px;height:52px;border-radius:50%;
  border:2.5px solid rgba(255,255,255,.7);
  object-fit:cover;flex-shrink:0;background:#fff;
}
.rc-title{flex:1;text-align:center;}
.rc-inst{font-size:13px;font-weight:900;color:#fff;line-height:1.3;}
.rc-branch{font-size:10px;color:rgba(255,255,255,.85);margin-top:2px;}
.rc-badge{
  text-align:center;flex-shrink:0;min-width:80px;
  background:rgba(255,255,255,.15);
  border:2px solid rgba(255,255,255,.5);
  border-radius:10px;padding:6px 10px;
}
.rc-copy-lbl{
  font-size:9px;font-weight:700;color:rgba(255,255,255,.9);
  background:rgba(255,255,255,.2);border-radius:4px;
  padding:2px 6px;margin-bottom:3px;
}
.rc-receipt-lbl{font-size:10px;color:rgba(255,255,255,.8);font-weight:600;}
.rc-num{font-size:22px;font-weight:900;color:#fff;direction:ltr;line-height:1.1;letter-spacing:1px;}

/* ── شريط التاريخ ── */
.rc-datebar{
  background:#eef3fa;border-bottom:1.5px solid #c5d8f0;
  padding:5px 14px;
  display:flex;justify-content:space-between;
  font-size:10px;color:#374151;font-weight:600;flex-shrink:0;
}
.rc-datebar b{color:#1a3a6e;}

/* ── جسم الإيصال ── */
.rc-body{flex:1;padding:8px 14px 6px;display:flex;flex-direction:column;gap:7px;}

/* ── عنوان القسم ── */
.rc-section{flex-shrink:0;}
.rc-sec-title{
  font-size:10.5px;font-weight:800;color:#1a3a6e;
  border-bottom:1.5px solid #bfdbfe;
  padding-bottom:4px;margin-bottom:6px;
}

/* ── شبكة بيانات الطالب (4 أعمدة) ── */
.rc-grid4{display:grid;grid-template-columns:repeat(4,1fr);gap:3px 10px;}
.rc-field{min-width:0;}
.rc-fk{font-size:8.5px;color:#6b7280;font-weight:600;line-height:1.3;}
.rc-fv{font-size:11px;font-weight:800;color:#111;line-height:1.4;}
.rc-fv.ltr{direction:ltr;text-align:right;font-family:monospace;}
.rc-field-fill{background:transparent;}

/* ── صف الدفع والمبلغ ── */
.rc-pay-row{display:flex;gap:10px;align-items:stretch;flex-shrink:0;}
.rc-pay-details{flex:1;}
.rc-pay-item{
  display:flex;align-items:baseline;gap:8px;
  border-bottom:1px dotted #e5e7eb;
  padding:3px 0;
}
.rc-pk{font-size:9.5px;color:#6b7280;font-weight:600;flex-shrink:0;min-width:70px;}
.rc-pv{font-size:12px;font-weight:800;color:#1a3a6e;flex:1;}
.rc-notes{font-size:10px;font-weight:600;color:#6b7280;}

/* ── صندوق المبلغ ── */
.rc-amount-box{
  flex-shrink:0;
  min-width:110px;
  background:linear-gradient(135deg,#e8f5e9,#f1f8e9);
  border:2px solid #4caf50;border-radius:8px;
  padding:8px 12px;text-align:center;
  display:flex;flex-direction:column;align-items:center;justify-content:center;
  -webkit-print-color-adjust:exact;print-color-adjust:exact;
}
.rc-amt-lbl{font-size:9px;font-weight:700;color:#1b5e20;margin-bottom:4px;}
.rc-amt-val{font-size:22px;font-weight:900;color:#2e7d32;line-height:1.1;direction:ltr;}
.rc-frac{font-size:13px;font-weight:700;}
.rc-amt-cur{font-size:10px;font-weight:700;color:#388e3c;margin-top:3px;}

/* ── تذييل الإيصال ── */
.rc-footer{
  background:#1a3a6e;padding:5px 14px;
  display:flex;justify-content:space-between;align-items:center;
  font-size:9px;color:rgba(255,255,255,.8);flex-shrink:0;
  -webkit-print-color-adjust:exact;print-color-adjust:exact;
}
.rc-footer b{color:#fff;}

/* ── طباعة ── */
@media print{
  @page{size:A4 portrait;margin:0}
  html,body{background:#f0f4f8}
  .page{
    width:210mm;height:297mm;padding:5mm;
    gap:0;overflow:hidden;
  }
  .receipt-copy{box-shadow:none;}
}`;

  const html = `<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
<meta charset="utf-8"/>
<title>إيصال قبض — ${receiptNo}</title>
<style>${css}</style>
</head>
<body>
<div class="page">
  ${buildCopy('نسخة الطالب', 'linear-gradient(135deg,#0f2744 0%,#1a3c5e 50%,#1e88e5 100%)')}
  <div class="cut-line">
    <div class="cut-line-inner"><span class="cut-scissors">&#9986;</span><span>قص هنا</span><span class="cut-scissors">&#9986;</span></div>
  </div>
  ${buildCopy('نسخة أوامر التوريد', 'linear-gradient(135deg,#1b4332 0%,#2d6a4f 50%,#40916c 100%)')}
  <div class="cut-line">
    <div class="cut-line-inner"><span class="cut-scissors">&#9986;</span><span>قص هنا</span><span class="cut-scissors">&#9986;</span></div>
  </div>
  ${buildCopy('نسخة الأرشيف', 'linear-gradient(135deg,#4a1942 0%,#6b2d6b 50%,#9b4dab 100%)')}
</div>
<script>window.onload=()=>{window.print();}<\/script>
</body>
</html>`;

  win.document.write(html);
  win.document.close();
}

// ══════════════════════════════════════════════════════════════════
// طباعة السجل المالي الشامل — A4 احترافي
// ══════════════════════════════════════════════════════════════════
export function printFinancialRecord(
  student: Student,
  charges: SemesterCharge[],
  receipts: Receipt[],
): void {
  const win = window.open('', '_blank', 'width=900,height=1100');
  if (!win) return;

  const today    = new Date().toLocaleDateString('ar-LY', { year: 'numeric', month: 'long', day: 'numeric' });
  const printAt  = new Date().toLocaleTimeString('ar-LY', { hour: '2-digit', minute: '2-digit' });
  const semLbl   = SEMESTER_LABELS[student.current_semester] ?? `الفصل ${student.current_semester}`;
  const debt     = student.total_charged - student.total_paid;
  const paidPct  = student.total_charged > 0 ? Math.round((student.total_paid / student.total_charged) * 100) : 100;
  const diplLabel = student.diploma_type === 'عالي' ? 'دبلوم عالٍ' : 'دبلوم متوسط';

  const fmt = (n: number) => n.toLocaleString('ar-LY', { minimumFractionDigits: 0, maximumFractionDigits: 0 });

  // ── صفوف جدول الرسوم ──
  const chargeRows = charges.map((c, i) => {
    const label =
      c.charge_type === 'تسجيل'       ? 'رسوم التسجيل' :
      c.charge_type === 'معادلة'       ? `رسوم معادلة ${SEMESTER_LABELS[c.semester_number] ?? `الفصل ${c.semester_number}`}` :
      c.charge_type === 'مشروع تخرج'  ? 'رسوم مشروع التخرج' :
      (SEMESTER_LABELS[c.semester_number] ?? `الفصل ${c.semester_number}`);
    const statusCls = c.is_cleared ? 'status-ok' : 'status-err';
    const statusTxt = c.is_cleared ? 'مسدد' : 'معلق';
    const bg = i % 2 === 1 ? 'style="background:#f8faff"' : '';
    return `<tr ${bg}>
      <td>${label}</td>
      <td class="num">${fmt(c.charge_amount)}</td>
      <td class="num ok">${fmt(c.paid_amount)}</td>
      <td class="num ${c.remaining_amount > 0 ? 'err' : 'ok'}">${fmt(c.remaining_amount)}</td>
      <td class="center"><span class="${statusCls}">${statusTxt}</span></td>
    </tr>`;
  }).join('');

  const chargeTotals = charges.reduce((a, c) => ({
    ch: a.ch + c.charge_amount, pa: a.pa + c.paid_amount, re: a.re + c.remaining_amount,
  }), { ch: 0, pa: 0, re: 0 });

  // ── صفوف جدول الإيصالات ──
  const sortedReceipts = [...receipts].sort(compareReceipts);
  const receiptRows = sortedReceipts.map((r, i) => {
    const bg = i % 2 === 1 ? 'style="background:#f8faff"' : '';
    const date = new Date(r.paid_at).toLocaleDateString('ar-LY', { year: 'numeric', month: '2-digit', day: '2-digit' });
    const time = new Date(r.paid_at).toLocaleTimeString('ar-LY', { hour: '2-digit', minute: '2-digit' });
    const purpose = r.semester_target ?? r.payment_type;
    return `<tr ${bg}>
      <td class="mono center">${String(r.receipt_number).padStart(5, '0')}</td>
      <td class="center">${date}</td>
      <td class="center light">${time}</td>
      <td class="num ok bold">${fmt(r.amount)}</td>
      <td>${purpose}</td>
      <td class="center light">${(r as Receipt & { payment_method?: string }).payment_method ?? 'كاش'}</td>
    </tr>`;
  }).join('');

  const receiptTotal = receipts.reduce((s, r) => s + r.amount, 0);

  const progressBar = `<div style="background:#e5e7eb;border-radius:4px;height:8px;overflow:hidden;margin-top:10px">
    <div style="height:8px;border-radius:4px;width:${paidPct}%;background:${debt <= 0 ? '#16a34a' : paidPct > 60 ? '#f59e0b' : '#dc2626'};-webkit-print-color-adjust:exact;print-color-adjust:exact"></div>
  </div>`;

  const css = `
@import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{font-family:'Cairo',Tahoma,Arial,sans-serif;direction:rtl;background:#fff;color:#1a1a1a;font-size:12px;
  -webkit-print-color-adjust:exact;print-color-adjust:exact}

/* ── صفحة ── */
.page{width:210mm;min-height:297mm;margin:0 auto;padding:10mm 12mm;background:#fff}

/* ── رأس الصفحة ── */
.hdr{background:linear-gradient(135deg,#0f2744 0%,#1a3c5e 50%,#1e5a94 100%);
  border-radius:10px;padding:12px 16px;margin-bottom:10px;
  display:flex;align-items:center;gap:12px;
  -webkit-print-color-adjust:exact;print-color-adjust:exact}
.hdr-logo{width:58px;height:58px;border-radius:50%;overflow:hidden;
  border:2px solid rgba(255,255,255,.8);flex-shrink:0;background:#fff}
.hdr-logo img{width:100%;height:100%;object-fit:cover}
.hdr-text{flex:1;text-align:center}
.hdr-text h1{font-size:14px;font-weight:900;color:#fff;margin-bottom:2px}
.hdr-text .sub{font-size:10px;color:rgba(200,225,255,.9);font-weight:600}
.hdr-meta{text-align:center;flex-shrink:0}
.hdr-meta .date-box{background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.25);
  border-radius:7px;padding:5px 12px;color:#fff}
.hdr-meta .date-lbl{font-size:8px;color:rgba(200,225,255,.8);display:block}
.hdr-meta .date-val{font-size:11px;font-weight:900}

/* ── بطاقة الطالب ── */
.student-bar{background:#f0f7ff;border:1px solid #bfdbfe;border-radius:8px;
  padding:9px 14px;margin-bottom:9px;display:flex;gap:12px;align-items:center;
  -webkit-print-color-adjust:exact;print-color-adjust:exact}
.student-bar .name{font-size:15px;font-weight:900;color:#0f2744;flex:1}
.student-bar .meta{font-size:10px;color:#475569;display:flex;gap:12px;flex-wrap:wrap;margin-top:3px}
.s-badge{display:inline-block;padding:1px 8px;border-radius:20px;font-size:9.5px;font-weight:700;
  -webkit-print-color-adjust:exact;print-color-adjust:exact}
.b-active{background:#dcfce7;color:#15803d;border:1px solid #86efac}
.b-hold{background:#ffedd5;color:#c2410c;border:1px solid #fed7aa}
.b-high{background:#dbeafe;color:#1d4ed8;border:1px solid #93c5fd}
.b-mid{background:#f0fdf4;color:#15803d;border:1px solid #86efac}
.b-exam{background:#f3e8ff;color:#7e22ce;border:1px solid #d8b4fe}
.b-reg{background:#e0f2fe;color:#0369a1;border:1px solid #7dd3fc}

/* ── ملخص مالي ── */
.fin-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:7px;margin-bottom:7px;
  -webkit-print-color-adjust:exact;print-color-adjust:exact}
.fin-box{border-radius:7px;padding:7px 10px;text-align:center}
.fin-box .f-lbl{font-size:8px;font-weight:600;margin-bottom:2px}
.fin-box .f-val{font-size:15px;font-weight:900}
.fin-box .f-cur{font-size:8px;margin-top:1px}
.fc-charged{background:#eff6ff;border:1px solid #bfdbfe}
.fc-charged .f-lbl,.fc-charged .f-val,.fc-charged .f-cur{color:#1d4ed8}
.fc-paid{background:#f0fdf4;border:1px solid #86efac}
.fc-paid .f-lbl,.fc-paid .f-val,.fc-paid .f-cur{color:#15803d}
.fc-debt{background:#fef2f2;border:1px solid #fca5a5}
.fc-debt .f-lbl,.fc-debt .f-val,.fc-debt .f-cur{color:#dc2626}
.fc-zero{background:#f0fdf4;border:1px solid #86efac}
.fc-zero .f-lbl,.fc-zero .f-val,.fc-zero .f-cur{color:#15803d}
.fc-pct{background:#f5f3ff;border:1px solid #c4b5fd}
.fc-pct .f-lbl,.fc-pct .f-val,.fc-pct .f-cur{color:#7c3aed}

/* ── عنوان القسم ── */
.sec-title{font-size:11px;font-weight:800;color:#1a3c5e;
  border-bottom:2px solid #1a3c5e;padding-bottom:4px;margin:10px 0 7px;
  display:flex;align-items:center;gap:5px}
.sec-title::before{content:'';display:inline-block;width:3px;height:13px;
  background:#1e5a94;border-radius:2px}

/* ── جداول ── */
table{width:100%;border-collapse:collapse;font-size:11px;margin-bottom:10px}
thead tr{background:linear-gradient(to left,#1a3c5e,#1e5a94);
  -webkit-print-color-adjust:exact;print-color-adjust:exact}
thead th{color:#fff;padding:7px 10px;font-weight:700;font-size:10.5px;
  border:1px solid #1a3c5e;text-align:right;white-space:nowrap}
tbody td{padding:6px 10px;border:1px solid #d1dae6;vertical-align:middle}
tfoot td{padding:7px 10px;border:1px solid #1a3c5e;font-weight:800;
  background:#1a3c5e;color:#fff;font-size:11px;
  -webkit-print-color-adjust:exact;print-color-adjust:exact}
.num{text-align:left;font-family:monospace;direction:ltr;font-size:11.5px}
.ok{color:#15803d;font-weight:700}.err{color:#dc2626;font-weight:700}
.bold{font-weight:900}.center{text-align:center}
.light{color:#6b7280;font-size:10.5px}.mono{font-family:monospace;font-size:10.5px}
.status-ok{background:#dcfce7;color:#15803d;padding:2px 9px;border-radius:20px;
  font-size:9.5px;font-weight:700;border:1px solid #86efac;white-space:nowrap;
  -webkit-print-color-adjust:exact;print-color-adjust:exact}
.status-err{background:#fee2e2;color:#dc2626;padding:2px 9px;border-radius:20px;
  font-size:9.5px;font-weight:700;border:1px solid #fca5a5;white-space:nowrap;
  -webkit-print-color-adjust:exact;print-color-adjust:exact}

/* ── تذييل ── */
.footer{margin-top:12px;border-top:2px solid #1a3c5e;padding-top:10px;
  display:flex;justify-content:space-between;align-items:flex-end}
.footer .institute{font-size:9px;color:#475569;line-height:1.8}
.footer .institute strong{font-size:10px;color:#1a3c5e;display:block}
.sig-block{text-align:center}
.sig-box{border:1.5px solid #1a3c5e;border-radius:6px;padding:5px 20px;
  margin-bottom:4px;background:#f8faff;
  -webkit-print-color-adjust:exact;print-color-adjust:exact}
.sig-box .role{font-size:10px;font-weight:800;color:#1a3c5e;display:block}
.sig-box .dept{font-size:8.5px;color:#475569;display:block;margin-top:1px}
.sig-line{border-bottom:1.5px dashed #94a3b8;width:160px;height:22px;margin:0 auto 3px}
.sig-stamp{font-size:8px;color:#94a3b8}

/* ── طباعة ── */
@media print{
  @page{size:A4 portrait;margin:6mm 8mm}
  html,body{background:#fff}
  .page{padding:0;width:100%}
  .no-print{display:none!important}
  /* منع قطع الجداول أو الأقسام بشكل غير لائق */
  .sec-block{break-inside:avoid;page-break-inside:avoid}
  thead{display:table-header-group}
  tfoot{display:table-footer-group}
}`;

  const html = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8"/>
<title>السجل المالي — ${student.full_name}</title>
<style>${css}</style>
</head>
<body>
<div class="page">

  <!-- رأس الصفحة -->
  <div class="hdr">
    <div class="hdr-logo"><img src="${LOGO_URL}" alt="شعار"/></div>
    <div class="hdr-text">
      <h1>معهد القمة للعلوم الطبية والإدارية</h1>
      <div class="sub">السجل المالي الشامل للطالب — وثيقة رسمية محاسبية</div>
    </div>
    <div class="hdr-meta">
      <div class="date-box">
        <span class="date-lbl">تاريخ الإصدار</span>
        <span class="date-val">${today}</span>
        <span class="date-lbl" style="margin-top:3px">الساعة ${printAt}</span>
      </div>
    </div>
  </div>

  <!-- بطاقة الطالب -->
  <div class="student-bar">
    <div>
      <div class="name">${student.full_name}</div>
      <div class="meta">
        <span>الرقم الوطني: <strong style="font-family:monospace">${student.national_id}</strong></span>
        <span>${diplLabel}</span>
        <span>${student.specialization}</span>
        <span>${semLbl}</span>
        ${student.phone ? `<span>📞 ${student.phone}</span>` : ''}
      </div>
    </div>
    <div style="display:flex;gap:6px;flex-shrink:0;flex-wrap:wrap;justify-content:flex-end">
      <span class="s-badge ${student.status === 'نشط' ? 'b-active' : 'b-hold'}">${student.status}</span>
      <span class="s-badge ${student.diploma_type === 'عالي' ? 'b-high' : 'b-mid'}">${diplLabel}</span>
      <span class="s-badge ${student.is_exam_only ? 'b-exam' : 'b-reg'}">${student.is_exam_only ? 'طالب 100' : 'نظامي'}</span>
    </div>
  </div>

  <!-- ملخص مالي -->
  <div class="sec-block">
    <div class="sec-title">الملخص المالي</div>
    <div class="fin-grid">
      <div class="fin-box fc-charged">
        <div class="f-lbl">إجمالي المستحق</div>
        <div class="f-val">${fmt(student.total_charged)}</div>
        <div class="f-cur">دينار ليبي</div>
      </div>
      <div class="fin-box fc-paid">
        <div class="f-lbl">إجمالي المدفوع</div>
        <div class="f-val">${fmt(student.total_paid)}</div>
        <div class="f-cur">دينار ليبي</div>
      </div>
      <div class="fin-box ${debt > 0 ? 'fc-debt' : 'fc-zero'}">
        <div class="f-lbl">المبلغ المتبقي</div>
        <div class="f-val">${debt > 0 ? fmt(debt) : '✓ مسدد'}</div>
        <div class="f-cur">${debt > 0 ? 'دينار ليبي' : 'بالكامل'}</div>
      </div>
      <div class="fin-box fc-pct">
        <div class="f-lbl">نسبة التحصيل</div>
        <div class="f-val">${paidPct}%</div>
        <div class="f-cur">من إجمالي المستحق</div>
      </div>
    </div>
    ${progressBar}
  </div>

  ${charges.length > 0 ? `
  <!-- جدول الرسوم المفروضة -->
  <div class="sec-block">
    <div class="sec-title">كشف الرسوم المفروضة</div>
    <table>
      <thead>
        <tr>
          <th>البند</th>
          <th>الرسوم الكلية (د.ل)</th>
          <th>المدفوع (د.ل)</th>
          <th>المتبقي (د.ل)</th>
          <th>الحالة</th>
        </tr>
      </thead>
      <tbody>${chargeRows}</tbody>
      <tfoot>
        <tr>
          <td>الإجمالي</td>
          <td class="num">${fmt(chargeTotals.ch)}</td>
          <td class="num">${fmt(chargeTotals.pa)}</td>
          <td class="num">${fmt(chargeTotals.re)}</td>
          <td></td>
        </tr>
      </tfoot>
    </table>
  </div>` : ''}

  ${receipts.length > 0 ? `
  <!-- جدول الإيصالات -->
  <div class="sec-block">
    <div class="sec-title">كشف الإيصالات (${receipts.length} إيصال)</div>
    <table>
      <thead>
        <tr>
          <th>رقم الإيصال</th>
          <th>التاريخ</th>
          <th>الوقت</th>
          <th>المبلغ (د.ل)</th>
          <th>البيان</th>
          <th>طريقة الدفع</th>
        </tr>
      </thead>
      <tbody>${receiptRows}</tbody>
      <tfoot>
        <tr>
          <td colspan="3">إجمالي المدفوعات</td>
          <td class="num">${fmt(receiptTotal)}</td>
          <td colspan="2"></td>
        </tr>
      </tfoot>
    </table>
  </div>` : ''}

  <!-- تذييل -->
  <div class="footer">
    <div class="institute">
      <strong>معهد القمة للعلوم الطبية والإدارية</strong>
      <span>سوق السبت — ليبيا</span>
      <span>هاتف: 0925040851 &nbsp;|&nbsp; البريد: alkema2024@gmail.com &nbsp;|&nbsp; الموقع: http://www.alkima.edu.ly</span>
      <span>صدر بتاريخ: ${today} الساعة ${printAt}</span>
    </div>
    <div class="sig-block">
      <div class="sig-box">
        <span class="role">مدير الشؤون المالية والإدارية</span>
        <span class="dept">معهد القمة للعلوم الطبية والإدارية</span>
      </div>
      <div class="sig-line"></div>
      <div class="sig-stamp">التوقيع والختم الرسمي</div>
    </div>
  </div>

</div>
<script>window.onload=function(){setTimeout(function(){window.print();},400);};<\/script>
</body>
</html>`;

  win.document.write(html);
  win.document.close();
}
