/**
 * دوال ذكية موحدة لمعالجة النصوص العربية والبحث الفوري بالحرف والتدقيق
 */

/**
 * تطبيع النص العربي: توحيد الهمزات، التاء المربوطة، الألف المقصورة، إزالة التشكيل والتطويل
 */
export function normalizeArabic(text: string | null | undefined): string {
  if (!text) return '';
  let s = String(text).toLowerCase().trim();
  // إزالة التشكيل والتنوين
  s = s.replace(/[\u064B-\u065F\u0670]/g, '');
  // إزالة التطويل (ـ)
  s = s.replace(/\u0640/g, '');
  // توحيد الهمزات والألف
  s = s.replace(/[أإآٱ]/g, 'ا');
  // توحيد التاء المربوطة والهاء
  s = s.replace(/ة/g, 'ه');
  // توحيد الياء والألف المقصورة
  s = s.replace(/ى/g, 'ي');
  // إزالة المسافات الزائدة
  s = s.replace(/\s+/g, ' ');
  return s;
}

/**
 * صيغة مضغوطة للأسماء المركبة (مثل عبد الرحمن -> عبدالرحمن، ابو بكر -> ابوبكر)
 */
export function compactArabic(text: string | null | undefined): string {
  const norm = normalizeArabic(text);
  return norm
    .replace(/\bعبد\s+/g, 'عبد')
    .replace(/\bابو\s+/g, 'ابو')
    .replace(/\bابن\s+/g, 'ابن')
    .replace(/\bبن\s+/g, 'بن')
    .replace(/\bال\s+/g, 'ال')
    .replace(/\s+/g, '');
}

/**
 * فحص مطابقة دقيق ومرن يبحث بالحرف الواحد وبكل الكلمات المدخلة
 * @param target النص المراد البحث فيه (مثل اسم الطالب أو التخصص)
 * @param query النص المكتوب في خانة البحث
 */
export function matchSearch(target: string | null | undefined, query: string): boolean {
  if (!query || !query.trim()) return true;
  if (!target) return false;

  const rawTarget = String(target).toLowerCase();
  const rawQuery = query.toLowerCase().trim();

  // 1. مطابقة مباشرة سريعة (للأرقام، الرموز، والحروف اللاتينية)
  if (rawTarget.includes(rawQuery)) return true;

  // 2. مطابقة عربية مطبعة بالحرف الواحد أو بالكلمات
  const normTarget = normalizeArabic(target);
  const normQuery = normalizeArabic(query);

  if (normTarget.includes(normQuery)) return true;

  // 3. مطابقة الكلمات المتعددة (إذا كتب المستخدم أكثر من كلمة مثل "محمد سالم")
  // يجب أن تكون كل كلمة موجودة في النص الهدف بأي ترتيب
  const queryTokens = normQuery.split(' ').filter(Boolean);
  if (queryTokens.length > 1) {
    const allTokensFound = queryTokens.every(tok => normTarget.includes(tok));
    if (allTokensFound) return true;
  }

  // 4. مطابقة الأسماء المركبة وتجاهل المسافات (مثل "عبدالرحمن" vs "عبد الرحمن")
  const compactT = compactArabic(target);
  const compactQ = compactArabic(query);
  if (compactQ && compactT.includes(compactQ)) return true;

  return false;
}

/**
 * توليد أشكال ومتغيرات للكلمة العربية للبحث الدقيق في قاعدة البيانات (PostgreSQL ilike)
 * لدعم البحث دون التأثر بالهمزات أو التاء المربوطة أو الفواصل في الأسماء المركبة
 */
export function getSearchVariations(query: string): string[] {
  if (!query || !query.trim()) return [];
  const text = query.trim();
  const variations = new Set<string>();
  variations.add(text);

  // تبديل همزة البداية
  const startsWithAlef = /^[أإآا]/.test(text);
  if (startsWithAlef) {
    variations.add(text.replace(/^[أإآا]/, 'ا'));
    variations.add(text.replace(/^[أإآا]/, 'أ'));
    variations.add(text.replace(/^[أإآا]/, 'إ'));
    variations.add(text.replace(/^[أإآا]/, 'آ'));
  }

  // تبديل التاء المربوطة / الهاء والألف المقصورة / الياء في النهايات
  const currentList = Array.from(variations);
  for (const item of currentList) {
    if (item.endsWith('ة')) variations.add(item.slice(0, -1) + 'ه');
    if (item.endsWith('ه')) variations.add(item.slice(0, -1) + 'ة');
    if (item.endsWith('ي')) variations.add(item.slice(0, -1) + 'ى');
    if (item.endsWith('ى')) variations.add(item.slice(0, -1) + 'ي');
  }

  // معالجة الأسماء المركبة (عبد/ابو)
  const afterSuffixes = Array.from(variations);
  for (const item of afterSuffixes) {
    if (item.includes('عبد ')) variations.add(item.replace(/عبد\s+/g, 'عبد'));
    if (item.includes('عبد') && !item.includes('عبد ')) variations.add(item.replace(/عبد/g, 'عبد '));
    if (item.includes('ابو ')) variations.add(item.replace(/ابو\s+/g, 'ابو'));
    if (item.includes('ابو') && !item.includes('ابو ')) variations.add(item.replace(/ابو/g, 'ابو '));
  }

  return Array.from(variations).slice(0, 10);
}

/**
 * فحص مطابقة شامل لسجل الطالب عبر جميع الحقول
 */
export interface SearchableStudent {
  full_name?: string | null;
  national_id?: string | null;
  registration_number?: string | null;
  phone?: string | null;
  specialization?: string | null;
  diploma_type?: string | null;
  notes?: string | null;
}

export function matchStudent(student: SearchableStudent, query: string): boolean {
  if (!query || !query.trim()) return true;
  return (
    matchSearch(student.full_name, query) ||
    matchSearch(student.national_id, query) ||
    matchSearch(student.registration_number, query) ||
    matchSearch(student.phone, query) ||
    matchSearch(student.specialization, query) ||
    matchSearch(student.diploma_type, query) ||
    matchSearch(student.notes, query)
  );
}
