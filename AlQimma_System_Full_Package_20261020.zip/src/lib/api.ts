// واجهة برمجة التطبيقات - منظومة معهد القمة
import { supabase } from '@/db/supabase';
import type {
  Student,
  Receipt,
  SemesterCharge,
  Notification,
  Specialization,
  SystemSetting,
  DiplomaType,
  PaymentType,
  StudentFile,
  DeviceRole,
  DeviceRolePermissions,
} from '@/types/index';
import { SETTINGS_KEYS } from '@/types/index';
import { getSearchVariations } from '@/lib/searchUtils';

// =============================================
// ترتيب الإيصالات: تسجيل → فصل 1 → ... → فصل 6 → مشروع تخرج → غير ذلك
// يُستخدم في كل صفحات النظام وأوامر التوريد
// =============================================
export function receiptSortKey(r: {
  payment_type?: string | null;
  semester_target?: string | null;
  paid_at?: string;
}): number {
  const type = r.payment_type ?? '';
  const target = r.semester_target ?? '';
  // التسجيل أولاً، ثم المعادلة (فصل 1، 2، 3...) ثم الفصول الدراسية
  if (type === 'تسجيل') return 0;
  if (type === 'معادلة') {
    // استخراج رقم الفصل من semester_target مثل "قسط من رسوم معادلة الفصل 2"
    const mEquiv = target.match(/الفصل\s*(\d+)/);
    const equivSem = mEquiv ? parseInt(mEquiv[1], 10) : 0;
    return 0.1 + equivSem * 0.01; // بعد التسجيل مباشرة، مرتبة حسب فصل المعادلة
  }
  // فصلي → استخراج رقم الفصل من semester_target (مثال: "الفصل الأول", "الفصل 2")
  const semMap: Record<string, number> = {
    'الأول': 1, 'الثاني': 2, 'الثالث': 3,
    'الرابع': 4, 'الخامس': 5, 'السادس': 6,
  };
  for (const [word, num] of Object.entries(semMap)) {
    if (target.includes(word)) return num;
  }
  // رقم مباشر في semester_target مثل "الفصل 3"
  const numMatch = target.match(/(\d+)/);
  if (numMatch) return parseInt(numMatch[1], 10);
  // مشروع تخرج → قبل الأخير
  if (type === 'مشروع تخرج') return 97;
  // ديون سابقة أو أي نوع آخر → آخراً، مرتّب بالتاريخ
  return 98;
}

/** ترتيب الإيصالات من الأقدم للأحدث: حسب رقم الإيصال تصاعدياً، ثم تاريخ الدفع */
export function sortReceiptsOldestFirst<T extends {
  receipt_number?: string | null;
  paid_at?: string;
}>(receipts: T[]): T[] {
  return [...receipts].sort((a, b) => {
    const numA = parseInt((a.receipt_number ?? '0').replace(/\D/g, ''), 10) || 0;
    const numB = parseInt((b.receipt_number ?? '0').replace(/\D/g, ''), 10) || 0;
    if (numA !== numB) return numA - numB;
    return new Date(a.paid_at ?? 0).getTime() - new Date(b.paid_at ?? 0).getTime();
  });
}

/** مقارن كامل للإيصالات: حسب نوع الفصل أولاً، ثم تاريخ الدفع تصاعدياً، ثم رقم الإيصال — يُستخدم للطباعة فقط */
export function compareReceipts(
  a: { payment_type?: string | null; semester_target?: string | null; paid_at?: string; receipt_number?: string | null },
  b: { payment_type?: string | null; semester_target?: string | null; paid_at?: string; receipt_number?: string | null },
): number {
  const diff = receiptSortKey(a) - receiptSortKey(b);
  if (diff !== 0) return diff;
  // ثانياً: تاريخ الدفع تصاعدياً (الأقدم أولاً)
  const dateDiff = new Date(a.paid_at ?? 0).getTime() - new Date(b.paid_at ?? 0).getTime();
  if (dateDiff !== 0) return dateDiff;
  // ثالثاً: رقم الإيصال تصاعدياً (الأصغر رقماً أولاً — يضمن الترتيب الصحيح حتى في نفس اليوم)
  const numA = parseInt((a.receipt_number ?? '0').replace(/\D/g, ''), 10) || 0;
  const numB = parseInt((b.receipt_number ?? '0').replace(/\D/g, ''), 10) || 0;
  return numA - numB;
}

// =============================================
// دوال المساعدة وإعادة المحاولة التلقائية
// =============================================
export async function withRetry<T>(
  fn: () => Promise<T>,
  retries = 2,
  baseDelayMs = 800
): Promise<T> {
  let attempt = 0;
  while (true) {
    try {
      return await fn();
    } catch (err: unknown) {
      attempt++;
      if (attempt > retries) {
        throw err;
      }
      // انتظار تزايدي قبل المحاولة التالية
      await new Promise(resolve => setTimeout(resolve, baseDelayMs * attempt));
    }
  }
}

// =============================================
// إعدادات النظام
// =============================================
const SETTINGS_CACHE_TTL = 30000; // 30 ثانية
let _settingsCache: Record<string, string> | null = null;
let _settingsCacheTime = 0;

export async function getSettings(forceRefresh = false): Promise<Record<string, string>> {
  const now = Date.now();
  if (!forceRefresh && _settingsCache && now - _settingsCacheTime < SETTINGS_CACHE_TTL) {
    return _settingsCache;
  }
  // فحص sessionStorage لعودة فورية بدون انتظار الشبكة (0ms)
  if (!forceRefresh && !_settingsCache && typeof window !== 'undefined') {
    try {
      const stored = sessionStorage.getItem('alqeema_settings_cache');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed.data && now - parsed.time < SETTINGS_CACHE_TTL * 4) {
          _settingsCache = parsed.data;
          _settingsCacheTime = parsed.time;
          return parsed.data;
        }
      }
    } catch {}
  }
  return withRetry(async () => {
    const { data, error } = await supabase
      .from('system_settings')
      .select('key, value')
      .order('id');
    if (error) throw error;
    const map: Record<string, string> = {};
    (Array.isArray(data) ? data : []).forEach((s: { key: string; value: string }) => {
      map[s.key] = s.value;
    });
    _settingsCache = map;
    _settingsCacheTime = now;
    if (typeof window !== 'undefined') {
      try {
        sessionStorage.setItem('alqeema_settings_cache', JSON.stringify({ data: map, time: now }));
      } catch {}
    }
    return map;
  });
}

// إبطال الكاش عند تحديث إعداد
export function invalidateSettingsCache() {
  _settingsCache = null;
  _settingsCacheTime = 0;
  if (typeof window !== 'undefined') {
    try { sessionStorage.removeItem('alqeema_settings_cache'); } catch {}
  }
}

export async function updateSetting(key: string, value: string): Promise<void> {
  const { error } = await supabase
    .from('system_settings')
    .update({ value, updated_at: new Date().toISOString() })
    .eq('key', key);
  if (error) throw error;
  invalidateSettingsCache();
}

export async function getNextLetterNumber(): Promise<string> {
  const year = new Date().getFullYear();
  const { data, error } = await supabase
    .from('system_settings')
    .select('value')
    .eq('key', SETTINGS_KEYS.LETTER_SEQ)
    .maybeSingle();
  if (error) throw error;

  // إعادة الضبط تلقائياً إذا تغيّرت السنة
  const stored = data?.value ?? '0';
  // الصيغة المحفوظة: "seq|year" مثل "3|2026"
  const parts = stored.split('|');
  let seq = parseInt(parts[0] ?? '0', 10);
  const storedYear = parseInt(parts[1] ?? '0', 10);

  if (storedYear !== year) seq = 0; // سنة جديدة → نبدأ من صفر

  const next = seq + 1;
  await supabase
    .from('system_settings')
    .update({ value: `${next}|${year}` })
    .eq('key', SETTINGS_KEYS.LETTER_SEQ);

  return `${String(next).padStart(4, '0')}/${year}`;
}

export async function getNextReceiptNumber(diplomaType: DiplomaType = 'عالي'): Promise<string> {
  const { data, error } = await supabase.rpc('get_next_receipt_number', { p_diploma_type: diplomaType });
  if (error) throw error;
  return data as string;
}

export async function getNextSupplyOrderNumber(diplomaType: DiplomaType = 'عالي'): Promise<string> {
  try {
    const { data, error } = await supabase.rpc('get_next_supply_order_number', { p_diploma_type: diplomaType });
    if (!error && data) return data as string;
  } catch (err) {
    console.warn('RPC get_next_supply_order_number failed, using fallback:', err);
  }
  // بديل أمان مباشر في حال تعطل دالة RPC
  const counterKey = diplomaType === 'عالي' ? SETTINGS_KEYS.SUPPLY_ORDER_COUNTER_HIGH : SETTINGS_KEYS.SUPPLY_ORDER_COUNTER_MID;
  const { data: curr } = await supabase.from('system_settings').select('value').eq('key', counterKey).maybeSingle();
  const nextVal = (parseInt(curr?.value ?? '0', 10) || 0) + 1;
  await supabase.from('system_settings').upsert({ key: counterKey, value: String(nextVal), updated_at: new Date().toISOString() }, { onConflict: 'key' });
  return `00${nextVal}`;
}

export async function syncUnassignedReceipts(): Promise<{ synced_count: number }> {
  const { data, error } = await supabase.rpc('sync_unassigned_receipts');
  if (error) throw error;
  invalidateSupplyOrdersCache();
  invalidateStudentsCache();
  return (data as { synced_count: number }) ?? { synced_count: 0 };
}

/**
 * منطق المعاملة اليومية:
 *   - إذا سبق أن سُجِّل أمر توريد لنفس نوع الدبلوم في نفس اليوم → يُعاد استخدام رقم المعاملة ذاته
 *   - إذا كان اليوم جديداً → يُنشأ رقم معاملة جديد ويُزاد العداد
 * هذا يضمن أن جميع الدفعات في يوم واحد تحمل رقم معاملة واحداً.
 */
export async function getOrCreateTodaySupplyOrderNumber(
  diplomaType: DiplomaType,
  dateStr?: string, // yyyy-mm-dd — افتراضي: اليوم بالتوقيت المحلي
): Promise<string> {
  // استخدام التوقيت المحلي (لا UTC) لتجنب خطأ تحديد اليوم عند منتصف الليل
  const day = dateStr ?? (() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  })();
  const from = `${day}T00:00:00`;
  const to   = `${day}T23:59:59.999`;

  // البحث عن أمر توريد مسجل لنفس نوع الدبلوم في نفس اليوم
  const { data, error } = await supabase
    .from('receipts')
    .select('supply_order_number, student_diploma, students(diploma_type)')
    .gte('paid_at', from)
    .lte('paid_at', to)
    .not('supply_order_number', 'is', null)
    .order('supply_order_number', { ascending: false })
    .limit(20); // جلب عدة صفوف لتصفيتها حسب نوع الدبلوم

  if (error) throw error;

  // تصفية النتائج حسب نوع الدبلوم — الأولوية: students حية ثم student_diploma المحفوظ
  const matching = (data ?? []).filter(
    (r: any) => (r.students?.diploma_type ?? r.student_diploma) === diplomaType && r.supply_order_number
  );

  if (matching.length > 0) {
    // يوجد أمر توريد اليوم لنفس النوع → أعد الرقم الأول (الأعلى تنازلياً)
    return matching[0].supply_order_number as string;
  }

  // لا يوجد أمر اليوم → أنشئ رقماً جديداً
  return getNextSupplyOrderNumber(diplomaType);
}

export async function peekCurrentSupplyOrderNumber(diplomaType: DiplomaType = 'عالي'): Promise<number> {
  const key = diplomaType === 'عالي'
    ? SETTINGS_KEYS.SUPPLY_ORDER_COUNTER_HIGH
    : SETTINGS_KEYS.SUPPLY_ORDER_COUNTER_MID;
  const { data, error } = await supabase
    .from('system_settings')
    .select('value')
    .eq('key', key)
    .maybeSingle();
  if (error) throw error;
  return parseInt(data?.value ?? '0');
}

// تنسيق رقم أمر التوريد: 00 ثابتتان + العداد كما هو
// مثال: 1→001, 10→0010, 100→00100, 1000→001000
export function formatSupplyOrderNumber(n: number): string {
  return '00' + String(n);
}

export async function peekCurrentReceiptNumber(diplomaType: DiplomaType = 'عالي'): Promise<string> {
  const key = diplomaType === 'عالي' ? SETTINGS_KEYS.RECEIPT_COUNTER_HIGH : SETTINGS_KEYS.RECEIPT_COUNTER_MID;
  const { data, error } = await supabase
    .from('system_settings')
    .select('value')
    .eq('key', key)
    .maybeSingle();
  if (error) throw error;
  const current = parseInt(data?.value ?? '0');
  return String(current + 1).padStart(6, '0');
}

// =============================================
// التخصصات
// =============================================
let _specializationsCache: Record<string, { data: Specialization[]; timestamp: number }> = {};
const SPECIALIZATIONS_TTL = 180000; // 3 دقائق كاش فائق السرعة

export function invalidateSpecializationsCache(): void {
  _specializationsCache = {};
  if (typeof window !== 'undefined') {
    try { sessionStorage.removeItem('alqeema_specializations_cache'); } catch {}
  }
}

export async function getSpecializations(diplomaType?: DiplomaType, forceRefresh = false): Promise<Specialization[]> {
  const cacheKey = diplomaType ?? 'all';
  const now = Date.now();
  if (!forceRefresh && _specializationsCache[cacheKey] && now - _specializationsCache[cacheKey].timestamp < SPECIALIZATIONS_TTL) {
    return _specializationsCache[cacheKey].data;
  }
  if (!forceRefresh && !_specializationsCache[cacheKey] && typeof window !== 'undefined') {
    try {
      const stored = sessionStorage.getItem('alqeema_spec_' + cacheKey);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed.data && now - parsed.time < SPECIALIZATIONS_TTL * 2) {
          _specializationsCache[cacheKey] = { data: parsed.data, timestamp: parsed.time };
          return parsed.data;
        }
      }
    } catch {}
  }
  let query = supabase
    .from('specializations')
    .select('*')
    .eq('is_active', true)
    .order('id');
  if (diplomaType) {
    query = query.eq('diploma_type', diplomaType);
  }
  const { data, error } = await query;
  if (error) throw error;
  const res = Array.isArray(data) ? data : [];
  _specializationsCache[cacheKey] = { data: res, timestamp: now };
  if (typeof window !== 'undefined') {
    try {
      sessionStorage.setItem('alqeema_spec_' + cacheKey, JSON.stringify({ data: res, time: now }));
    } catch {}
  }
  return res;
}

export async function addSpecialization(name: string, diplomaType: DiplomaType): Promise<void> {
  const { error } = await supabase
    .from('specializations')
    .insert({ name, diploma_type: diplomaType });
  if (error) throw error;
  invalidateSpecializationsCache();
}

export async function updateSpecialization(id: number, name: string): Promise<void> {
  const { error } = await supabase
    .from('specializations')
    .update({ name })
    .eq('id', id);
  if (error) throw error;
  invalidateSpecializationsCache();
}

export async function deleteSpecialization(id: number): Promise<void> {
  const { error } = await supabase
    .from('specializations')
    .update({ is_active: false })
    .eq('id', id);
  if (error) throw error;
  invalidateSpecializationsCache();
}

// =============================================
// الطلاب
// =============================================
export type QuickFilterType = 'all' | 'active' | 'suspended' | 'has_debt' | 'missing_docs' | 'complete';

export interface StudentQueryParams {
  search?: string;
  diplomaType?: DiplomaType;
  specialization?: string;
  status?: string;
  semester?: number;
  quickFilter?: QuickFilterType;
  missingRegistrationNumber?: boolean;
  limit?: number;
  offset?: number;
  fields?: string;
  forceRefresh?: boolean;
  noCount?: boolean;
}

// كاش ذكي للطلاب لتقليل زمن الاستجابة والتنقل الفوري بين الصفحات
interface StudentsCacheEntry {
  data: Student[];
  count: number;
  timestamp: number;
  key: string;
}
let _studentsCache: StudentsCacheEntry | null = null;
const STUDENTS_CACHE_TTL = 25000; // 25 ثانية كاش خفيف فائق السرعة

export function invalidateStudentsCache(): void {
  _studentsCache = null;
  invalidatePendingArchiveCache();
  invalidateDashboardStatsCache();
  if (typeof window !== 'undefined') {
    try { sessionStorage.removeItem('alqeema_students_cache'); } catch {}
  }
}

export async function getStudents(params?: StudentQueryParams): Promise<{ data: Student[]; count: number }> {
  const limit = params?.limit ?? 50;
  const offset = params?.offset ?? 0;
  const cacheKey = JSON.stringify({
    ...params,
    offset,
    limit,
    forceRefresh: undefined
  });

  // إذا كان استدعاء كبير (مثل المالية أو الترحيل) وغير مقترن بطلب إجبار التحديث
  if (!params?.forceRefresh && limit >= 1000 && _studentsCache && _studentsCache.key === cacheKey && (Date.now() - _studentsCache.timestamp < STUDENTS_CACHE_TTL)) {
    return { data: _studentsCache.data, count: _studentsCache.count };
  }

  // فحص sessionStorage للاستجابة اللحظية (0ms) عند التنقل بين الشاشات
  if (!params?.forceRefresh && limit >= 1000 && !_studentsCache && !params?.search && typeof window !== 'undefined') {
    try {
      const stored = sessionStorage.getItem('alqeema_students_cache');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed.key === cacheKey && (Date.now() - parsed.time < STUDENTS_CACHE_TTL * 3)) {
          _studentsCache = { data: parsed.data, count: parsed.count, timestamp: parsed.time, key: parsed.key };
          return { data: parsed.data, count: parsed.count };
        }
      }
    } catch {}
  }

  return withRetry(async () => {
    const buildQuery = (withCount: boolean = false) => {
      const selectFields = params?.fields ?? '*';
      let query = (supabase
        .from('students') as any)
        .select(selectFields, withCount ? { count: 'exact' } : undefined)
        .order('created_at', { ascending: false });

      if (params?.search && params.search.trim()) {
        const variations = getSearchVariations(params.search);
        const orClauses = variations.flatMap(v => {
          const s = v.replace(/'/g, "''");
          return [
            `full_name.ilike.%${s}%`,
            `national_id.ilike.%${s}%`,
            `registration_number.ilike.%${s}%`
          ];
        });
        query = query.or(orClauses.slice(0, 15).join(','));
      }
      if (params?.missingRegistrationNumber) {
        query = query.or('registration_number.is.null,registration_number.eq.');
      }
      if (params?.diplomaType) query = query.eq('diploma_type', params.diplomaType);
      if (params?.specialization) query = query.eq('specialization', params.specialization);
      if (params?.status) query = query.eq('status', params.status);
      if (params?.semester) query = query.eq('current_semester', params.semester);
      // simple status quick-filters → push to server
      if (params?.quickFilter === 'active')    query = query.eq('status', 'نشط');
      if (params?.quickFilter === 'suspended') query = query.eq('status', 'موقوف قيد');
      return query;
    };

    if (limit <= 1000) {
      const needCount = !params?.noCount;
      const { data, error, count } = await buildQuery(needCount).range(offset, offset + limit - 1);
      if (error) throw error;
      return { data: (Array.isArray(data) ? data : []) as unknown as Student[], count: count ?? 0 };
    }

    // جلب البيانات على دفعات متوازية لدعم أكثر من 1000 طالب دون اقتطاع
    const firstChunkSize = 1000;
    // الدفعة الأولى فقط تطلب count لتحديد العدد الإجمالي
    const { data: firstBatch, error: firstErr, count } = await buildQuery(true).range(offset, offset + firstChunkSize - 1);
    if (firstErr) throw firstErr;

    const allData = [...(firstBatch ?? [])];
    const totalCount = count ?? allData.length;
    const maxToFetch = Math.min(totalCount, offset + limit);

    if (maxToFetch > offset + allData.length && allData.length === 1000) {
      const promises = [];
      for (let curr = offset + 1000; curr < maxToFetch; curr += 1000) {
        const end = Math.min(curr + 999, maxToFetch - 1);
        // الدفعات اللاحقة لا تطلب count نهائياً لتفادي مسح الجدول المتكرر
        promises.push(buildQuery(false).range(curr, end));
      }
      const results = await Promise.all(promises);
      for (const res of results) {
        if (res.error) throw res.error;
        if (res.data) allData.push(...res.data);
      }
    }

    const finalResult = { data: allData as unknown as Student[], count: count ?? allData.length };
    if (limit >= 1000) {
      _studentsCache = {
        data: finalResult.data,
        count: finalResult.count,
        timestamp: Date.now(),
        key: cacheKey,
      };
      if (typeof window !== 'undefined' && !params?.search) {
        try {
          sessionStorage.setItem('alqeema_students_cache', JSON.stringify({
            data: finalResult.data,
            count: finalResult.count,
            time: Date.now(),
            key: cacheKey
          }));
        } catch {}
      }
    }
    return finalResult;
  });
}

export interface StudentStats {
  total: number;
  active: number;
  suspended: number;
  debt: number;
  missing: number;
  complete: number;
}

// جلب الإحصاءات من الـ DB دفعة واحدة عبر دالة SQL فائقة السرعة
export async function getStudentStats(params?: Pick<StudentQueryParams, 'search' | 'diplomaType' | 'specialization' | 'semester'>): Promise<StudentStats> {
  try {
    const { data, error } = await supabase.rpc('get_student_management_stats', {
      p_search: params?.search?.trim() || null,
      p_diploma_type: params?.diplomaType || null,
      p_specialization: params?.specialization || null,
      p_semester: params?.semester ?? null,
    });
    if (!error && data) {
      const d = data as any;
      return {
        total: Number(d.total ?? 0),
        active: Number(d.active ?? 0),
        suspended: Number(d.suspended ?? 0),
        debt: Number(d.debt ?? 0),
        missing: Number(d.missing ?? 0),
        complete: Number(d.complete ?? 0),
      };
    }
  } catch (err) {
    console.warn('Fallback to manual stats calculation', err);
  }

  // في حال تعذر استدعاء دالة RPC لأي سبب طارئ
  const buildBase = () => {
    let q = supabase.from('students').select('id, status, total_charged, total_paid, has_birth_certificate, has_registration_certificate, photos_received, photos_required', { count: 'exact' });
    if (params?.search && params.search.trim()) {
      const variations = getSearchVariations(params.search);
      const orClauses = variations.flatMap(v => {
        const s = v.replace(/'/g, "''");
        return [`full_name.ilike.%${s}%`, `national_id.ilike.%${s}%`];
      });
      q = q.or(orClauses.slice(0, 10).join(','));
    }
    if (params?.diplomaType) q = q.eq('diploma_type', params.diplomaType);
    if (params?.specialization) q = q.eq('specialization', params.specialization);
    if (params?.semester) q = q.eq('current_semester', params.semester);
    return q;
  };

  const [totalRes, activeRes, suspendedRes, allRes] = await Promise.all([
    buildBase().limit(1),
    buildBase().eq('status', 'نشط').limit(1),
    buildBase().eq('status', 'موقوف قيد').limit(1),
    buildBase().limit(2000),
  ]);

  const allStudents = (allRes.data ?? []) as Student[];
  let debt = 0, missing = 0, complete = 0;
  for (const s of allStudents) {
    const d = (s.total_charged ?? 0) - (s.total_paid ?? 0);
    const hasMissing = !s.has_birth_certificate || !s.has_registration_certificate || (s.photos_received ?? 0) < (s.photos_required ?? 0);
    if (d > 0) debt++;
    if (hasMissing) missing++;
    if (d <= 0 && !hasMissing && s.status === 'نشط') complete++;
  }

  return {
    total: totalRes.count ?? 0,
    active: activeRes.count ?? 0,
    suspended: suspendedRes.count ?? 0,
    debt,
    missing,
    complete,
  };
}

// كاش ذكي خفيف لقائمة الطلاب الجاهزين للأرشفة
let _pendingArchiveCache: { data: Student[]; timestamp: number } | null = null;
const PENDING_ARCHIVE_TTL = 25000; // 25 ثانية

export function invalidatePendingArchiveCache(): void {
  _pendingArchiveCache = null;
  if (typeof window !== 'undefined') {
    try { sessionStorage.removeItem('alqeema_pending_archive_cache'); } catch {}
  }
}

// جلب الطلاب الجاهزين للأرشفة — الفلترة تتم في قاعدة البيانات عبر RPC
export async function getPendingArchiveStudents(forceRefresh = false): Promise<Student[]> {
  const now = Date.now();
  if (!forceRefresh && _pendingArchiveCache && now - _pendingArchiveCache.timestamp < PENDING_ARCHIVE_TTL) {
    return _pendingArchiveCache.data;
  }
  if (!forceRefresh && !_pendingArchiveCache && typeof window !== 'undefined') {
    try {
      const stored = sessionStorage.getItem('alqeema_pending_archive_cache');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed.data && now - parsed.time < PENDING_ARCHIVE_TTL * 2) {
          _pendingArchiveCache = { data: parsed.data, timestamp: parsed.time };
          return parsed.data;
        }
      }
    } catch {}
  }
  const { data, error } = await supabase.rpc('get_pending_archive_students');
  if (error) throw error;
  const res = Array.isArray(data) ? (data as Student[]) : [];
  _pendingArchiveCache = { data: res, timestamp: now };
  if (typeof window !== 'undefined') {
    try {
      sessionStorage.setItem('alqeema_pending_archive_cache', JSON.stringify({ data: res, time: now }));
    } catch {}
  }
  return res;
}

export async function getStudentById(id: string): Promise<Student | null> {
  const { data, error } = await supabase
    .from('students')
    .select('*')
    .eq('id', id)
    .maybeSingle();
  if (error) throw error;
  return data;
}

export async function checkNationalIdExists(nationalId: string, excludeId?: string): Promise<boolean> {
  let query = supabase
    .from('students')
    .select('id')
    .eq('national_id', nationalId);
  if (excludeId) {
    query = query.neq('id', excludeId);
  }
  const { data, error } = await query.maybeSingle();
  if (error) throw error;
  return data !== null;
}

export async function createStudent(student: Omit<Student, 'id' | 'created_at' | 'updated_at' | 'total_charged' | 'total_paid'>): Promise<Student> {
  invalidateStudentsCache();
  const { data, error } = await supabase
    .from('students')
    .insert(student)
    .select()
    .maybeSingle();
  if (error) throw error;
  const s = data as Student;

  // إشعار التسجيل
  await createNotification({
    type: 'تسجيل',
    student_id: s.id,
    message: [
      `تم تسجيل الطالب: ${s.full_name}`,
      `الدبلوم: ${s.diploma_type} | التخصص: ${s.specialization ?? '—'}`,
      `الفصل الدراسي: الأول | تاريخ التسجيل: ${new Date().toLocaleDateString('ar-LY')}`,
      `رقم الهاتف: ${s.phone ?? '—'} | الجنس: ${s.gender ?? '—'}`,
    ].join('\n'),
  }).catch(() => {});

  return s;
}

export async function updateStudent(id: string, updates: Partial<Student>): Promise<void> {
  invalidateStudentsCache();
  const { error } = await supabase
    .from('students')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id);
  if (error) throw error;
}

export async function deleteStudent(id: string): Promise<void> {
  invalidateStudentsCache();
  const { error } = await supabase
    .from('students')
    .delete()
    .eq('id', id);
  if (error) throw error;
}

export async function suspendStudent(id: string): Promise<void> {
  await updateStudent(id, { status: 'موقوف قيد' });
  const { data } = await supabase.from('students').select('full_name, diploma_type, specialization, current_semester, total_charged, total_paid').eq('id', id).maybeSingle();
  if (data) {
    const debt = Math.max(0, (data.total_charged ?? 0) - (data.total_paid ?? 0));
    await createNotification({
      type: 'إيقاف',
      student_id: id,
      message: [
        `تم إيقاف قيد الطالب: ${data.full_name}`,
        `الدبلوم: ${data.diploma_type} | التخصص: ${data.specialization ?? '—'}`,
        `الفصل الدراسي: ${data.current_semester}`,
        `المديونية المتراكمة: ${debt.toFixed(2)} دينار`,
        `تاريخ الإيقاف: ${new Date().toLocaleDateString('ar-LY')}`,
      ].join('\n'),
    }).catch(() => {});
  }
}

export async function activateStudent(id: string): Promise<void> {
  await updateStudent(id, { status: 'نشط' });
  const { data } = await supabase.from('students').select('full_name, diploma_type, specialization, current_semester, total_charged, total_paid').eq('id', id).maybeSingle();
  if (data) {
    const debt = Math.max(0, (data.total_charged ?? 0) - (data.total_paid ?? 0));
    await createNotification({
      type: 'تفعيل',
      student_id: id,
      message: [
        `تم تفعيل قيد الطالب: ${data.full_name}`,
        `الدبلوم: ${data.diploma_type} | التخصص: ${data.specialization ?? '—'}`,
        `الفصل الدراسي: ${data.current_semester}`,
        debt > 0 ? `المديونية المتبقية: ${debt.toFixed(2)} دينار` : `الحساب: مسوّى بالكامل ✓`,
        `تاريخ التفعيل: ${new Date().toLocaleDateString('ar-LY')}`,
      ].join('\n'),
    }).catch(() => {});
  }
}

// الحد الأقصى للفصول الدراسية لكل نوع دبلوم
// الدبلوم المتوسط: 6 فصول مثل العالي، لكن بدون مشروع تخرج في الفصل السادس
export const MAX_SEMESTERS: Record<string, number> = {
  'عالي':  6,
  'متوسط': 6,
};

// أسماء الفصول بالعربي — لاستخدامها في البيانات بدلاً من الأرقام
const SEM_ARABIC: Record<number, string> = {
  1: 'الفصل الأول', 2: 'الفصل الثاني', 3: 'الفصل الثالث',
  4: 'الفصل الرابع', 5: 'الفصل الخامس', 6: 'الفصل السادس',
};

// الترحيل إلى الفصل التالي
export async function promoteStudent(
  student: Student,
  settings: Record<string, string>,
  targetSemester?: number
): Promise<void> {
  const newSemester = targetSemester ?? (student.current_semester + 1);
  const feeKey = student.diploma_type === 'عالي'
    ? SETTINGS_KEYS.HIGH_DIPLOMA_FEE
    : SETTINGS_KEYS.MID_DIPLOMA_FEE;
  const semesterFee = parseFloat(settings[feeKey] ?? (student.diploma_type === 'عالي' ? '600' : '550'));

  // الرصيد المتبقي من الفصل الحالي
  const currentCharges = await getSemesterCharges(student.id);
  const unpaidAmount = currentCharges.reduce(
    (sum, c) => sum + (c.is_cleared ? 0 : c.remaining_amount),
    0
  );

  // إنشاء رسوم الفصل الجديد — إن كان قيد مسبق مقفل (is_locked) موجود نفعّله بدلاً من إنشاء قيد جديد
  const existingCharge = currentCharges
    .find(c => c.charge_type === 'فصلي' && c.semester_number === newSemester);

  let effectiveNewFee: number = 0;
  if (existingCharge) {
    if (existingCharge.is_locked) {
      // فعّل القيد المسبق: ارفع القفل وحدّث المبلغ إن اختلف
      await updateSemesterCharge(existingCharge.id, {
        is_locked: false,
        charge_amount: existingCharge.charge_amount, // يحتفظ بمبلغه الأصلي مع تخفيضه المسبق
      });
      effectiveNewFee = existingCharge.charge_amount - (existingCharge.discount_amount ?? 0);
    } else {
      // القيد موجود ونشط مسبقاً، لا داعي لتكرار الرسوم
      effectiveNewFee = 0;
    }
  } else {
    // لا يوجد قيد مسبق — أنشئ الفصل بالقيمة الأساسية الكاملة
    await createSemesterCharge({
      student_id: student.id,
      semester_number: newSemester,
      charge_amount: semesterFee,
      paid_amount: 0,
      charge_type: 'فصلي',
      is_cleared: false,
      is_locked: false,
    });
    effectiveNewFee = semesterFee;
  }

  // تحديث إجمالي المستحقات بالقيمة الفعلية بعد التخفيض إن وُجد
  const newTotalCharged = student.total_charged + effectiveNewFee;

  await updateStudent(student.id, {
    current_semester: newSemester,
    total_charged: newTotalCharged,
  });

  // إشعار الترحيل
  await createNotification({
    type: 'ترحيل',
    student_id: student.id,
    message: [
      `تم ترحيل الطالب: ${student.full_name}`,
      `الدبلوم: ${student.diploma_type} | التخصص: ${student.specialization ?? '—'}`,
      `من الفصل ${student.current_semester} إلى الفصل ${newSemester}`,
      `رسوم الفصل الجديد: ${effectiveNewFee.toFixed(2)} دينار`,
      `إجمالي المستحقات الجديدة: ${newTotalCharged.toFixed(2)} دينار`,
      `تاريخ الترحيل: ${new Date().toLocaleDateString('ar-LY')}`,
    ].join('\n'),
  }).catch(() => {});

  // إشعار بالديون المعلقة إن وجدت
  if (unpaidAmount > 0) {
    // تفصيل الفصول غير المسددة
    const unpaidCharges = currentCharges.filter(c => !c.is_cleared && c.remaining_amount > 0);
    const breakdown = unpaidCharges.map(
      c => `   • الفصل ${c.semester_number} (${c.charge_type}): متبقي ${c.remaining_amount.toFixed(2)} دينار`
    ).join('\n');
    await createNotification({
      type: 'ديون_معلقة',
      student_id: student.id,
      message: [
        `تحذير: الطالب ${student.full_name} رُحِّل برصيد معلق`,
        `الدبلوم: ${student.diploma_type} | الفصل الجديد: ${newSemester}`,
        `إجمالي الديون المعلقة: ${unpaidAmount.toFixed(2)} دينار`,
        `التفصيل:`,
        breakdown,
      ].join('\n'),
    }).catch(() => {});
  }

  // إضافة تلقائية لقائمة المشاريع عند الفصل السادس — للدبلوم العالي فقط
  // الدبلوم المتوسط لا يملك مشروع تخرج؛ يُؤرشف بمجرد سداد رسوم الفصل السادس
  if (newSemester === 6 && student.diploma_type === 'عالي') {
    const projectFee = parseFloat(settings[SETTINGS_KEYS.GRADUATION_PROJECT_FEE] ?? '350');
    await createSemesterCharge({
      student_id: student.id,
      semester_number: 6,
      charge_amount: projectFee,
      paid_amount: 0,
      charge_type: 'مشروع تخرج',
      is_cleared: false,
      is_locked: false,
    });
    await updateStudent(student.id, {
      total_charged: newTotalCharged + projectFee,
    });
    await createNotification({
      type: 'مشروع_تخرج',
      student_id: student.id,
      message: [
        `الطالب ${student.full_name} وصل للفصل السادس`,
        `الدبلوم: ${student.diploma_type} | التخصص: ${student.specialization ?? '—'}`,
        `تمت إضافته تلقائياً لقائمة مشاريع التخرج`,
        `رسوم المشروع: ${projectFee.toFixed(2)} دينار`,
        `تاريخ الإضافة: ${new Date().toLocaleDateString('ar-LY')}`,
      ].join('\n'),
    }).catch(() => {});
  }
}

// أرشفة الطالب — تحفظ لقطة كاملة (صورة + إيصالات + رسوم) ثم تحذفه من المنظومة
// ── نظام الدفعات ──────────────────────────────────────────────────────────────
// المنطق التلقائي:
// • كل طالب يُؤرشف يأخذ رقم الدفعة الحالي لنوع دبلومه.
// • بعد كل أرشفة، يُفحص: هل لا يزال هناك طلاب نشطون (غير موقوفين) في الفصل الأخير؟
//   - إذا لا → تُفتح دفعة جديدة تلقائياً (يزداد العداد) لاستقبال الموسم القادم.
//   - إذا نعم → تبقى الدفعة الحالية مفتوحة حتى يتخرج الجميع.
// • طلاب موقوف قيدهم لا يُحتسبون في فحص إغلاق الدفعة.

async function getCurrentBatchNumber(diplomaType: string): Promise<number> {
  const { data } = await supabase
    .from('graduation_batches')
    .select('batch_number')
    .eq('diploma_type', diplomaType)
    .order('batch_number', { ascending: false })
    .limit(1)
    .maybeSingle();
  return data?.batch_number ?? 1;
}

// يضمن وجود سجل الدفعة في graduation_batches — ينشئها إن لم تكن موجودة
async function ensureBatchExists(diplomaType: string, batchNumber: number): Promise<void> {
  const { data } = await supabase
    .from('graduation_batches')
    .select('id')
    .eq('diploma_type', diplomaType)
    .eq('batch_number', batchNumber)
    .maybeSingle();
  if (!data) {
    await supabase.from('graduation_batches').insert({
      diploma_type: diplomaType,
      batch_number: batchNumber,
      graduation_date: new Date().toISOString().slice(0, 10),
    });
  }
}

// بعد أرشفة طالب: إن لم يتبقَّ أي طالب نشط في الفصل الأخير → افتح دفعة جديدة مع تاريخ اليوم
async function autoAdvanceBatchIfNeeded(diplomaType: string): Promise<void> {
  const maxSem = MAX_SEMESTERS[diplomaType] ?? 6;
  const { count } = await supabase
    .from('students')
    .select('id', { count: 'exact', head: true })
    .eq('diploma_type', diplomaType)
    .eq('current_semester', maxSem)
    .neq('status', 'موقوف قيد');
  if ((count ?? 0) === 0) {
    const current = await getCurrentBatchNumber(diplomaType);
    const next = current + 1;
    await supabase.from('graduation_batches').insert({
      diploma_type: diplomaType,
      batch_number: next,
      graduation_date: new Date().toISOString().slice(0, 10),
    });
  }
}

// تُنشئ دفعة جديدة يدوياً (للاستخدام الطارئ فقط)
export async function incrementGraduationBatch(diplomaType: string): Promise<number> {
  const current = await getCurrentBatchNumber(diplomaType);
  const next = current + 1;
  await supabase.from('graduation_batches').insert({
    diploma_type: diplomaType,
    batch_number: next,
    graduation_date: new Date().toISOString().slice(0, 10),
  });
  return next;
}

// تحديث تاريخ التخرج لدفعة معينة
export async function updateGraduationBatchDate(
  diplomaType: string,
  batchNumber: number,
  newDate: string  // YYYY-MM-DD
): Promise<void> {
  const { error } = await supabase
    .from('graduation_batches')
    .update({ graduation_date: newDate })
    .eq('diploma_type', diplomaType)
    .eq('batch_number', batchNumber);
  if (error) throw error;
}
// تعيين طالب مؤرشف لدفعة معينة يدوياً (بكلمة سر)
export async function assignArchivedStudentToBatch(
  archivedStudentId: string,
  batchNumber: number
): Promise<void> {
  const { error } = await supabase
    .from('archived_students')
    .update({ batch_number: batchNumber })
    .eq('id', archivedStudentId);
  if (error) throw error;
}

// جلب كل الدفعات المتاحة (للفلتر في الواجهة) مع تاريخ التخرج
export async function getGraduationBatches(): Promise<{ diploma_type: string; batch_number: number; created_at: string; graduation_date: string | null }[]> {
  const { data } = await supabase
    .from('graduation_batches')
    .select('diploma_type, batch_number, created_at, graduation_date')
    .order('batch_number', { ascending: true });
  return (data ?? []).map((r: any) => ({ ...r }));
}

export async function archiveStudent(student: Student): Promise<void> {
  // 0أ) التحقق: لا أرشفة إلا عند بلوغ الفصل الأخير (6)
  const maxSem = MAX_SEMESTERS[student.diploma_type] ?? 6;
  if (student.current_semester < maxSem) {
    throw new Error(
      `لا يمكن أرشفة الطالب — الفصل الحالي (${student.current_semester}) لم يبلغ الفصل الأخير (${maxSem})`
    );
  }

  // 0ب) التحقق المبدئي: لا أرشفة إلا بعد سداد جميع الأقساط
  const { data: chargesCheck } = await supabase
    .from('semester_charges')
    .select('remaining_amount, charge_amount, paid_amount, discount_amount')
    .eq('student_id', student.id);

  if (chargesCheck && chargesCheck.length > 0) {
    const totalDebt = chargesCheck.reduce((sum, c) => {
      const effective = (c.charge_amount ?? 0) - (c.discount_amount ?? 0);
      return sum + Math.max(0, effective - (c.paid_amount ?? 0));
    }, 0);
    if (totalDebt > 0.01) {
      throw new Error(`لا يمكن أرشفة الطالب — يوجد رصيد متبقٍ: ${totalDebt.toFixed(2)} دينار`);
    }
  }

  // 1) جلب رقم الدفعة الحالي لهذا الدبلوم وضمان وجود سجلها
  const batchNumber = await getCurrentBatchNumber(student.diploma_type);
  await ensureBatchExists(student.diploma_type, batchNumber);

  // 2) جلب الإيصالات والرسوم والملفات قبل الحذف
  const [receiptsRaw, chargesRaw, filesRaw] = await Promise.all([
    supabase.from('receipts').select('*').eq('student_id', student.id).eq('is_deleted', false)
      .order('paid_at', { ascending: true }),
    supabase.from('semester_charges').select('*').eq('student_id', student.id)
      .order('semester_number', { ascending: true }),
    supabase.from('student_files').select('*').eq('student_id', student.id)
      .order('created_at', { ascending: true }),
  ]);

  const receiptsSnapshot = (receiptsRaw.data ?? []).slice().sort(compareReceipts);
  const chargesSnapshot  = chargesRaw.data  ?? [];
  const filesSnapshot    = filesRaw.data    ?? [];

  // 3) حفظ اللقطة المجمّدة في جدول الأرشيف مع رقم الدفعة
  const { error: archErr } = await supabase.from('archived_students').insert({
    original_id:       student.id,
    full_name:         student.full_name,
    national_id:       student.national_id   ?? null,
    phone:             student.phone          ?? null,
    address:           student.address        ?? null,
    gender:            student.gender         ?? null,
    diploma_type:      student.diploma_type,
    specialization:    student.specialization ?? null,
    enrollment_date:   student.enrollment_date ?? null,
    current_semester:  student.current_semester,
    status:            'خريج',
    is_equivalency:    student.is_equivalency ?? false,
    notes:             student.notes          ?? null,
    total_charged:     student.total_charged  ?? 0,
    total_paid:        student.total_paid     ?? 0,
    remaining_amount:  (student.total_charged ?? 0) - (student.total_paid ?? 0),
    photo_url:         student.photo_url      ?? null,
    graduation_year:   new Date().getFullYear(),
    receipts_snapshot: receiptsSnapshot,
    charges_snapshot:  chargesSnapshot,
    files_snapshot:    filesSnapshot,
    batch_number:      batchNumber,
  });
  if (archErr) throw archErr;

  // 4) إشعار الأرشفة
  const totalPd  = student.total_paid    ?? 0;
  const totalChg = student.total_charged ?? 0;
  const archDebt = Math.max(0, totalChg - totalPd);
  await createNotification({
    type: 'أرشفة',
    student_id: student.id,
    message: [
      `تمت أرشفة الطالب: ${student.full_name}`,
      `الدبلوم: ${student.diploma_type} | التخصص: ${student.specialization ?? '—'}`,
      `آخر فصل دراسي: الفصل ${student.current_semester}`,
      `الدفعة: ${batchNumber}`,
      `إجمالي المستحقات: ${totalChg.toFixed(2)} دينار`,
      `إجمالي المدفوع:   ${totalPd.toFixed(2)} دينار`,
      archDebt > 0
        ? `الديون عند الأرشفة: ${archDebt.toFixed(2)} دينار`
        : `الحساب: مسوّى بالكامل ✓`,
      `سنة التخرج: ${new Date().getFullYear()}`,
      `تاريخ الأرشفة: ${new Date().toLocaleDateString('ar-LY')}`,
    ].join('\n'),
  }).catch(() => {});

  // 5) حفظ اسم الطالب ودبلومه في الإيصالات قبل الحذف (لحماية أوامر التوريد)
  await supabase
    .from('receipts')
    .update({
      student_name:   student.full_name,
      student_diploma: student.diploma_type,
    })
    .eq('student_id', student.id);

  // 6) حذف الطالب نهائياً من المنظومة (receipts تبقى بـ student_id=NULL، semester_charges تُحذف CASCADE)
  const { error: delErr } = await supabase.from('students').delete().eq('id', student.id);
  if (delErr) throw delErr;

  // 6) فحص تلقائي: هل أُغلقت الدفعة؟ (لا يوجد طلاب نشطون بالفصل الأخير)
  await autoAdvanceBatchIfNeeded(student.diploma_type);

  // 7) إرسال إيميل تلقائي بجميع بيانات الطالب المؤرشف
  // نجلب id الطالب من الأرشيف (تمّ إدراجه للتو)
  void supabase
    .from('archived_students')
    .select('id')
    .eq('original_id', student.id)
    .order('archived_at', { ascending: false })
    .limit(1)
    .maybeSingle()
    .then(({ data: arch }) => {
      if (arch?.id) {
        supabase.functions.invoke('send-archive-email', {
          body: { archived_student_id: arch.id },
        }).catch(() => {});
      }
    });
}

// =============================================
// السجلات المالية - رسوم الفصول
// =============================================
export async function getSemesterCharges(studentId: string): Promise<SemesterCharge[]> {
  const { data, error } = await supabase
    .from('semester_charges')
    .select('*')
    .eq('student_id', studentId)
    .order('semester_number', { ascending: true });
  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function createSemesterCharge(
  charge: Omit<SemesterCharge, 'id' | 'remaining_amount' | 'created_at' | 'updated_at'>
): Promise<void> {
  const { error } = await supabase
    .from('semester_charges')
    .insert(charge);
  if (error) throw error;
}

export async function updateSemesterCharge(id: string, updates: Partial<SemesterCharge>): Promise<void> {
  const { error } = await supabase
    .from('semester_charges')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id);
  if (error) throw error;
}

// تطبيق تخفيض على رسمة فصل أو تسجيل مع إعادة حساب الرصيد
export async function applyDiscount(
  chargeId: string,
  studentId: string,
  discountAmount: number,
  discountReason: string
): Promise<void> {
  // جلب الرسمة الحالية
  const { data, error } = await supabase
    .from('semester_charges')
    .select('*')
    .eq('id', chargeId)
    .single();
  if (error) throw error;
  const charge = data as SemesterCharge;

  const clamped = Math.max(0, Math.min(discountAmount, charge.charge_amount));
  const effectiveAmount = charge.charge_amount - clamped;
  // عند التخفيض الكامل (القيمة = 0) تُعدّ مسدَّدة فوراً بدفع صفر
  const isCleared = charge.paid_amount >= effectiveAmount;

  await updateSemesterCharge(chargeId, {
    discount_amount: clamped,
    discount_reason: discountReason.trim() || null,
    is_cleared: isCleared,
  });

  // إعادة حساب التوزيع المالي الكامل
  await recalculateStudentFinances(studentId);
}

// =============================================
// الديون السابقة — رسوم الفصول الماضية غير المسددة
// =============================================
export interface PreviousDebtRow {
  student_id: string;
  full_name: string;
  national_id: string | null;
  phone: string | null;
  diploma_type: string;
  specialization: string | null;
  current_semester: number;
  status: string;
  registration_number?: string | null;
  photo_url?: string | null;
  charge_id: string;
  semester_number: number;
  charge_amount: number;
  paid_amount: number;
  discount_amount: number;
  remaining: number;
}

export async function getPreviousDebts(): Promise<PreviousDebtRow[]> {
  // 1. محاولة استدعاء الدالة السحابية الفائقة السرعة get_previous_debts_v2 (أقل من 30ms)
  try {
    const { data: rpcData, error: rpcError } = await supabase.rpc('get_previous_debts_v2');
    const list = Array.isArray(rpcData)
      ? rpcData
      : (typeof rpcData === 'string' ? JSON.parse(rpcData) : []);

    if (!rpcError && Array.isArray(list) && list.length > 0) {
      return list.map((row: any) => ({
        student_id: row.student_id,
        full_name: row.full_name,
        national_id: row.national_id ?? null,
        phone: row.phone ?? null,
        diploma_type: row.diploma_type,
        specialization: row.specialization ?? null,
        current_semester: row.current_semester,
        status: row.status,
        registration_number: row.registration_number ?? null,
        photo_url: row.photo_url ?? null,
        charge_id: row.charge_id,
        semester_number: row.semester_number,
        charge_amount: parseFloat(row.charge_amount),
        paid_amount: parseFloat(row.paid_amount),
        discount_amount: parseFloat(row.discount_amount ?? 0),
        remaining: parseFloat(row.remaining),
      }));
    }
  } catch (err) {
    console.warn('Fallback to standard query for previous debts:', err);
  }

  // 2. خطة بديلة احتياطية في حال تعذر تشغيل RPC
  const { data, error } = await supabase
    .from('semester_charges')
    .select(`
      id,
      student_id,
      semester_number,
      charge_amount,
      paid_amount,
      discount_amount,
      is_cleared,
      students!inner (
        full_name,
        national_id,
        phone,
        diploma_type,
        specialization,
        current_semester,
        status,
        registration_number,
        photo_url
      )
    `)
    .eq('is_cleared', false)
    .order('semester_number', { ascending: true });

  if (error) throw error;

  const rows: PreviousDebtRow[] = [];
  for (const row of (data ?? []) as any[]) {
    const s = row.students;
    const disc = parseFloat(row.discount_amount ?? 0);
    const effective = parseFloat(row.charge_amount) - disc;
    const paid = parseFloat(row.paid_amount);
    const remaining = effective - paid;
    // فقط الفصول السابقة (قبل الفصل الحالي) وعليها دَيْن فعلي
    if (remaining > 0.01 && row.semester_number < s.current_semester) {
      rows.push({
        student_id:      row.student_id,
        full_name:       s.full_name,
        national_id:     s.national_id ?? null,
        phone:           s.phone ?? null,
        diploma_type:    s.diploma_type,
        specialization:  s.specialization ?? null,
        current_semester: s.current_semester,
        status:          s.status,
        registration_number: s.registration_number ?? null,
        photo_url:       s.photo_url ?? null,
        charge_id:       row.id,
        semester_number: row.semester_number,
        charge_amount:   parseFloat(row.charge_amount),
        paid_amount:     paid,
        discount_amount: disc,
        remaining,
      });
    }
  }

  // ترتيب: الأعلى دَيناً أولاً
  rows.sort((a, b) => b.remaining - a.remaining);
  return rows;
}

// =============================================
// الإيصالات
// =============================================
export async function getReceipts(studentId: string): Promise<Receipt[]> {
  const { data, error } = await supabase
    .from('receipts')
    .select('*')
    .eq('student_id', studentId)
    .eq('is_deleted', false)
    .order('receipt_number', { ascending: true });
  if (error) throw error;
  const list = Array.isArray(data) ? data : [];
  // ترتيب نهائي: رقم الإيصال رقمياً تصاعدياً (000001 → 000002 → 000003 ...)
  return [...list].sort((a, b) => {
    const nA = parseInt((a.receipt_number ?? '0').replace(/\D/g, ''), 10) || 0;
    const nB = parseInt((b.receipt_number ?? '0').replace(/\D/g, ''), 10) || 0;
    return nA - nB;
  });
}

// جلب جميع الإيصالات مع بيانات الطالب (غير المحذوفة) — مرتّبة حسب نوع الفصل
export type ReceiptFilters = {
  search?: string;
  diploma?: string;
  specialization?: string;
  paymentType?: string;
  dateFrom?: string;
  dateTo?: string;
  limit?: number;
  offset?: number;
};

export type FullReceiptRow = Receipt & {
  student_name: string; student_national_id: string;
  student_diploma: string; student_specialization: string; student_phone: string | null;
  student_exam_only: boolean;
};

function mapReceiptRow(r: any): FullReceiptRow {
  return {
    ...r,
    student_name:           r.students?.full_name      ?? r.student_name    ?? '—',
    student_national_id:    r.students?.national_id    ?? '—',
    student_diploma:        r.students?.diploma_type   ?? r.student_diploma ?? '—',
    student_specialization: r.students?.specialization ?? '—',
    student_phone:          r.students?.phone          ?? null,
    student_exam_only:      r.students?.is_exam_only   ?? false,
  };
}

// جلب الإيصالات مع فلترة من الخادم + ترقيم صفحات
export async function getAllReceipts(
  filters?: ReceiptFilters,
): Promise<{ data: FullReceiptRow[]; count: number }> {
  const limit  = filters?.limit  ?? 100;
  const offset = filters?.offset ?? 0;

  let q = supabase
    .from('receipts')
    .select(`*, students(full_name, national_id, diploma_type, specialization, phone, is_exam_only)`, { count: 'exact' })
    .eq('is_deleted', false);

  // فلترة الدبلوم من العمود المُخزَّن student_diploma
  if (filters?.diploma)       q = q.eq('student_diploma', filters.diploma);
  if (filters?.paymentType)   q = q.eq('payment_type', filters.paymentType);
  if (filters?.dateFrom)      q = q.gte('paid_at', filters.dateFrom);
  if (filters?.dateTo)        q = q.lte('paid_at', filters.dateTo + 'T23:59:59');

  // البحث النصي: اسم الطالب (عمود مُخزَّن) أو رقم الإيصال مع التطبيع والمتغيرات العربية
  if (filters?.search && filters.search.trim()) {
    const variations = getSearchVariations(filters.search);
    const orClauses = variations.flatMap(v => {
      const s = v.replace(/'/g, "''");
      return [
        `student_name.ilike.%${s}%`,
        `receipt_number.ilike.%${s}%`,
        `student_national_id.ilike.%${s}%`
      ];
    });
    q = q.or(orClauses.slice(0, 12).join(','));
  }

  q = q.order('receipt_number', { ascending: true }).range(offset, offset + limit - 1);

  const { data, error, count } = await q;
  if (error) throw error;
  return {
    data: (Array.isArray(data) ? data : []).map(mapReceiptRow),
    count: count ?? 0,
  };
}

// جلب جميع الإيصالات بدون حدّ (للطباعة والتصدير) — بدون استعلامات join ثقيلة لتسريع التصدير 10 أضعاف
export async function getAllReceiptsUnpaged(): Promise<FullReceiptRow[]> {
  const CHUNK_SIZE = 1000;
  const selectCols = 'id, receipt_number, student_id, student_name, student_national_id, student_diploma, amount, payment_type, semester_target, paid_at, notes, payment_method, supply_order_number, is_deleted, created_at';
  const { data: firstData, error: firstErr, count } = await supabase
    .from('receipts')
    .select(selectCols, { count: 'exact' })
    .eq('is_deleted', false)
    .order('receipt_number', { ascending: true })
    .range(0, CHUNK_SIZE - 1);
  if (firstErr) throw firstErr;

  const allReceipts = [...(firstData ?? [])];
  const totalCount = count ?? allReceipts.length;

  if (totalCount > CHUNK_SIZE) {
    const promises = [];
    for (let offset = CHUNK_SIZE; offset < totalCount; offset += CHUNK_SIZE) {
      const end = Math.min(offset + CHUNK_SIZE - 1, totalCount - 1);
      promises.push(
        supabase
          .from('receipts')
          .select(selectCols)
          .eq('is_deleted', false)
          .order('receipt_number', { ascending: true })
          .range(offset, end)
      );
    }
    const results = await Promise.all(promises);
    for (const res of results) {
      if (res.error) throw res.error;
      if (res.data) allReceipts.push(...res.data);
    }
  }

  return (Array.isArray(allReceipts) ? allReceipts : []).map(mapReceiptRow);
}

// حذف إيصال واحد بالمعرّف
export async function deleteReceipt(receiptId: string): Promise<void> {
  const { error } = await supabase.from('receipts').delete().eq('id', receiptId);
  if (error) throw error;
}

// تعديل بيانات إيصال (المبلغ + البيان + الملاحظات)
export async function updateReceipt(
  receiptId: string,
  payload: { amount?: number; semester_target?: string | null; notes?: string | null },
): Promise<void> {
  const { error } = await supabase.from('receipts').update(payload).eq('id', receiptId);
  if (error) throw error;
}

// =============================================
// إعادة حساب التوزيع المالي للطالب
// تُستدعى بعد تعديل أي مبلغ لإيصال لإعادة توزيع كامل الإيصالات على الرسوم
// =============================================
export async function recalculateStudentFinances(studentId: string): Promise<void> {
  // 1) جلب جميع الرسوم مرتبة: تسجيل (-1) أولاً ثم تصاعدياً
  const { data: chargesData, error: chargesErr } = await supabase
    .from('semester_charges')
    .select('*')
    .eq('student_id', studentId)
    .order('semester_number', { ascending: true });
  if (chargesErr) throw chargesErr;
  const charges: SemesterCharge[] = (chargesData ?? []).slice().sort((a, b) => {
    if (a.semester_number === -1) return -1;
    if (b.semester_number === -1) return 1;
    return a.semester_number - b.semester_number;
  });

  // 2) جلب جميع الإيصالات الفعّالة (غير المحذوفة) مرتبة من الأقدم للأحدث
  const { data: receiptsData, error: receiptsErr } = await supabase
    .from('receipts')
    .select('*')
    .eq('student_id', studentId)
    .eq('is_deleted', false)
    .order('paid_at', { ascending: true });
  if (receiptsErr) throw receiptsErr;
  const allReceipts: Receipt[] = receiptsData ?? [];

  // القيود الفعّالة فقط (is_locked=false) — القيود المقفلة المسبقة لا تدخل في الحساب
  const activeCharges = charges.filter(c => !c.is_locked);

  // 3) مجموع الإيصالات = total_paid الجديد
  const totalPaid = allReceipts.reduce((s, r) => s + r.amount, 0);

  // 4) إعادة التوزيع: مصفوفة تتبع المدفوع لكل رسمة
  const paid = new Map<string, number>(activeCharges.map(c => [c.id, 0]));

  for (const receipt of allReceipts) {
    let remaining = receipt.amount;
    for (const charge of activeCharges) {
      if (remaining <= 0) break;
      const alreadyPaid = paid.get(charge.id) ?? 0;
      // المبلغ الفعلي بعد التخفيض
      const effectiveAmount = charge.charge_amount - (charge.discount_amount ?? 0);
      const stillDue = effectiveAmount - alreadyPaid;
      if (stillDue <= 0) continue;
      const toApply = Math.min(remaining, stillDue);
      paid.set(charge.id, alreadyPaid + toApply);
      remaining -= toApply;
    }
  }

  // 5) تحديث كل رسمة فعّالة بالقيم المحسوبة — بالتوازي بدلاً من الحلقة المتسلسلة
  let registrationCleared = false;
  await Promise.all(activeCharges.map(charge => {
    const newPaid = paid.get(charge.id) ?? 0;
    const effectiveAmount = charge.charge_amount - (charge.discount_amount ?? 0);
    const isCleared = newPaid >= effectiveAmount;
    if (charge.charge_type === 'تسجيل' && isCleared) registrationCleared = true;
    return updateSemesterCharge(charge.id, { paid_amount: newPaid, is_cleared: isCleared });
  }));

  // 6) تحديث إجمالي الطالب + حالة رسوم التسجيل (فقط القيود الفعّالة)
  const regCharge = activeCharges.find(c => c.charge_type === 'تسجيل');
  const regEffective = regCharge ? regCharge.charge_amount - (regCharge.discount_amount ?? 0) : 0;
  const finalRegPaid = regCharge ? (paid.get(regCharge.id) ?? 0) >= regEffective : false;
  // إجمالي المستحق بعد التخفيضات — فقط القيود الفعّالة
  const totalCharged = activeCharges.reduce((s, c) => s + c.charge_amount - (c.discount_amount ?? 0), 0);
  await updateStudent(studentId, {
    total_paid: totalPaid,
    total_charged: totalCharged,
    registration_fee_paid: registrationCleared || finalRegPaid,
  });
}

// حذف ناعم لكل إيصالات أمر توريد + إعادة حساب مالية الطلاب المتأثرين
export async function deleteSupplyOrder(supplyOrderNumber: string): Promise<void> {
  // 1) جلب الإيصالات أولاً لمعرفة الطلاب المتأثرين
  const { data: affected, error: fetchErr } = await supabase
    .from('receipts')
    .select('id, student_id')
    .eq('supply_order_number', supplyOrderNumber)
    .eq('is_deleted', false);
  if (fetchErr) throw fetchErr;

  // 2) حذف ناعم (soft delete)
  const { error } = await supabase
    .from('receipts')
    .update({ is_deleted: true, deleted_at: new Date().toISOString() })
    .eq('supply_order_number', supplyOrderNumber);
  if (error) throw error;

  invalidateSupplyOrdersCache();
  invalidateStudentsCache();

  // 3) إعادة حساب مالية كل طالب متأثر
  const uniqueStudents = [...new Set((affected ?? []).map((r: any) => r.student_id as string))];
  await Promise.all(uniqueStudents.map(sid => recalculateStudentFinances(sid)));
}

// استعادة أمر توريد محذوف بناءً على رقمه + إعادة حساب مالية الطلاب
export async function restoreSupplyOrder(supplyOrderNumber: string): Promise<{
  restoredCount: number;
  studentNames: string[];
  total: number;
  paid_at: string;
}> {
  // 1) جلب الإيصالات المحذوفة لهذا الرقم مع بيانات الطلاب
  const { data: deleted, error: fetchErr } = await supabase
    .from('receipts')
    .select('id, student_id, amount, paid_at, students(full_name)')
    .eq('supply_order_number', supplyOrderNumber)
    .eq('is_deleted', true);
  if (fetchErr) throw fetchErr;
  if (!deleted || deleted.length === 0) throw new Error('لا توجد إيصالات محذوفة لهذا الرقم');

  // 2) استعادة (رفع علامة الحذف)
  const { error: restoreErr } = await supabase
    .from('receipts')
    .update({ is_deleted: false, deleted_at: null })
    .eq('supply_order_number', supplyOrderNumber)
    .eq('is_deleted', true);
  if (restoreErr) throw restoreErr;

  invalidateSupplyOrdersCache();
  invalidateStudentsCache();

  // 3) إعادة حساب مالية كل طالب متأثر
  const uniqueStudents = [...new Set((deleted as any[]).map(r => r.student_id as string))];
  await Promise.all(uniqueStudents.map(sid => recalculateStudentFinances(sid)));

  // 4) إرجاع ملخص الاستعادة
  const names: string[] = [];
  for (const r of deleted as any[]) {
    const n = r.students?.full_name ?? r.student_name ?? '—';
    if (!names.includes(n)) names.push(n);
  }
  const total = (deleted as any[]).reduce((s: number, r: any) => s + (r.amount ?? 0), 0);
  return {
    restoredCount: deleted.length,
    studentNames: names,
    total,
    paid_at: (deleted as any[])[0].paid_at,
  };
}

// تحديث بيان وملاحظات إيصالات أمر توريد
export async function updateSupplyOrderNotes(
  supplyOrderNumber: string,
  notes: string | null,
  semesterTarget?: string | null,
): Promise<void> {
  const payload: Record<string, unknown> = { notes };
  if (semesterTarget !== undefined) payload.semester_target = semesterTarget;
  const { error } = await supabase
    .from('receipts')
    .update(payload)
    .eq('supply_order_number', supplyOrderNumber);
  if (error) throw error;
}

// تحديث شامل لأمر التوريد: رقم الإيصال، التاريخ، طريقة الدفع، البيان، الملاحظات
export async function updateSupplyOrderFull(
  supplyOrderNumber: string,
  params: {
    receipt_number?: string;
    paid_at?: string;
    payment_method?: string;
    semester_target?: string | null;
    notes?: string | null;
  },
): Promise<void> {
  const payload: Record<string, unknown> = {};
  if (params.receipt_number !== undefined) payload.receipt_number = params.receipt_number;
  if (params.paid_at !== undefined) payload.paid_at = params.paid_at;
  if (params.payment_method !== undefined) payload.payment_method = params.payment_method;
  if (params.semester_target !== undefined) payload.semester_target = params.semester_target;
  if (params.notes !== undefined) payload.notes = params.notes;
  const { error } = await supabase
    .from('receipts')
    .update(payload)
    .eq('supply_order_number', supplyOrderNumber);
  if (error) throw error;
}
type SupplyOrderReceipt = Receipt & {
  student_name: string; student_national_id: string;
  student_diploma: string; student_specialization: string; student_phone: string | null;
  student_exam_only: boolean;
};

function mapSupplyOrderRows(data: any[]): SupplyOrderReceipt[] {
  return data.map((r: any) => ({
    ...r,
    // الأولوية: بيانات students الحية → بيانات محفوظة في العمود → '—'
    student_name:           r.students?.full_name     ?? r.student_name    ?? '—',
    student_national_id:    r.students?.national_id   ?? '—',
    student_diploma:        r.students?.diploma_type  ?? r.student_diploma ?? '—',
    student_specialization: r.students?.specialization ?? '—',
    student_phone:          r.students?.phone          ?? null,
    student_exam_only:      r.students?.is_exam_only   ?? false,
  }));
}

export async function getSupplyOrdersByDate(dateStr: string): Promise<SupplyOrderReceipt[]> {
  // بدون Z suffix → Supabase يفسّره بالتوقيت المحلي للسيرفر، مما يتطابق مع اليوم المحدد
  const from = `${dateStr}T00:00:00`;
  const to   = `${dateStr}T23:59:59.999`;
  const { data, error } = await supabase
    .from('receipts')
    .select(`id, receipt_number, student_id, student_name, student_national_id, student_diploma, amount, payment_type, semester_target, paid_at, notes, payment_method, supply_order_number, is_deleted, created_at`)
    .not('supply_order_number', 'is', null)
    .eq('is_deleted', false)
    .gte('paid_at', from)
    .lte('paid_at', to)
    .order('supply_order_number', { ascending: false });
  if (error) throw error;
  return mapSupplyOrderRows(Array.isArray(data) ? data : []);
}

// كاش ذكي لأوامر التوريد لتسريع التنقل
interface SupplyOrdersCacheEntry {
  data: SupplyOrderReceipt[];
  timestamp: number;
}
let _supplyOrdersCache: SupplyOrdersCacheEntry | null = null;
const SUPPLY_ORDERS_CACHE_TTL = 15000; // 15 ثانية

export function invalidateSupplyOrdersCache(): void {
  _supplyOrdersCache = null;
}

// جميع أوامر التوريد بدون تصفية بالتاريخ
export async function getAllSupplyOrders(forceRefresh = false): Promise<SupplyOrderReceipt[]> {
  if (!forceRefresh && _supplyOrdersCache && Date.now() - _supplyOrdersCache.timestamp < SUPPLY_ORDERS_CACHE_TTL) {
    return _supplyOrdersCache.data;
  }
  const { data, error } = await supabase
    .from('receipts')
    .select(`id, receipt_number, student_id, student_name, student_national_id, student_diploma, amount, payment_type, semester_target, paid_at, notes, payment_method, supply_order_number, is_deleted, created_at`)
    .not('supply_order_number', 'is', null)
    .eq('is_deleted', false)
    .order('supply_order_number', { ascending: false });
  if (error) throw error;
  const mapped = mapSupplyOrderRows(Array.isArray(data) ? data : []);
  _supplyOrdersCache = { data: mapped, timestamp: Date.now() };
  return mapped;
}

export async function getUnassignedReceiptsCount(): Promise<number> {
  const { count, error } = await supabase
    .from('receipts')
    .select('id', { count: 'exact', head: true })
    .is('supply_order_number', null)
    .eq('is_deleted', false);
  if (error) return 0;
  return count ?? 0;
}

export async function issueSupplyOrderForReceipts(receiptIds: string[], diplomaType: DiplomaType = 'عالي'): Promise<string> {
  if (!receiptIds.length) throw new Error('لا توجد إيصالات محددة');
  const soNum = await getNextSupplyOrderNumber(diplomaType);
  const { error } = await supabase
    .from('receipts')
    .update({ supply_order_number: soNum })
    .in('id', receiptIds);
  if (error) throw error;
  invalidateSupplyOrdersCache();
  return soNum;
}

export async function createReceipt(receipt: Omit<Receipt, 'id' | 'created_at'>): Promise<Receipt> {
  // جلب بيانات الطالب لحفظها مباشرة في الإيصال (تحمي أوامر التوريد عند الأرشفة)
  const { data: st } = await supabase
    .from('students')
    .select('full_name, diploma_type, specialization, current_semester, total_charged, total_paid')
    .eq('id', receipt.student_id).maybeSingle();

  // تأكيد رقم أمر التوريد تلقائياً إن لم يُمرر لضمان المزامنة الدائمة مع صفحة أوامر التوريد
  let finalSupplyOrder = receipt.supply_order_number;
  if (!finalSupplyOrder && receipt.amount > 0) {
    try {
      const diploma = (st?.diploma_type as DiplomaType) || 'عالي';
      const day = receipt.paid_at ? receipt.paid_at.slice(0, 10) : undefined;
      finalSupplyOrder = await getOrCreateTodaySupplyOrderNumber(diploma, day);
    } catch (e) {
      console.warn('Could not auto-generate supply order number:', e);
    }
  }

  const { data, error } = await supabase
    .from('receipts')
    .insert({
      ...receipt,
      supply_order_number: finalSupplyOrder ?? null,
      student_name:    st?.full_name    ?? null,
      student_diploma: st?.diploma_type ?? null,
    })
    .select()
    .maybeSingle();
  if (error) throw error;
  const r = data as Receipt;

  invalidateSupplyOrdersCache();
  invalidateStudentsCache();

  // لا تُنشئ إشعاراً هنا — الإشعار يُنشأ مرة واحدة في processPayment بعد تجميع كل الإيصالات
  return r;
}

// دفعة مالية مع توزيع ذكي: رسوم تسجيل أولاً ثم أقساط الفصول
// =============================================
// ملخص أرقام أوامر التوريد: الموجودة + المحذوفة ناعماً (قابلة للاستعادة) + الفجوات الحقيقية
// =============================================
export async function getSupplyOrdersSummary(): Promise<{
  existing: Array<{
    supply_order_number: string; num: number; diploma_type: string;
    paid_at: string; student_count: number; total: number; student_names: string[];
  }>;
  deleted: Array<{
    supply_order_number: string; num: number; diploma_type: string;
    paid_at: string; deleted_at: string; student_count: number; total: number; student_names: string[];
  }>;
  trueGapsHigh: number[];
  trueGapsMid: number[];
  maxHigh: number;
  maxMid: number;
}> {
  // جلب كل الإيصالات (موجودة + محذوفة ناعماً)
  const { data, error } = await supabase
    .from('receipts')
    .select('supply_order_number, amount, paid_at, deleted_at, is_deleted, students(full_name, diploma_type)')
    .not('supply_order_number', 'is', null)
    .order('paid_at', { ascending: false });
  if (error) throw error;

  const existingMap = new Map<string, { diploma_type: string; paid_at: string; student_count: number; total: number; student_names: string[] }>();
  const deletedMap  = new Map<string, { diploma_type: string; paid_at: string; deleted_at: string; student_count: number; total: number; student_names: string[] }>();

  for (const r of (data ?? []) as any[]) {
    const soNum: string  = r.supply_order_number;
    const diplomaType    = r.students?.diploma_type ?? r.student_diploma ?? '—';
    const studentName    = r.students?.full_name    ?? r.student_name    ?? '—';

    if (r.is_deleted) {
      if (!deletedMap.has(soNum)) {
        deletedMap.set(soNum, { diploma_type: diplomaType, paid_at: r.paid_at, deleted_at: r.deleted_at ?? '', student_count: 0, total: 0, student_names: [] });
      }
      const entry = deletedMap.get(soNum)!;
      entry.student_count += 1;
      entry.total += r.amount ?? 0;
      if (!entry.student_names.includes(studentName)) entry.student_names.push(studentName);
      if (r.deleted_at && r.deleted_at > entry.deleted_at) entry.deleted_at = r.deleted_at;
    } else {
      if (!existingMap.has(soNum)) {
        existingMap.set(soNum, { diploma_type: diplomaType, paid_at: r.paid_at, student_count: 0, total: 0, student_names: [] });
      }
      const entry = existingMap.get(soNum)!;
      entry.student_count += 1;
      entry.total += r.amount ?? 0;
      if (!entry.student_names.includes(studentName)) entry.student_names.push(studentName);
    }
  }

  const existing = Array.from(existingMap.entries())
    .map(([soNum, v]) => ({ supply_order_number: soNum, num: parseInt(soNum.slice(2)), ...v }))
    .sort((a, b) => b.num - a.num);

  const deleted = Array.from(deletedMap.entries())
    .map(([soNum, v]) => ({ supply_order_number: soNum, num: parseInt(soNum.slice(2)), ...v as any }))
    .sort((a, b) => b.num - a.num);

  const [maxHigh, maxMid] = await Promise.all([
    peekCurrentSupplyOrderNumber('عالي'),
    peekCurrentSupplyOrderNumber('متوسط'),
  ]);

  // الفجوات الحقيقية = أرقام ليس لها أي إيصال (لا موجودة ولا محذوفة)
  const knownHighNums = new Set([
    ...existing.filter(e => e.diploma_type === 'عالي').map(e => e.num),
    ...deleted.filter(e => e.diploma_type === 'عالي').map(e => e.num),
  ]);
  const knownMidNums = new Set([
    ...existing.filter(e => e.diploma_type === 'متوسط').map(e => e.num),
    ...deleted.filter(e => e.diploma_type === 'متوسط').map(e => e.num),
  ]);
  const trueGapsHigh = Array.from({ length: maxHigh }, (_, i) => i + 1).filter(n => !knownHighNums.has(n)).reverse();
  const trueGapsMid  = Array.from({ length: maxMid  }, (_, i) => i + 1).filter(n => !knownMidNums.has(n)).reverse();

  return { existing, deleted, trueGapsHigh, trueGapsMid, maxHigh, maxMid };
}

export async function processPayment(params: {
  studentId: string;
  amount: number;
  receiptNumber?: string; // اختياري: يُستخدم فقط في وضع الاستعادة — وإلا يُولَّد تلقائياً
  paymentType?: PaymentType;
  notes?: string;
  paidAt?: string;
  paymentMethod?: string;
  overrideSupplyOrderNumber?: string; // لاستعادة أمر توريد محذوف بنفس رقمه
}): Promise<{ receipts: Receipt[]; updatedCharges: SemesterCharge[] }> {
  const { studentId, amount, notes, paidAt, paymentMethod, overrideSupplyOrderNumber } = params;

  const student = await getStudentById(studentId);
  if (!student) throw new Error('الطالب غير موجود');

  // توليد رقم الإيصال هنا (بعد التحقق من وجود الطالب) — يضمن عدم استهلاك الرقم إذا فشل التحقق
  // في وضع الاستعادة يُمرَّر الرقم صراحةً، وإلا يُولَّد تلقائياً الآن
  let receiptNumber: string;
  if (params.receiptNumber && params.receiptNumber.trim()) {
    receiptNumber = params.receiptNumber.trim();
    // مزامنة عداد الإيصالات في الإعدادات إذا كان هذا الرقم المخصص أكبر من العداد الحالي
    try {
      const counterKey = student.diploma_type === 'عالي' ? SETTINGS_KEYS.RECEIPT_COUNTER_HIGH : SETTINGS_KEYS.RECEIPT_COUNTER_MID;
      const { data: currSetting } = await supabase.from('system_settings').select('value').eq('key', counterKey).maybeSingle();
      const currVal = parseInt(currSetting?.value ?? '0', 10);
      const numVal = parseInt(receiptNumber, 10);
      if (!isNaN(numVal) && numVal > currVal) {
        const padded = String(numVal).padStart(Math.max(6, receiptNumber.length), '0');
        await supabase.from('system_settings').update({ value: padded, updated_at: new Date().toISOString() }).eq('key', counterKey);
      }
    } catch (syncErr) {
      console.warn('Could not sync receipt counter:', syncErr);
    }
  } else {
    receiptNumber = await getNextReceiptNumber(student.diploma_type);
  }

  // استخدام الرقم المجبر إن وُجد (وضع الاستعادة)، وإلا توليد/إعادة استخدام رقم أمر اليوم
  const paymentDay = paidAt ? paidAt.slice(0, 10) : new Date().toISOString().slice(0, 10);
  const supplyOrderNumber = overrideSupplyOrderNumber
    ?? await getOrCreateTodaySupplyOrderNumber(student.diploma_type, paymentDay);

  // جلب جميع الرسوم غير المسددة مرتبة:
  // تسجيل (-1) أولاً، ثم معادلة (فصل 1، 2، 3...) تسلسلياً، ثم الفصول الدراسية
  const charges = await getSemesterCharges(studentId);
  const unpaidCharges = charges
    .filter(c => !c.is_cleared)
    .sort((a, b) => {
      // رسوم التسجيل (semester_number = -1) لها الأولوية القصوى
      if (a.semester_number === -1) return -1;
      if (b.semester_number === -1) return 1;
      // رسوم المعادلة تأتي قبل رسوم الفصول الدراسية
      const aIsEquiv = a.charge_type === 'معادلة';
      const bIsEquiv = b.charge_type === 'معادلة';
      if (aIsEquiv && !bIsEquiv) return -1;
      if (!aIsEquiv && bIsEquiv) return 1;
      // ضمن المعادلة أو الفصول: ترتيب تصاعدي حسب رقم الفصل
      return a.semester_number - b.semester_number;
    });

  let remaining = amount;
  const updatedCharges: SemesterCharge[] = [];
  const receipts: Receipt[] = [];
  const now = paidAt ?? new Date().toISOString();

  // توزيع الدفعة على كل رسوم بحسب الأولوية
  for (const charge of unpaidCharges) {
    if (remaining <= 0) break;

    // يُحسَب المتبقي محلياً لتجنب القيمة المخزّنة القديمة في remaining_amount
    const effectiveAmt = charge.charge_amount - (charge.discount_amount ?? 0);
    const localRemaining = Math.max(0, effectiveAmt - charge.paid_amount);
    const toApply = Math.min(remaining, localRemaining);
    const newPaid = charge.paid_amount + toApply;
    const isCleared = newPaid >= effectiveAmt;

    const newRemaining = Math.max(0, effectiveAmt - newPaid);
    await updateSemesterCharge(charge.id, {
      paid_amount: newPaid,
      is_cleared: isCleared,
    });

    updatedCharges.push({ ...charge, paid_amount: newPaid, is_cleared: isCleared, remaining_amount: newRemaining });

    // تحديد نوع الدفعة ونص البيان لهذه الجزئية
    let sliceType: PaymentType;
    let sliceTarget: string;

    if (charge.charge_type === 'تسجيل') {
      sliceType = 'تسجيل';
      sliceTarget = 'رسوم التسجيل';
    } else if (charge.charge_type === 'معادلة') {
      sliceType = 'معادلة';
      const semArabic = SEM_ARABIC[charge.semester_number] ?? `الفصل ${charge.semester_number}`;
      sliceTarget = isCleared
        ? `سداد رسوم معادلة ${semArabic} بالكامل`
        : `قسط من رسوم معادلة ${semArabic}`;
    } else if (charge.charge_type === 'مشروع تخرج') {
      sliceType = 'مشروع تخرج';
      sliceTarget = 'رسوم مشروع التخرج';
    } else {
      // فصلي — عرض هل هو قسط أو سداد كامل باسم الفصل العربي الصحيح
      const semArabic = SEM_ARABIC[charge.semester_number] ?? `الفصل ${charge.semester_number}`;
      sliceType = 'قسط فصلي';
      sliceTarget = isCleared
        ? `رسوم ${semArabic} بالكامل`
        : `قسط من رسوم ${semArabic}`;
    }

    // ملاحظة تخفيض تُضاف تلقائياً إن كان هذا القيد مخفَّضاً
    const discountNote = (charge.discount_amount ?? 0) > 0
      ? `تخفيض: ${charge.charge_amount.toFixed(0)} ← ${(charge.charge_amount - (charge.discount_amount ?? 0)).toFixed(0)} د.ل${charge.discount_reason ? ` (${charge.discount_reason})` : ''}`
      : null;

    const receipt = await createReceipt({
      student_id: studentId,
      receipt_number: receiptNumber,
      supply_order_number: supplyOrderNumber,
      amount: toApply,
      payment_type: sliceType,
      semester_target: sliceTarget,
      notes: discountNote ?? (notes || null),
      paid_at: now,
      payment_method: paymentMethod ?? 'كاش',
    });
    receipts.push(receipt);

    // تحديث حالة رسوم التسجيل على الطالب
    if (charge.charge_type === 'تسجيل' && isCleared) {
      await updateStudent(studentId, { registration_fee_paid: true });
    }

    remaining -= toApply;
  }

  // تحديث إجمالي المدفوعات
  const totalPaidAfter = student.total_paid + amount;
  await updateStudent(studentId, { total_paid: totalPaidAfter });

  // إشعار دفع واحد موحّد بعد اكتمال كل الإيصالات — يعكس الأرصدة الصحيحة النهائية
  const finalRemaining = Math.max(0, (student.total_charged ?? 0) - totalPaidAfter);
  const semLabel  = `الفصل ${student.current_semester}`;
  const paidPct   = Math.round((totalPaidAfter / (student.total_charged || 1)) * 100);
  await createNotification({
    type: 'دفع',
    student_id: studentId,
    message: [
      `دفع الطالب: ${student.full_name}`,
      `الدبلوم: ${student.diploma_type} | التخصص: ${student.specialization ?? '—'} | ${semLabel}`,
      `المبلغ المدفوع: ${amount.toFixed(2)} دينار`,
      `إجمالي المستحقات: ${(student.total_charged ?? 0).toFixed(2)} دينار`,
      finalRemaining === 0
        ? `الحساب: مسوّى بالكامل ✓`
        : `المبلغ المتبقي: ${finalRemaining.toFixed(2)} دينار`,
      finalRemaining > 0 ? `نسبة السداد: ${paidPct}%` : null,
      notes?.trim() ? `ملاحظة: ${notes}` : null,
      `تاريخ الدفع: ${new Date(paidAt ?? new Date()).toLocaleDateString('ar-LY')}`,
    ].filter(Boolean).join('\n'),
  }).catch(() => {});

  return { receipts, updatedCharges };
}

// =============================================
// الإشعارات
// =============================================
export async function getNotifications(onlyUnread = false): Promise<Notification[]> {
  return withRetry(async () => {
    let query = supabase
      .from('notifications')
      .select('*, student:students(id, full_name, national_id)')
      .order('created_at', { ascending: false })
      .limit(100);
    if (onlyUnread) {
      query = query.eq('is_read', false);
    }
    const { data, error } = await query;
    if (error) throw error;
    return Array.isArray(data) ? data as unknown as Notification[] : [];
  });
}

export async function markNotificationRead(id: string): Promise<void> {
  const { error } = await supabase
    .from('notifications')
    .update({ is_read: true })
    .eq('id', id);
  if (error) throw error;
}

export async function markAllNotificationsRead(): Promise<void> {
  const { error } = await supabase
    .from('notifications')
    .update({ is_read: true })
    .eq('is_read', false);
  if (error) throw error;
}

export async function createNotification(
  notif: Omit<Notification, 'id' | 'is_read' | 'created_at' | 'student'>
): Promise<void> {
  const { error } = await supabase
    .from('notifications')
    .insert({ ...notif, is_read: false });
  if (error) throw error;

  // إرسال إيميل تلقائي بشكل غير متزامن (لا يوقف العملية إذا فشل)
  supabase.functions.invoke('send-email', {
    body: { type: notif.type, message: notif.message },
  }).catch(() => {});
}

// بعد حفظ الطالب - إنشاء إشعار النواقص تلقائياً
export async function checkAndCreateDocumentNotification(student: Student): Promise<void> {
  const missing: string[] = [];
  if (student.photos_received < student.photos_required) {
    missing.push(`${student.photos_required - student.photos_received} صور شخصية`);
  }
  if (!student.has_birth_certificate) missing.push('شهادة ميلاد');
  if (!student.has_registration_certificate) missing.push('شهادة التسجيل');
  if (!student.has_suspended_file) missing.push('ملف معلق');

  if (missing.length > 0) {
    await createNotification({
      type: 'نواقص_ملف',
      student_id: student.id,
      message: [
        `ملف الطالب ${student.full_name} يحتاج إلى إكمال`,
        `الدبلوم: ${student.diploma_type} | التخصص: ${student.specialization ?? '—'} | الفصل ${student.current_semester}`,
        `المستندات الناقصة (${missing.length}):`,
        ...missing.map(m => `   • ${m}`),
        `يرجى المتابعة مع الطالب لاستيفاء الملف`,
      ].join('\n'),
    }).catch(() => {});
  }
}

// =============================================
// إحصائيات لوحة التحكم
// =============================================
export interface DashboardStats {
  totalStudents: number;
  highDiplomaStudents: number;
  midDiplomaStudents: number;
  totalDebt: number;
  activeStudents: number;
  suspendedStudents: number;
  archivedStudents?: number;
  studentsWithMissingDocs: number;
  studentsWithoutRegistrationNumber?: number;
}

let _dashboardStatsCache: { data: DashboardStats; timestamp: number } | null = null;
const DASHBOARD_STATS_CACHE_TTL = 20000; // 20 ثانية

export function invalidateDashboardStatsCache(): void {
  _dashboardStatsCache = null;
  if (typeof window !== 'undefined') {
    try { sessionStorage.removeItem('alqeema_dashboard_stats_cache'); } catch {}
  }
}

export async function getDashboardStats(forceRefresh = false): Promise<DashboardStats> {
  const now = Date.now();
  if (!forceRefresh && _dashboardStatsCache && now - _dashboardStatsCache.timestamp < DASHBOARD_STATS_CACHE_TTL) {
    return _dashboardStatsCache.data;
  }
  if (!forceRefresh && !_dashboardStatsCache && typeof window !== 'undefined') {
    try {
      const stored = sessionStorage.getItem('alqeema_dashboard_stats_cache');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed.data && now - parsed.time < DASHBOARD_STATS_CACHE_TTL * 3) {
          _dashboardStatsCache = { data: parsed.data, timestamp: parsed.time };
          return parsed.data;
        }
      }
    } catch {}
  }

  return withRetry(async () => {
    // استعلام RPC واحد يحسب كل الإحصائيات دفعة واحدة في قاعدة البيانات
    const { data, error } = await supabase.rpc('get_dashboard_stats');
    if (error) throw error;
    const d = (data as any) ?? {};
    const res: DashboardStats = {
      totalStudents:                     d.totalStudents                     ?? 0,
      highDiplomaStudents:               d.highDiplomaStudents               ?? 0,
      midDiplomaStudents:                d.midDiplomaStudents                ?? 0,
      activeStudents:                    d.activeStudents                    ?? 0,
      suspendedStudents:                 d.suspendedStudents                 ?? 0,
      archivedStudents:                  d.archivedStudents                  ?? 0,
      totalDebt:                         d.totalDebt                         ?? 0,
      studentsWithMissingDocs:           d.studentsWithMissingDocs           ?? 0,
      studentsWithoutRegistrationNumber: d.studentsWithoutRegistrationNumber ?? 0,
    };
    _dashboardStatsCache = { data: res, timestamp: now };
    if (typeof window !== 'undefined') {
      try {
        sessionStorage.setItem('alqeema_dashboard_stats_cache', JSON.stringify({ data: res, time: now }));
      } catch {}
    }
    return res;
  });
}

export async function updateStudentRegistrationNumber(studentId: string, registrationNumber: string): Promise<void> {
  return withRetry(async () => {
    const trimmed = registrationNumber.trim();
    const { error } = await supabase
      .from('students')
      .update({
        registration_number: trimmed.length > 0 ? trimmed : null,
        updated_at: new Date().toISOString()
      })
      .eq('id', studentId);
    if (error) throw error;
  });
}

// إحصائيات التخصصات — GROUP BY في الـ DB بدل جلب كل السجلات
export async function getSpecializationStats(): Promise<{ specialization: string; diploma_type: string; count: number }[]> {
  return withRetry(async () => {
    const { data, error } = await supabase.rpc('get_specialization_stats');
    if (error) {
      // fallback: استعلام خفيف بحقلين فقط
      const { data: raw, error: e2 } = await supabase
        .from('students')
        .select('specialization, diploma_type')
        .limit(5000);
      if (e2) throw e2;
      const list = Array.isArray(raw) ? raw : [];
      const map: Record<string, { specialization: string; diploma_type: string; count: number }> = {};
      list.forEach((s: { specialization: string; diploma_type: string }) => {
        const key = `${s.diploma_type}__${s.specialization}`;
        if (!map[key]) map[key] = { specialization: s.specialization, diploma_type: s.diploma_type, count: 0 };
        map[key].count++;
      });
      return Object.values(map).sort((a, b) => b.count - a.count);
    }
    return Array.isArray(data) ? data : [];
  });
}

// =============================================
// الصور الشخصية وملفات الطالب
// =============================================

// رفع صورة شخصية للطالب
export async function uploadStudentAvatar(studentId: string, file: File): Promise<string> {
  const ext = file.name.split('.').pop() ?? 'jpg';
  const path = `${studentId}/avatar_${Date.now()}.${ext}`;
  const { data, error } = await supabase.storage
    .from('student-avatars')
    .upload(path, file, { contentType: file.type, upsert: true });
  if (error) throw error;
  const { data: urlData } = supabase.storage.from('student-avatars').getPublicUrl(data.path);
  await updateStudent(studentId, { photo_url: urlData.publicUrl });
  return urlData.publicUrl;
}

// جلب ملفات الطالب
export async function getStudentFiles(studentId: string): Promise<StudentFile[]> {
  const { data, error } = await supabase
    .from('student_files')
    .select('*')
    .eq('student_id', studentId)
    .order('created_at', { ascending: false })
    .limit(50);
  if (error) throw error;
  return Array.isArray(data) ? (data as StudentFile[]) : [];
}

// رفع ملف للطالب
export async function uploadStudentFile(
  studentId: string,
  file: File,
  label?: string
): Promise<StudentFile> {
  const sanitized = file.name.replace(/\s+/g, '_').replace(/[^a-zA-Z0-9._-]/g, '');
  const path = `${studentId}/${Date.now()}_${sanitized}`;
  const { data, error } = await supabase.storage
    .from('student-files')
    .upload(path, file, { contentType: file.type });
  if (error) throw error;
  const { data: urlData } = supabase.storage.from('student-files').getPublicUrl(data.path);

  const fileType = file.type.startsWith('image/') ? 'image' : 'document';
  const { data: rec, error: dbErr } = await supabase
    .from('student_files')
    .insert({
      student_id: studentId,
      file_url: urlData.publicUrl,
      file_name: file.name,
      file_type: fileType,
      label: label ?? null,
    })
    .select()
    .maybeSingle();
  if (dbErr) throw dbErr;
  return rec as StudentFile;
}

// حذف ملف الطالب
export async function deleteStudentFile(fileId: string): Promise<void> {
  const { error } = await supabase
    .from('student_files')
    .delete()
    .eq('id', fileId);
  if (error) throw error;
}

// =============================================
// الأرشيف — الطلاب الخريجون (لقطة مجمّدة)
// =============================================

// =============================================
// الأرشيف والبيانات التاريخية (محسّن لـ 100,000+ طالب)
// =============================================

export interface ArchivedStudentLean {
  id: string;
  original_id: string | null;
  archived_at: string;
  full_name: string;
  national_id: string | null;
  phone: string | null;
  address: string | null;
  gender: string | null;
  diploma_type: string;
  specialization: string | null;
  enrollment_date: string | null;
  current_semester: number | null;
  status: string | null;
  is_equivalency: boolean;
  notes: string | null;
  total_charged: number;
  total_paid: number;
  remaining_amount: number;
  photo_url: string | null;
  graduation_year: number | null;
  batch_number: number | null;
  receipts_snapshot?: any[];
  charges_snapshot?: any[];
  files_snapshot?: any[];
}

export interface ArchiveQueryParams {
  search?: string;
  diplomaType?: string;
  specialization?: string;
  batchNumber?: number;
  limit?: number;
  offset?: number;
}

export interface ArchiveStats {
  total: number;
  highDiploma: number;
  midDiploma: number;
  totalPaid: number;
}

export async function getArchiveStats(params?: Pick<ArchiveQueryParams, 'search' | 'diplomaType' | 'specialization' | 'batchNumber'>): Promise<ArchiveStats> {
  return withRetry(async () => {
    const { data, error } = await supabase.rpc('get_archive_stats', {
      p_search: params?.search || null,
      p_diploma_type: params?.diplomaType && params.diplomaType !== 'الكل' ? params.diplomaType : null,
      p_specialization: params?.specialization && params.specialization !== 'الكل' ? params.specialization : null,
      p_batch_number: params?.batchNumber ?? null,
    });
    if (error) throw error;
    const d = data as any;
    return {
      total: Number(d?.total ?? 0),
      highDiploma: Number(d?.highDiploma ?? 0),
      midDiploma: Number(d?.midDiploma ?? 0),
      totalPaid: Number(d?.totalPaid ?? 0),
    };
  });
}

// جلب الطلاب المؤرشفين بشكل خفيف وسريع (مفهرس مع pagination لدعم +100,000 طالب بدون بطء)
export async function getArchivedStudents(params?: ArchiveQueryParams): Promise<{ data: ArchivedStudentLean[]; count: number }> {
  return withRetry(async () => {
    const limit = params?.limit ?? 36;
    const offset = params?.offset ?? 0;

    // استثناء حقول JSONB الضخمة (receipts_snapshot, charges_snapshot, files_snapshot) لتقليص حجم البيانات بـ 95%
    let query = supabase
      .from('archived_students')
      .select('id, original_id, archived_at, full_name, national_id, phone, address, gender, diploma_type, specialization, enrollment_date, current_semester, status, is_equivalency, notes, total_charged, total_paid, remaining_amount, photo_url, graduation_year, batch_number', { count: 'exact' })
      .order('archived_at', { ascending: false })
      .range(offset, offset + limit - 1);

    if (params?.search?.trim()) {
      const q = params.search.trim();
      query = query.or(`full_name.ilike.%${q}%,national_id.ilike.%${q}%,specialization.ilike.%${q}%`);
    }
    if (params?.diplomaType && params.diplomaType !== 'الكل') {
      query = query.eq('diploma_type', params.diplomaType);
    }
    if (params?.specialization && params.specialization !== 'الكل') {
      query = query.eq('specialization', params.specialization);
    }
    if (params?.batchNumber != null) {
      query = query.eq('batch_number', params.batchNumber);
    }

    const { data, error, count } = await query;
    if (error) throw error;
    const parsed = (Array.isArray(data) ? data : []).map((r: any) => ({
      ...r,
      total_charged: parseFloat(r.total_charged ?? 0),
      total_paid: parseFloat(r.total_paid ?? 0),
      remaining_amount: parseFloat(r.remaining_amount ?? 0),
      photo_url: r.photo_url ?? null,
      graduation_year: r.graduation_year ?? null,
      batch_number: r.batch_number ?? null,
    }));
    return { data: parsed, count: count ?? 0 };
  });
}

// جلب تفاصيل طالب مؤرشف بالكامل (مع لقطات الإيصالات والمصاريف والملفات) عند النقر على بطاقته
export async function getArchivedStudentDetails(id: string): Promise<ArchivedStudentLean | null> {
  return withRetry(async () => {
    const { data, error } = await supabase
      .from('archived_students')
      .select('*')
      .eq('id', id)
      .single();
    if (error) throw error;
    if (!data) return null;
    return {
      ...data,
      total_charged: parseFloat(data.total_charged ?? 0),
      total_paid: parseFloat(data.total_paid ?? 0),
      remaining_amount: parseFloat(data.remaining_amount ?? 0),
      receipts_snapshot: Array.isArray(data.receipts_snapshot) ? data.receipts_snapshot : [],
      charges_snapshot: Array.isArray(data.charges_snapshot) ? data.charges_snapshot : [],
      files_snapshot: Array.isArray(data.files_snapshot) ? data.files_snapshot : [],
    };
  });
}

// مسح جميع سجلات الأرشيف
export async function clearArchive(): Promise<void> {
  const { error } = await supabase
    .from('archived_students')
    .delete()
    .not('id', 'is', null); // حذف الكل
  if (error) throw error;
}

// مسح كامل لبيانات النظام (مع إعادة تعيين العدادات) — لا يمسّ الأرشيف ولا الإعدادات الثابتة
export async function clearAllSystemData(): Promise<void> {
  // 1) حذف الملفات المرفقة
  const { error: e1 } = await supabase.from('student_files').delete().not('id', 'is', null);
  if (e1) throw e1;

  // 2) حذف الإشعارات
  const { error: e2 } = await supabase.from('notifications').delete().not('id', 'is', null);
  if (e2) throw e2;

  // 3) حذف الإيصالات (بما فيها المحذوفة ناعماً)
  const { error: e3 } = await supabase.from('receipts').delete().not('id', 'is', null);
  if (e3) throw e3;

  // 4) حذف رسوم الفصول
  const { error: e4 } = await supabase.from('semester_charges').delete().not('id', 'is', null);
  if (e4) throw e4;

  // 5) حذف جميع الطلاب
  const { error: e5 } = await supabase.from('students').delete().not('id', 'is', null);
  if (e5) throw e5;

  // 6) إعادة تعيين عدادات أوامر التوريد والإيصالات إلى صفر
  const counterKeys = [
    SETTINGS_KEYS.RECEIPT_COUNTER,
    SETTINGS_KEYS.RECEIPT_COUNTER_HIGH,
    SETTINGS_KEYS.RECEIPT_COUNTER_MID,
    SETTINGS_KEYS.SUPPLY_ORDER_COUNTER_HIGH,
    SETTINGS_KEYS.SUPPLY_ORDER_COUNTER_MID,
  ];
  await Promise.all(
    counterKeys.map(key => updateSetting(key, '0'))
  );
}
// ── تقرير التحصيل المالي: جميع رسوم الفصول مع بيانات الطالب ──
export type SemesterChargeRow = SemesterCharge & {
  diploma_type:       string;
  student_name:       string;
  student_status:     string;
  student_current_semester: number;
};

export async function getAllSemesterCharges(): Promise<SemesterChargeRow[]> {
  const CHUNK_SIZE = 1000;
  const { data: firstData, error: firstErr, count } = await supabase
    .from('semester_charges')
    .select('*, students(full_name, diploma_type, status, current_semester)', { count: 'exact' })
    .order('semester_number', { ascending: true })
    .range(0, CHUNK_SIZE - 1);
  if (firstErr) throw firstErr;

  const allCharges = [...(firstData ?? [])];
  const totalCount = count ?? allCharges.length;

  if (totalCount > CHUNK_SIZE) {
    const promises = [];
    for (let offset = CHUNK_SIZE; offset < totalCount; offset += CHUNK_SIZE) {
      const end = Math.min(offset + CHUNK_SIZE - 1, totalCount - 1);
      promises.push(
        supabase
          .from('semester_charges')
          .select('*, students(full_name, diploma_type, status, current_semester)')
          .order('semester_number', { ascending: true })
          .range(offset, end)
      );
    }
    const results = await Promise.all(promises);
    for (const res of results) {
      if (res.error) throw res.error;
      if (res.data) allCharges.push(...res.data);
    }
  }

  return (Array.isArray(allCharges) ? allCharges : []).map((c: any) => ({
    ...c,
    diploma_type:             c.students?.diploma_type      ?? '—',
    student_name:             c.students?.full_name         ?? '—',
    student_status:           c.students?.status            ?? '—',
    student_current_semester: c.students?.current_semester  ?? 1,
  }));
}

// تصفير رصيد الطالب بالكامل: حذف الأقساط والواصلات وإعادة الرصيد إلى صفر
// تصفير كامل: حذف الإيصالات والرسوم، إعادة الطالب للفصل الأول، وإنشاء رسوم جديدة كأنه لم يبدأ
export async function resetStudentBalance(studentId: string): Promise<void> {
  // جلب بيانات الطالب والإعدادات
  const [student, settings] = await Promise.all([
    getStudentById(studentId),
    getSettings(),
  ]);
  if (!student) throw new Error('الطالب غير موجود');

  // 1) حذف جميع الرسوم والإيصالات
  const { error: delChargesErr } = await supabase
    .from('semester_charges')
    .delete()
    .eq('student_id', studentId);
  if (delChargesErr) throw delChargesErr;

  const { error: delReceiptsErr } = await supabase
    .from('receipts')
    .delete()
    .eq('student_id', studentId);
  if (delReceiptsErr) throw delReceiptsErr;

  // 2) حساب الرسوم الجديدة للفصل الأول
  const regFeeKey = student.is_equivalency
    ? SETTINGS_KEYS.EQUIVALENCY_REGISTRATION_FEE
    : SETTINGS_KEYS.REGISTRATION_FEE;
  const semFeeKey = student.is_equivalency
    ? SETTINGS_KEYS.EQUIVALENCY_SEMESTER_FEE
    : (student.diploma_type === 'عالي' ? SETTINGS_KEYS.HIGH_DIPLOMA_FEE : SETTINGS_KEYS.MID_DIPLOMA_FEE);

  const regFee  = parseFloat(settings[regFeeKey]  ?? '100');
  const semFee  = parseFloat(settings[semFeeKey]  ?? (student.diploma_type === 'عالي' ? '600' : '550'));
  const totalNew = regFee + semFee;

  // 3) إعادة تعيين بيانات الطالب للبداية
  const { error: updateErr } = await supabase
    .from('students')
    .update({
      current_semester: 1,
      total_charged: totalNew,
      total_paid: 0,
      registration_fee_paid: false,
    })
    .eq('id', studentId);
  if (updateErr) throw updateErr;

  // 4) إنشاء رسوم التسجيل (semester_number = -1)
  await createSemesterCharge({
    student_id: studentId,
    semester_number: -1,
    charge_amount: regFee,
    paid_amount: 0,
    charge_type: 'تسجيل',
    is_cleared: false,
    is_locked: false,
  });

  // 5) إنشاء رسوم الفصل الأول
  await createSemesterCharge({
    student_id: studentId,
    semester_number: 1,
    charge_amount: semFee,
    paid_amount: 0,
    charge_type: 'فصلي',
    is_cleared: false,
    is_locked: false,
  });
}

// ─── واتساب: قوالب الرسائل ──────────────────────────────────────────────────

export interface WhatsappTemplate {
  id: string;
  name: string;
  body: string;
  category: string;
  created_at: string;
  updated_at: string;
}

export async function getWhatsappTemplates(): Promise<WhatsappTemplate[]> {
  const { data, error } = await supabase
    .from('whatsapp_templates')
    .select('*')
    .order('category')
    .order('name');
  if (error) throw error;
  return (data ?? []) as WhatsappTemplate[];
}

export async function createWhatsappTemplate(
  t: Omit<WhatsappTemplate, 'id' | 'created_at' | 'updated_at'>
): Promise<WhatsappTemplate> {
  const { data, error } = await supabase
    .from('whatsapp_templates')
    .insert(t)
    .select()
    .single();
  if (error) throw error;
  return data as WhatsappTemplate;
}

export async function updateWhatsappTemplate(
  id: string,
  t: Partial<Pick<WhatsappTemplate, 'name' | 'body' | 'category'>>
): Promise<void> {
  const { error } = await supabase
    .from('whatsapp_templates')
    .update(t)
    .eq('id', id);
  if (error) throw error;
}

export async function deleteWhatsappTemplate(id: string): Promise<void> {
  const { error } = await supabase
    .from('whatsapp_templates')
    .delete()
    .eq('id', id);
  if (error) throw error;
}

// ─── واتساب: سجل الرسائل ────────────────────────────────────────────────────

export interface WhatsappLog {
  id: string;
  student_id: string | null;
  student_name: string;
  phone: string;
  message: string;
  sent_at: string;
  status: string;
}

export async function getWhatsappLog(limit = 200): Promise<WhatsappLog[]> {
  const { data, error } = await supabase
    .from('whatsapp_log')
    .select('*')
    .order('sent_at', { ascending: false })
    .limit(limit);
  if (error) throw error;
  return (data ?? []) as WhatsappLog[];
}

export async function logWhatsappMessage(
  entry: Omit<WhatsappLog, 'id' | 'sent_at'>
): Promise<void> {
  const { error } = await supabase.from('whatsapp_log').insert(entry);
  if (error) throw error;
}

// ─── واتساب: جلب الطلاب مع فلاتر المديونية ─────────────────────────────────

export type DebtFilter = 'الكل' | 'مدين' | 'مسدد_جزئي' | 'مسدد_كامل';

export async function getStudentsForWhatsapp(params?: {
  diplomaType?: string;
  specialization?: string;
  debtFilter?: DebtFilter;
  search?: string;
}): Promise<Student[]> {
  const { data } = await getStudents({
    diplomaType: params?.diplomaType && params.diplomaType !== 'الكل' ? (params.diplomaType as DiplomaType) : undefined,
    specialization: params?.specialization && params.specialization !== 'الكل' ? params.specialization : undefined,
    search: params?.search,
    status: 'نشط',
    limit: 20000,
    fields: 'id,full_name,national_id,registration_number,diploma_type,specialization,current_semester,status,phone,guardian_phone,total_charged,total_paid',
  });
  let students = data;

  if (params?.debtFilter && params.debtFilter !== 'الكل') {
    students = students.filter((s) => {
      const debt = (s.total_charged ?? 0) - (s.total_paid ?? 0);
      if (params.debtFilter === 'مسدد_كامل') return debt <= 0;
      if (params.debtFilter === 'مسدد_جزئي') return s.total_paid > 0 && debt > 0;
      if (params.debtFilter === 'مدين')       return s.total_paid === 0 && debt > 0;
      return true;
    });
  }
  return students;
}

// =============================================
// إدارة وظائف وصلاحيات الأجهزة (Device Roles)
// =============================================
let _deviceRolesCache: { data: DeviceRole[]; timestamp: number } | null = null;
const DEVICE_ROLES_CACHE_TTL = 300000; // 5 دقائق

export function invalidateDeviceRolesCache(): void {
  _deviceRolesCache = null;
  if (typeof window !== 'undefined') {
    try { sessionStorage.removeItem('alqeema_device_roles_cache'); } catch {}
  }
}

export async function getDeviceRoles(forceRefresh = false): Promise<DeviceRole[]> {
  const now = Date.now();
  if (!forceRefresh && _deviceRolesCache && now - _deviceRolesCache.timestamp < DEVICE_ROLES_CACHE_TTL) {
    return _deviceRolesCache.data;
  }
  if (!forceRefresh && !_deviceRolesCache && typeof window !== 'undefined') {
    try {
      const stored = sessionStorage.getItem('alqeema_device_roles_cache');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed.data && now - parsed.time < DEVICE_ROLES_CACHE_TTL * 2) {
          _deviceRolesCache = { data: parsed.data, timestamp: parsed.time };
          return parsed.data;
        }
      }
    } catch {}
  }
  const { data, error } = await supabase
    .from('device_roles')
    .select('*')
    .order('is_system', { ascending: false })
    .order('created_at', { ascending: true });

  if (error) {
    console.error('Error fetching device roles:', error);
    throw error;
  }
  const res = (data as DeviceRole[]) || [];
  _deviceRolesCache = { data: res, timestamp: now };
  if (typeof window !== 'undefined') {
    try {
      sessionStorage.setItem('alqeema_device_roles_cache', JSON.stringify({ data: res, time: now }));
    } catch {}
  }
  return res;
}

export async function upsertDeviceRole(role: {
  id: string;
  name: string;
  description?: string | null;
  is_system?: boolean;
  is_active?: boolean;
  permissions: DeviceRolePermissions;
  passcode?: string | null;
}): Promise<DeviceRole> {
  const payload: any = {
    id: role.id,
    name: role.name,
    description: role.description ?? null,
    is_system: role.is_system ?? false,
    is_active: role.is_active ?? true,
    permissions: role.permissions,
    updated_at: new Date().toISOString(),
  };

  if (role.passcode !== undefined) {
    payload.passcode = role.passcode;
  }

  const { data, error } = await supabase
    .from('device_roles')
    .upsert(payload)
    .select()
    .single();

  if (error) {
    console.error('Error saving device role:', error);
    throw error;
  }
  return data as DeviceRole;
}

export async function deleteDeviceRole(roleId: string): Promise<void> {
  const { error } = await supabase
    .from('device_roles')
    .delete()
    .eq('id', roleId);

  if (error) {
    console.error('Error deleting device role:', error);
    throw error;
  }
}
