// مساعد طباعة استمارة تسجيل وقيد طالب معتمدة — معهد القمة للعلوم الطبية والإدارية
import type { Student } from '@/types/index';
import { SEMESTER_LABELS } from '@/types/index';

const LOGO_URL = 'https://miaoda-conversation-file.s3cdn.medo.dev/user-cim4m3x63pxc/app-f6avantw6h35/20261018/FB_IMG_1780949707596.jpg';

export interface PrintRegistrationData {
  student: {
    id?: string;
    full_name: string;
    national_id: string;
    nationality?: string | null;
    registration_number?: string | null;
    phone?: string | null;
    guardian_phone?: string | null;
    address?: string | null;
    diploma_type: string;
    specialization: string;
    current_semester?: number;
    enrollment_date?: string | null;
    is_equivalency?: boolean;
    equivalency_start_semester?: number | null;
    photos_required: number;
    photos_received: number;
    has_birth_certificate: boolean;
    has_registration_certificate: boolean;
    has_suspended_file: boolean;
    photo_url?: string | null;
    [key: string]: any;
  };
  financial?: {
    registrationFee?: number;
    semesterFee?: number;
    initialPayment?: number;
    receiptNumber?: string | null;
    discountAmount?: number;
    discountReason?: string | null;
  };
  photoPreviewUrl?: string | null;
}

function fmtArabicDate(iso?: string | null): string {
  if (!iso) {
    return new Date().toLocaleDateString('ar-LY', {
      weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
    });
  }
  return new Date(iso).toLocaleDateString('ar-LY', {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
  });
}

function fmtArabicTime(): string {
  return new Date().toLocaleTimeString('ar-LY', { hour: '2-digit', minute: '2-digit' });
}

export function printRegistrationForm(data: PrintRegistrationData) {
  const win = window.open('', '_blank', 'width=900,height=1150');
  if (!win) return;

  const { student, financial, photoPreviewUrl } = data;
  const regDate = fmtArabicDate(student.enrollment_date);
  const printTime = fmtArabicTime();
  const diplLabel = student.diploma_type === 'عالي' ? 'دبلوم عالٍ' : 'دبلوم متوسط';
  const semLabel = SEMESTER_LABELS[student.current_semester ?? 1] ?? `الفصل ${student.current_semester ?? 1}`;
  const studentPhoto = photoPreviewUrl || student.photo_url;
  const hasRegNumber = !!student.registration_number && student.registration_number.trim() !== '';

  const allDocsComplete =
    student.photos_received >= student.photos_required &&
    student.has_birth_certificate &&
    student.has_registration_certificate &&
    student.has_suspended_file;

  const html = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8"/>
<title>استمارة تسجيل طالب — ${student.full_name}</title>
<style>
  @page {
    size: A4 portrait;
    margin: 8mm 10mm 8mm 10mm;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    font-family: 'Tajawal', 'Segoe UI', Tahoma, Arial, sans-serif;
    background: #fff;
    color: #111827;
    font-size: 11.5px;
    line-height: 1.45;
    direction: rtl;
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
  }
  .page {
    width: 100%;
    max-width: 190mm;
    margin: 0 auto;
    padding: 2mm 0;
  }

  /* ── الترويسة الفاخرة ── */
  .hdr {
    background: linear-gradient(135deg, #0b1f3a 0%, #163660 60%, #1e4577 100%);
    border-radius: 12px;
    padding: 12px 16px;
    color: #fff;
    position: relative;
    overflow: hidden;
    border: 1.5px solid #d4af37;
    box-shadow: 0 3px 10px rgba(11,31,58,0.15);
    margin-bottom: 8px;
  }
  .hdr::before {
    content: '';
    position: absolute;
    top: -30px;
    right: -30px;
    width: 110px;
    height: 110px;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(212,175,55,0.25) 0%, transparent 70%);
    pointer-events: none;
  }
  .hdr-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
  }
  .logo-box {
    width: 68px;
    height: 68px;
    border-radius: 12px;
    background: #fff;
    padding: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 3px 8px rgba(0,0,0,0.25);
    border: 2px solid #d4af37;
    flex-shrink: 0;
  }
  .logo-box img {
    max-width: 100%;
    max-height: 100%;
    object-fit: contain;
  }
  .hdr-center {
    flex: 1;
    text-align: center;
  }
  .inst-name {
    font-size: 17px;
    font-weight: 900;
    color: #ffffff;
    letter-spacing: 0.3px;
    margin-bottom: 2px;
    text-shadow: 0 1px 3px rgba(0,0,0,0.4);
  }
  .inst-sub {
    font-size: 8.5px;
    color: rgba(220,235,255,0.85);
    font-weight: 500;
    margin-bottom: 4px;
    letter-spacing: 0.4px;
  }
  .form-badge {
    display: inline-block;
    background: linear-gradient(90deg, #d4af37, #f3e5ab, #d4af37);
    color: #0b1f3a;
    font-size: 11px;
    font-weight: 900;
    padding: 3px 16px;
    border-radius: 20px;
    box-shadow: 0 2px 6px rgba(0,0,0,0.2);
    border: 1px solid #fff;
  }
  .hdr-left {
    text-align: left;
    font-size: 9px;
    line-height: 1.5;
    color: rgba(230,240,255,0.95);
    background: rgba(255,255,255,0.08);
    padding: 6px 10px;
    border-radius: 8px;
    border: 1px solid rgba(255,255,255,0.15);
    flex-shrink: 0;
  }
  .hdr-left div { display: flex; align-items: center; gap: 4px; justify-content: flex-end; }
  .hdr-left .gold-txt { color: #f3e5ab; font-weight: 700; }

  /* ── شريط المعلومات السريعة والصورة ── */
  .meta-bar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    padding: 6px 12px;
    margin-bottom: 8px;
    font-size: 10px;
  }
  .meta-item { display: flex; align-items: center; gap: 5px; }
  .meta-lbl { color: #64748b; font-weight: 600; }
  .meta-val { color: #0f172a; font-weight: 800; }

  /* ── أقسام الاستمارة ── */
  .section {
    background: #fff;
    border: 1.2px solid #e2e8f0;
    border-radius: 9px;
    margin-bottom: 7px;
    overflow: hidden;
  }
  .sec-hdr {
    background: linear-gradient(90deg, #f1f5f9 0%, #e2e8f0 100%);
    border-bottom: 1.2px solid #cbd5e1;
    padding: 5px 12px;
    font-size: 11px;
    font-weight: 800;
    color: #0f2744;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .sec-hdr .dot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: #d4af37;
    display: inline-block;
    margin-left: 6px;
  }
  .sec-body {
    padding: 8px 12px;
  }

  /* ── شبكة الحقول ── */
  .grid-3 {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 7px 12px;
  }
  .grid-4 {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 7px 10px;
  }
  .grid-2 {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 7px 12px;
  }
  .field-box {
    display: flex;
    flex-direction: column;
    gap: 2px;
  }
  .f-lbl {
    font-size: 9px;
    color: #64748b;
    font-weight: 700;
  }
  .f-val {
    font-size: 11px;
    color: #0f172a;
    font-weight: 800;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 5px;
    padding: 4px 8px;
    min-height: 24px;
    display: flex;
    align-items: center;
  }
  .f-val.highlight {
    background: #f0fdf4;
    border-color: #86efac;
    color: #166534;
  }
  .f-val.gold {
    background: #fffbeb;
    border-color: #fde68a;
    color: #92400e;
  }

  /* ── كروت المستندات ── */
  .docs-row {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 8px;
  }
  .doc-badge {
    border-radius: 6px;
    padding: 6px 8px;
    text-align: center;
    border: 1px solid #cbd5e1;
    background: #f8fafc;
  }
  .doc-badge.ok {
    background: #ecfdf5;
    border-color: #a7f3d0;
    color: #065f46;
  }
  .doc-badge.missing {
    background: #fef2f2;
    border-color: #fecaca;
    color: #991b1b;
  }
  .doc-title { font-size: 9.5px; font-weight: 800; margin-bottom: 2px; }
  .doc-status { font-size: 8.5px; font-weight: 700; }

  /* ── الأختام والتوقيعات الثلاثة المطلوبة بالنص ── */
  .stamps-section {
    border: 1.5px solid #0f2744;
    border-radius: 10px;
    background: #fff;
    padding: 10px 12px;
    margin-top: 4px;
    margin-bottom: 8px;
    page-break-inside: avoid;
  }
  .stamps-title {
    text-align: center;
    font-size: 11.5px;
    font-weight: 900;
    color: #0f2744;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
  }
  .stamps-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 10px;
  }
  .stamp-card {
    border: 1.2px solid #cbd5e1;
    border-radius: 8px;
    background: #fafbfc;
    padding: 10px;
    text-align: center;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    min-height: 110px;
    position: relative;
  }
  .stamp-hdr {
    font-size: 11px;
    font-weight: 900;
    color: #0b1f3a;
    padding-bottom: 5px;
    border-bottom: 1px dashed #cbd5e1;
  }
  .stamp-role {
    font-size: 8.5px;
    color: #64748b;
    font-weight: 600;
    margin-top: 2px;
  }
  .stamp-box {
    width: 68px;
    height: 68px;
    border: 1.5px dashed #94a3b8;
    border-radius: 50%;
    margin: 8px auto;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #94a3b8;
    font-size: 8.5px;
    font-weight: 700;
    background: rgba(255,255,255,0.7);
  }
  .stamp-lines {
    font-size: 8.5px;
    color: #475569;
    text-align: right;
    line-height: 1.5;
    margin-top: auto;
  }

  /* ── التذييل الرسمي ── */
  .footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-top: 1.2px solid #e2e8f0;
    padding-top: 6px;
    font-size: 8.5px;
    color: #64748b;
  }
  .ft-contacts { display: flex; align-items: center; gap: 12px; }
  .ft-item { display: flex; align-items: center; gap: 3px; }

  @media print {
    body { background: #fff; }
    .page { max-width: 100%; }
  }
</style>
</head>
<body>
<div class="page">

  <!-- ── الترويسة ── -->
  <div class="hdr">
    <div class="hdr-row">
      <!-- الشعار -->
      <div class="logo-box">
        <img src="${LOGO_URL}" alt="شعار المعهد" />
      </div>

      <!-- المركز: الاسم والاستمارة -->
      <div class="hdr-center">
        <div class="inst-name">معهد القمة للعلوم الطبية والإدارية</div>
        <div class="inst-sub">Al-Qimma Institute for Medical & Administrative Sciences</div>
        <div class="form-badge">✦ استمارة تسجيل وقيد طالب معتمدة ✦</div>
      </div>

      <!-- اليسار: بيانات التواصل المعتمدة الرسمية -->
      <div class="hdr-left">
        <div><span class="gold-txt">المقر:</span> سوق السبت – ليبيا 📍</div>
        <div><span class="gold-txt">الهاتف:</span> 0925040851 📞</div>
        <div><span class="gold-txt">البريد:</span> alkema2024@gmail.com ✉</div>
        <div><span class="gold-txt">الموقع:</span> www.alkima.edu.ly 🌐</div>
      </div>
    </div>
  </div>

  <!-- ── شريط الميتاداتا السريع ── -->
  <div class="meta-bar">
    <div class="meta-item">
      <span class="meta-lbl">تاريخ التسجيل:</span>
      <span class="meta-val">${regDate}</span>
    </div>
    <div class="meta-item">
      <span class="meta-lbl">وقت الإصدار:</span>
      <span class="meta-val">${printTime}</span>
    </div>
    <div class="meta-item">
      <span class="meta-lbl">نظام الدراسة:</span>
      <span class="meta-val">${student.is_equivalency ? 'نظام معادلة فصول' : 'نظامي مستجد'}</span>
    </div>
    <div class="meta-item">
      <span class="meta-lbl">حالة الملف:</span>
      <span class="meta-val" style="color:${allDocsComplete ? '#166534' : '#b91c1c'}">
        ${allDocsComplete ? '✓ مستوفي الشروط' : '⚠ توجد نواقص'}
      </span>
    </div>
  </div>

  <!-- ── القسم الأول: البيانات الشخصية والاتصال ── -->
  <div class="section">
    <div class="sec-hdr">
      <div><span class="dot"></span>البيانات الشخصية وبيانات الاتصال</div>
      <span style="font-size:9px;color:#64748b;">الرقم الوطني: ${student.national_id}</span>
    </div>
    <div class="sec-body">
      <div class="grid-3">
        <div class="field-box" style="grid-column: span 2;">
          <span class="f-lbl">الاسم الرباعي للطالب</span>
          <div class="f-val highlight" style="font-size:12px;">${student.full_name}</div>
        </div>
        <div class="field-box">
          <span class="f-lbl">الرقم الوطني</span>
          <div class="f-val" style="direction:ltr;justify-content:flex-end;">${student.national_id}</div>
        </div>
        <div class="field-box">
          <span class="f-lbl">الجنسية</span>
          <div class="f-val highlight">${student.nationality || 'ليبي'}</div>
        </div>
        <div class="field-box">
          <span class="f-lbl">رقم قيد الطالب</span>
          <div class="f-val ${hasRegNumber ? 'gold' : ''}" style="direction:ltr;justify-content:flex-end;font-weight:900;">
            ${hasRegNumber ? student.registration_number : 'قيد التعيين لدى المسجل'}
          </div>
        </div>
        <div class="field-box">
          <span class="f-lbl">رقم هاتف الطالب</span>
          <div class="f-val" style="direction:ltr;justify-content:flex-end;">${student.phone || '—'}</div>
        </div>
        <div class="field-box">
          <span class="f-lbl">هاتف ولي الأمر / الطوارئ</span>
          <div class="f-val" style="direction:ltr;justify-content:flex-end;">${student.guardian_phone || '—'}</div>
        </div>
        <div class="field-box" style="grid-column: span 3;">
          <span class="f-lbl">العنوان ومحل الإقامة الحالي</span>
          <div class="f-val">${student.address || 'سوق السبت – ليبيا'}</div>
        </div>
      </div>
    </div>
  </div>

  <!-- ── القسم الثاني: البيانات الأكاديمية ── -->
  <div class="section">
    <div class="sec-hdr">
      <div><span class="dot"></span>البيانات الأكاديمية والقيد</div>
      <span style="font-size:9px;color:#64748b;">${diplLabel}</span>
    </div>
    <div class="sec-body">
      <div class="grid-3">
        <div class="field-box">
          <span class="f-lbl">نوع الدبلوم</span>
          <div class="f-val highlight">${diplLabel}</div>
        </div>
        <div class="field-box" style="grid-column: span 2;">
          <span class="f-lbl">التخصص المقيد به</span>
          <div class="f-val highlight" style="font-size:11.5px;">${student.specialization}</div>
        </div>
        <div class="field-box">
          <span class="f-lbl">الفصل الدراسي المقيد به</span>
          <div class="f-val gold">${semLabel}</div>
        </div>
        <div class="field-box">
          <span class="f-lbl">نظام المعادلة</span>
          <div class="f-val">
            ${student.is_equivalency ? `معادلة (${student.equivalency_start_semester ?? 0}) فصول سابقة` : 'لا يوجد (تسجيل نظامي)'}
          </div>
        </div>
        <div class="field-box">
          <span class="f-lbl">سنة / تاريخ القيد</span>
          <div class="f-val">${regDate}</div>
        </div>
      </div>
    </div>
  </div>

  <!-- ── القسم الثالث: موقف الأوراق الثبوتية والمستندات ── -->
  <div class="section">
    <div class="sec-hdr">
      <div><span class="dot"></span>موقف الأوراق الثبوتية والمستندات المسلمة</div>
      <span style="font-size:9px;color:#64748b;">المطلوب: 4 متطلبات رسمية</span>
    </div>
    <div class="sec-body">
      <div class="docs-row">
        <!-- الصور الشخصية -->
        <div class="doc-badge ${student.photos_received >= student.photos_required ? 'ok' : 'missing'}">
          <div class="doc-title">الصور الشخصية</div>
          <div class="doc-status">${student.photos_received} من ${student.photos_required} صور مسلمة</div>
        </div>
        <!-- شهادة الميلاد -->
        <div class="doc-badge ${student.has_birth_certificate ? 'ok' : 'missing'}">
          <div class="doc-title">شهادة الميلاد</div>
          <div class="doc-status">${student.has_birth_certificate ? '✓ تم الاستلام' : '✕ غير مستلمة'}</div>
        </div>
        <!-- شهادة التسجيل / المؤهل -->
        <div class="doc-badge ${student.has_registration_certificate ? 'ok' : 'missing'}">
          <div class="doc-title">شهادة التسجيل / المؤهل</div>
          <div class="doc-status">${student.has_registration_certificate ? '✓ تم الاستلام' : '✕ غير مستلمة'}</div>
        </div>
        <!-- الملف المعلق -->
        <div class="doc-badge ${student.has_suspended_file ? 'ok' : 'missing'}">
          <div class="doc-title">الملف المعلق</div>
          <div class="doc-status">${student.has_suspended_file ? '✓ تم الاستلام' : '✕ غير مستلم'}</div>
        </div>
      </div>
    </div>
  </div>

  ${financial ? `
  <!-- ── القسم الرابع: البيانات المالية الأولية ── -->
  <div class="section">
    <div class="sec-hdr">
      <div><span class="dot"></span>بيانات الرسوم المالية الأولية وإيصال القبض</div>
      <span style="font-size:9px;color:#64748b;">قسم المالية</span>
    </div>
    <div class="sec-body">
      <div class="grid-4">
        <div class="field-box">
          <span class="f-lbl">رسوم التسجيل</span>
          <div class="f-val">${financial.registrationFee ?? 100} د.ل</div>
        </div>
        <div class="field-box">
          <span class="f-lbl">الرسوم الدراسية</span>
          <div class="f-val">${financial.semesterFee ?? 0} د.ل</div>
        </div>
        <div class="field-box">
          <span class="f-lbl">المدفوع نقداً عند القيد</span>
          <div class="f-val ${(financial.initialPayment ?? 0) > 0 ? 'highlight' : ''}" style="font-weight:900;">
            ${(financial.initialPayment ?? 0) > 0 ? `${financial.initialPayment} د.ل` : '0 د.ل (غير مسدد)'}
          </div>
        </div>
        <div class="field-box">
          <span class="f-lbl">رقم إيصال القبض المالي</span>
          <div class="f-val ${(financial.initialPayment ?? 0) > 0 && financial.receiptNumber ? 'gold' : ''}" style="direction:ltr;justify-content:flex-end;">
            ${(financial.initialPayment ?? 0) > 0 && financial.receiptNumber ? '#' + financial.receiptNumber : '— (معلق حتى السداد)'}
          </div>
        </div>
      </div>
    </div>
  </div>` : ''}

  <!-- ── الأختام والتوقيعات الثلاثة المطلوبة بالنص ── -->
  <div class="stamps-section">
    <div class="stamps-title">
      <span>✦ الاعتمادات والأختام الرسمية المعتمدة للمعهد ✦</span>
    </div>
    <div class="stamps-grid">
      <!-- 1. ختم وتوقيع المسجل العام -->
      <div class="stamp-card">
        <div class="stamp-hdr">ختم وتوقيع المسجل العام</div>
        <div class="stamp-role">قسم القبول والتسجيل وشؤون الطلاب</div>
        <div class="stamp-box">ختم المسجل العام</div>
        <div class="stamp-lines">
          <div>الاسم: .......................................</div>
          <div>التوقيع: ....................................</div>
          <div>التاريخ: ...... / ...... / 202... م</div>
        </div>
      </div>

      <!-- 2. ختم وتوقيع الشؤون الإدارية والمالية -->
      <div class="stamp-card">
        <div class="stamp-hdr">ختم وتوقيع الشؤون الإدارية والمالية</div>
        <div class="stamp-role">إدارة الشؤون المالية والحسابات</div>
        <div class="stamp-box">ختم الشؤون المالية</div>
        <div class="stamp-lines">
          <div>الاسم: .......................................</div>
          <div>التوقيع: ....................................</div>
          <div>التاريخ: ...... / ...... / 202... م</div>
        </div>
      </div>

      <!-- 3. ختم وتوقيع شؤون الدراسة والامتحانات -->
      <div class="stamp-card">
        <div class="stamp-hdr">ختم وتوقيع شؤون الدراسة والامتحانات</div>
        <div class="stamp-role">قسم الدراسة والامتحانات والجداول</div>
        <div class="stamp-box">ختم الامتحانات</div>
        <div class="stamp-lines">
          <div>الاسم: .......................................</div>
          <div>التوقيع: ....................................</div>
          <div>التاريخ: ...... / ...... / 202... م</div>
        </div>
      </div>
    </div>
  </div>

  <!-- ── التذييل الرسمي ── -->
  <div class="footer">
    <div class="ft-contacts">
      <div class="ft-item">📍 سوق السبت – ليبيا</div>
      <div class="ft-item">📞 0925040851</div>
      <div class="ft-item">✉ alkema2024@gmail.com</div>
      <div class="ft-item">🌐 http://www.alkima.edu.ly</div>
    </div>
    <div>وثيقة رسمية معتمدة صادرة آلياً من منظومة معهد القمة</div>
  </div>

</div>
<script>
  window.onload = function() {
    setTimeout(function() {
      window.print();
    }, 450);
  };
</script>
</body>
</html>`;

  win.document.write(html);
  win.document.close();
}
