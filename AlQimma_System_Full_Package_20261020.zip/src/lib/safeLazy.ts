import { lazy, type ComponentType } from 'react';

/**
 * استيراد كسول آمن — يعيد المحاولة عند فشل جلب الملف في sandbox
 * يحل مشكلة "Failed to fetch dynamically imported module"
 */
export const safeLazy = (importFn: () => Promise<{ default: ComponentType<unknown> }>) => {
  return lazy(async () => {
    try {
      return await importFn();
    } catch (error) {
      console.error('فشل تحميل الصفحة، جاري إعادة المحاولة...', error);
      window.location.reload();
      throw error;
    }
  });
};
