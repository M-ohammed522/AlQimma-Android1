export interface Option {
  label: string;
  value: string;
  icon?: React.ComponentType<{ className?: string }>;
  withCount?: boolean;
}

// =============================================
// منظومة معهد القمة - أنواع البيانات
// =============================================

export type DiplomaType = 'عالي' | 'متوسط';
export type StudentStatus = 'نشط' | 'موقوف قيد' | 'خريج';
export type PaymentType = 'تسجيل' | 'معادلة' | 'قسط فصلي' | 'مشروع تخرج' | 'ديون سابقة' | 'تخفيض';
export type NotificationType =
  | 'نواقص_ملف'
  | 'ديون_معلقة'
  | 'مشروع_تخرج'
  | 'أرشفة'
  | 'تسجيل'
  | 'إيقاف'
  | 'تفعيل'
  | 'ترحيل'
  | 'دفع';
export type ChargeType = 'فصلي' | 'معادلة' | 'مشروع تخرج' | 'تسجيل';

export interface SystemSetting {
  id: number;
  key: string;
  value: string;
  updated_at: string;
}

export interface Specialization {
  id: number;
  name: string;
  diploma_type: DiplomaType;
  is_active: boolean;
  created_at: string;
}

export interface Student {
  id: string;
  full_name: string;
  national_id: string;
  phone: string | null;
  guardian_phone: string | null;
  address: string | null;
  gender: string | null;
  diploma_type: DiplomaType;
  specialization: string;
  current_semester: number;
  status: StudentStatus;
  enrollment_date: string | null;
  is_equivalency: boolean;
  equivalency_start_semester: number | null;
  equivalency_equivalent_semesters: number[] | null;
  photos_required: number;
  photos_received: number;
  has_birth_certificate: boolean;
  has_registration_certificate: boolean;
  has_suspended_file: boolean;
  registration_fee_paid: boolean;
  photo_url: string | null;
  nationality?: string | null;
  registration_number?: string | null;
  project_name: string | null;
  project_summary: string | null;
  project_supervisor: string | null;
  total_charged: number;
  total_paid: number;
  notes: string | null;
  is_exam_only: boolean;
  default_semester_discount?: number;
  default_semester_discount_reason?: string | null;
  verify_token?: string;
  /** وقت اكتمال سداد رسوم الفصل الأخير — يُضبط تلقائياً بـ trigger */
  final_paid_at?: string | null;
  /** هل أُرسل إشعار "جاهز للأرشفة" لهذا الطالب؟ */
  archive_notified?: boolean;
  created_at: string;
  updated_at: string;
}

export interface Receipt {
  id: string;
  student_id: string;
  receipt_number: string;
  supply_order_number: string | null;
  amount: number;
  payment_type: PaymentType;
  semester_target: string | null;
  notes: string | null;
  paid_at: string;
  payment_method?: string | null;
  created_at: string;
}

export interface SemesterCharge {
  id: string;
  student_id: string;
  semester_number: number;
  charge_amount: number;
  paid_amount: number;
  remaining_amount: number;
  charge_type: ChargeType;
  is_cleared: boolean;
  is_locked: boolean;
  discount_amount?: number;
  discount_reason?: string | null;
  created_at: string;
  updated_at: string;
}

export interface Notification {
  id: string;
  type: NotificationType;
  student_id: string;
  message: string;
  is_read: boolean;
  created_at: string;
  student?: Pick<Student, 'id' | 'full_name' | 'national_id'>;
}

export interface StudentFile {
  id: string;
  student_id: string;
  file_url: string;
  file_name: string;
  file_type: string;
  label: string | null;
  created_at: string;
}

// ثوابت النظام
export const SETTINGS_KEYS = {
  HIGH_DIPLOMA_FEE: 'high_diploma_fee',
  MID_DIPLOMA_FEE: 'mid_diploma_fee',
  REGISTRATION_FEE: 'registration_fee',
  EQUIVALENCY_REGISTRATION_FEE: 'equivalency_registration_fee',
  EQUIVALENCY_SEMESTER_FEE: 'equivalency_semester_fee',
  GRADUATION_PROJECT_FEE: 'graduation_project_fee',
  REQUIRED_PHOTOS_COUNT: 'required_photos_count',
  RECEIPT_COUNTER: 'receipt_counter',
  RECEIPT_COUNTER_HIGH: 'receipt_counter_high',
  RECEIPT_COUNTER_MID: 'receipt_counter_mid',
  RECEIPT_PREFIX: 'receipt_prefix',
  SUPPLY_ORDER_COUNTER_HIGH: 'supply_order_counter_high',
  SUPPLY_ORDER_COUNTER_MID: 'supply_order_counter_mid',
  // عداد الإفادات التسلسلي
  LETTER_SEQ: 'letter_seq',
  // إعدادات البريد الإلكتروني (Gmail App Password)
  EMAIL_ENABLED:   'email_enabled',
  EMAIL_TO:        'email_to',
  EMAIL_FROM:      'email_from',
  EMAIL_PASSWORD:  'email_password',
} as const;

export const DEFAULT_NATIONALITY = 'ليبي';

export const ARAB_NATIONALITIES = [
  { value: 'ليبي', label: 'ليبي (ليبيا) 🇱🇾', flag: '🇱🇾' },
  { value: 'مصري', label: 'مصري (مصر) 🇪🇬', flag: '🇪🇬' },
  { value: 'تونسي', label: 'تونسي (تونس) 🇹🇳', flag: '🇹🇳' },
  { value: 'جزائري', label: 'جزائري (الجزائر) 🇩🇿', flag: '🇩🇿' },
  { value: 'مغربي', label: 'مغربي (المغرب) 🇲🇦', flag: '🇲🇦' },
  { value: 'سوداني', label: 'سوداني (السودان) 🇸🇩', flag: '🇸🇩' },
  { value: 'فلسطيني', label: 'فلسطيني (فلسطين) 🇵🇸', flag: '🇵🇸' },
  { value: 'سوري', label: 'سوري (سوريا) 🇸🇾', flag: '🇸🇾' },
  { value: 'أردني', label: 'أردني (الأردن) 🇯🇴', flag: '🇯🇴' },
  { value: 'لبناني', label: 'لبناني (لبنان) 🇱🇧', flag: '🇱🇧' },
  { value: 'عراقي', label: 'عراقي (العراق) 🇮🇶', flag: '🇮🇶' },
  { value: 'يمني', label: 'يمني (اليمن) 🇾🇪', flag: '🇾🇪' },
  { value: 'موريتاني', label: 'موريتاني (موريتانيا) 🇲🇷', flag: '🇲🇷' },
  { value: 'صومالي', label: 'صومالي (الصومال) 🇸🇴', flag: '🇸🇴' },
  { value: 'جيبوتي', label: 'جيبوتي (جيبوتي) 🇩🇯', flag: '🇩🇯' },
  { value: 'قمري', label: 'قمري (جزر القمر) 🇰🇲', flag: '🇰🇲' },
  { value: 'سعودي', label: 'سعودي (السعودية) 🇸🇦', flag: '🇸🇦' },
  { value: 'إماراتي', label: 'إماراتي (الإمارات) 🇦🇪', flag: '🇦🇪' },
  { value: 'كويتي', label: 'كويتي (الكويت) 🇰🇼', flag: '🇰🇼' },
  { value: 'قطري', label: 'قطري (قطر) 🇶🇦', flag: '🇶🇦' },
  { value: 'بحريني', label: 'بحريني (البحرين) 🇧🇭', flag: '🇧🇭' },
  { value: 'عماني', label: 'عماني (عمان) 🇴🇲', flag: '🇴🇲' },
  { value: 'أخرى', label: 'جنسية أخرى 🌍', flag: '🌍' },
];

export const SYSTEM_PASSWORD = '5224410';

export const SEMESTER_LABELS: Record<number, string> = {
  1: 'الفصل الأول',
  2: 'الفصل الثاني',
  3: 'الفصل الثالث',
  4: 'الفصل الرابع',
  5: 'الفصل الخامس',
  6: 'الفصل السادس',
};

// تخصصات ثابتة لكل نوع دبلوم
export const SPECIALIZATIONS_BY_DIPLOMA: Record<string, string[]> = {
  'عالي':   ['إدارة أعمال', 'محاسبة', 'حاسوب', 'صيدلة', 'تمريض', 'مختبرات', 'أشعة', 'تخدير وعناية فائقة', 'علاج طبيعي'],
  'متوسط': ['إدارة أعمال', 'محاسبة', 'حاسوب', 'تمريض'],
};

// ─── إدارة وظائف وصلاحيات الأجهزة ──────────────────────────────
export interface DeviceModulePermissions {
  view: boolean;
  add?: boolean;
  edit?: boolean;
  delete?: boolean;
  export?: boolean;
  print?: boolean;
  [key: string]: boolean | undefined;
}

export interface DeviceRolePermissions {
  pages: {
    dashboard: { view: boolean };
    students: { view: boolean; add?: boolean; edit?: boolean; delete?: boolean; export?: boolean; print?: boolean };
    student_profile: { view: boolean; edit?: boolean; delete?: boolean; manage_reg_num?: boolean; print?: boolean };
    student_finance: { view: boolean; add_payment?: boolean; delete_payment?: boolean; print_receipt?: boolean; edit_fees?: boolean };
    registration: { view: boolean; register_student?: boolean; initial_payment?: boolean };
    archive: { view: boolean; restore?: boolean; print?: boolean; export?: boolean };
    graduation_projects: { view: boolean; edit?: boolean; print?: boolean; export?: boolean };
    specialization_report: { view: boolean; print?: boolean; export?: boolean };
    financial_report: { view: boolean; print?: boolean; export?: boolean };
    diploma_registry: { view: boolean; print?: boolean; export?: boolean };
    receipts: { view: boolean; print?: boolean; delete?: boolean };
    supply_orders: { view: boolean; add?: boolean; edit?: boolean; delete?: boolean };
    whatsapp: { view: boolean; send?: boolean };
    system_settings: { view: boolean; edit_settings?: boolean; manage_roles?: boolean; reset_device?: boolean };
    [key: string]: Record<string, boolean | undefined>;
  };
}

export interface DeviceRole {
  id: string;
  name: string;
  description: string | null;
  is_system: boolean;
  is_active: boolean;
  permissions: DeviceRolePermissions;
  passcode?: string | null;
  created_at?: string;
  updated_at?: string;
}
