// نقطة دخول المنظومة — v3.0
import { createRoot } from 'react-dom/client';
import { ThemeProvider } from 'next-themes';
import { AppWrapper } from './components/common/PageMeta';
import { AuthProvider } from './contexts/AuthContext';
import App from './App';
import './index.css';

const container = document.getElementById('root');
if (!container) {
  document.body.innerHTML =
    '<div style="padding:40px;font-family:Cairo,sans-serif;direction:rtl;color:#c00">خطأ: عنصر #root غير موجود</div>';
} else {
  createRoot(container).render(
    <ThemeProvider attribute="class" defaultTheme="light" enableSystem={false} forcedTheme="light">
      <AppWrapper>
        <AuthProvider>
          <App />
        </AuthProvider>
      </AppWrapper>
    </ThemeProvider>
  );
}
