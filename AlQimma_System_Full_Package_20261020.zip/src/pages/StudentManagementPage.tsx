// صفحة إدارة الطلاب الشاملة - منظومة معهد القمة
import React, { useEffect, useState, useCallback, useMemo, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Users, Search, Eye, Edit, PauseCircle, PlayCircle,
  Trash2, ChevronUp, ChevronRight, AlertTriangle, CheckCircle2,
  FileWarning, DollarSign, UserCheck, UserX, Phone, MapPin, User, Globe,
  RefreshCw, X, ChevronDown, GraduationCap, BookOpen,
  CreditCard, Banknote, Star, FileSpreadsheet, FileText, Printer, FileDown, AlertCircle,
} from 'lucide-react';
import { toast } from 'sonner';
import { printTable, exportPDF, exportExcel, exportWord } from '@/lib/printUtils';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Label } from '@/components/ui/label';
import {
  getStudents, getStudentStats, getSpecializations, suspendStudent, activateStudent,
  deleteStudent, promoteStudent, getSettings, MAX_SEMESTERS,
} from '@/lib/api';
import type { StudentStats } from '@/lib/api';
import type { Student, Specialization } from '@/types/index';
import { SEMESTER_LABELS, SYSTEM_PASSWORD } from '@/types/index';
import { StudentAvatar } from '@/components/ui/StudentAvatar';
import { RefreshButton } from '@/components/ui/RefreshButton';
import { useDeviceRole } from '@/contexts/DeviceRoleContext';

const DISPLAY_PAGE_SIZE = 40; // عدد العناصر المعروضة في كل صفحة محلية

type QuickFilter = 'all' | 'active' | 'suspended' | 'has_debt' | 'missing_docs' | 'complete';

interface Filters {
  search: string;
  diplomaType: string;
  specialization: string;
  semester: string;
  quickFilter: QuickFilter;
}

const initialFilters: Filters = {
  search: '',
  diplomaType: 'all',
  specialization: 'all',
  semester: 'all',
  quickFilter: 'all',
};

// ── مساعدات ──
function InfoRow({ icon: Icon, label, value, mono, valueClass }: {
  icon: React.ComponentType<{ className?: string }>;
  label: string; value: string;
  mono?: boolean; valueClass?: string;
}) {
  return (
    <div className="flex items-center justify-between gap-2">
      <div className="flex items-center gap-1.5 shrink-0">
        <Icon className="w-3 h-3 text-muted-foreground" />
        <span className="text-[11px] text-muted-foreground">{label}</span>
      </div>
      <span className={`text-[11px] font-semibold text-right break-all ${mono ? 'font-mono' : ''} ${valueClass ?? 'text-foreground'}`}>{value}</span>
    </div>
  );
}

function DocRow({ label, ok }: { label: string; ok: boolean }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span className="text-[11px] text-muted-foreground">{label}</span>
      {ok
        ? <span className="text-[10px] font-bold text-chart-2 bg-chart-2/10 px-1.5 py-0.5 rounded">✓ موجود</span>
        : <span className="text-[10px] font-bold text-destructive bg-destructive/10 px-1.5 py-0.5 rounded">✗ ناقص</span>
      }
    </div>
  );
}

// ── مكوّن صف الطالب (Accordion) - مُحسَّن بـ React.memo ──
const StudentAccordionRow = React.memo(function StudentAccordionRow({
  student, index, onNavigate, onSuspend, onActivate, onPromote, onDelete, actionLoading,
}: {
  student: Student;
  index: number;
  onNavigate: (id: string, edit?: boolean) => void;
  onSuspend: (s: Student) => void;
  onActivate: (s: Student) => void;
  onPromote: (s: Student) => void;
  onDelete: (s: Student) => void;
  actionLoading: boolean;
}) {
  const [expanded, setExpanded] = useState(false);
  const { can } = useDeviceRole();
  const debt = student.total_charged - student.total_paid;
  const hasMissingDocs = !student.has_birth_certificate || !student.has_registration_certificate || student.photos_received < student.photos_required;
  const isComplete = debt <= 0 && !hasMissingDocs && student.status === 'نشط';

  const missingList = useMemo(() => [
    !student.has_birth_certificate && 'شهادة الميلاد',
    !student.has_registration_certificate && 'شهادة التسجيل',
    student.photos_received < student.photos_required && `الصور (${student.photos_received}/${student.photos_required})`,
  ].filter(Boolean) as string[], [student]);

  return (
    <div className={`border rounded-xl overflow-hidden transition-all duration-200 ${
      expanded
        ? 'border-primary/40 shadow-md ring-1 ring-primary/15'
        : 'border-primary/15 hover:border-primary/35 hover:shadow-sm'
    }`}>
      {/* ── رأس الكرت ── */}
      <button
        className={`w-full text-right flex items-stretch gap-0 transition-colors duration-100 ${
          expanded
            ? 'bg-gradient-to-l from-primary/18 via-primary/12 to-primary/8 border-b border-primary/20'
            : 'bg-gradient-to-l from-primary/10 via-primary/6 to-primary/3 hover:from-primary/15 hover:via-primary/10 hover:to-primary/5'
        }`}
        onClick={() => setExpanded(v => !v)}
      >
        {/* ── العمود الأيسر: شارة + صورة + سهم ── */}
        <div className="flex flex-col items-center justify-between gap-2 px-2.5 py-2.5 shrink-0 border-l border-border/20">
          {/* شارة الحالة — أقصى اليسار أعلى */}
          <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full border whitespace-nowrap ${
            student.status === 'نشط'
              ? 'bg-chart-2/15 text-chart-2 border-chart-2/30'
              : 'bg-orange-500/15 text-orange-500 border-orange-500/30'
          }`}>
            <span className={`w-1.5 h-1.5 rounded-full ${student.status === 'نشط' ? 'bg-chart-2 animate-pulse' : 'bg-orange-500'}`} />
            {student.status === 'نشط' ? 'نشط' : 'موقوف قيد'}
          </span>

          {/* الصورة — في المنتصف */}
          <StudentAvatar
            photoUrl={student.photo_url}
            name={student.full_name}
            size="lg"
            variant="square"
          />

          {/* سهم الفتح/الإغلاق — أسفل اليسار */}
          <div className={`w-7 h-7 rounded-full flex items-center justify-center transition-all duration-200 ${
            expanded
              ? 'bg-primary text-primary-foreground shadow-sm'
              : 'bg-muted text-muted-foreground hover:bg-primary/15 hover:text-primary'
          }`}>
            <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${expanded ? 'rotate-180' : ''}`} />
          </div>
        </div>

        {/* ── العمود الأيمن: معلومات الطالب ── */}
        <div className="flex-1 min-w-0 text-right px-3 py-2.5">
          {/* الاسم كاملاً */}
          <div className="flex items-start justify-end gap-1.5">
            {isComplete && <Star className="w-3 h-3 text-purple-500 shrink-0 mt-0.5" />}
            <p className="text-[14px] font-bold text-foreground leading-snug">{student.full_name}</p>
          </div>

          {/* رقم وطني */}
          <div className="flex items-center justify-end gap-1 mt-1">
            <span className="text-[11px] font-mono text-muted-foreground/65 tracking-wide">{student.national_id}</span>
            <span className="text-muted-foreground/40 font-bold text-xs">#</span>
          </div>

          {/* الدبلوم — التخصص | الفصل */}
          <div className="flex items-center justify-end gap-2 mt-1.5 flex-wrap">
            <div className="flex items-center gap-1">
              <span className="text-[11px] text-foreground/70">{student.specialization}</span>
              <span className="text-muted-foreground/35 text-[10px]">—</span>
              <span className={`text-[11px] font-bold ${student.diploma_type === 'عالي' ? 'text-blue-700 dark:text-blue-400' : 'text-emerald-600 dark:text-emerald-400'}`}>
                {student.diploma_type}
              </span>
              <GraduationCap className="w-3 h-3 text-muted-foreground/45 shrink-0" />
            </div>
            <span className="text-border/40 text-[10px]">|</span>
            <div className="flex items-center gap-1">
              <span className="text-[11px] text-foreground/70">
                {SEMESTER_LABELS[student.current_semester] ?? `الفصل ${student.current_semester}`}
              </span>
              <BookOpen className="w-3 h-3 text-muted-foreground/45 shrink-0" />
            </div>
            <span className="text-border/40 text-[10px]">|</span>
            <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full border ${
              student.is_exam_only
                ? 'bg-purple-100 text-purple-700 border-purple-300'
                : 'bg-sky-100 text-sky-700 border-sky-300'
            }`}>
              {student.is_exam_only ? 'طالب 100' : 'نظامي'}
            </span>
          </div>

          {/* مؤشرات (دين / نواقص / 100%) */}
          {(debt > 0 || hasMissingDocs || isComplete) && (
            <div className="flex items-center justify-end gap-1.5 mt-2 flex-wrap">
              {debt > 0 && (
                <span className="inline-flex items-center gap-1 text-[10px] font-bold text-destructive bg-destructive/8 px-1.5 py-0.5 rounded-full border border-destructive/20">
                  <AlertTriangle className="w-2.5 h-2.5" />مديونية: {debt.toFixed(0)} د.ل
                </span>
              )}
              {hasMissingDocs && (
                <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-warning bg-warning/8 px-1.5 py-0.5 rounded-full border border-warning/20">
                  <FileWarning className="w-2.5 h-2.5" />{missingList.length} نقص
                </span>
              )}
              {isComplete && (
                <span className="inline-flex items-center gap-1 text-[10px] font-bold text-purple-500 bg-purple-500/8 px-1.5 py-0.5 rounded-full border border-purple-500/20">
                  <CheckCircle2 className="w-2.5 h-2.5" />100%
                </span>
              )}
            </div>
          )}
        </div>
      </button>

      {/* التفاصيل */}
      {expanded && (
        <div className="px-4 pb-4 pt-3 bg-muted/15 space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {/* الشخصية */}
            <div className="bg-card border border-border/50 rounded-xl p-3 space-y-2">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                  <UserCheck className="w-3.5 h-3.5 text-primary" />
                </div>
                <p className="text-xs font-bold">البيانات الشخصية</p>
              </div>
              <InfoRow icon={CreditCard} label="الرقم الوطني" value={student.national_id} mono />
              <InfoRow icon={User} label="الجنسية" value={student.nationality || 'ليبي'} />
              {student.phone && <InfoRow icon={Phone} label="الهاتف" value={student.phone} />}
              {student.guardian_phone && <InfoRow icon={Phone} label="ولي الأمر" value={student.guardian_phone} />}
              {student.address && <InfoRow icon={MapPin} label="العنوان" value={student.address} />}
              <InfoRow icon={student.status === 'نشط' ? CheckCircle2 : AlertTriangle} label="حالة القيد"
                value={student.status} valueClass={student.status === 'نشط' ? 'text-chart-2 font-bold' : 'text-warning font-bold'} />
            </div>
            {/* الأكاديمية */}
            <div className="bg-card border border-border/50 rounded-xl p-3 space-y-2">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-7 h-7 rounded-lg bg-chart-4/10 flex items-center justify-center shrink-0">
                  <GraduationCap className="w-3.5 h-3.5 text-chart-4" />
                </div>
                <p className="text-xs font-bold">البيانات الأكاديمية</p>
              </div>
              <InfoRow icon={BookOpen} label="نوع الدبلوم" value={`دبلوم ${student.diploma_type}`} />
              <InfoRow icon={GraduationCap} label="التخصص" value={student.specialization} />
              <InfoRow icon={BookOpen} label="الفصل الحالي" value={SEMESTER_LABELS[student.current_semester] ?? `الفصل ${student.current_semester}`} />
              {student.is_equivalency && (
                <InfoRow icon={Star} label="معادلة من" value={`الفصل ${student.equivalency_start_semester}`} valueClass="text-chart-4 font-semibold" />
              )}
              <div className="pt-1 border-t border-border/40 space-y-1">
                <DocRow label="شهادة الميلاد" ok={student.has_birth_certificate} />
                <DocRow label="شهادة التسجيل" ok={student.has_registration_certificate} />
                <DocRow label={`الصور (${student.photos_received}/${student.photos_required})`} ok={student.photos_received >= student.photos_required} />
              </div>
            </div>
            {/* المالية */}
            <div className="bg-card border border-border/50 rounded-xl p-3 space-y-2">
              <div className="flex items-center gap-2 mb-2">
                <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${debt > 0 ? 'bg-destructive/10' : 'bg-chart-2/10'}`}>
                  <Banknote className={`w-3.5 h-3.5 ${debt > 0 ? 'text-destructive' : 'text-chart-2'}`} />
                </div>
                <p className="text-xs font-bold">البيانات المالية</p>
              </div>
              <InfoRow icon={DollarSign} label="إجمالي المستحق" value={`${student.total_charged.toFixed(0)} د.ل`} />
              <InfoRow icon={CheckCircle2} label="إجمالي المدفوع" value={`${student.total_paid.toFixed(0)} د.ل`} valueClass="text-chart-2 font-semibold" />
              <div className={`flex items-center justify-between p-2 rounded-lg border ${debt > 0 ? 'bg-destructive/8 border-destructive/20' : 'bg-chart-2/8 border-chart-2/20'}`}>
                <span className="text-xs font-bold text-muted-foreground">المتبقي</span>
                <span className={`text-sm font-black ${debt > 0 ? 'text-destructive' : 'text-chart-2'}`}>
                  {debt > 0 ? `${debt.toFixed(0)} د.ل` : '✓ مسدد'}
                </span>
              </div>
            </div>
          </div>

          {/* أزرار الإجراءات */}
          <div className="pt-3 border-t border-border/40 mt-1 space-y-2">
            {/* الصف الأول: عرض + تعديل */}
            <div className="grid grid-cols-2 gap-2">
              {can('student_profile', 'view') && (
                <button
                  onClick={() => onNavigate(student.id)}
                  className="inline-flex items-center justify-center gap-1.5 h-9 px-3 rounded-lg text-[12px] font-semibold
                    bg-primary text-primary-foreground
                    shadow-[0_2px_8px_-2px_hsl(var(--primary)/0.45)]
                    hover:shadow-[0_4px_14px_-2px_hsl(var(--primary)/0.55)]
                    active:scale-95 transition-all duration-150 select-none">
                  <Eye className="w-3.5 h-3.5 shrink-0" />
                  <span>عرض الملف</span>
                </button>
              )}
              {can('student_profile', 'edit') && (
                <button
                  onClick={() => onNavigate(student.id, true)}
                  className="inline-flex items-center justify-center gap-1.5 h-9 px-3 rounded-lg text-[12px] font-semibold
                    bg-muted text-muted-foreground border border-border/60
                    hover:bg-accent hover:text-accent-foreground hover:border-border
                    hover:shadow-sm active:scale-95 transition-all duration-150 select-none">
                  <Edit className="w-3.5 h-3.5 shrink-0" />
                  <span>تعديل</span>
                </button>
              )}
            </div>
            {/* الصف الثاني: إيقاف/تنشيط + حذف */}
            <div className="grid grid-cols-2 gap-2">
              {can('students', 'edit') && (
                student.status === 'نشط' ? (
                  <button
                    onClick={() => onSuspend(student)}
                    disabled={actionLoading}
                    className="inline-flex items-center justify-center gap-1.5 h-9 px-3 rounded-lg text-[12px] font-semibold
                      bg-amber-500 text-white border-0
                      shadow-[0_2px_8px_rgba(245,158,11,0.45)]
                      hover:bg-amber-600 hover:shadow-[0_4px_14px_rgba(245,158,11,0.55)]
                      disabled:opacity-50 disabled:cursor-not-allowed
                      active:scale-95 transition-all duration-150 select-none">
                    {actionLoading
                      ? <div className="w-3 h-3 border-2 border-white/50 border-t-white rounded-full animate-spin shrink-0" />
                      : <PauseCircle className="w-3.5 h-3.5 shrink-0" />}
                    <span>إيقاف القيد</span>
                  </button>
                ) : (
                  <button
                    onClick={() => onActivate(student)}
                    disabled={actionLoading}
                    className="inline-flex items-center justify-center gap-1.5 h-9 px-3 rounded-lg text-[12px] font-semibold
                      bg-emerald-500 text-white border-0
                      shadow-[0_2px_8px_rgba(16,185,129,0.45)]
                      hover:bg-emerald-600 hover:shadow-[0_4px_14px_rgba(16,185,129,0.55)]
                      disabled:opacity-50 disabled:cursor-not-allowed
                      active:scale-95 transition-all duration-150 select-none">
                    {actionLoading
                      ? <div className="w-3 h-3 border-2 border-white/50 border-t-white rounded-full animate-spin shrink-0" />
                      : <PlayCircle className="w-3.5 h-3.5 shrink-0" />}
                    <span>تنشيط القيد</span>
                  </button>
                )
              )}
              {can('students', 'delete') && (
                <button
                  onClick={() => onDelete(student)}
                  className="inline-flex items-center justify-center gap-1.5 h-9 px-3 rounded-lg text-[12px] font-semibold
                    bg-red-500 text-white border-0
                    shadow-[0_2px_8px_rgba(239,68,68,0.4)]
                    hover:bg-red-600 hover:shadow-[0_4px_14px_rgba(239,68,68,0.55)]
                    active:scale-95 transition-all duration-150 select-none">
                  <Trash2 className="w-3.5 h-3.5 shrink-0" />
                  <span>حذف الطالب</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
});

// ── الصفحة الرئيسية ──
export default function StudentManagementPage() {
  const navigate = useNavigate();
  const { can } = useDeviceRole();

  // البيانات المعروضة فقط (صفحة واحدة من الـ DB)
  const [students, setStudents] = useState<Student[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [displayPage, setDisplayPage] = useState(0);
  const [loading, setLoading] = useState(true);
  const [statsLoading, setStatsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);
  const [filters, setFilters] = useState<Filters>(initialFilters);
  const [searchInput, setSearchInput] = useState('');
  const [specializations, setSpecializations] = useState<Specialization[]>([]);
  const [systemSettings, setSystemSettings] = useState<Record<string, string>>({});
  const [stats, setStats] = useState<StudentStats>(() => {
    if (typeof window === 'undefined') return { total: 0, active: 0, suspended: 0, debt: 0, missing: 0, complete: 0 };
    try {
      const stored = sessionStorage.getItem('alqeema_student_mgmt_stats');
      if (stored) return JSON.parse(stored);
    } catch {}
    return { total: 0, active: 0, suspended: 0, debt: 0, missing: 0, complete: 0 };
  });
  const searchTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const fetchAbortRef = useRef<AbortController | null>(null);

  const [deleteTarget, setDeleteTarget] = useState<Student | null>(null);
  const [deletePassword, setDeletePassword] = useState('');
  const [deleteError, setDeleteError] = useState('');
  const [promoteTarget, setPromoteTarget] = useState<Student | null>(null);

  useEffect(() => {
    getSpecializations().then(setSpecializations).catch(() => {});
    getSettings().then(setSystemSettings).catch(() => {});
  }, []);

  // debounce البحث الفوري بالحرف — 80ms
  const handleSearchChange = (val: string) => {
    setSearchInput(val);
    if (searchTimerRef.current) clearTimeout(searchTimerRef.current);
    searchTimerRef.current = setTimeout(() => {
      setFilters(prev => ({ ...prev, search: val }));
      setDisplayPage(0);
    }, 80);
  };

  // بناء params الـ API من الفلاتر
  const buildParams = useCallback((f: Filters, page: number) => {
    const p: Parameters<typeof getStudents>[0] = {
      limit: DISPLAY_PAGE_SIZE,
      offset: page * DISPLAY_PAGE_SIZE,
    };
    if (f.search)                   p.search        = f.search;
    if (f.diplomaType !== 'all')    p.diplomaType   = f.diplomaType as 'عالي' | 'متوسط';
    if (f.specialization !== 'all') p.specialization = f.specialization;
    if (f.semester !== 'all')       p.semester      = Number(f.semester);
    // quickFilters التي تُترجَم مباشرة لـ server
    if (f.quickFilter === 'active')    p.status = 'نشط';
    if (f.quickFilter === 'suspended') p.status = 'موقوف قيد';
    // quickFilters المعقدة (debt/missing/complete) تُطلب بـ limit كبير وتُفلتر client-side
    if (['has_debt','missing_docs','complete'].includes(f.quickFilter)) {
      p.limit = 15000; p.offset = 0;
    }
    return p;
  }, []);

  // جلب صفحة الطلاب فقط (server-side pagination)
  const fetchStudents = useCallback(async (f = filters, page = displayPage) => {
    // إلغاء أي طلب سابق
    if (fetchAbortRef.current) fetchAbortRef.current.abort();
    fetchAbortRef.current = new AbortController();

    setLoading(true);
    setHasError(false);
    try {
      const params = buildParams(f, page);
      const { data, count } = await getStudents(params);

      // فلتر client-side للحالات المعقدة فقط
      let finalData = data;
      if (f.quickFilter === 'has_debt') {
        finalData = data.filter(s => (s.total_charged - s.total_paid) > 0);
      } else if (f.quickFilter === 'missing_docs') {
        finalData = data.filter(s =>
          !s.has_birth_certificate || !s.has_registration_certificate || s.photos_received < s.photos_required
        );
      } else if (f.quickFilter === 'complete') {
        finalData = data.filter(s => {
          const d = s.total_charged - s.total_paid;
          const ok = s.has_birth_certificate && s.has_registration_certificate && s.photos_received >= s.photos_required;
          return d <= 0 && ok && s.status === 'نشط';
        });
      }

      setStudents(finalData);
      setTotalCount(['has_debt','missing_docs','complete'].includes(f.quickFilter) ? finalData.length : count);
    } catch {
      setHasError(true);
      toast.error('خطأ في تحميل بيانات الطلاب — اضغط إعادة المحاولة');
    } finally {
      setLoading(false);
    }
  }, [filters, displayPage, buildParams]);

  // جلب الإحصاءات بشكل مستقل (لا تعيق عرض القائمة)
  const fetchStats = useCallback(async (f = filters) => {
    setStatsLoading(true);
    try {
      const baseParams = {
        search:         f.search || undefined,
        diplomaType:    f.diplomaType !== 'all' ? f.diplomaType as 'عالي' | 'متوسط' : undefined,
        specialization: f.specialization !== 'all' ? f.specialization : undefined,
        semester:       f.semester !== 'all' ? Number(f.semester) : undefined,
      };
      const s = await getStudentStats(baseParams);
      setStats(s);
      setTotalCount(s.total);
      if (typeof window !== 'undefined') {
        try { sessionStorage.setItem('alqeema_student_mgmt_stats', JSON.stringify(s)); } catch {}
      }
    } catch { /* لا شيء */ } finally {
      setStatsLoading(false);
    }
  }, [filters]);

  // تشغيل الجلبَين معاً عند تغيير الفلاتر
  useEffect(() => {
    fetchStudents(filters, 0);
    fetchStats(filters);
    setDisplayPage(0);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filters]);

  // تحميل الصفحة التالية عند "عرض المزيد"
  useEffect(() => {
    if (displayPage === 0) return;
    fetchStudents(filters, displayPage);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [displayPage]);

  const filteredStudents = students; // الفلترة تمت بالفعل في fetchStudents
  const displayedStudents = students;
  const hasMoreLocal = !['has_debt','missing_docs','complete'].includes(filters.quickFilter)
    && students.length === DISPLAY_PAGE_SIZE
    && totalCount > (displayPage + 1) * DISPLAY_PAGE_SIZE;

  const setFilter = useCallback((key: keyof Filters, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  }, []);

  const resetFilters = useCallback(() => {
    setFilters(initialFilters);
    setSearchInput('');
  }, []);

  const hasActiveFilters = useMemo(() =>
    JSON.stringify(filters) !== JSON.stringify(initialFilters), [filters]);

  const filtSpecializations = useMemo(() =>
    filters.diplomaType !== 'all'
      ? specializations.filter(s => s.diploma_type === filters.diplomaType)
      : specializations,
    [filters.diplomaType, specializations]);

  const handleSuspend = useCallback(async (student: Student) => {
    setActionLoading(true);
    try { await suspendStudent(student.id); toast.success(`تم إيقاف قيد ${student.full_name}`); fetchStudents(filters, 0); fetchStats(filters); }
    catch { toast.error('فشل الإيقاف'); } finally { setActionLoading(false); }
  }, [fetchStudents, fetchStats, filters]);

  const handleActivate = useCallback(async (student: Student) => {
    setActionLoading(true);
    try { await activateStudent(student.id); toast.success(`تم تنشيط قيد ${student.full_name}`); fetchStudents(filters, 0); fetchStats(filters); }
    catch { toast.error('فشل التنشيط'); } finally { setActionLoading(false); }
  }, [fetchStudents, fetchStats, filters]);

  const handleDelete = async () => {
    if (!deleteTarget) return;
    if (deletePassword !== SYSTEM_PASSWORD) { setDeleteError('كلمة المرور غير صحيحة'); return; }
    setActionLoading(true);
    try { await deleteStudent(deleteTarget.id); toast.success(`تم حذف ${deleteTarget.full_name}`); setDeleteTarget(null); fetchStudents(filters, 0); fetchStats(filters); }
    catch { toast.error('فشل الحذف'); } finally { setActionLoading(false); }
  };

  const handlePromote = async () => {
    if (!promoteTarget) return;
    setActionLoading(true);
    try {
      const maxSem = MAX_SEMESTERS[promoteTarget.diploma_type] ?? 6;
      if (promoteTarget.current_semester >= maxSem) {
        toast.error(`الطالب ${promoteTarget.full_name} في الفصل الأخير — يجب الترحيل من صفحة "ترحيل الطلاب"`);
        setPromoteTarget(null);
        return;
      }
      await promoteStudent(promoteTarget, systemSettings);
      toast.success(`تم ترحيل ${promoteTarget.full_name}`);
      setPromoteTarget(null);
      fetchStudents(filters, 0);
    }
    catch { toast.error('فشل الترحيل'); } finally { setActionLoading(false); }
  };

  const handleOpenDelete = useCallback((s: Student) => { setDeleteTarget(s); setDeletePassword(''); setDeleteError(''); }, []);

  // ── أعمدة التصدير المشتركة ──
  const exportColumns = ['#', 'الاسم الكامل', 'الرقم الوطني', 'الهاتف', 'الحالة',
    'التخصص', 'نوع الدبلوم', 'الفصل', 'المستحق (د.ل)', 'المدفوع (د.ل)', 'المتبقي (د.ل)'];

  // ── عنوان الكشف يعكس الفلاتر المفعّلة ──
  const exportMeta = useMemo(() => {
    const parts: string[] = [];
    if (filters.specialization !== 'all') parts.push(`تخصص: ${filters.specialization}`);
    if (filters.semester !== 'all') parts.push(SEMESTER_LABELS[Number(filters.semester)] ?? `الفصل ${filters.semester}`);
    if (filters.diplomaType !== 'all') parts.push(`دبلوم ${filters.diplomaType}`);
    if (filters.quickFilter === 'active') parts.push('الطلاب النشطون');
    if (filters.quickFilter === 'suspended') parts.push('موقوفو القيد');
    if (filters.quickFilter === 'has_debt') parts.push('لديهم ديون');
    if (filters.search) parts.push(`بحث: ${filters.search}`);
    const title    = parts.length > 0 ? `كشف الطلاب — ${parts.join(' | ')}` : 'كشف الطلاب';
    const subtitle = `إجمالي: ${totalCount} طالب`;
    return { title, subtitle, totalInfo: subtitle, accentColor: '#1a3c5e' };
  }, [filters, totalCount]);

  // ── جلب كل الطلاب للتصدير (يدعم حتى 15,000 طالب) ──
  const fetchAllForExport = useCallback(async (): Promise<Student[]> => {
    const params: Parameters<typeof getStudents>[0] = { limit: 15000 };
    if (filters.diplomaType !== 'all') params.diplomaType = filters.diplomaType as 'عالي' | 'متوسط';
    if (filters.specialization !== 'all') params.specialization = filters.specialization;
    if (filters.semester !== 'all') params.semester = Number(filters.semester);
    if (filters.search) params.search = filters.search;
    if (filters.quickFilter === 'active') params.status = 'نشط';
    if (filters.quickFilter === 'suspended') params.status = 'موقوف قيد';
    const { data } = await getStudents(params);
    // فلاتر quickFilter المحلية
    return data.filter(s => {
      const debt = s.total_charged - s.total_paid;
      const hasMissing = (
        s.photos_received < s.photos_required ||
        !s.has_birth_certificate ||
        !s.has_registration_certificate ||
        !s.has_suspended_file
      );
      const isComplete = debt <= 0.01 && !hasMissing;
      if (filters.quickFilter === 'has_debt') return debt > 0;
      if (filters.quickFilter === 'missing_docs') return hasMissing;
      if (filters.quickFilter === 'complete') return isComplete;
      return true;
    });
  }, [filters]);

  const buildExportRows = (all: Student[]) => all.map((s, i) => [
    i + 1, s.full_name, s.national_id ?? '', s.phone ?? '', s.status,
    s.specialization, s.diploma_type,
    SEMESTER_LABELS[s.current_semester] ?? `ف${s.current_semester}`,
    s.total_charged.toFixed(0), s.total_paid.toFixed(0),
    (s.total_charged - s.total_paid).toFixed(0),
  ] as (string | number)[]);

  const handleExportExcel = useCallback(async () => {
    const tid = toast.loading('جاري تحضير البيانات...');
    try {
      const all = await fetchAllForExport();
      const meta = { ...exportMeta, subtitle: `إجمالي: ${all.length} طالب`, totalInfo: `إجمالي: ${all.length} طالب` };
      exportExcel({
        ...meta,
        columns: exportColumns,
        rows: buildExportRows(all),
        filename: `طلاب-معهد-القمة-${new Date().toLocaleDateString('ar')}`,
        sheetName: 'الطلاب',
      });
      toast.success(`تم تصدير ${all.length} طالب إلى Excel`, { id: tid });
    } catch (e) { console.error('Excel export error:', e); toast.error('فشل التصدير: ' + String(e), { id: tid }); }
  }, [fetchAllForExport, exportMeta]);

  const handleExportWord = useCallback(async () => {
    const tid = toast.loading('جاري تحضير البيانات...');
    try {
      const all = await fetchAllForExport();
      const meta = { ...exportMeta, subtitle: `إجمالي: ${all.length} طالب`, totalInfo: `إجمالي: ${all.length} طالب` };
      exportWord({
        ...meta,
        columns: exportColumns,
        rows: buildExportRows(all),
        filename: `طلاب-معهد-القمة-${new Date().toLocaleDateString('ar')}`,
      });
      toast.success(`تم تصدير ${all.length} طالب إلى Word`, { id: tid });
    } catch (e) { console.error('Word export error:', e); toast.error('فشل التصدير: ' + String(e), { id: tid }); }
  }, [fetchAllForExport, exportMeta]);

  const handleExportPDF = useCallback(async () => {
    const tid = toast.loading('جاري تحضير البيانات...');
    try {
      const all = await fetchAllForExport();
      const meta = { ...exportMeta, subtitle: `إجمالي: ${all.length} طالب`, totalInfo: `إجمالي: ${all.length} طالب` };
      exportPDF({
        ...meta,
        columns: exportColumns,
        rows: buildExportRows(all),
        filename: `طلاب-معهد-القمة-${new Date().toLocaleDateString('ar')}`,
        landscape: true,
      });
      toast.success(`تم تصدير ${all.length} طالب إلى PDF`, { id: tid });
    } catch (e) { console.error('PDF export error:', e); toast.error('فشل التصدير: ' + String(e), { id: tid }); }
  }, [fetchAllForExport, exportMeta]);

  const handlePrint = useCallback(() => {
    const printColumns = ['#', 'الاسم الكامل', 'الرقم الوطني', 'الهاتف', 'الحالة',
      'التخصص', 'نوع الدبلوم', 'الفصل'];
    const printRows = students.map((s, i) => [
      i + 1, s.full_name, s.national_id ?? '', s.phone ?? '', s.status,
      s.specialization, s.diploma_type,
      SEMESTER_LABELS[s.current_semester] ?? `ف${s.current_semester}`,
    ] as (string | number)[]);
    printTable({
      ...exportMeta,
      columns: printColumns,
      rows: printRows,
      landscape: true,
      hideSignatures: true,
      cellColor: {
        4: (v: string | number) => v === 'نشط' ? '#1e8449' : '#e67e22',
      },
    });
    toast.success('جارٍ فتح نافذة الطباعة');
  }, [students, exportMeta]);

  return (
    <MainLayout>
      <div className="space-y-4">

        {hasError && !loading && (
          <div className="bg-destructive/10 border border-destructive/30 rounded-xl p-4 flex items-center justify-between gap-3 text-destructive animate-in fade-in">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 shrink-0" />
              <span className="text-sm font-semibold">تعذر الاتصال بقاعدة البيانات مؤقتاً (جاري استيقاظ الخادم أو ضعف في الشبكة).</span>
            </div>
            <Button size="sm" variant="outline" onClick={() => { fetchStudents(); fetchStats(); }} className="shrink-0 gap-1.5 border-destructive/40 hover:bg-destructive/10">
              <RefreshCw className="w-4 h-4" />
              إعادة المحاولة الآن
            </Button>
          </div>
        )}

        {/* ترويسة */}
        <div className="relative rounded-2xl overflow-hidden" style={{ boxShadow: 'var(--shadow-lg)' }}>
          <div className="absolute inset-0 bg-gradient-to-br from-chart-2/80 via-chart-2/90 to-primary/80" />
          <div className="absolute inset-0 opacity-[0.06]"
            style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '24px 24px' }} />
          <div className="relative px-5 py-4 md:px-7 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <button onClick={() => navigate('/')}
                className="w-9 h-9 rounded-xl bg-white/15 border border-white/20 flex items-center justify-center shrink-0 hover:bg-white/25 transition-colors">
                <ChevronRight className="w-4 h-4 text-white" />
              </button>
              <div className="w-10 h-10 rounded-xl bg-white/15 border border-white/20 flex items-center justify-center shrink-0">
                <Users className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-white">إدارة الطلاب</h1>
                <p className="text-white/60 text-xs mt-0.5">اضغط على أي طالب لعرض بياناته الكاملة</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2 shrink-0">
              {/* أزرار التصدير */}
              {can('students', 'export') && (
                <>
                  <button onClick={handleExportExcel}
                    className="inline-flex items-center gap-1.5 h-8 px-3 rounded-lg text-[11px] font-bold bg-emerald-600/20 text-emerald-100 border border-emerald-400/30 hover:bg-emerald-600 hover:border-emerald-600 transition-all">
                    <FileSpreadsheet className="w-3.5 h-3.5" /> Excel
                  </button>
                  <button onClick={handleExportWord}
                    className="inline-flex items-center gap-1.5 h-8 px-3 rounded-lg text-[11px] font-bold bg-blue-600/20 text-blue-100 border border-blue-400/30 hover:bg-blue-600 hover:border-blue-600 transition-all">
                    <FileText className="w-3.5 h-3.5" /> Word
                  </button>
                  <button onClick={handleExportPDF}
                    className="inline-flex items-center gap-1.5 h-8 px-3 rounded-lg text-[11px] font-bold bg-red-600/20 text-red-100 border border-red-400/30 hover:bg-red-600 hover:border-red-600 transition-all">
                    <FileDown className="w-3.5 h-3.5" /> PDF
                  </button>
                </>
              )}
              {can('students', 'print') && (
                <button onClick={handlePrint}
                  className="inline-flex items-center gap-1.5 h-8 px-3 rounded-lg text-[11px] font-bold bg-white/15 text-white border border-white/25 hover:bg-white/30 transition-all">
                  <Printer className="w-3.5 h-3.5" /> طباعة
                </button>
              )}
              <div className="w-px bg-white/20 mx-0.5 self-stretch" />
              <RefreshButton
                onRefresh={() => { fetchStudents(filters, 0); fetchStats(filters); }}
                loading={loading}
                variant="white"
                label="تحديث"
              />
              {can('registration', 'view') && (
                <Button size="sm" onClick={() => navigate('/register')}
                  className="bg-white text-chart-2 hover:bg-white/90 gap-1.5 font-semibold shadow-md h-9">
                  <ChevronUp className="w-4 h-4" /> تسجيل طالب
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* الفلاتر السريعة */}
        <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
          {([
            { key: 'all', label: 'الكل', value: totalCount, color: 'bg-gradient-to-br from-primary/80 to-primary' },
            { key: 'active', label: 'نشطون', value: stats.active, color: 'bg-gradient-to-br from-chart-2/80 to-chart-2' },
            { key: 'suspended', label: 'موقوف قيد', value: stats.suspended, color: 'bg-gradient-to-br from-orange-500/75 to-orange-500' },
            { key: 'complete', label: 'طالب 100%', value: stats.complete, color: 'bg-gradient-to-br from-purple-600/75 to-purple-600' },
            { key: 'has_debt', label: 'لديهم ديون', value: stats.debt, color: 'bg-gradient-to-br from-destructive/75 to-destructive' },
            { key: 'missing_docs', label: 'نواقص', value: stats.missing, color: 'bg-gradient-to-br from-warning/75 to-warning' },
          ] as const).map(card => {
            const isActive = filters.quickFilter === card.key;
            return (
              <button key={card.key} onClick={() => setFilter('quickFilter', card.key)}
                className={`relative rounded-xl overflow-hidden text-right transition-all duration-200 select-none
                  ${isActive
                    ? 'ring-2 ring-white/70 ring-offset-2 ring-offset-background shadow-xl scale-[1.04]'
                    : 'opacity-60 hover:opacity-80'
                  }`}>
                <div className={`absolute inset-0 ${card.color}`} />
                <div className="relative p-3">
                  <p className={`text-[10px] font-semibold leading-tight ${isActive ? 'text-white' : 'text-white/70'}`}>{card.label}</p>
                  <p className="text-white text-xl font-black leading-none mt-0.5">{(loading || statsLoading) ? '—' : card.value}</p>
                </div>
              </button>
            );
          })}
        </div>

        {/* الجدول */}
        <Card className="shadow-sm border-border/60 overflow-hidden">
          {/* شريط البحث والفلاتر */}
          <div className="px-4 py-3 border-b border-border/60 bg-gradient-to-l from-chart-2/5 to-transparent">
            <div className="flex flex-col md:flex-row gap-2">
              {/* البحث */}
              <div className="relative flex-1">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                <Input placeholder="بحث بالاسم أو الرقم الوطني..." value={searchInput}
                  onChange={e => handleSearchChange(e.target.value)} className="pr-9 h-9 text-sm" />
                {searchInput && (
                  <button onClick={() => { setSearchInput(''); setFilters(prev => ({ ...prev, search: '' })); }}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
              {/* الدبلوم */}
              <Select value={filters.diplomaType} onValueChange={v => setFilter('diplomaType', v)}>
                <SelectTrigger className="w-full md:w-36 h-9 text-sm"><SelectValue placeholder="الدبلوم" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">كل الدبلومات</SelectItem>
                  <SelectItem value="عالي">دبلوم عالي</SelectItem>
                  <SelectItem value="متوسط">دبلوم متوسط</SelectItem>
                </SelectContent>
              </Select>
              {/* التخصص */}
              <Select value={filters.specialization} onValueChange={v => setFilter('specialization', v)}>
                <SelectTrigger className="w-full md:w-44 h-9 text-sm"><SelectValue placeholder="التخصص" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">كل التخصصات</SelectItem>
                  {filtSpecializations.map(s => (
                    <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {/* الفصل */}
              <Select value={filters.semester} onValueChange={v => setFilter('semester', v)}>
                <SelectTrigger className="w-full md:w-36 h-9 text-sm"><SelectValue placeholder="الفصل" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">كل الفصول</SelectItem>
                  {[1,2,3,4,5,6].map(n => (
                    <SelectItem key={n} value={String(n)}>{SEMESTER_LABELS[n]}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {/* إلغاء الفلاتر */}
              {hasActiveFilters && (
                <Button size="sm" variant="ghost" onClick={resetFilters} className="h-9 shrink-0 text-muted-foreground hover:text-destructive gap-1">
                  <X className="w-3.5 h-3.5" /> إلغاء
                </Button>
              )}
            </div>
            {!loading && (
              <p className="text-xs text-muted-foreground mt-2">
                عرض <span className="font-semibold text-foreground">{students.length}</span>
                {totalCount > students.length && <span className="text-muted-foreground"> من {totalCount}</span>} طالب
                {filters.quickFilter !== 'all' && <span className={`font-semibold mr-1 ${
                  { active:'text-chart-2', suspended:'text-orange-500', has_debt:'text-destructive', missing_docs:'text-warning', complete:'text-purple-500' }[filters.quickFilter] ?? 'text-primary'
                }`}>· {
                  { active:'نشطون', suspended:'موقوف قيد', has_debt:'لديهم ديون', missing_docs:'نواقص', complete:'طالب 100%' }[filters.quickFilter]
                }</span>}
              </p>
            )}
          </div>

          {/* قائمة الطلاب */}
          <CardContent className="p-3 space-y-1.5">
            {loading ? (
              Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-14 bg-muted rounded-xl" />)
            ) : filteredStudents.length === 0 ? (
              <div className="text-center py-14 text-muted-foreground">
                <div className="w-14 h-14 rounded-full bg-muted mx-auto mb-3 flex items-center justify-center">
                  <Users className="w-7 h-7 opacity-30" />
                </div>
                <p className="text-sm font-semibold">لا يوجد طلاب مطابقون</p>
                <Button size="sm" variant="outline" onClick={resetFilters} className="mt-3 gap-1.5">
                  <X className="w-3.5 h-3.5" /> إعادة الضبط
                </Button>
              </div>
            ) : displayedStudents.map((student, idx) => (
              <StudentAccordionRow
                key={student.id}
                student={student}
                index={idx + 1}
                onNavigate={(id, edit) => navigate(`/student/${id}${edit ? '?edit=true' : ''}`)}
                onSuspend={handleSuspend}
                onActivate={handleActivate}
                onPromote={setPromoteTarget}
                onDelete={handleOpenDelete}
                actionLoading={actionLoading}
              />
            ))}
          </CardContent>

          {/* عرض المزيد — server-side pagination */}
          {hasMoreLocal && (
            <div className="flex items-center justify-between px-4 py-2.5 border-t border-border/40 bg-muted/20">
              <p className="text-[11px] text-muted-foreground">
                يُعرض <span className="font-bold text-foreground">{students.length}</span> من <span className="font-bold text-foreground">{totalCount}</span> طالب
              </p>
              <Button size="sm" variant="outline"
                onClick={() => setDisplayPage(p => p + 1)}
                className="h-7 text-xs font-semibold px-4 border-primary/30 text-primary hover:bg-primary hover:text-primary-foreground transition-all">
                عرض المزيد ({totalCount - students.length})
              </Button>
            </div>
          )}
        </Card>
      </div>

      {/* حوار الحذف */}
      <AlertDialog open={!!deleteTarget} onOpenChange={open => !open && setDeleteTarget(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg" dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-destructive flex items-center gap-2">
              <Trash2 className="w-5 h-5" /> تأكيد حذف الملف
            </AlertDialogTitle>
            <AlertDialogDescription>
              سيتم حذف جميع بيانات <span className="font-bold text-foreground">{deleteTarget?.full_name}</span> نهائياً.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-2 py-1">
            <Label className="text-sm font-semibold">كلمة مرور النظام</Label>
            <Input type="password" placeholder="أدخل كلمة المرور"
              value={deletePassword} onChange={e => { setDeletePassword(e.target.value); setDeleteError(''); }} className="h-10" />
            {deleteError && <p className="text-xs text-destructive font-medium">{deleteError}</p>}
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel className="h-9">إلغاء</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} disabled={actionLoading}
              className="bg-destructive text-white hover:bg-destructive/90 h-9">تأكيد الحذف</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* حوار الترحيل */}
      <AlertDialog open={!!promoteTarget} onOpenChange={open => !open && setPromoteTarget(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg" dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-chart-2 flex items-center gap-2">
              <ChevronUp className="w-5 h-5" /> تأكيد الترحيل
            </AlertDialogTitle>
            <AlertDialogDescription>
              ترحيل <span className="font-bold text-foreground">{promoteTarget?.full_name}</span> من{' '}
              <span className="font-semibold">{SEMESTER_LABELS[promoteTarget?.current_semester ?? 1]}</span> إلى{' '}
              <span className="font-semibold">{SEMESTER_LABELS[(promoteTarget?.current_semester ?? 1) + 1]}</span>.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="h-9">إلغاء</AlertDialogCancel>
            <AlertDialogAction onClick={handlePromote} disabled={actionLoading}
              className="bg-chart-2 text-white hover:bg-chart-2/90 h-9">تأكيد الترحيل</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </MainLayout>
  );
}
