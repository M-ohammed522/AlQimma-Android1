// صفحة الإدارة المالية للطلاب - منظومة معهد القمة
import React, { useEffect, useState, useCallback, useMemo, useRef } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import {
  DollarSign, Search, ChevronRight, ChevronLeft, RefreshCw, X,
  AlertTriangle, CheckCircle2,
  FileSpreadsheet, FileDown, GraduationCap, BookOpen,
  History, ChevronDown, ChevronUp, AlertCircle, Archive, Loader2,
  Users, UserX, Printer, Hash, Sparkles, ShieldCheck, ClipboardList,
} from 'lucide-react';
import { toast } from 'sonner';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { exportExcel, printCustom, INSTITUTE_NAME, LOGO_URL } from '@/lib/printUtils';
import {
  getStudents, getPreviousDebts, getPendingArchiveStudents, archiveStudent, type PreviousDebtRow,
} from '@/lib/api';
import { matchStudent, matchSearch } from '@/lib/searchUtils';
import type { Student } from '@/types/index';
import { SEMESTER_LABELS, SPECIALIZATIONS_BY_DIPLOMA } from '@/types/index';
import StudentProfileDialog from '@/components/StudentProfileDialog';
import { StudentAvatar } from '@/components/ui/StudentAvatar';
import { RefreshButton } from '@/components/ui/RefreshButton';
import { FinancialAuditDialog } from '@/components/finance/FinancialAuditDialog';

// ──────────────────────────────────────────────
// مساعدات
// ──────────────────────────────────────────────
function StatCard({ label, value, sub, color }: { label: string; value: string; sub?: string; color: string }) {
  return (
    <div className={`relative rounded-xl overflow-hidden border ${color}`}>
      <div className="p-3">
        <p className="text-[11px] text-white/70 font-medium leading-tight">{label}</p>
        <p className="text-xl font-black text-white leading-none mt-0.5">{value}</p>
        {sub && <p className="text-[10px] text-white/55 mt-0.5">{sub}</p>}
      </div>
    </div>
  );
}

// ──────────────────────────────────────────────
// كرت الطالب المالي الاحترافي — بطاقة متكاملة وعالية الجودة
// ──────────────────────────────────────────────
const StudentFinanceCard = React.memo(function StudentFinanceCard({
  student, index, onOpen,
}: { student: Student; index: number; onOpen: (s: Student) => void }) {
  const debt = student.total_charged - student.total_paid;
  const paidPct = student.total_charged > 0
    ? Math.min(100, Math.round((student.total_paid / student.total_charged) * 100))
    : 100;
  const isFullyPaid = debt <= 0;

  return (
    <div
      onClick={() => onOpen(student)}
      className="group relative cursor-pointer rounded-2xl border border-border/70 bg-card hover:border-primary/50 hover:shadow-xl hover:-translate-y-0.5 transition-all duration-200 overflow-hidden flex flex-col justify-between p-4"
    >
      {/* شريط تمييز علوي ملون */}
      <div className={`absolute top-0 right-0 left-0 h-1.5 ${
        isFullyPaid
          ? 'bg-gradient-to-r from-emerald-500 via-teal-500 to-green-600'
          : student.status === 'موقوف قيد'
          ? 'bg-gradient-to-r from-amber-500 via-orange-500 to-yellow-600'
          : 'bg-gradient-to-r from-rose-500 via-red-600 to-rose-700'
      }`} />

      <div>
        {/* رأس البطاقة: الصورة والاسم ورقم القيد والوطني */}
        <div className="flex items-start gap-3">
          <div className="relative shrink-0">
            <StudentAvatar
              photoUrl={student.photo_url}
              name={student.full_name}
              size="md"
              variant="square"
            />
            <span
              title={student.status}
              className={`absolute -bottom-1 -left-1 w-3.5 h-3.5 rounded-full border-2 border-background ${
                student.status === 'نشط' ? 'bg-emerald-500' : 'bg-amber-500'
              }`}
            />
          </div>

          <div className="flex-1 min-w-0 text-right">
            <div className="flex items-start justify-between gap-1.5">
              <h3
                className="text-xs sm:text-sm font-bold text-foreground leading-snug break-words line-clamp-2 md:line-clamp-1 group-hover:text-primary transition-colors"
                title={student.full_name}
              >
                {student.full_name}
              </h3>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0 border ${
                isFullyPaid
                  ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/25'
                  : 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/25'
              }`}>
                {isFullyPaid ? '✓ مسدد' : 'عليه دين'}
              </span>
            </div>

            <div className="flex items-center gap-1.5 mt-1 flex-wrap">
              <span className="text-[11px] font-mono text-muted-foreground/80">{student.national_id ? student.national_id : 'لا يوجد رقم وطني'}</span>
              {student.registration_number ? (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-amber-500/15 text-amber-700 dark:text-amber-300 border border-amber-500/30 text-[10px] font-mono font-bold shadow-xs">
                  <Hash className="w-2.5 h-2.5 text-amber-600 dark:text-amber-400 shrink-0" />
                  <span>قيد: {student.registration_number}</span>
                </span>
              ) : (
                <span className="text-[10px] text-muted-foreground/50 italic">• بدون قيد</span>
              )}
            </div>
          </div>
        </div>

        {/* معلومات الدبلوم والتخصص والفصل */}
        <div className="flex items-center gap-1.5 mt-3 flex-wrap">
          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
            student.diploma_type === 'عالي'
              ? 'bg-blue-500/10 text-blue-700 dark:text-blue-300 border border-blue-500/20'
              : 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20'
          }`}>
            {student.diploma_type}
          </span>
          <span className="text-[10px] font-medium px-2 py-0.5 rounded-md bg-muted text-muted-foreground border border-border/50 truncate max-w-[130px]">
            {student.specialization || 'عام'}
          </span>
          <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-violet-500/10 text-violet-700 dark:text-violet-300 border border-violet-500/20 mr-auto">
            {SEMESTER_LABELS[student.current_semester] ?? `الفصل ${student.current_semester}`}
          </span>
        </div>

        {/* الموقف المالي: شريط تقدم ومبالغ */}
        <div className="mt-3 p-2.5 rounded-xl bg-muted/40 border border-border/50 space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <span className="text-[11px] text-muted-foreground">
              المستحق: <b className="text-foreground font-bold">{student.total_charged.toLocaleString('ar-LY')} د.ل</b>
            </span>
            <span className="text-[11px] font-black text-emerald-600 dark:text-emerald-400">
              مدفوع: {student.total_paid.toLocaleString('ar-LY')} د.ل
            </span>
          </div>

          <div className="h-1.5 w-full bg-muted-foreground/15 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-300 ${
                isFullyPaid ? 'bg-emerald-500' : paidPct > 50 ? 'bg-amber-500' : 'bg-rose-500'
              }`}
              style={{ width: `${paidPct}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-[10px] pt-0.5">
            <span className="font-bold text-muted-foreground">نسبة السداد: {paidPct}%</span>
            {debt > 0 ? (
              <span className="font-black text-rose-600 dark:text-rose-400">
                المتبقي: {debt.toLocaleString('ar-LY')} د.ل
              </span>
            ) : (
              <span className="font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> تم استيفاء الرسوم
              </span>
            )}
          </div>
        </div>
      </div>

      {/* زر أسفل البطاقة */}
      <div className="mt-3.5 pt-2.5 border-t border-border/50 flex items-center justify-between gap-2 text-xs">
        <span className="text-[11px] text-muted-foreground group-hover:text-foreground transition-colors truncate">
          إدارة الدفعات والوصولات
        </span>
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onOpen(student);
          }}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-emerald-600 via-teal-600 to-primary hover:from-emerald-700 hover:via-teal-700 hover:to-primary/90 shadow-sm shadow-emerald-700/20 hover:shadow-md transition-all active:scale-95 shrink-0 group/btn"
        >
          <DollarSign className="w-3.5 h-3.5 text-emerald-200" />
          <span>الملف المالي</span>
          <ChevronLeft className="w-3 h-3 text-white/80 group-hover/btn:-translate-x-0.5 transition-transform" />
        </button>
      </div>
    </div>
  );
});


// ──────────────────────────────────────────────
// الصفحة الرئيسية
// ──────────────────────────────────────────────
// ── مكوّن بطاقة الطالب الجاهز للأرشفة ──────────────────────────────────────
// خلفية ملونة بتدرج حسب الدبلوم
function ArchiveReadyCard({
  student,
  onOpen,
  onArchive,
  archiving,
  selected,
  onToggleSelect,
}: {
  student: Student;
  onOpen: (s: Student) => void;
  onArchive: (s: Student) => void;
  archiving: boolean;
  selected: boolean;
  onToggleSelect: (id: string) => void;
}) {
  const semLbl = SEMESTER_LABELS[student.current_semester] ?? `الفصل ${student.current_semester}`;
  const isHigh = student.diploma_type === 'عالي';

  return (
    <div
      className={`group relative rounded-2xl overflow-hidden transition-all duration-200
        ${selected
          ? 'ring-2 ring-offset-2 ring-emerald-500 shadow-lg shadow-emerald-200/50 dark:shadow-emerald-900/40 scale-[1.01]'
          : 'hover:shadow-lg hover:scale-[1.01]'
        }`}
    >
      {/* خلفية تدرجية ملونة */}
      <div className={`absolute inset-0 ${
        isHigh
          ? 'bg-gradient-to-br from-blue-600 via-blue-500 to-indigo-600'
          : 'bg-gradient-to-br from-teal-500 via-emerald-500 to-cyan-600'
      }`} />
      {/* طبقة نقاط زخرفية */}
      <div className="absolute inset-0 opacity-[0.08]"
        style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '16px 16px' }} />
      {/* هالة ضوئية */}
      <div className="absolute -top-6 -right-6 w-24 h-24 bg-white/10 rounded-full blur-2xl pointer-events-none" />

      {/* checkbox اختيار */}
      <button
        onClick={e => { e.stopPropagation(); onToggleSelect(student.id); }}
        className={`absolute top-3 left-3 z-10 rounded-md border-2 flex items-center justify-center transition-all
          ${selected ? 'bg-white border-white' : 'border-white/60 bg-white/10 hover:bg-white/20'}`}
        style={{ width: '18px', height: '18px' }}
      >
        {selected && (
          <svg viewBox="0 0 12 12" style={{ width: '10px', height: '10px' }}>
            <path d="M2 6l3 3 5-5" stroke={isHigh ? '#2563eb' : '#10b981'} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" fill="none" />
          </svg>
        )}
      </button>

      {/* المحتوى الرئيسي */}
      <div className="relative p-4 flex flex-col gap-3">
        {/* الصف الأول: الصورة + الاسم + badge */}
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => onOpen(student)}>
          {/* صورة مع حلقة بيضاء */}
          <div className="shrink-0 rounded-full p-0.5 bg-white/30 shadow-md">
            <StudentAvatar name={student.full_name} photoUrl={student.photo_url ?? undefined} size="sm" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-black text-white leading-snug break-words drop-shadow-sm">{student.full_name}</p>
            <span className="inline-flex items-center gap-1 bg-white/20 border border-white/30 text-white text-[9px] font-bold px-2 py-0.5 rounded-full mt-0.5">
              <CheckCircle2 className="w-2.5 h-2.5" />
              مكتمل السداد
            </span>
          </div>
        </div>

        {/* الصف الثاني: badges أكاديمية */}
        <div className="flex items-center gap-1.5 flex-wrap cursor-pointer" onClick={() => onOpen(student)}>
          <span className="inline-flex items-center gap-1 bg-white/15 border border-white/25 text-white text-[10px] font-semibold px-2 py-1 rounded-lg">
            <GraduationCap className="w-3 h-3" />
            {student.diploma_type}
          </span>
          <span className="inline-flex items-center gap-1 bg-white/15 border border-white/25 text-white text-[10px] font-medium px-2 py-1 rounded-lg truncate max-w-[120px]">
            {student.specialization}
          </span>
          <span className="inline-flex items-center gap-1 bg-white/15 border border-white/25 text-white text-[10px] font-medium px-2 py-1 rounded-lg">
            <BookOpen className="w-3 h-3" />
            {semLbl}
          </span>
        </div>

        {/* الصف الثالث: زر الأرشفة */}
        <button
          onClick={e => { e.stopPropagation(); onArchive(student); }}
          disabled={archiving}
          className="w-full inline-flex items-center justify-center gap-2 text-[11px] font-black py-2 rounded-xl bg-white/90 hover:bg-white active:scale-95 transition-all disabled:opacity-60 disabled:cursor-not-allowed shadow-md"
          style={{ color: isHigh ? '#1d4ed8' : '#059669' }}
        >
          {archiving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Archive className="w-3.5 h-3.5" />}
          {archiving ? 'جارٍ الأرشفة…' : 'أرشفة هذا الطالب'}
        </button>
      </div>
    </div>
  );
}

// ──────────────────────────────────────────────
export default function StudentFinancePage() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const [students, setStudents] = useState<Student[]>(() => {
    if (typeof window === 'undefined') return [];
    try {
      const stored = sessionStorage.getItem('alqeema_students_cache');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed.data) && parsed.data.length > 0) {
          return parsed.data;
        }
      }
    } catch {}
    return [];
  });
  const studentsMap = useMemo(() => new Map(students.map(s => [s.id, s])), [students]);
  const [loading, setLoading] = useState<boolean>(() => students.length === 0);
  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState('');
  type FinanceTab = 'all' | 'debt' | 'paid' | 'suspended' | 'prev_debts';
  const [statusFilter, setStatusFilter] = useState<FinanceTab>('all');
  const [semesterFilter, setSemesterFilter] = useState<string>('all');
  const [diplomaFilter, setDiplomaFilter] = useState<string>('all');
  const [specializationFilter, setSpecializationFilter] = useState<string>('all');
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [showPrevDebts, setShowPrevDebts] = useState(false);
  // حالة الديون السابقة المضمنة في البطاقة
  const [prevDebts, setPrevDebts] = useState<PreviousDebtRow[]>([]);
  const [loadingPrevDebts, setLoadingPrevDebts] = useState(false);
  const [prevDebtsSearch, setPrevDebtsSearch] = useState('');
  const [prevDebtsDiploma, setPrevDebtsDiploma] = useState('all');
  const [prevDebtsSpec, setPrevDebtsSpec] = useState('all');
  const [expandedPrevStudentId, setExpandedPrevStudentId] = useState<string | null>(null);

  const fetchPrevDebts = useCallback(async () => {
    setLoadingPrevDebts(true);
    try {
      const data = await getPreviousDebts();
      setPrevDebts(data);
    } catch {
      toast.error('فشل تحميل الديون السابقة');
    } finally {
      setLoadingPrevDebts(false);
    }
  }, []);

  // خيارات تخصصات الديون السابقة
  const prevDebtsSpecOptions = useMemo(() =>
    prevDebtsDiploma !== 'all'
      ? (SPECIALIZATIONS_BY_DIPLOMA[prevDebtsDiploma] ?? [])
      : [...new Set(Object.values(SPECIALIZATIONS_BY_DIPLOMA).flat())].sort(),
  [prevDebtsDiploma]);

  // تصفية وتجميع الديون السابقة وحساب الإجماليات مرة واحدة لسرعة فائقة
  const groupedPrevDebts = useMemo(() => {
    let list = prevDebts;
    if (prevDebtsDiploma !== 'all') list = list.filter(r => r.diploma_type === prevDebtsDiploma);
    if (prevDebtsSpec !== 'all') list = list.filter(r => r.specialization === prevDebtsSpec);
    if (prevDebtsSearch.trim()) {
      list = list.filter(r =>
        matchSearch(r.full_name, prevDebtsSearch) ||
        matchSearch(r.national_id, prevDebtsSearch) ||
        matchSearch(r.specialization, prevDebtsSearch)
      );
    }
    const map = new Map<string, { info: PreviousDebtRow; charges: PreviousDebtRow[]; totalRemaining: number }>();
    for (const r of list) {
      let g = map.get(r.student_id);
      if (!g) {
        g = { info: r, charges: [], totalRemaining: 0 };
        map.set(r.student_id, g);
      }
      g.charges.push(r);
      g.totalRemaining += r.remaining;
    }
    const result = Array.from(map.values());
    result.sort((a, b) => b.totalRemaining - a.totalRemaining);
    return result;
  }, [prevDebts, prevDebtsDiploma, prevDebtsSpec, prevDebtsSearch]);

  const totalPrevDebtsAmount = useMemo(
    () => groupedPrevDebts.reduce((s, g) => s + g.totalRemaining, 0),
    [groupedPrevDebts]
  );

  // نظام التحميل التدريجي لسجل الديون السابقة
  const PREV_DEBTS_CHUNK = 18;
  const [prevDebtsVisibleCount, setPrevDebtsVisibleCount] = useState<number>(PREV_DEBTS_CHUNK);

  useEffect(() => {
    setPrevDebtsVisibleCount(PREV_DEBTS_CHUNK);
  }, [prevDebtsSearch, prevDebtsDiploma, prevDebtsSpec]);

  const displayedPrevDebts = useMemo(() => {
    return groupedPrevDebts.slice(0, prevDebtsVisibleCount);
  }, [groupedPrevDebts, prevDebtsVisibleCount]);

  const hasMorePrevDebts = prevDebtsVisibleCount < groupedPrevDebts.length;
  const prevDebtsProgress = groupedPrevDebts.length > 0
    ? Math.min(100, Math.round((displayedPrevDebts.length / groupedPrevDebts.length) * 100))
    : 100;

  // طباعة كشف الديون السابقة المضمن
  const handlePrintPrevDebts = () => {
    if (groupedPrevDebts.length === 0) {
      toast.error('لا توجد ديون سابقة للطباعة');
      return;
    }
    const cols = ['#', 'اسم الطالب', 'الرقم الوطني', 'الدبلوم', 'التخصص', 'الفصل الحالي', 'المبلغ المتبقي', 'الفصول غير المسددة'];
    const rows = groupedPrevDebts.map((g, i) => {
      const remaining = g.totalRemaining;
      const sems = g.charges.map(c => SEMESTER_LABELS[c.semester_number] ?? `ف${c.semester_number}`).join('، ');
      return [
        i + 1,
        g.info.full_name,
        g.info.national_id ?? '—',
        g.info.diploma_type,
        g.info.specialization ?? '—',
        SEMESTER_LABELS[g.info.current_semester] ?? `الفصل ${g.info.current_semester}`,
        remaining.toLocaleString('ar-LY', { maximumFractionDigits: 0 }) + ' د.ل',
        sems,
      ];
    });
    const totalRow = ['', `الإجمالي: ${groupedPrevDebts.length} طالب`, '', '', '', '', totalPrevDebtsAmount.toLocaleString('ar-LY', { maximumFractionDigits: 0 }) + ' د.ل', ''];
    printCustom({
      title: 'كشف الديون والمستحقات السابقة',
      accentColor: '#7c3aed',
      sig1: 'الشؤون المالية',
      sig2: 'المدير العام',
      bodyHtml: `
        <div class="hdr">
          <div class="hdr-logo"><img src="${LOGO_URL}" alt="شعار" crossorigin="anonymous"/></div>
          <div class="hdr-text">
            <div class="inst-name">${INSTITUTE_NAME}</div>
            <div class="sub1">كشف الديون والمستحقات عن الفصول السابقة</div>
            <div class="sub2">إجمالي المطالبين: ${groupedPrevDebts.length} طالب | إجمالي المبلغ المتبقي: ${totalPrevDebtsAmount.toLocaleString('ar-LY')} د.ل</div>
          </div>
          <div class="hdr-meta">
            <div>التاريخ: <b>${new Date().toLocaleDateString('ar-LY')}</b></div>
          </div>
        </div>
        <table style="width:100%;border-collapse:collapse;margin-top:10px">
          <thead>
            <tr style="background:#7c3aed;color:#fff;-webkit-print-color-adjust:exact">
              ${cols.map(c => `<th style="padding:6px 8px;font-size:10px;text-align:right;border:1px solid #ddd">${c}</th>`).join('')}
            </tr>
          </thead>
          <tbody>
            ${rows.map((row, ri) => `
              <tr style="${ri % 2 === 1 ? 'background:#fbf7ff' : ''}">
                ${row.map(cell => `<td style="padding:6px 8px;font-size:10px;text-align:right;border:1px solid #ddd">${cell}</td>`).join('')}
              </tr>
            `).join('')}
            <tr style="background:#ede9fe;font-weight:bold;-webkit-print-color-adjust:exact">
              ${totalRow.map(cell => `<td style="padding:7px 8px;font-size:11px;text-align:right;border:1px solid #bbb">${cell}</td>`).join('')}
            </tr>
          </tbody>
        </table>
      `,
    });
  };

  // لوحة الطلاب الجاهزين للأرشفة
  const [pendingArchive, setPendingArchive] = useState<Student[]>(() => {
    if (typeof window === 'undefined') return [];
    try {
      const p = sessionStorage.getItem('alqeema_pending_archive_cache');
      if (p) {
        const parsed = JSON.parse(p);
        return parsed.data ?? parsed;
      }
    } catch {}
    return [];
  });
  const [archivePanelOpen, setArchivePanelOpen] = useState(true);
  // حالة نافذة تأكيد الأرشفة
  const [archiveConfirm, setArchiveConfirm] = useState<Student | null>(null);   // null = مغلقة
  const [archivingId, setArchivingId] = useState<string | null>(null);           // id الطالب قيد الأرشفة
  const [archivingAll, setArchivingAll] = useState(false);                        // أرشفة الكل
  // اختيار طلاب للأرشفة الجماعية
  const [selectedForArchive, setSelectedForArchive] = useState<Set<string>>(new Set());
  const [archiveBatchConfirm, setArchiveBatchConfirm] = useState(false);
  const [auditDialogOpen, setAuditDialogOpen] = useState(false);
  const searchTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const DISPLAY_CHUNK_SIZE = 18;
  const [visibleCount, setVisibleCount] = useState<number>(DISPLAY_CHUNK_SIZE);
  // حفظ id الطالب المطلوب من الـ URL لاستخدامه بعد تحميل البيانات
  const targetStudentId = searchParams.get('student');

  const fetchStudents = useCallback(async () => {
    if (students.length === 0) setLoading(true);
    try {
      // جلب جميع الطلاب مع الطلاب الجاهزين للأرشفة بالتوازي بأمان تام وسرعة فائقة
      const [{ data }, pending] = await Promise.all([
        getStudents({
          limit: 12000,
          offset: 0,
          fields: 'id, full_name, national_id, phone, diploma_type, specialization, current_semester, status, total_charged, total_paid, is_exam_only, registration_number, photo_url'
        }),
        getPendingArchiveStudents(),
      ]);
      setStudents(data);
      setPendingArchive(pending);
    } catch (err) {
      console.error('Error fetching students in finance page:', err);
      toast.error('خطأ في تحميل الطلاب');
    }
    finally { setLoading(false); }
  }, [students.length]);

  useEffect(() => { fetchStudents(); }, [fetchStudents]);

  // بعد تحميل الطلاب: إذا كان هناك ?student=id في الـ URL افتح بطاقته تلقائياً
  useEffect(() => {
    if (!targetStudentId || loading || students.length === 0) return;
    const found = students.find(s => s.id === targetStudentId);
    if (found) {
      setSelectedStudent(found);
      // مسح الـ param من الـ URL بدون reload
      setSearchParams(prev => { prev.delete('student'); return prev; });
    }
  }, [targetStudentId, loading, students, setSearchParams]);

  // بحث فوري بالحرف والتدقيق العربي
  const handleSearchChange = (v: string) => {
    setSearchInput(v);
    if (searchTimer.current) clearTimeout(searchTimer.current);
    searchTimer.current = setTimeout(() => setSearch(v), 50);
  };

  // ── أرشفة طالب واحد ──
  const handleArchiveSingle = async (student: Student) => {
    setArchivingId(student.id);
    try {
      await archiveStudent(student);
      toast.success(`تمت أرشفة ${student.full_name} بنجاح`);
      setPendingArchive(prev => prev.filter(s => s.id !== student.id));
      setStudents(prev => prev.filter(s => s.id !== student.id));
      setSelectedForArchive(prev => { const n = new Set(prev); n.delete(student.id); return n; });
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : 'فشلت الأرشفة');
    } finally {
      setArchivingId(null);
      setArchiveConfirm(null);
    }
  };

  // ── أرشفة مجموعة (الكل أو المختارين) ──
  const handleArchiveBatch = async (targets: Student[]) => {
    setArchivingAll(true);
    let successCount = 0;
    const failed: string[] = [];
    for (const student of targets) {
      try {
        await archiveStudent(student);
        successCount++;
        setPendingArchive(prev => prev.filter(s => s.id !== student.id));
        setStudents(prev => prev.filter(s => s.id !== student.id));
      } catch {
        failed.push(student.full_name);
      }
    }
    setArchivingAll(false);
    setArchiveBatchConfirm(false);
    setArchiveConfirm(null);
    setSelectedForArchive(new Set());
    if (successCount > 0) toast.success(`تمت أرشفة ${successCount} طالب بنجاح`);
    if (failed.length > 0) toast.error(`فشلت أرشفة: ${failed.join('، ')}`);
  };

  // toggle اختيار طالب للأرشفة الجماعية
  const toggleSelectForArchive = (id: string) => {
    setSelectedForArchive(prev => {
      const n = new Set(prev);
      n.has(id) ? n.delete(id) : n.add(id);
      return n;
    });
  };
  const toggleSelectAll = () => {
    if (selectedForArchive.size === pendingArchive.length)
      setSelectedForArchive(new Set());
    else
      setSelectedForArchive(new Set(pendingArchive.map(s => s.id)));
  };

  const filteredStudents = useMemo(() => {
    let list = students;
    if (search.trim()) {
      list = list.filter(s => matchStudent(s, search));
    }
    if (semesterFilter !== 'all') list = list.filter(s => String(s.current_semester) === semesterFilter);
    if (diplomaFilter !== 'all') list = list.filter(s => s.diploma_type === diplomaFilter);
    if (specializationFilter !== 'all') list = list.filter(s => s.specialization === specializationFilter);
    if (statusFilter === 'debt') list = list.filter(s => s.total_charged - s.total_paid > 0);
    if (statusFilter === 'paid') list = list.filter(s => s.total_charged - s.total_paid <= 0);
    if (statusFilter === 'suspended') list = list.filter(s => s.status === 'موقوف قيد');
    return list;
  }, [students, search, semesterFilter, diplomaFilter, specializationFilter, statusFilter]);

  // إعادة تعيين عدد الطلاب المعروضين عند تغيير الفلاتر أو البحث
  useEffect(() => {
    setVisibleCount(DISPLAY_CHUNK_SIZE);
  }, [search, statusFilter, semesterFilter, diplomaFilter, specializationFilter]);

  const totalFiltered = filteredStudents.length;
  const displayedStudents = useMemo(() => {
    return filteredStudents.slice(0, visibleCount);
  }, [filteredStudents, visibleCount]);
  const hasMoreStudents = visibleCount < totalFiltered;
  const loadMoreProgress = totalFiltered > 0
    ? Math.min(100, Math.round((displayedStudents.length / totalFiltered) * 100))
    : 100;

  // قائمة التخصصات الثابتة — تتصفى حسب الدبلوم المختار
  const specializationOptions = useMemo(() =>
    diplomaFilter !== 'all'
      ? (SPECIALIZATIONS_BY_DIPLOMA[diplomaFilter] ?? [])
      : [...new Set(Object.values(SPECIALIZATIONS_BY_DIPLOMA).flat())].sort(),
  [diplomaFilter]);

  const hasActiveFilters = semesterFilter !== 'all' || diplomaFilter !== 'all' || specializationFilter !== 'all';
  const clearDropdownFilters = () => { setSemesterFilter('all'); setDiplomaFilter('all'); setSpecializationFilter('all'); };

  // إحصاءات
  const stats = useMemo(() => {
    const totalCharged = students.reduce((s, x) => s + x.total_charged, 0);
    const totalPaid = students.reduce((s, x) => s + x.total_paid, 0);
    const withDebt = students.filter(s => s.total_charged - s.total_paid > 0).length;
    const totalDebt = students.reduce((s, x) => s + Math.max(0, x.total_charged - x.total_paid), 0);
    return { totalCharged, totalPaid, withDebt, totalDebt };
  }, [students]);

  // تصدير Excel
  const handleExportExcel = () => {
    if (filteredStudents.length === 0) { toast.error('لا توجد بيانات للتصدير'); return; }

    const totalStudents = filteredStudents.length;
    const withDebt      = filteredStudents.filter(s => s.total_charged - s.total_paid > 0).length;
    const fullyPaid     = totalStudents - withDebt;
    const suspended     = filteredStudents.filter(s => s.status === 'موقوف قيد').length;
    const totalCharged  = filteredStudents.reduce((a, s) => a + s.total_charged, 0);
    const totalPaid     = filteredStudents.reduce((a, s) => a + s.total_paid, 0);
    const totalDebt     = totalCharged - totalPaid;
    const collRate      = totalCharged > 0 ? Math.round((totalPaid / totalCharged) * 100) : 0;

    const filterLabel =
      statusFilter === 'debt'      ? 'ديون'    :
      statusFilter === 'paid'      ? 'مسددون'  :
      statusFilter === 'suspended' ? 'موقوفون' : 'الكل';

    const safeLabel =
      statusFilter === 'debt'      ? 'debt'      :
      statusFilter === 'paid'      ? 'paid'      :
      statusFilter === 'suspended' ? 'suspended' : 'all';

    const cols = ['#', 'الاسم الرباعي', 'الرقم الوطني', 'الهاتف', 'التخصص', 'الدبلوم', 'الفصل', 'الحالة', 'المستحق (د.ل)', 'المدفوع (د.ل)', 'المتبقي (د.ل)', '% التحصيل'];
    const rows = filteredStudents.map((s, i) => {
      const debt = s.total_charged - s.total_paid;
      const pct  = s.total_charged > 0 ? Math.round((s.total_paid / s.total_charged) * 100) : 100;
      return [i + 1, s.full_name, s.national_id, s.phone ?? '', s.specialization, s.diploma_type, SEMESTER_LABELS[s.current_semester] ?? `الفصل ${s.current_semester}`, s.status, s.total_charged, s.total_paid, debt, pct];
    });
    const totalRow = ['', `الإجمالي — ${totalStudents} طالب`, '', '', '', '', '', `${fullyPaid} مسدد / ${withDebt} دين`, totalCharged, totalPaid, totalDebt, collRate];

    exportExcel({
      title: `الإدارة المالية — كشف الطلاب (${filterLabel})`,
      subtitle: `إجمالي: ${totalStudents} طالب | مسددون: ${fullyPaid} | عليهم ديون: ${withDebt} | موقوف قيد: ${suspended} | نسبة التحصيل: ${collRate}%`,
      columns: cols,
      rows,
      totalRow,
      filename: `finance-alqimma-${safeLabel}-${new Date().toISOString().slice(0, 10)}`,
      sheetName: 'الكشف الشامل',
    });
    toast.success(`تم تصدير ${totalStudents} طالب — ${filterLabel} ✓`);
  };

  // طباعة / تصدير PDF
  const handleExportPDF = () => {
    if (filteredStudents.length === 0) { toast.error('لا توجد بيانات للطباعة'); return; }

    const totalStudents = filteredStudents.length;
    const withDebt      = filteredStudents.filter(s => s.total_charged - s.total_paid > 0).length;
    const fullyPaid     = totalStudents - withDebt;
    const suspended     = filteredStudents.filter(s => s.status === 'موقوف قيد').length;
    const totalCharged  = filteredStudents.reduce((a, s) => a + s.total_charged, 0);
    const totalPaid     = filteredStudents.reduce((a, s) => a + s.total_paid, 0);
    const totalDebt     = totalCharged - totalPaid;
    const collRate      = totalCharged > 0 ? Math.round((totalPaid / totalCharged) * 100) : 0;

    const cols = ['#', 'الاسم الرباعي', 'الرقم الوطني', 'التخصص', 'الدبلوم', 'الفصل', 'الحالة', 'المستحق', 'المدفوع', 'المتبقي'];
    const rows = filteredStudents.map((s, i) => {
      const debt = s.total_charged - s.total_paid;
      return [i + 1, s.full_name, s.national_id, s.specialization, s.diploma_type,
        SEMESTER_LABELS[s.current_semester] ?? `ف${s.current_semester}`,
        s.status,
        s.total_charged.toLocaleString('ar-LY', { maximumFractionDigits: 0 }),
        s.total_paid.toLocaleString('ar-LY', { maximumFractionDigits: 0 }),
        debt <= 0 ? '✓ مسدد' : debt.toLocaleString('ar-LY', { maximumFractionDigits: 0 }),
      ];
    });
    const totalRow = ['', `${totalStudents} طالب`, `${withDebt} دين / ${suspended} موقوف`, '', '', '', `${collRate}%`,
      totalCharged.toLocaleString('ar-LY', { maximumFractionDigits: 0 }),
      totalPaid.toLocaleString('ar-LY', { maximumFractionDigits: 0 }),
      totalDebt > 0 ? totalDebt.toLocaleString('ar-LY', { maximumFractionDigits: 0 }) : '✓ مسدد الكل',
    ];

    const safeLabel = statusFilter === 'debt' ? 'debt' : statusFilter === 'paid' ? 'paid' : statusFilter === 'suspended' ? 'suspended' : 'all';

    printCustom({
      title: 'الإدارة المالية — كشف الطلاب الشامل',
      accentColor: '#065f46',
      sig1: 'مدير الشؤون المالية',
      sig2: 'اعتماد المدير العام',
      bodyHtml: `
        <div class="hdr">
          <div class="hdr-logo"><img src="${LOGO_URL}" alt="شعار" crossorigin="anonymous"/></div>
          <div class="hdr-text">
            <div class="inst-name">${INSTITUTE_NAME}</div>
            <div class="sub1">الإدارة المالية — كشف الطلاب الشامل</div>
            <div class="sub2">إجمالي: ${totalStudents} طالب | مسددون: ${fullyPaid} | ديون: ${withDebt} | نسبة التحصيل: ${collRate}%</div>
          </div>
          <div class="hdr-meta">
            <div>تاريخ الطباعة: <b>${new Date().toLocaleDateString('ar-LY')}</b></div>
            <div>الوقت: <b>${new Date().toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit' })}</b></div>
          </div>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px">
          ${[
            { label: 'المستحق', val: totalCharged.toLocaleString('ar-LY', { maximumFractionDigits: 0 }) + ' د.ل', color: '#1d4ed8' },
            { label: 'المحصَّل', val: totalPaid.toLocaleString('ar-LY', { maximumFractionDigits: 0 }) + ' د.ل',   color: '#15803d' },
            { label: 'المتبقي',  val: totalDebt.toLocaleString('ar-LY', { maximumFractionDigits: 0 }) + ' د.ل',   color: totalDebt > 0 ? '#dc2626' : '#15803d' },
            { label: 'نسبة التحصيل', val: collRate + '%', color: '#7c3aed' },
            { label: 'مسددون',   val: fullyPaid + ' طالب', color: '#15803d' },
            { label: 'ديون',     val: withDebt + ' طالب',  color: '#dc2626' },
          ].map(c => `<div style="flex:1;min-width:90px;background:#f8faff;border:1px solid #e2e8f0;border-radius:8px;padding:7px 10px;text-align:center">
            <div style="font-size:8px;color:#6b7280;font-weight:600;margin-bottom:2px">${c.label}</div>
            <div style="font-size:12px;font-weight:900;color:${c.color}">${c.val}</div>
          </div>`).join('')}
        </div>
        <table style="width:100%;border-collapse:collapse">
          <thead><tr style="background:linear-gradient(90deg,#064e3b,#065f46);-webkit-print-color-adjust:exact;print-color-adjust:exact">
            ${cols.map(c => `<th style="color:#fff;padding:8px 7px;font-size:9.5px;font-weight:700;text-align:right;white-space:nowrap;border-left:1px solid rgba(255,255,255,0.1)">${c}</th>`).join('')}
          </tr></thead>
          <tbody>
            ${rows.map((row, ri) => `<tr style="${ri % 2 === 1 ? 'background:#f0fdf9' : ''}">
              ${row.map((cell, ci) => {
                const isDebt = ci === 9 && String(cell) !== '✓ مسدد';
                const isPaid = ci === 9 && String(cell) === '✓ مسدد';
                const style = isDebt ? 'color:#dc2626;font-weight:800' : isPaid ? 'color:#16a34a;font-weight:800' : ci === 8 ? 'color:#15803d;font-weight:700' : '';
                return `<td style="padding:6px 7px;border-bottom:1px solid #e2e8f0;font-size:10px;text-align:right;white-space:nowrap;${style}">${cell}</td>`;
              }).join('')}
            </tr>`).join('')}
            <tr style="background:#dcfce7;-webkit-print-color-adjust:exact;print-color-adjust:exact">
              ${totalRow.map(c => `<td style="padding:8px 7px;font-size:11px;font-weight:800;text-align:right;border-top:2px solid #065f46">${c}</td>`).join('')}
            </tr>
          </tbody>
        </table>`,
    });

    // تنزيل Excel إضافي بنفس الوقت
    exportExcel({ title: 'كشف الطلاب المالي', columns: cols, rows, totalRow, filename: `finance-alqimma-${safeLabel}-${new Date().toISOString().slice(0, 10)}` });
    toast.success('جارٍ فتح نافذة الطباعة — يمكنك اختيار "حفظ كـ PDF"');
  };

  const filterTabs = [
    {
      key: 'all' as const,
      label: 'الكل',
      icon: Users,
      activeClass: 'bg-gradient-to-r from-blue-700 via-indigo-700 to-slate-900 text-white shadow-lg shadow-blue-900/35 border-blue-400/50 ring-2 ring-white/20',
      iconClass: 'text-white',
      inactiveClass: 'bg-background hover:bg-blue-50/70 dark:hover:bg-blue-950/25 text-foreground/85 hover:text-blue-700 dark:hover:text-blue-300 border-border/80 hover:border-blue-400/50 shadow-xs',
      inactiveIconClass: 'text-blue-600 dark:text-blue-400',
      topAccent: 'from-blue-600 via-indigo-600 to-sky-500',
      headerTitle: 'كشف جميع الطلاب المسجلين',
      headerDesc: 'عرض جميع الطلاب مع إمكانية التصفية، البحث، ومتابعة السجلات المالية',
      headerIconBg: 'bg-blue-500/15 text-blue-600 dark:text-blue-400 border border-blue-500/30',
    },
    {
      key: 'debt' as const,
      label: 'عليهم ديون',
      icon: AlertTriangle,
      activeClass: 'bg-gradient-to-r from-rose-600 via-red-700 to-rose-950 text-white shadow-lg shadow-rose-900/35 border-rose-400/50 ring-2 ring-white/20',
      iconClass: 'text-white',
      inactiveClass: 'bg-background hover:bg-rose-50/70 dark:hover:bg-rose-950/25 text-foreground/85 hover:text-rose-700 dark:hover:text-rose-300 border-border/80 hover:border-rose-400/50 shadow-xs',
      inactiveIconClass: 'text-rose-600 dark:text-rose-400',
      topAccent: 'from-rose-600 via-red-600 to-amber-500',
      headerTitle: 'كشف الطلاب الذين عليهم ديون ومتبقيات',
      headerDesc: 'حصر ومتابعة الطلاب المطالبين بسداد رسوم أو أقساط متبقية للفصل الحالي',
      headerIconBg: 'bg-rose-500/15 text-rose-600 dark:text-rose-400 border border-rose-500/30',
    },
    {
      key: 'paid' as const,
      label: 'مسددون',
      icon: CheckCircle2,
      activeClass: 'bg-gradient-to-r from-emerald-600 via-teal-700 to-emerald-950 text-white shadow-lg shadow-emerald-900/35 border-emerald-400/50 ring-2 ring-white/20',
      iconClass: 'text-white',
      inactiveClass: 'bg-background hover:bg-emerald-50/70 dark:hover:bg-emerald-950/25 text-foreground/85 hover:text-emerald-700 dark:hover:text-emerald-300 border-border/80 hover:border-emerald-400/50 shadow-xs',
      inactiveIconClass: 'text-emerald-600 dark:text-emerald-400',
      topAccent: 'from-emerald-600 via-teal-600 to-green-500',
      headerTitle: 'كشف الطلاب المسددين للرسوم بالكامل',
      headerDesc: 'الطلاب المستوفون لكافة الالتزامات المالية ولا توجد عليهم أي مديونية مسجلة',
      headerIconBg: 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30',
    },
    {
      key: 'suspended' as const,
      label: 'موقوف قيد',
      icon: UserX,
      activeClass: 'bg-gradient-to-r from-amber-600 via-amber-700 to-yellow-950 text-white shadow-lg shadow-amber-900/35 border-amber-400/50 ring-2 ring-white/20',
      iconClass: 'text-white',
      inactiveClass: 'bg-background hover:bg-amber-50/70 dark:hover:bg-amber-950/25 text-foreground/85 hover:text-amber-700 dark:hover:text-amber-300 border-border/80 hover:border-amber-400/50 shadow-xs',
      inactiveIconClass: 'text-amber-600 dark:text-amber-400',
      topAccent: 'from-amber-600 via-yellow-600 to-orange-500',
      headerTitle: 'كشف الطلاب موقوفي القيد',
      headerDesc: 'حصر الطلاب الذين تم إيقاف قيدهم الدراسي وتجميد حساباتهم مؤقتاً',
      headerIconBg: 'bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30',
    },
    {
      key: 'prev_debts' as const,
      label: 'ديون سابقة',
      icon: History,
      activeClass: 'bg-gradient-to-r from-purple-700 via-violet-700 to-indigo-950 text-white shadow-lg shadow-purple-900/35 border-purple-400/50 ring-2 ring-white/20',
      iconClass: 'text-white',
      inactiveClass: 'bg-background hover:bg-purple-50/70 dark:hover:bg-purple-950/25 text-foreground/85 hover:text-purple-700 dark:hover:text-purple-300 border-border/80 hover:border-purple-400/50 shadow-xs',
      inactiveIconClass: 'text-purple-600 dark:text-purple-400',
      topAccent: 'from-purple-600 via-violet-600 to-indigo-500',
      headerTitle: 'سجل الديون والمستحقات عن الفصول السابقة',
      headerDesc: 'متابعة المتبقيات المالية للفصول الدراسية السابقة للطلاب المستمرين وتفصيلها',
      headerIconBg: 'bg-purple-500/15 text-purple-600 dark:text-purple-400 border border-purple-500/30',
    },
  ];

  return (
    <>
    <MainLayout>
      <div className="space-y-4">

        {/* ── الترويسة ── */}
        <div className="relative rounded-2xl overflow-hidden shadow-lg">
          <div className="absolute inset-0 bg-gradient-to-br from-emerald-700/85 via-emerald-700/90 to-primary/80" />
          <div className="absolute inset-0 opacity-[0.06]"
            style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '24px 24px' }} />
          <div className="relative px-5 py-4 md:px-7 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <button onClick={() => navigate('/')}
                className="w-9 h-9 rounded-xl bg-white/15 border border-white/20 flex items-center justify-center shrink-0 hover:bg-white/25 transition-colors">
                <ChevronRight className="w-4 h-4 text-white" />
              </button>
              <div className="w-10 h-10 rounded-xl bg-white/15 border border-white/20 flex items-center justify-center shrink-0">
                <DollarSign className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-white">الإدارة المالية</h1>
                <p className="text-white/60 text-xs mt-0.5">إدارة الأقساط والوصلات لجميع الطلاب</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2 shrink-0">
              <button
                type="button"
                onClick={() => navigate('/supply-orders')}
                className="inline-flex items-center gap-1.5 h-9 px-3.5 rounded-xl text-[12px] font-semibold bg-white/20 text-white border border-white/25 hover:bg-white/30 active:scale-95 transition-all shadow-sm"
                title="الانتقال إلى صفحة أوامر التوريد لمتابعة الإيصالات وطباعة الأوامر"
              >
                <ClipboardList className="w-4 h-4" /> أوامر التوريد
              </button>
              <button
                type="button"
                onClick={() => setAuditDialogOpen(true)}
                className="inline-flex items-center gap-2 h-9 px-4 rounded-xl text-[12px] font-semibold bg-amber-500 text-white shadow-sm shadow-amber-500/25 hover:bg-amber-600 active:scale-95 transition-all"
                title="فحص وتدقيق السجلات المالية والمطابقة الشاملة"
              >
                <ShieldCheck className="w-4 h-4" /> التدقيق والمطابقة
              </button>
              <button onClick={handleExportExcel}
                className="inline-flex items-center gap-2 h-9 px-4 rounded-xl text-[12px] font-semibold bg-emerald-500 text-white shadow-sm shadow-emerald-500/25 hover:bg-emerald-600 active:scale-95 transition-all">
                <FileSpreadsheet className="w-4 h-4" /> Excel
              </button>
              <button onClick={handleExportPDF}
                className="inline-flex items-center gap-2 h-9 px-4 rounded-xl text-[12px] font-semibold bg-blue-600 text-white shadow-sm shadow-blue-600/30 hover:bg-blue-700 active:scale-95 transition-all">
                <FileDown className="w-4 h-4" /> طباعة PDF
              </button>
              <RefreshButton
                onRefresh={fetchStudents}
                loading={loading}
                variant="white"
                label="تحديث"
                className="h-9 rounded-xl text-[12px] font-semibold"
              />
            </div>
          </div>
        </div>

        {/* ── بطاقات الإحصاءات المالية ── */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          <StatCard label="إجمالي المستحق" value={`${(stats.totalCharged / 1000).toFixed(1)}k`} sub="دينار ليبي" color="bg-gradient-to-br from-primary/75 to-primary border-primary/20" />
          <StatCard label="إجمالي المحصل" value={`${(stats.totalPaid / 1000).toFixed(1)}k`} sub="دينار ليبي" color="bg-gradient-to-br from-chart-2/75 to-chart-2 border-chart-2/20" />
          <StatCard label="إجمالي الديون" value={`${(stats.totalDebt / 1000).toFixed(1)}k`} sub="دينار ليبي" color="bg-gradient-to-br from-destructive/70 to-destructive border-destructive/20" />
          <StatCard label="طلاب بديون" value={`${stats.withDebt}`} sub={`من ${students.length} طالب`} color="bg-gradient-to-br from-amber-500/70 to-amber-500 border-amber-500/20" />
        </div>

        {/* ── لوحة الطلاب الجاهزين للأرشفة ── */}
        <AnimatePresence mode="wait">
          {pendingArchive.length > 0 && (
            <motion.div
              key="archive-panel"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.3, ease: [0.25, 0.46, 0.45, 0.94] }}
            >
              <div className="rounded-2xl border border-emerald-300/50 dark:border-emerald-600/40 bg-white dark:bg-card shadow-sm overflow-hidden">

                {/* رأس اللوحة */}
                <button
                  onClick={() => setArchivePanelOpen(v => !v)}
                  className="w-full flex items-center justify-between px-5 py-3.5 bg-gradient-to-l from-emerald-50/80 to-emerald-100/40 dark:from-emerald-950/60 dark:to-emerald-900/30 hover:from-emerald-100/80 hover:to-emerald-50/60 transition-colors border-b border-emerald-200/50 dark:border-emerald-700/40"
                >
                  <div className="flex items-center gap-3">
                    {/* أيقونة مع badge عدد */}
                    <div className="relative shrink-0">
                      <div className="w-9 h-9 rounded-xl bg-emerald-500 flex items-center justify-center shadow-sm shadow-emerald-300/50">
                        <Archive className="w-4.5 h-4.5 text-white" style={{ width: '18px', height: '18px' }} />
                      </div>
                      <span className="absolute -top-1.5 -left-1.5 min-w-[18px] h-[18px] bg-amber-400 text-white text-[9px] font-black rounded-full flex items-center justify-center px-1 shadow border border-white dark:border-card">
                        {pendingArchive.length}
                      </span>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold text-foreground leading-tight">
                        طلاب جاهزون للأرشفة
                      </p>
                      <p className="text-[10px] text-muted-foreground mt-0.5">
                        سيُؤرشفون تلقائياً بعد 24 ساعة من اكتمال السداد — يمكن الأرشفة اليدوية الآن
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="hidden md:inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-100 dark:bg-emerald-900/50 border border-emerald-200/60 dark:border-emerald-700/50 px-2.5 py-1 rounded-full">
                      <CheckCircle2 className="w-3 h-3" />
                      {pendingArchive.length} طالب مكتمل السداد
                    </span>
                    {/* زر أرشفة المختارين / الكل */}
                    {selectedForArchive.size > 0 ? (
                      <button
                        onClick={e => { e.stopPropagation(); setArchiveBatchConfirm(true); }}
                        disabled={archivingAll}
                        className="hidden md:inline-flex items-center gap-1.5 text-[10px] font-bold px-3 py-1.5 rounded-xl bg-emerald-500 text-white hover:bg-emerald-600 active:scale-95 transition-all disabled:opacity-60 shadow-sm"
                      >
                        {archivingAll ? <Loader2 className="w-3 h-3 animate-spin" /> : <Archive className="w-3 h-3" />}
                        أرشفة المختارين ({selectedForArchive.size})
                      </button>
                    ) : (
                      <button
                        onClick={e => { e.stopPropagation(); setArchiveBatchConfirm(true); }}
                        disabled={archivingAll}
                        className="hidden md:inline-flex items-center gap-1.5 text-[10px] font-bold px-3 py-1.5 rounded-xl bg-emerald-500 text-white hover:bg-emerald-600 active:scale-95 transition-all disabled:opacity-60 shadow-sm"
                      >
                        {archivingAll ? <Loader2 className="w-3 h-3 animate-spin" /> : <Archive className="w-3 h-3" />}
                        أرشفة الكل
                      </button>
                    )}
                    <motion.div
                      animate={{ rotate: archivePanelOpen ? 180 : 0 }}
                      transition={{ duration: 0.25, ease: 'easeInOut' }}
                    >
                      <ChevronDown className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                    </motion.div>
                  </div>
                </button>

                {/* قائمة الطلاب — accordion سلس بـ grid-rows */}
                <motion.div
                  initial={false}
                  animate={{
                    gridTemplateRows: archivePanelOpen ? '1fr' : '0fr',
                    opacity: archivePanelOpen ? 1 : 0,
                  }}
                  transition={{ duration: 0.3, ease: [0.25, 0.46, 0.45, 0.94] }}
                  style={{ display: 'grid' }}
                >
                  <div className="overflow-hidden">
                    <motion.div
                      className="p-4"
                      animate={{ opacity: archivePanelOpen ? 1 : 0 }}
                      transition={{ duration: 0.2, delay: archivePanelOpen ? 0.1 : 0 }}
                    >
                      {/* شريط الاختيار الجماعي */}
                      <div className="flex items-center justify-between mb-3 gap-2">
                        <button
                          onClick={e => { e.stopPropagation(); toggleSelectAll(); }}
                          className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-emerald-700 dark:text-emerald-300 hover:underline"
                        >
                          <span className={`inline-flex items-center justify-center w-4 h-4 rounded border-2 transition-all ${selectedForArchive.size === pendingArchive.length ? 'bg-emerald-500 border-emerald-500' : 'border-emerald-400 bg-white dark:bg-transparent'}`} style={{ width: '16px', height: '16px' }}>
                            {selectedForArchive.size === pendingArchive.length && (
                              <svg viewBox="0 0 12 12" className="w-2.5 h-2.5 text-white fill-current">
                                <path d="M2 6l3 3 5-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none" />
                              </svg>
                            )}
                          </span>
                          {selectedForArchive.size === pendingArchive.length ? 'إلغاء تحديد الكل' : 'تحديد الكل'}
                        </button>
                        {selectedForArchive.size > 0 && (
                          <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold">
                            {selectedForArchive.size} طالب محدد
                          </span>
                        )}
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
                        {pendingArchive.map((s, i) => (
                          <motion.div
                            key={s.id}
                            initial={{ opacity: 0, y: 8 }}
                            animate={{
                              opacity: archivePanelOpen ? 1 : 0,
                              y: archivePanelOpen ? 0 : 8,
                            }}
                            transition={{
                              duration: 0.25,
                              delay: archivePanelOpen ? 0.1 + i * 0.05 : 0,
                              ease: 'easeOut',
                            }}
                          >
                            <ArchiveReadyCard
                              student={s}
                              onOpen={st => setSelectedStudent(st)}
                              onArchive={st => setArchiveConfirm(st)}
                              archiving={archivingId === s.id}
                              selected={selectedForArchive.has(s.id)}
                              onToggleSelect={toggleSelectAll.length > 0 ? toggleSelectForArchive : toggleSelectForArchive}
                            />
                          </motion.div>
                        ))}
                      </div>
                    </motion.div>
                  </div>
                </motion.div>

              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ── شريط تبويبات التصفية الاحترافي والمنسق (بدون أرقام داخل الأزرار) ── */}
        <div className="bg-muted/40 dark:bg-card/60 p-1.5 md:p-2 rounded-2xl border border-border/60 shadow-sm backdrop-blur-sm">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-1.5 md:gap-2">
            {filterTabs.map((tab, idx) => {
              const isActive = statusFilter === tab.key;
              const Icon = tab.icon;
              return (
                <button
                  key={tab.key}
                  type="button"
                  onClick={() => {
                    setStatusFilter(tab.key);
                    if (tab.key === 'prev_debts' && prevDebts.length === 0) {
                      fetchPrevDebts();
                    }
                  }}
                  className={`relative flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl font-bold text-xs md:text-sm transition-all duration-200 select-none border ${
                    idx === 4 ? 'col-span-2 sm:col-span-1 md:col-span-1' : ''
                  } ${
                    isActive
                      ? `${tab.activeClass} scale-[1.02]`
                      : `${tab.inactiveClass}`
                  }`}
                >
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? tab.iconClass : tab.inactiveIconClass}`} />
                  <span className="truncate">{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* ── بطاقة البيانات التفاعلية الاحترافية المنسقة مع الهاتف والكمبيوتر ── */}
        <Card className="shadow-lg border-border/70 overflow-hidden rounded-2xl bg-card relative">
          {/* شريط الألوان العلوي المتوافق مع التبويب النشط */}
          <div className={`h-1.5 w-full bg-gradient-to-r ${filterTabs.find(t => t.key === statusFilter)?.topAccent ?? 'from-primary to-accent'} transition-all duration-300`} />

          {/* ترويسة البطاقة الفخمة */}
          <div className="px-4 py-3.5 md:px-6 md:py-4 border-b border-border/60 bg-gradient-to-l from-muted/40 via-muted/15 to-transparent flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 shadow-sm ${filterTabs.find(t => t.key === statusFilter)?.headerIconBg}`}>
                {(() => {
                  const current = filterTabs.find(t => t.key === statusFilter);
                  const Icon = current?.icon ?? Users;
                  return <Icon className="w-5 h-5" />;
                })()}
              </div>
              <div>
                <h2 className="text-sm md:text-base font-bold text-foreground">
                  {filterTabs.find(t => t.key === statusFilter)?.headerTitle}
                </h2>
                <p className="text-[11px] text-muted-foreground mt-0.5">
                  {filterTabs.find(t => t.key === statusFilter)?.headerDesc}
                </p>
              </div>
            </div>

            {/* شارات الإحصاءات والمعلومات السريعة داخل البطاقة */}
            <div className="flex items-center gap-2 self-start sm:self-auto shrink-0 flex-wrap">
              {statusFilter !== 'prev_debts' ? (
                <>
                  <span className="text-xs px-2.5 py-1 rounded-lg bg-muted text-foreground font-semibold border border-border/40">
                    {loading ? 'جارٍ التحميل…' : `${filteredStudents.length} طالب`}
                  </span>
                  {statusFilter === 'debt' && !loading && (
                    <span className="text-xs px-2.5 py-1 rounded-lg bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 font-bold border border-rose-200/50 dark:border-rose-800/40">
                      إجمالي الديون: {filteredStudents.reduce((a, s) => a + Math.max(0, s.total_charged - s.total_paid), 0).toLocaleString('ar-LY', { maximumFractionDigits: 0 })} د.ل
                    </span>
                  )}
                  {statusFilter === 'paid' && !loading && (
                    <span className="text-xs px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 font-bold border border-emerald-200/50 dark:border-emerald-800/40">
                      إجمالي المسدد: {filteredStudents.reduce((a, s) => a + s.total_paid, 0).toLocaleString('ar-LY', { maximumFractionDigits: 0 })} د.ل
                    </span>
                  )}
                </>
              ) : (
                <>
                  <span className="text-xs px-2.5 py-1 rounded-lg bg-violet-50 dark:bg-violet-950/40 text-violet-700 dark:text-violet-300 font-bold border border-violet-200/50 dark:border-violet-800/40">
                    {loadingPrevDebts ? 'جارٍ التحميل…' : `${groupedPrevDebts.length} طالب مطالب`}
                  </span>
                  {!loadingPrevDebts && (
                    <span className="text-xs px-2.5 py-1 rounded-lg bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 font-bold border border-rose-200/50 dark:border-rose-800/40">
                      إجمالي الديون السابقة: {totalPrevDebtsAmount.toLocaleString('ar-LY', { maximumFractionDigits: 0 })} د.ل
                    </span>
                  )}
                  <button
                    onClick={handlePrintPrevDebts}
                    className="inline-flex items-center gap-1.5 h-8 px-3 rounded-lg text-xs font-semibold bg-violet-600 text-white shadow-xs hover:bg-violet-700 active:scale-95 transition-all"
                  >
                    <Printer className="w-3.5 h-3.5" /> طباعة الكشف
                  </button>
                </>
              )}
            </div>
          </div>

          {/* ── محتوى البطاقة عند اختيار الديون السابقة ── */}
          {statusFilter === 'prev_debts' ? (
            <div className="p-4 space-y-4">
              {/* بطاقات المؤشرات السريعة للديون السابقة */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-4 rounded-2xl border border-violet-500/25 bg-gradient-to-br from-violet-500/10 via-purple-500/5 to-transparent flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-violet-600 text-white flex items-center justify-center shadow-sm shadow-violet-600/30">
                      <History className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-[11px] font-bold text-muted-foreground">الطلاب المطالبون بديون سابقة</p>
                      <h3 className="text-lg font-black text-foreground">
                        {loadingPrevDebts ? '...' : `${groupedPrevDebts.length} طالب`}
                      </h3>
                    </div>
                  </div>
                  <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-violet-500/15 text-violet-700 dark:text-violet-300 border border-violet-500/25">
                    فصول سابقة
                  </span>
                </div>

                <div className="p-4 rounded-2xl border border-rose-500/25 bg-gradient-to-br from-rose-500/10 via-red-500/5 to-transparent flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-rose-600 text-white flex items-center justify-center shadow-sm shadow-rose-600/30">
                      <AlertTriangle className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-[11px] font-bold text-muted-foreground">إجمالي الديون السابقة المتبقية</p>
                      <h3 className="text-lg font-black text-rose-600 dark:text-rose-400">
                        {loadingPrevDebts ? '...' : `${totalPrevDebtsAmount.toLocaleString('ar-LY', { maximumFractionDigits: 0 })} د.ل`}
                      </h3>
                    </div>
                  </div>
                  <button
                    onClick={handlePrintPrevDebts}
                    className="inline-flex items-center gap-1.5 h-8 px-3 rounded-xl text-xs font-bold bg-gradient-to-r from-violet-600 to-indigo-700 text-white shadow-sm hover:from-violet-700 hover:to-indigo-800 transition-all active:scale-95"
                  >
                    <Printer className="w-3.5 h-3.5" /> طباعة الكشف
                  </button>
                </div>
              </div>

              {/* شريط البحث وفلاتر الديون السابقة */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                <div className="relative flex-1">
                  <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                  <Input
                    placeholder="ابحث بالاسم أو الرقم الوطني أو التخصص..."
                    value={prevDebtsSearch}
                    onChange={e => setPrevDebtsSearch(e.target.value)}
                    className="pr-9 h-9 text-sm bg-background"
                  />
                </div>
                {prevDebtsSearch && (
                  <button
                    onClick={() => setPrevDebtsSearch('')}
                    className="h-9 px-2 rounded-lg text-muted-foreground hover:text-destructive hover:bg-destructive/8 transition-colors shrink-0"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}

                <Select value={prevDebtsDiploma} onValueChange={v => { setPrevDebtsDiploma(v); setPrevDebtsSpec('all'); }}>
                  <SelectTrigger className="h-9 w-full sm:w-36 text-xs bg-background">
                    <SelectValue placeholder="كل الدبلومات" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">كل الدبلومات</SelectItem>
                    <SelectItem value="عالي">دبلوم عالي</SelectItem>
                    <SelectItem value="متوسط">دبلوم متوسط</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={prevDebtsSpec} onValueChange={setPrevDebtsSpec}>
                  <SelectTrigger className="h-9 w-full sm:w-44 text-xs bg-background">
                    <SelectValue placeholder="كل التخصصات" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">كل التخصصات</SelectItem>
                    {prevDebtsSpecOptions.map(sp => (
                      <SelectItem key={sp} value={sp}>{sp}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {(prevDebtsDiploma !== 'all' || prevDebtsSpec !== 'all' || prevDebtsSearch) && (
                  <button
                    onClick={() => { setPrevDebtsDiploma('all'); setPrevDebtsSpec('all'); setPrevDebtsSearch(''); }}
                    className="inline-flex items-center justify-center gap-1 h-9 px-3 rounded-xl text-xs font-semibold text-destructive bg-destructive/8 border border-destructive/25 hover:bg-destructive hover:text-white transition-all shrink-0"
                  >
                    <X className="w-3.5 h-3.5" /> مسح
                  </button>
                )}
              </div>

              {/* قائمة الديون السابقة بهيئة بطاقات طلاب احترافية */}
              {loadingPrevDebts ? (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 py-2">
                  {Array(6).fill(0).map((_, i) => (
                    <div key={i} className="border border-border/50 rounded-2xl p-4 space-y-3">
                      <div className="flex items-center gap-3">
                        <Skeleton className="w-10 h-10 rounded-xl" />
                        <div className="flex-1 space-y-1.5">
                          <Skeleton className="h-4 w-32" />
                          <Skeleton className="h-2.5 w-24" />
                        </div>
                      </div>
                      <Skeleton className="h-16 w-full rounded-xl" />
                      <Skeleton className="h-8 w-full rounded-xl" />
                    </div>
                  ))}
                </div>
              ) : groupedPrevDebts.length === 0 ? (
                <div className="text-center py-12 border border-dashed border-border/60 rounded-2xl bg-muted/10">
                  <CheckCircle2 className="w-12 h-12 text-emerald-500/50 mx-auto mb-2" />
                  <p className="text-sm font-bold text-foreground">لا توجد ديون سابقة مسجلة على الطلاب</p>
                  <p className="text-xs text-muted-foreground mt-1">جميع الطلاب المستمرين في فصولهم الحالية مسددون لكافة الفصول السابقة</p>
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                    {displayedPrevDebts.map(g => {
                      const studentRemaining = g.totalRemaining;
                      const isExpanded = expandedPrevStudentId === g.info.student_id;
                      const photoUrl = g.info.photo_url || studentsMap.get(g.info.student_id)?.photo_url;
                      const regNumber = g.info.registration_number || studentsMap.get(g.info.student_id)?.registration_number;

                      return (
                        <div
                          key={g.info.student_id}
                          className="group rounded-2xl border border-violet-500/30 bg-card hover:border-violet-500/60 hover:shadow-xl transition-all duration-200 p-4 flex flex-col justify-between relative overflow-hidden"
                        >
                          <div className="absolute top-0 right-0 left-0 h-1.5 bg-gradient-to-r from-violet-600 via-purple-600 to-indigo-600" />

                          <div>
                            {/* رأس بطاقة الطالب */}
                            <div className="flex items-start gap-3">
                              <div className="relative shrink-0">
                                <StudentAvatar
                                  photoUrl={photoUrl}
                                  name={g.info.full_name}
                                  size="md"
                                  variant="square"
                                />
                                <span className="absolute -bottom-1 -left-1 w-3.5 h-3.5 rounded-full border-2 border-background bg-violet-600" />
                              </div>

                              <div className="flex-1 min-w-0 text-right">
                                <div className="flex items-start justify-between gap-1.5">
                                  <h3
                                    className="text-xs sm:text-sm font-bold text-foreground leading-snug break-words line-clamp-2 md:line-clamp-1 group-hover:text-primary transition-colors"
                                    title={g.info.full_name}
                                  >
                                    {g.info.full_name}
                                  </h3>
                                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-violet-500/10 text-violet-700 dark:text-violet-300 border border-violet-500/25 shrink-0">
                                    دين سابق
                                  </span>
                                </div>

                                <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                                  <span className="text-[11px] font-mono text-muted-foreground/80">{g.info.national_id ? g.info.national_id : 'لا يوجد رقم وطني'}</span>
                                  {regNumber ? (
                                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-amber-500/15 text-amber-700 dark:text-amber-300 border border-amber-500/30 text-[10px] font-mono font-bold shadow-xs">
                                      <Hash className="w-2.5 h-2.5 text-amber-600 dark:text-amber-400 shrink-0" />
                                      <span>قيد: {regNumber}</span>
                                    </span>
                                  ) : (
                                    <span className="text-[10px] text-muted-foreground/50 italic">• بدون قيد</span>
                                  )}
                                </div>
                              </div>
                            </div>

                            {/* الأكاديميات */}
                            <div className="flex items-center gap-1.5 mt-3 flex-wrap">
                              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                                g.info.diploma_type === 'عالي'
                                  ? 'bg-blue-500/10 text-blue-700 dark:text-blue-300 border border-blue-500/20'
                                  : 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20'
                              }`}>
                                {g.info.diploma_type}
                              </span>
                              <span className="text-[10px] font-medium px-2 py-0.5 rounded-md bg-muted text-muted-foreground border border-border/50 truncate max-w-[130px]">
                                {g.info.specialization || 'عام'}
                              </span>
                              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-purple-500/10 text-purple-700 dark:text-purple-300 border border-purple-500/20 mr-auto">
                                حالياً: {SEMESTER_LABELS[g.info.current_semester] ?? `الفصل ${g.info.current_semester}`}
                              </span>
                            </div>

                            {/* صندوق المديونية السابقة المميز */}
                            <div className="mt-3 p-3 rounded-xl bg-gradient-to-br from-rose-500/10 via-purple-500/5 to-transparent border border-rose-500/25 space-y-1">
                              <div className="flex items-center justify-between text-xs">
                                <span className="text-[11px] font-bold text-muted-foreground">إجمالي المتبقي السابق:</span>
                                <span className="text-base font-black text-rose-600 dark:text-rose-400">
                                  {studentRemaining.toLocaleString('ar-LY', { maximumFractionDigits: 0 })} د.ل
                                </span>
                              </div>
                              <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                                <span>عدد الفصول غير المسددة:</span>
                                <span className="font-bold text-foreground">{g.charges.length} فصول</span>
                              </div>
                            </div>

                            {/* تفاصيل الفصول السابقة غير المسددة القابلة للتوسيع */}
                            {isExpanded && (
                              <div className="mt-2.5 pt-2.5 border-t border-border/50 space-y-2 bg-muted/30 p-2.5 rounded-xl">
                                <p className="text-[11px] font-bold text-foreground">تفاصيل المديونية حسب الفصل:</p>
                                {g.charges.map(c => (
                                  <div key={c.charge_id} className="p-2 rounded-lg bg-background border border-border/50 text-xs space-y-1">
                                    <div className="flex items-center justify-between font-bold text-foreground">
                                      <span>{SEMESTER_LABELS[c.semester_number] ?? `الفصل ${c.semester_number}`}</span>
                                      <span className="text-rose-600 dark:text-rose-400 font-black">متبقي: {c.remaining.toLocaleString('ar-LY')} د.ل</span>
                                    </div>
                                    <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                                      <span>الرسم الأصلي: {c.charge_amount.toLocaleString('ar-LY')} د.ل</span>
                                      <span className="text-emerald-600 font-bold">المدفوع: {c.paid_amount.toLocaleString('ar-LY')} د.ل</span>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>

                          {/* أزرار التحكم في أسفل البطاقة */}
                          <div className="mt-3 pt-2.5 border-t border-border/50 flex items-center justify-between gap-2">
                            <button
                              type="button"
                              onClick={() => setExpandedPrevStudentId(isExpanded ? null : g.info.student_id)}
                              className="inline-flex items-center gap-1 text-[11px] font-bold text-violet-700 dark:text-violet-400 hover:underline"
                            >
                              {isExpanded ? (
                                <><ChevronUp className="w-3.5 h-3.5" /> إخفاء الفصول</>
                              ) : (
                                <><ChevronDown className="w-3.5 h-3.5" /> تفاصيل الفصول ({g.charges.length})</>
                              )}
                            </button>

                            <button
                              type="button"
                              onClick={() => {
                                const found = studentsMap.get(g.info.student_id);
                                if (found) {
                                  setSelectedStudent(found);
                                } else {
                                  getStudents({ search: g.info.full_name, limit: 1 }).then(res => {
                                    if (res.data[0]) setSelectedStudent(res.data[0]);
                                    else toast.error('تعذر فتح الملف المالي');
                                  });
                                }
                              }}
                              className="inline-flex items-center gap-1.5 text-xs font-bold px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-violet-600 via-purple-600 to-indigo-700 hover:from-violet-700 hover:via-purple-700 hover:to-indigo-800 text-white shadow-md shadow-violet-700/25 hover:shadow-lg transition-all active:scale-95 group/btn"
                            >
                              <DollarSign className="w-3.5 h-3.5 text-violet-200" />
                              <span>الملف المالي والسداد</span>
                              <ChevronLeft className="w-3 h-3 text-white/80 group-hover/btn:-translate-x-0.5 transition-transform" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* ── نظام «عرض المزيد» لديون الفصول السابقة ── */}
                  <div className="flex flex-col items-center justify-center gap-4 pt-8 pb-4">
                    {/* شريط الإحصائية والتقدم */}
                    <div className="w-full max-w-lg bg-card/90 dark:bg-card/70 border border-border/80 rounded-2xl p-4 shadow-sm space-y-2.5">
                      <div className="flex items-center justify-between text-xs font-bold text-foreground px-1">
                        <span className="text-muted-foreground flex items-center gap-1.5">
                          <History className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
                          حالة عرض ديون الطلاب:
                        </span>
                        <span className="text-purple-600 dark:text-purple-400 font-black text-sm">
                          {displayedPrevDebts.length.toLocaleString('ar-LY')} <span className="text-muted-foreground font-normal text-xs">من إجمالي</span> {groupedPrevDebts.length.toLocaleString('ar-LY')} طالب
                        </span>
                      </div>

                      {/* شريط التقدم الفخم */}
                      <div className="h-2.5 w-full bg-muted/80 rounded-full overflow-hidden p-0.5 border border-border/50">
                        <div
                          className="h-full bg-gradient-to-r from-purple-600 via-violet-600 to-indigo-500 rounded-full transition-all duration-500 shadow-xs"
                          style={{ width: `${prevDebtsProgress}%` }}
                        />
                      </div>

                      <div className="flex items-center justify-between text-[11px] text-muted-foreground px-1">
                        <span>نسبة المعروض: <strong className="text-foreground font-bold">{prevDebtsProgress}%</strong></span>
                        <span>
                          {hasMorePrevDebts
                            ? `متبقي ${(groupedPrevDebts.length - displayedPrevDebts.length).toLocaleString('ar-LY')} طالب`
                            : '✓ تم عرض كافة الطلاب أصحاب الديون السابقة'}
                        </span>
                      </div>
                    </div>

                    {/* زر عرض المزيد الاحترافي للديون السابقة */}
                    {hasMorePrevDebts && (
                      <button
                        type="button"
                        onClick={() => setPrevDebtsVisibleCount(prev => Math.min(prev + PREV_DEBTS_CHUNK, groupedPrevDebts.length))}
                        className="group relative inline-flex items-center justify-center gap-3 px-8 py-3.5 rounded-2xl font-bold text-sm text-white bg-gradient-to-r from-purple-700 via-violet-700 to-indigo-900 hover:from-purple-800 hover:via-violet-800 hover:to-indigo-950 shadow-lg shadow-purple-950/25 hover:shadow-xl hover:shadow-purple-950/35 hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200 border border-white/20 ring-2 ring-purple-500/20"
                      >
                        <ChevronDown className="w-4 h-4 text-purple-200 group-hover:translate-y-0.5 transition-transform" />
                        <span>عرض المزيد من ديون الفصول السابقة</span>
                        <span className="inline-flex items-center gap-1 text-xs px-2.5 py-0.5 rounded-full bg-white/20 text-white font-mono font-bold shadow-xs">
                          +{Math.min(PREV_DEBTS_CHUNK, groupedPrevDebts.length - displayedPrevDebts.length).toLocaleString('ar-LY')}
                        </span>
                      </button>
                    )}
                  </div>
                </>
              )}
            </div>
          ) : (
            /* ── محتوى البطاقة لبقية التبويبات (الكل / عليهم ديون / مسددون / موقوف قيد) ── */
            <>
              {/* شريط البحث والفلاتر */}
              <div className="px-4 py-3 border-b border-border/50 bg-muted/10 space-y-2">
                {/* السطر الأول: بحث نصي */}
                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                    <Input
                      placeholder="ابحث بالاسم أو الرقم الوطني أو التخصص أو الهاتف..."
                      value={searchInput}
                      onChange={e => handleSearchChange(e.target.value)}
                      className="pr-9 h-9 text-sm bg-background"
                    />
                  </div>
                  {searchInput && (
                    <button onClick={() => { setSearchInput(''); setSearch(''); }}
                      className="h-9 px-2 rounded-lg text-muted-foreground hover:text-destructive hover:bg-destructive/8 transition-colors">
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {/* السطر الثاني: فلاتر الفصل والدبلوم والتخصص */}
                <div className="flex items-center gap-2 flex-wrap">
                  {/* فلتر الفصل */}
                  <Select value={semesterFilter} onValueChange={setSemesterFilter}>
                    <SelectTrigger className="h-8 w-36 text-xs bg-background">
                      <SelectValue placeholder="كل الفصول" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">كل الفصول</SelectItem>
                      {Object.entries(SEMESTER_LABELS).map(([num, label]) => (
                        <SelectItem key={num} value={num}>{label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  {/* فلتر الدبلوم */}
                  <Select value={diplomaFilter} onValueChange={v => { setDiplomaFilter(v); setSpecializationFilter('all'); }}>
                    <SelectTrigger className="h-8 w-32 text-xs bg-background">
                      <SelectValue placeholder="كل الدبلومات" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">كل الدبلومات</SelectItem>
                      <SelectItem value="عالي">دبلوم عالي</SelectItem>
                      <SelectItem value="متوسط">دبلوم متوسط</SelectItem>
                    </SelectContent>
                  </Select>

                  {/* فلتر التخصص */}
                  <Select value={specializationFilter} onValueChange={setSpecializationFilter}>
                    <SelectTrigger className="h-8 w-44 text-xs bg-background">
                      <SelectValue placeholder="كل التخصصات" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">كل التخصصات</SelectItem>
                      {specializationOptions.map(sp => (
                        <SelectItem key={sp} value={sp}>{sp}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  {/* زر مسح الفلاتر */}
                  {hasActiveFilters && (
                    <button onClick={clearDropdownFilters}
                      className="inline-flex items-center gap-1.5 h-8 px-3 rounded-xl text-[12px] font-semibold text-destructive bg-destructive/8 border border-destructive/25 hover:bg-destructive hover:text-white transition-all">
                      <X className="w-3.5 h-3.5" /> مسح الفلاتر
                    </button>
                  )}

                  <span className="mr-auto text-xs text-muted-foreground shrink-0">
                    {!loading && (
                      <>عرض <span className="font-semibold text-foreground">{filteredStudents.length}</span> من {students.length} طالب</>
                    )}
                  </span>
                </div>
              </div>

              {/* القائمة بهيئة بطاقات طلاب احترافية */}
              <CardContent className="p-4">
                {loading ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3.5">
                    {Array(6).fill(0).map((_, i) => (
                      <div key={i} className="border border-border/50 rounded-2xl p-4 space-y-3">
                        <div className="flex items-center gap-3">
                          <Skeleton className="w-10 h-10 rounded-xl" />
                          <div className="flex-1 space-y-1.5">
                            <Skeleton className="h-4 w-32" />
                            <Skeleton className="h-2.5 w-24" />
                          </div>
                        </div>
                        <Skeleton className="h-16 w-full rounded-xl" />
                        <Skeleton className="h-8 w-full rounded-xl" />
                      </div>
                    ))}
                  </div>
                ) : filteredStudents.length === 0 ? (
                  <div className="text-center py-12 border border-dashed border-border/60 rounded-2xl bg-muted/10">
                    <DollarSign className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
                    <p className="text-sm font-semibold text-foreground">لا يوجد طلاب مطابقون للبحث والتصفية</p>
                    <p className="text-xs text-muted-foreground mt-1">يمكنك تغيير فلاتر البحث أو اختيار تبويب آخر</p>
                  </div>
                ) : (
                  <>
                    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3.5">
                      {displayedStudents.map((s, i) => (
                        <StudentFinanceCard key={s.id} student={s} index={i + 1} onOpen={setSelectedStudent} />
                      ))}
                    </div>

                    {/* ── نظام «عرض المزيد» الاحترافي مع مؤشر تقدم ونسبة إنجاز ── */}
                    <div className="flex flex-col items-center justify-center gap-4 pt-8 pb-4">
                      {/* شريط الإحصائية والتقدم */}
                      <div className="w-full max-w-lg bg-card/90 dark:bg-card/70 border border-border/80 rounded-2xl p-4 shadow-sm space-y-2.5">
                        <div className="flex items-center justify-between text-xs font-bold text-foreground px-1">
                          <span className="text-muted-foreground flex items-center gap-1.5">
                            <Users className="w-3.5 h-3.5 text-primary" />
                            حالة عرض الطلاب:
                          </span>
                          <span className="text-primary font-black text-sm">
                            {displayedStudents.length.toLocaleString('ar-LY')} <span className="text-muted-foreground font-normal text-xs">من إجمالي</span> {totalFiltered.toLocaleString('ar-LY')} طالب
                          </span>
                        </div>

                        {/* شريط التقدم الفخم */}
                        <div className="h-2.5 w-full bg-muted/80 rounded-full overflow-hidden p-0.5 border border-border/50">
                          <div
                            className="h-full bg-gradient-to-r from-blue-600 via-indigo-600 to-emerald-500 rounded-full transition-all duration-500 shadow-xs"
                            style={{ width: `${loadMoreProgress}%` }}
                          />
                        </div>

                        <div className="flex items-center justify-between text-[11px] text-muted-foreground px-1">
                          <span>نسبة المعروض: <strong className="text-foreground font-bold">{loadMoreProgress}%</strong></span>
                          <span>
                            {hasMoreStudents
                              ? `متبقي ${(totalFiltered - displayedStudents.length).toLocaleString('ar-LY')} طالب`
                              : '✓ تم عرض كافة الطلاب المطابقين'}
                          </span>
                        </div>
                      </div>

                      {/* زر عرض المزيد الاحترافي ذو التدرج اللوني الملكي والظل الأنيق */}
                      {hasMoreStudents && (
                        <button
                          type="button"
                          onClick={() => setVisibleCount(prev => Math.min(prev + DISPLAY_CHUNK_SIZE, totalFiltered))}
                          className="group relative inline-flex items-center justify-center gap-3 px-8 py-3.5 rounded-2xl font-bold text-sm text-white bg-gradient-to-r from-blue-700 via-indigo-700 to-slate-900 hover:from-blue-800 hover:via-indigo-800 hover:to-black shadow-lg shadow-indigo-950/25 hover:shadow-xl hover:shadow-indigo-950/35 hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200 border border-white/20 ring-2 ring-indigo-500/20"
                        >
                          <ChevronDown className="w-4 h-4 text-sky-200 group-hover:translate-y-0.5 transition-transform" />
                          <span>عرض المزيد من الطلاب</span>
                          <span className="inline-flex items-center gap-1 text-xs px-2.5 py-0.5 rounded-full bg-white/20 text-white font-mono font-bold shadow-xs">
                            +{Math.min(DISPLAY_CHUNK_SIZE, totalFiltered - displayedStudents.length).toLocaleString('ar-LY')}
                          </span>
                        </button>
                      )}
                    </div>
                  </>
                )}
              </CardContent>
            </>
          )}
        </Card>
      </div>
    </MainLayout>

    <StudentProfileDialog
      student={selectedStudent}
      open={!!selectedStudent}
      onOpenChange={open => { if (!open) setSelectedStudent(null); }}
      onDataChange={fetchStudents}
    />
    <PreviousDebtsDialog open={showPrevDebts} onOpenChange={setShowPrevDebts} />
    <FinancialAuditDialog open={auditDialogOpen} onOpenChange={setAuditDialogOpen} />

    {/* ── نافذة تأكيد الأرشفة الفردية ── */}
    <AlertDialog open={!!archiveConfirm} onOpenChange={open => { if (!open) setArchiveConfirm(null); }}>
      <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
        <AlertDialogHeader className="gap-3">
          {/* أيقونة مركزية */}
          <div className="mx-auto w-14 h-14 rounded-2xl bg-emerald-50 dark:bg-emerald-900/40 border border-emerald-200/60 dark:border-emerald-700/50 flex items-center justify-center">
            <Archive className="w-7 h-7 text-emerald-500" />
          </div>
          <AlertDialogTitle className="text-center text-base font-bold">
            تأكيد الأرشفة
          </AlertDialogTitle>
          <AlertDialogDescription className="text-center leading-relaxed space-y-2">
            <span className="block text-foreground font-bold text-sm">{archiveConfirm?.full_name}</span>
            <span className="block text-muted-foreground text-xs">
              سيُنقل هذا الطالب إلى الأرشيف بشكل نهائي. هذا الإجراء لا يمكن التراجع عنه.
            </span>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter className="gap-2 sm:gap-2 flex-col sm:flex-row">
          <AlertDialogCancel disabled={!!archivingId} className="w-full sm:w-auto">إلغاء</AlertDialogCancel>
          <AlertDialogAction
            disabled={!!archivingId}
            onClick={() => { if (archiveConfirm) handleArchiveSingle(archiveConfirm); }}
            className="w-full sm:w-auto bg-emerald-500 hover:bg-emerald-600 text-white gap-2 inline-flex items-center justify-center"
          >
            {archivingId ? <><Loader2 className="w-4 h-4 animate-spin" />جارٍ الأرشفة…</> : <><Archive className="w-4 h-4" />تأكيد الأرشفة</>}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>

    {/* ── نافذة تأكيد الأرشفة الجماعية ── */}
    <AlertDialog open={archiveBatchConfirm} onOpenChange={open => { if (!open) setArchiveBatchConfirm(false); }}>
      <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
        <AlertDialogHeader className="gap-3">
          <div className="mx-auto w-14 h-14 rounded-2xl bg-emerald-50 dark:bg-emerald-900/40 border border-emerald-200/60 dark:border-emerald-700/50 flex items-center justify-center">
            <Archive className="w-7 h-7 text-emerald-500" />
          </div>
          <AlertDialogTitle className="text-center text-base font-bold">
            {selectedForArchive.size > 0 && selectedForArchive.size < pendingArchive.length
              ? `أرشفة ${selectedForArchive.size} طلاب محددين`
              : `أرشفة جميع الطلاب (${pendingArchive.length})`}
          </AlertDialogTitle>
          <AlertDialogDescription className="text-center text-xs text-muted-foreground leading-relaxed">
            سيُنقل الطلاب التاليون إلى الأرشيف بشكل نهائي — هذا الإجراء لا يمكن التراجع عنه.
          </AlertDialogDescription>
        </AlertDialogHeader>

        {/* قائمة الطلاب المُراد أرشفتهم */}
        <div className="max-h-48 overflow-y-auto rounded-xl border border-emerald-200/60 dark:border-emerald-700/40 divide-y divide-emerald-100/60 dark:divide-emerald-800/40 bg-emerald-50/40 dark:bg-emerald-950/30">
          {(selectedForArchive.size > 0
            ? pendingArchive.filter(s => selectedForArchive.has(s.id))
            : pendingArchive
          ).map(s => (
            <div key={s.id} className="flex items-center gap-2.5 px-3 py-2">
              <StudentAvatar name={s.full_name} photoUrl={s.photo_url ?? undefined} size="xs" />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-bold text-foreground leading-tight">{s.full_name}</p>
                <p className="text-[10px] text-muted-foreground">{s.diploma_type} · {s.specialization}</p>
              </div>
              <span className="text-[9px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-100 dark:bg-emerald-900/50 px-1.5 py-0.5 rounded-full shrink-0">مكتمل</span>
            </div>
          ))}
        </div>

        <AlertDialogFooter className="gap-2 sm:gap-2 flex-col sm:flex-row">
          <AlertDialogCancel disabled={archivingAll} className="w-full sm:w-auto">إلغاء</AlertDialogCancel>
          <AlertDialogAction
            disabled={archivingAll}
            onClick={() => {
              const targets = selectedForArchive.size > 0
                ? pendingArchive.filter(s => selectedForArchive.has(s.id))
                : pendingArchive;
              handleArchiveBatch(targets);
            }}
            className="w-full sm:w-auto bg-emerald-500 hover:bg-emerald-600 text-white gap-2 inline-flex items-center justify-center"
          >
            {archivingAll
              ? <><Loader2 className="w-4 h-4 animate-spin" />جارٍ الأرشفة…</>
              : <><Archive className="w-4 h-4" />تأكيد الأرشفة</>}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
    </>
  );
}

// ══════════════════════════════════════════════════════
// نافذة الديون السابقة
// ══════════════════════════════════════════════════════
function getInitials(name: string) {
  const parts = name.trim().split(/\s+/);
  return parts.length >= 2 ? parts[0][0] + parts[1][0] : parts[0].slice(0, 2);
}

function PreviousDebtsDialog({
  open, onOpenChange,
}: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const [rows, setRows]               = useState<PreviousDebtRow[]>([]);
  const [loading, setLoading]         = useState(false);
  const [diplomaFilter, setDiplomaFilter]         = useState('all');
  const [specializationFilter, setSpecFilter]     = useState('all');
  const [expandedStudent, setExpandedStudent]     = useState<string | null>(null);
  const [search, setSearch]           = useState('');

  // جلب البيانات عند فتح النافذة
  useEffect(() => {
    if (!open) return;
    setLoading(true);
    getPreviousDebts()
      .then(setRows)
      .catch(() => toast.error('فشل تحميل الديون السابقة'))
      .finally(() => setLoading(false));
  }, [open]);

  // خيارات التخصص
  const specializationOptions = useMemo(() =>
    diplomaFilter !== 'all'
      ? (SPECIALIZATIONS_BY_DIPLOMA[diplomaFilter] ?? [])
      : [...new Set(Object.values(SPECIALIZATIONS_BY_DIPLOMA).flat())].sort(),
  [diplomaFilter]);

  // تصفية وتجميع حسب الطالب
  const grouped = useMemo(() => {
    let list = rows;
    if (diplomaFilter !== 'all') list = list.filter(r => r.diploma_type === diplomaFilter);
    if (specializationFilter !== 'all') list = list.filter(r => r.specialization === specializationFilter);
    if (search.trim()) {
      list = list.filter(r =>
        matchSearch(r.full_name, search) ||
        matchSearch(r.national_id, search) ||
        matchSearch(r.specialization, search)
      );
    }
    // تصفية وتجميع حسب الطالب مع حساب الإجمالي مباشرة
    const map = new Map<string, { info: PreviousDebtRow; charges: PreviousDebtRow[]; totalRemaining: number }>();
    for (const r of list) {
      let g = map.get(r.student_id);
      if (!g) {
        g = { info: r, charges: [], totalRemaining: 0 };
        map.set(r.student_id, g);
      }
      g.charges.push(r);
      g.totalRemaining += r.remaining;
    }
    const result = Array.from(map.values());
    result.sort((a, b) => b.totalRemaining - a.totalRemaining);
    return result;
  }, [rows, diplomaFilter, specializationFilter, search]);

  const totalRemaining = useMemo(
    () => grouped.reduce((s, g) => s + g.totalRemaining, 0),
    [grouped]
  );

  const [dialogVisibleLimit, setDialogVisibleLimit] = useState(50);
  useEffect(() => {
    setDialogVisibleLimit(50);
  }, [diplomaFilter, specializationFilter, search]);

  const displayedGrouped = useMemo(() => {
    return grouped.slice(0, dialogVisibleLimit);
  }, [grouped, dialogVisibleLimit]);

  const handleClose = () => {
    onOpenChange(false);
    setDiplomaFilter('all');
    setSpecFilter('all');
    setSearch('');
    setExpandedStudent(null);
  };

  return (
    <Dialog open={open} onOpenChange={v => { if (!v) handleClose(); }}>
      <DialogContent
        className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-hidden flex flex-col p-0"
        dir="rtl">

        {/* ── رأس النافذة ── */}
        <div className="bg-violet-600 px-5 py-4 rounded-t-lg shrink-0">
          <DialogHeader>
            <DialogTitle className="text-white font-black text-base flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-white/15 flex items-center justify-center">
                <History className="w-4 h-4 text-white" />
              </div>
              الديون السابقة
            </DialogTitle>
          </DialogHeader>
          <p className="text-white/60 text-xs mt-1">
            رسوم الفصول الماضية غير المسددة حتى الآن
          </p>
        </div>

        {/* ── ملخص الإجماليات ── */}
        <div className="px-5 py-3 bg-violet-50 border-b border-violet-100 shrink-0 flex items-center gap-4 flex-wrap">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-violet-500/15 flex items-center justify-center">
              <AlertCircle className="w-3.5 h-3.5 text-violet-600" />
            </div>
            <div>
              <p className="text-[10px] text-violet-500 font-medium">عدد الطلاب</p>
              <p className="text-base font-black text-violet-700 leading-none">{loading ? '…' : grouped.length}</p>
            </div>
          </div>
          <div className="w-px h-8 bg-violet-200" />
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-violet-500/15 flex items-center justify-center">
              <DollarSign className="w-3.5 h-3.5 text-violet-600" />
            </div>
            <div>
              <p className="text-[10px] text-violet-500 font-medium">إجمالي الديون السابقة</p>
              <p className="text-base font-black text-violet-700 leading-none tabular-nums">
                {loading ? '…' : `${totalRemaining.toFixed(2)} د.ل`}
              </p>
            </div>
          </div>
        </div>

        {/* ── أدوات البحث والفلترة ── */}
        <div className="px-5 py-3 border-b border-border/40 bg-muted/10 shrink-0 space-y-2">
          {/* بحث نصي */}
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
            <Input
              placeholder="بحث بالاسم أو الرقم الوطني أو التخصص..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pr-9 h-9 text-sm bg-background"
            />
          </div>
          {/* فلاتر */}
          <div className="flex gap-2 flex-wrap">
            <Select value={diplomaFilter} onValueChange={v => { setDiplomaFilter(v); setSpecFilter('all'); }}>
              <SelectTrigger className="h-8 w-36 text-xs bg-background">
                <SelectValue placeholder="كل الدبلومات" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">كل الدبلومات</SelectItem>
                <SelectItem value="عالي">دبلوم عالي</SelectItem>
                <SelectItem value="متوسط">دبلوم متوسط</SelectItem>
              </SelectContent>
            </Select>

            <Select value={specializationFilter} onValueChange={setSpecFilter}>
              <SelectTrigger className="h-8 w-44 text-xs bg-background">
                <SelectValue placeholder="كل التخصصات" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">كل التخصصات</SelectItem>
                {specializationOptions.map(sp => (
                  <SelectItem key={sp} value={sp}>{sp}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            {(diplomaFilter !== 'all' || specializationFilter !== 'all' || search) && (
              <button
                onClick={() => { setDiplomaFilter('all'); setSpecFilter('all'); setSearch(''); }}
                className="inline-flex items-center gap-1.5 h-8 px-3 rounded-lg text-xs font-semibold text-destructive bg-destructive/8 border border-destructive/25 hover:bg-destructive hover:text-white transition-all">
                <X className="w-3 h-3" /> مسح الفلاتر
              </button>
            )}

            <span className="mr-auto text-xs text-muted-foreground self-center">
              {!loading && <>{grouped.length} طالب</>}
            </span>
          </div>
        </div>

        {/* ── القائمة القابلة للتمرير ── */}
        <div className="flex-1 overflow-y-auto min-h-0">
          {loading ? (
            <div className="p-5 space-y-3">
              {Array(4).fill(0).map((_, i) => (
                <div key={i} className="flex items-center gap-3 p-3 rounded-xl border border-border/30">
                  <Skeleton className="w-10 h-10 rounded-xl shrink-0" />
                  <div className="flex-1 space-y-1.5">
                    <Skeleton className="h-4 w-40" />
                    <Skeleton className="h-3 w-28" />
                  </div>
                  <Skeleton className="h-6 w-20 rounded-lg" />
                </div>
              ))}
            </div>
          ) : grouped.length === 0 ? (
            <div className="flex flex-col items-center py-16 gap-3">
              <div className="w-14 h-14 rounded-2xl bg-muted flex items-center justify-center">
                <CheckCircle2 className="w-7 h-7 text-emerald-500/60" />
              </div>
              <p className="text-sm font-semibold text-muted-foreground">
                {rows.length === 0 ? 'لا توجد ديون سابقة 🎉' : 'لا توجد نتائج للبحث'}
              </p>
            </div>
          ) : (
            <div className="divide-y divide-border/30">
              {displayedGrouped.map(({ info, charges, totalRemaining: totalDebt }) => {
                const isHigh       = info.diploma_type === 'عالي';
                const isExpanded   = expandedStudent === info.student_id;

                return (
                  <div key={info.student_id} className="hover:bg-muted/10 transition-colors">
                    {/* صف الطالب */}
                    <div className="flex items-center gap-3 px-5 py-3.5">
                      {/* أفاتار */}
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm shrink-0 select-none ${
                        isHigh ? 'bg-blue-500/10 text-blue-700' : 'bg-emerald-500/10 text-emerald-700'
                      }`}>
                        {getInitials(info.full_name)}
                      </div>

                      {/* بيانات الطالب */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-sm font-bold text-foreground">{info.full_name}</span>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                            isHigh
                              ? 'bg-blue-50 text-blue-700 border-blue-200'
                              : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          }`}>{info.diploma_type}</span>
                          <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-violet-50 text-violet-700 border border-violet-200">
                            {charges.length} فصل
                          </span>
                        </div>
                        <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                          {info.specialization && (
                            <span className="text-xs text-muted-foreground">{info.specialization}</span>
                          )}
                          <span className="text-xs text-muted-foreground/50">
                            الفصل الحالي: {SEMESTER_LABELS[info.current_semester] ?? `ف${info.current_semester}`}
                          </span>
                        </div>
                      </div>

                      {/* إجمالي الدين */}
                      <div className="shrink-0 text-left flex flex-col items-end gap-0.5">
                        <span className="text-sm font-black text-destructive tabular-nums">
                          {totalDebt.toFixed(2)}
                          <span className="text-xs font-normal text-muted-foreground mr-0.5">د.ل</span>
                        </span>
                        <span className="text-[10px] text-muted-foreground">إجمالي الديون</span>
                      </div>

                      {/* زر التوسيع */}
                      <button
                        onClick={() => setExpandedStudent(isExpanded ? null : info.student_id)}
                        className="w-8 h-8 rounded-lg flex items-center justify-center text-muted-foreground hover:bg-muted border border-border/40 transition-all shrink-0">
                        {isExpanded
                          ? <ChevronUp className="w-4 h-4" />
                          : <ChevronDown className="w-4 h-4" />}
                      </button>
                    </div>

                    {/* تفاصيل الفصول المتوسّعة */}
                    {isExpanded && (
                      <div className="px-5 pb-4 pt-1 bg-muted/10 border-t border-border/20">
                        <div className="space-y-2 mt-1">
                          {charges.map(c => (
                            <div key={c.charge_id}
                              className="flex items-center gap-3 p-3 rounded-xl bg-background border border-border/40 shadow-sm">
                              {/* رقم الفصل */}
                              <div className="w-8 h-8 rounded-lg bg-violet-500/10 flex items-center justify-center shrink-0">
                                <span className="text-xs font-black text-violet-700">{c.semester_number}</span>
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-xs font-semibold text-foreground">
                                  {SEMESTER_LABELS[c.semester_number] ?? `الفصل ${c.semester_number}`}
                                </p>
                                <div className="flex items-center gap-3 mt-0.5 flex-wrap">
                                  <span className="text-[10px] text-muted-foreground">
                                    الرسوم: <span className="font-semibold text-foreground">{c.charge_amount.toFixed(2)}</span>
                                  </span>
                                  {c.discount_amount > 0 && (
                                    <span className="text-[10px] text-emerald-600">
                                      خصم: {c.discount_amount.toFixed(2)}
                                    </span>
                                  )}
                                  <span className="text-[10px] text-muted-foreground">
                                    مدفوع: <span className="font-semibold text-foreground">{c.paid_amount.toFixed(2)}</span>
                                  </span>
                                </div>
                              </div>
                              {/* المتبقي */}
                              <div className="shrink-0 flex flex-col items-end">
                                <span className="text-sm font-black text-destructive tabular-nums">
                                  {c.remaining.toFixed(2)}
                                  <span className="text-[10px] font-normal text-muted-foreground mr-0.5">د.ل</span>
                                </span>
                                <span className="text-[9px] text-muted-foreground">متبقي</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
              {grouped.length > dialogVisibleLimit && (
                <div className="p-4 text-center border-t border-border/30 bg-muted/10">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setDialogVisibleLimit(prev => prev + 50)}
                    className="gap-2 font-bold"
                  >
                    <span>عرض المزيد (+50 طالب)</span>
                    <span className="text-xs text-muted-foreground">
                      (معروض {dialogVisibleLimit} من أصل {grouped.length})
                    </span>
                  </Button>
                </div>
              )}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
