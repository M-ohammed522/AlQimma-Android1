// صفحة إيصالات الدفع - منظومة معهد القمة
import React, { useEffect, useState, useCallback, useMemo, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Receipt as ReceiptIcon, Search, RefreshCw, X, Printer,
  FileSpreadsheet, FileDown, ChevronRight, Calendar,
  BadgeDollarSign, Users, Hash, Filter, Clock,
  ListOrdered, TriangleAlert, CheckCheck, Loader2,
} from 'lucide-react';
import { toast } from 'sonner';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTableLib from 'jspdf-autotable';
const autoTable = (typeof autoTableLib === 'function' ? autoTableLib : (autoTableLib as any).default) as typeof autoTableLib;
import { triggerDownload } from '@/lib/printUtils';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { getAllReceipts, getAllReceiptsUnpaged, getSupplyOrdersSummary, formatSupplyOrderNumber, restoreSupplyOrder, compareReceipts } from '@/lib/api';
import type { ReceiptFilters } from '@/lib/api';
import { SEMESTER_LABELS, SPECIALIZATIONS_BY_DIPLOMA } from '@/types/index';
import type { Receipt } from '@/types/index';
import { RefreshButton } from '@/components/ui/RefreshButton';

// ── نوع الإيصال الموسّع ──
type FullReceipt = Receipt & {
  student_name: string;
  student_national_id: string;
  student_diploma: string;
  student_specialization: string;
  student_phone: string | null;
  student_exam_only: boolean;
};

// ── أنواع الدفع ──
const PAYMENT_TYPES = ['تسجيل', 'معادلة', 'قسط فصلي', 'مشروع تخرج', 'ديون سابقة'] as const;

// ── ألوان نوع الدفع ──
function paymentTypeBadge(type: string) {
  const map: Record<string, string> = {
    'تسجيل':       'bg-primary/10 text-primary border-primary/20',
    'معادلة':      'bg-chart-4/10 text-chart-4 border-chart-4/20',
    'قسط فصلي':    'bg-chart-2/10 text-chart-2 border-chart-2/20',
    'مشروع تخرج': 'bg-purple-500/10 text-purple-600 border-purple-400/20',
    'ديون سابقة':  'bg-destructive/10 text-destructive border-destructive/20',
  };
  return map[type] ?? 'bg-muted text-muted-foreground border-border';
}

// ── مكوّن نافذة أرقام أوامر التوريد ──
type SoSummary = Awaited<ReturnType<typeof getSupplyOrdersSummary>>;

function SupplyOrderNumbersDialog({
  open, onClose,
}: { open: boolean; onClose: () => void }) {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<SoSummary | null>(null);
  const [tab, setTab] = useState<'عالي' | 'متوسط'>('عالي');
  const [restoringNum, setRestoringNum] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try { setData(await getSupplyOrdersSummary()); }
    catch { toast.error('فشل في تحميل أرقام المعاملات'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { if (open) load(); }, [open, load]);

  // قائمة موحّدة: موجودة (أخضر) + محذوفة ناعماً (برتقالي، قابل للاستعادة) + فجوات حقيقية (رمادي)
  const unified = useMemo(() => {
    if (!data) return [];
    const max = tab === 'عالي' ? data.maxHigh : data.maxMid;
    const existing  = data.existing.filter(e => e.diploma_type === tab);
    const softDel   = data.deleted.filter(e => e.diploma_type === tab);
    const trueGaps  = tab === 'عالي' ? data.trueGapsHigh : data.trueGapsMid;

    type Row =
      | { kind: 'existing'; num: number; entry: SoSummary['existing'][0] }
      | { kind: 'deleted';  num: number; entry: SoSummary['deleted'][0] }
      | { kind: 'gap';      num: number };

    const rows: Row[] = [];
    for (let n = max; n >= 1; n--) {
      const ex = existing.find(e => e.num === n);
      if (ex) { rows.push({ kind: 'existing', num: n, entry: ex }); continue; }
      const dl = softDel.find(e => e.num === n);
      if (dl) { rows.push({ kind: 'deleted', num: n, entry: dl }); continue; }
      if (trueGaps.includes(n)) rows.push({ kind: 'gap', num: n });
    }
    return rows;
  }, [data, tab]);

  const handleRestore = async (soNum: string) => {
    setRestoringNum(soNum);
    try {
      const result = await restoreSupplyOrder(soNum);
      toast.success(`تمت استعادة المعاملة ${soNum} بنجاح`, {
        description: `${result.restoredCount} إيصال — ${result.studentNames.slice(0, 3).join(' · ')} — إجمالي ${result.total.toFixed(2)} د.ل`,
        duration: 7000,
      });
      await load(); // تحديث القائمة بعد الاستعادة
    } catch (err: any) {
      toast.error(`فشل في استعادة المعاملة ${soNum}`, { description: err?.message });
    } finally {
      setRestoringNum(null);
    }
  };

  const AR_MONTHS_SHORT = ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
  const fmtShort = (iso: string) => {
    const d = new Date(iso);
    return `${d.getDate()} ${AR_MONTHS_SHORT[d.getMonth()]} ${d.getFullYear()}`;
  };

  const softDelCount  = tab === 'عالي'
    ? data?.deleted.filter(e => e.diploma_type === 'عالي').length ?? 0
    : data?.deleted.filter(e => e.diploma_type === 'متوسط').length ?? 0;
  const trueGapsCount = tab === 'عالي' ? (data?.trueGapsHigh.length ?? 0) : (data?.trueGapsMid.length ?? 0);
  const maxNum        = tab === 'عالي' ? (data?.maxHigh ?? 0) : (data?.maxMid ?? 0);

  return (
    <Dialog open={open} onOpenChange={v => { if (!v) onClose(); }}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] flex flex-col p-0 gap-0">
        {/* رأس النافذة */}
        <DialogHeader className="px-4 pt-4 pb-3 border-b border-border/50 shrink-0">
          <DialogTitle className="flex items-center gap-2 text-base font-bold">
            <div className="w-7 h-7 rounded-lg bg-[#1a3c5e]/10 flex items-center justify-center">
              <ListOrdered className="w-3.5 h-3.5 text-[#1a3c5e]" />
            </div>
            أرقام أوامر التوريد
          </DialogTitle>
          <p className="text-xs text-muted-foreground mt-0.5">
            الأرقام المحذوفة تُستعاد تلقائياً بضغطة واحدة مع جميع بياناتها
          </p>
        </DialogHeader>

        {/* تبويبات الدبلوم */}
        <div className="flex px-4 pt-3 gap-2 shrink-0">
          {(['عالي', 'متوسط'] as const).map(d => (
            <button key={d} onClick={() => setTab(d)}
              className={`flex-1 h-9 rounded-lg text-[12px] font-bold border transition-all ${
                tab === d
                  ? d === 'عالي' ? 'bg-blue-600 text-white border-blue-600' : 'bg-emerald-600 text-white border-emerald-600'
                  : 'bg-background text-muted-foreground border-border hover:border-primary/40'
              }`}>
              دبلوم {d}
              {!loading && data && (
                <span className="mr-1.5 opacity-70 font-normal text-[10px]">
                  ({data.existing.filter(e => e.diploma_type === d).length})
                </span>
              )}
            </button>
          ))}
        </div>

        {/* إحصاء سريع */}
        {!loading && data && (
          <div className="flex flex-wrap items-center gap-2 px-4 py-2 shrink-0">
            <div className="flex items-center gap-1.5 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-lg">
              <CheckCheck className="w-3 h-3 text-emerald-600" />
              <span className="text-[11px] font-bold text-emerald-700">
                {data.existing.filter(e => e.diploma_type === tab).length} موجودة
              </span>
            </div>
            {softDelCount > 0 && (
              <div className="flex items-center gap-1.5 bg-orange-50 border border-orange-200 px-2.5 py-1 rounded-lg">
                <TriangleAlert className="w-3 h-3 text-orange-600" />
                <span className="text-[11px] font-bold text-orange-700">{softDelCount} محذوفة — قابلة للاستعادة</span>
              </div>
            )}
            {trueGapsCount > 0 && (
              <div className="flex items-center gap-1.5 bg-muted/60 border border-border px-2.5 py-1 rounded-lg">
                <Hash className="w-3 h-3 text-muted-foreground" />
                <span className="text-[11px] font-bold text-muted-foreground">{trueGapsCount} فجوة</span>
              </div>
            )}
            <div className="mr-auto text-[11px] text-muted-foreground">
              الأعلى: <span className="font-mono font-bold">{formatSupplyOrderNumber(maxNum)}</span>
            </div>
          </div>
        )}

        {/* القائمة */}
        <div className="flex-1 overflow-y-auto px-4 pb-4 min-h-0">
          {loading ? (
            <div className="space-y-2 pt-2">
              {Array(6).fill(0).map((_, i) => <Skeleton key={i} className="h-14 w-full rounded-lg" />)}
            </div>
          ) : unified.length === 0 ? (
            <div className="flex flex-col items-center py-12 gap-2">
              <ListOrdered className="w-10 h-10 text-muted-foreground/30" />
              <p className="text-sm text-muted-foreground">لا توجد بيانات لدبلوم {tab}</p>
            </div>
          ) : (
            <div className="space-y-1.5 pt-2">
              {unified.map(item => {
                const soNum = formatSupplyOrderNumber(item.num);
                const isRestoring = restoringNum === soNum;

                // ── فجوة حقيقية (لا بيانات) ──
                if (item.kind === 'gap') {
                  return (
                    <div key={item.num}
                      className="flex items-center gap-3 px-3 py-2.5 rounded-xl border border-dashed border-border/50 bg-muted/20">
                      <div className="w-8 h-8 rounded-lg bg-muted/40 flex items-center justify-center shrink-0">
                        <Hash className="w-3.5 h-3.5 text-muted-foreground/50" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-[13px] font-black text-muted-foreground/60">{soNum}</span>
                          <span className="text-[10px] text-muted-foreground/50 bg-muted/40 border border-border/30 px-1.5 py-0.5 rounded-full">فجوة في الترقيم</span>
                        </div>
                        <p className="text-[10px] text-muted-foreground/40 mt-0.5">لا توجد بيانات لهذا الرقم</p>
                      </div>
                    </div>
                  );
                }

                // ── محذوف ناعماً — قابل للاستعادة التلقائية ──
                if (item.kind === 'deleted') {
                  const e = item.entry;
                  return (
                    <div key={item.num}
                      className="flex items-center gap-3 px-3 py-2.5 rounded-xl border-2 border-orange-300/70 bg-orange-50/70">
                      <div className="w-8 h-8 rounded-lg bg-orange-500/15 border border-orange-400/30 flex items-center justify-center shrink-0">
                        <TriangleAlert className="w-3.5 h-3.5 text-orange-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-mono text-[13px] font-black text-orange-700">{soNum}</span>
                          <span className="text-[10px] font-bold text-orange-600 bg-orange-100 border border-orange-300 px-1.5 py-0.5 rounded-full">محذوف — قابل للاستعادة</span>
                          <span className="text-[10px] text-orange-500/70">{fmtShort(e.paid_at)}</span>
                        </div>
                        <p className="text-[10px] text-orange-600/70 truncate mt-0.5">
                          {e.student_count} إيصال · {e.student_names.slice(0, 3).join(' · ')}{e.student_names.length > 3 ? ` +${e.student_names.length - 3}` : ''}
                          {' · '}<span className="font-mono font-bold">{e.total.toFixed(2)} د.ل</span>
                        </p>
                      </div>
                      <button onClick={() => handleRestore(soNum)} disabled={!!restoringNum}
                        className="shrink-0 inline-flex items-center gap-1.5 h-8 px-3 rounded-lg text-[11px] font-bold bg-orange-500 text-white hover:bg-orange-600 disabled:opacity-60 disabled:cursor-not-allowed transition-all whitespace-nowrap">
                        {isRestoring ? <Loader2 className="w-3 h-3 animate-spin" /> : <TriangleAlert className="w-3 h-3" />}
                        {isRestoring ? 'جاري الاستعادة...' : 'استعادة تلقائية'}
                      </button>
                    </div>
                  );
                }

                // ── موجودة ──
                const e = item.entry;
                return (
                  <div key={item.num}
                    className="flex items-center gap-3 px-3 py-2.5 rounded-xl border border-border/40 bg-card hover:bg-muted/10 transition-colors">
                    <div className="w-8 h-8 rounded-lg bg-[#1a3c5e]/8 border border-[#1a3c5e]/15 flex items-center justify-center shrink-0">
                      <CheckCheck className="w-3.5 h-3.5 text-[#1a3c5e]/70" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono text-[13px] font-black text-[#1a3c5e]">{soNum}</span>
                        <span className="text-[10px] text-muted-foreground">{fmtShort(e.paid_at)}</span>
                        <span className="text-[10px] text-muted-foreground/60">· {e.student_count} إيصال</span>
                      </div>
                      <p className="text-[10px] text-muted-foreground/60 truncate mt-0.5">
                        {e.student_names.slice(0, 3).join(' · ')}{e.student_names.length > 3 ? ` +${e.student_names.length - 3}` : ''}
                      </p>
                    </div>
                    <div className="shrink-0 text-left">
                      <span className="font-mono text-[12px] font-black text-[#1a3c5e] tabular-nums">{e.total.toFixed(2)}</span>
                      <span className="text-[10px] text-muted-foreground mr-0.5">د.ل</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ── بطاقة إحصاء ──
function StatCard({ icon: Icon, label, value, sub, gradient }: {
  icon: React.ComponentType<{ className?: string }>;
  label: string; value: string; sub?: string; gradient: string;
}) {
  return (
    <div className={`relative rounded-xl overflow-hidden border shadow-sm ${gradient}`}>
      <div className="p-3.5">
        <div className="flex items-start justify-between gap-2">
          <div>
            <p className="text-[11px] text-white/70 font-medium leading-tight">{label}</p>
            <p className="text-xl font-black text-white leading-none mt-1">{value}</p>
            {sub && <p className="text-[10px] text-white/55 mt-1">{sub}</p>}
          </div>
          <div className="w-8 h-8 rounded-lg bg-white/15 flex items-center justify-center shrink-0">
            <Icon className="w-4 h-4 text-white" />
          </div>
        </div>
      </div>
    </div>
  );
}

// ── ثابت شعار المعهد ──
const LOGO_URL = 'https://miaoda-conversation-file.s3cdn.medo.dev/user-cim4m3x63pxc/app-f6avantw6h35/20261018/FB_IMG_1780949707596.jpg';

// ── مساعدات التاريخ والوقت ──
function fmtArabicDate(iso: string) {
  return new Date(iso).toLocaleDateString('ar-LY', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
}
function fmtArabicTime(iso: string) {
  return new Date(iso).toLocaleTimeString('ar-LY', { hour: '2-digit', minute: '2-digit' });
}

// ── طباعة إيصال — 3 نسخ في A4 احترافي ──
function printReceipt(r: FullReceipt) {
  const win = window.open('', '_blank', 'width=820,height=1100');
  if (!win) return;

  const now          = new Date().toISOString();
  const payDate      = fmtArabicDate(r.paid_at);
  const payTime      = fmtArabicTime(r.paid_at);
  const printDate    = fmtArabicDate(now);
  const printTime    = fmtArabicTime(now);
  const diplLabel    = r.student_diploma === 'عالي' ? 'دبلوم عالٍ' : 'دبلوم متوسط';
  const examLabel    = r.student_exam_only ? 'طالب 100' : 'نظامي';
  const examBadge    = r.student_exam_only
    ? '<span style="background:#f3e8ff;color:#6b21a8;border:1px solid #c084fc;padding:1px 6px;border-radius:4px;font-size:10px;font-weight:800;">طالب 100</span>'
    : '<span style="background:#e0f2fe;color:#0369a1;border:1px solid #38bdf8;padding:1px 6px;border-radius:4px;font-size:10px;font-weight:800;">نظامي</span>';
  const semLabel     = r.semester_target ?? r.payment_type;
  const purposeLabel = r.semester_target
    ? `${r.payment_type} — ${r.semester_target}`
    : r.payment_type;
  const payMethod    = (r as FullReceipt & { payment_method?: string }).payment_method ?? 'كاش';
  const amtInt       = Math.floor(r.amount);
  const amtFrac      = Math.round((r.amount - amtInt) * 1000);
  const receiptNo    = String(r.receipt_number).padStart(5, '0');

  const buildCopy = (copyLabel: string, showSig: boolean) => `
<div class="receipt-copy">
  <header class="header">
    <div class="logo-wrap"><img src="${LOGO_URL}" alt="شعار"/></div>
    <div class="institute-info">
      <h1>معهد القمة للعلوم الطبية والإدارية</h1>
      <div class="sub">الرئيسي — إدارة الشؤون المالية والإدارية</div>
    </div>
    <div class="receipt-badge">
      <div class="copy-tag">${copyLabel}</div>
      <div class="rlabel">إيصال قبض</div>
      <div class="rnum">${receiptNo}</div>
    </div>
  </header>

  <div class="date-bar">
    <span>📅 تاريخ الدفع: <b>${payDate}</b> — <b>${payTime}</b></span>
    <span>🖨️ طُبع: <b>${printDate}</b> الساعة <b>${printTime}</b></span>
  </div>

  <div class="body">
    <div class="student-card">
      <div class="card-title">بيانات الطالب</div>
      <div class="info-grid">
        <div class="info-item"><div class="key">الاسم الرباعي</div><div class="val">${r.student_name}</div></div>
        <div class="info-item"><div class="key">الرقم الوطني</div><div class="val ltr">${r.student_national_id}</div></div>
        <div class="info-item"><div class="key">نوع الدبلوم</div><div class="val">${diplLabel}</div></div>
        <div class="info-item"><div class="key">التخصص</div><div class="val">${r.student_specialization}</div></div>
        <div class="info-item"><div class="key">الفصل الدراسي</div><div class="val">${semLabel}</div></div>
        <div class="info-item"><div class="key">نوع الطالب</div><div class="val">${examLabel} ${examBadge}</div></div>
        ${r.student_phone ? `<div class="info-item"><div class="key">رقم الهاتف</div><div class="val ltr">${r.student_phone}</div></div>` : '<div class="info-item"></div>'}
      </div>
    </div>

    <div class="payment-section">
      <div class="section-title">تفاصيل الدفعة</div>
      <div class="payment-cards">
        <div class="pay-card">
          <div class="pay-icon">📋</div>
          <div class="pay-info"><div class="pay-key">البيان</div><div class="pay-val">${purposeLabel}</div></div>
        </div>
        <div class="pay-card">
          <div class="pay-icon">💳</div>
          <div class="pay-info"><div class="pay-key">طريقة الدفع</div><div class="pay-val">${payMethod}</div></div>
        </div>
        ${r.notes ? `<div class="pay-card pay-card-full"><div class="pay-icon">📝</div><div class="pay-info"><div class="pay-key">ملاحظات</div><div class="pay-val">${r.notes}</div></div></div>` : ''}
      </div>
    </div>

    <div class="amount-box">
      <div class="alabel">إجمالي المبلغ المستلم</div>
      <div class="aright">
        <span class="avalue">${amtInt.toLocaleString('ar-LY')}</span>
        ${amtFrac > 0 ? `<span class="afrac">,${String(amtFrac).padStart(3,'0')}</span>` : ''}
        <span class="acurrency">دينار ليبي</span>
      </div>
    </div>

    ${showSig ? `<div class="sig-single">
      <div class="sig-title">اعتماد الشؤون الإدارية والمالية</div>
      <div class="sig-space"></div>
      <div class="sig-sub">التوقيع والختم الرسمي</div>
    </div>` : ''}
  </div>

  <footer class="footer">
    <span>معهد القمة للعلوم الطبية والإدارية</span>
    <span>إيصال رقم: <b>${receiptNo}</b></span>
    <span>هذا الإيصال وثيقة رسمية احتفظ به</span>
  </footer>
</div>`;

  win.document.write(`<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
<meta charset="utf-8"/>
<title>إيصال قبض — ${receiptNo}</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{font-family:'Cairo',Tahoma,Arial,sans-serif;direction:rtl;background:#fff;color:#111;-webkit-print-color-adjust:exact;print-color-adjust:exact;}
.page{width:210mm;height:297mm;margin:0 auto;display:flex;flex-direction:column;background:#fff;overflow:hidden;}
.receipt-copy{flex:0 0 calc((297mm - 10mm) / 3);width:100%;display:flex;flex-direction:column;overflow:hidden;border:1px solid #dde3ec;background:#fff;}
.cut-line{flex:0 0 5mm;display:flex;align-items:center;gap:4px;padding:0 6px;background:#fff;}
.cut-line::before,.cut-line::after{content:'';flex:1;border-top:1.5px dashed #bbb;}
.cut-line span{font-size:8px;color:#aaa;white-space:nowrap;}
.header{background:linear-gradient(135deg,#1a3a6e 0%,#2563ab 60%,#1e88e5 100%);padding:5px 10px;display:flex;align-items:center;gap:8px;flex-shrink:0;}
.logo-wrap{width:44px;height:44px;border-radius:50%;overflow:hidden;border:2px solid rgba(255,255,255,.5);flex-shrink:0;background:#fff;}
.logo-wrap img{width:100%;height:100%;object-fit:cover}
.institute-info{flex:1;text-align:center;}
.institute-info h1{font-size:11.5px;font-weight:900;color:#fff;line-height:1.3;}
.institute-info .sub{font-size:8.5px;color:rgba(255,255,255,.8);margin-top:1px;}
.receipt-badge{text-align:center;background:rgba(255,255,255,.18);border:1.5px solid rgba(255,255,255,.4);border-radius:7px;padding:3px 8px;flex-shrink:0;min-width:64px;}
.copy-tag{font-size:7.5px;font-weight:700;color:rgba(255,255,255,.85);background:rgba(255,255,255,.15);border-radius:3px;padding:1px 4px;margin-bottom:2px;white-space:nowrap;}
.receipt-badge .rlabel{font-size:8px;color:rgba(255,255,255,.75);font-weight:600;}
.receipt-badge .rnum{font-size:19px;font-weight:900;color:#fff;line-height:1.1;direction:ltr;}
.date-bar{background:#eef3fa;border-bottom:1px solid #c8d9ee;padding:2px 10px;display:flex;justify-content:space-between;font-size:8.5px;color:#444;font-weight:600;flex-shrink:0;}
.date-bar b{color:#1a3a6e;}
.body{padding:4px 10px 3px;flex:1;display:flex;flex-direction:column;gap:4px;overflow:hidden;}
.student-card{background:#f7f9fc;border:1px solid #d0dff2;border-radius:5px;padding:3px 8px;flex-shrink:0;}
.card-title{font-size:8px;font-weight:700;color:#2563ab;border-bottom:1px solid #d0dff2;padding-bottom:2px;margin-bottom:3px;}
.info-grid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:2px 8px;}
.info-item .key{font-size:7.5px;color:#777;font-weight:600;}
.info-item .val{font-size:9.5px;font-weight:800;color:#111;}
.info-item .val.ltr{direction:ltr;text-align:right;}
.payment-section{flex-shrink:0;}
.section-title{font-size:8px;font-weight:700;color:#2563ab;border-bottom:1px solid #d0dff2;padding-bottom:2px;margin-bottom:4px;}
.payment-cards{display:flex;gap:4px;flex-wrap:wrap;}
.pay-card{display:flex;align-items:center;gap:5px;background:#f7f9fc;border:1px solid #d0dff2;border-radius:5px;padding:3px 7px;flex:1;min-width:0;}
.pay-card-full{flex:100%;}
.pay-icon{font-size:12px;flex-shrink:0;}
.pay-info{min-width:0;}
.pay-key{font-size:7.5px;color:#777;font-weight:600;line-height:1.2;}
.pay-val{font-size:10px;font-weight:800;color:#1a3a6e;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.amount-box{background:linear-gradient(135deg,#e8f5e9,#f1f8e9);border:1.5px solid #4caf50;border-radius:5px;padding:4px 8px;display:flex;justify-content:space-between;align-items:center;flex-shrink:0;}
.amount-box .alabel{font-size:9.5px;font-weight:800;color:#1b5e20;}
.aright{display:flex;align-items:baseline;gap:2px;}
.amount-box .avalue{font-size:17px;font-weight:900;color:#2e7d32;direction:ltr;}
.amount-box .afrac{font-size:11px;font-weight:700;color:#2e7d32;}
.amount-box .acurrency{font-size:9px;font-weight:700;color:#388e3c;}
.sig-single{border:1px solid #d0dff2;border-radius:5px;padding:3px 8px;text-align:center;flex-shrink:0;}
.sig-title{font-size:9px;font-weight:800;color:#1a3a6e;}
.sig-space{border-bottom:1.5px solid #aaa;margin:8px 30px 2px;}
.sig-sub{font-size:7.5px;color:#999;}
.footer{background:#1a3a6e;padding:2px 10px;display:flex;justify-content:space-between;align-items:center;font-size:7.5px;color:rgba(255,255,255,.75);flex-shrink:0;}
.footer b{color:#fff;}
@media print{@page{size:A4 portrait;margin:0}html,body{background:#fff;}.page{width:210mm;height:297mm;margin:0;}}
</style>
</head>
<body>
<div class="page">
  ${buildCopy('نسخة الطالب', true)}
  <div class="cut-line"><span>✂ &nbsp;قص هنا&nbsp; ✂</span></div>
  ${buildCopy('نسخة أوامر التوريد', false)}
  <div class="cut-line"><span>✂ &nbsp;قص هنا&nbsp; ✂</span></div>
  ${buildCopy('نسخة الأرشيف', false)}
</div>
<script>window.onload=()=>{window.print();}<\/script>
</body>
</html>`);
  win.document.close();
}

// ── طباعة كل الإيصالات المفلترة ──
function printAllReceipts(receipts: FullReceipt[]) {
  const win = window.open('', '_blank', 'width=900,height=700');
  if (!win) return;
  const rows = receipts.map((r, i) => `
    <tr class="${i % 2 === 0 ? '' : 'alt'}">
      <td>${i + 1}</td>
      <td class="badge-cell"><span class="rnum">${r.receipt_number}</span></td>
      <td>${r.student_name}</td>
      <td>${r.student_diploma}</td>
      <td>${r.student_specialization}</td>
      <td>${r.payment_type}</td>
      <td>${(r as FullReceipt & {payment_method?:string}).semester_target ?? '—'}</td>
      <td class="amount">${r.amount.toFixed(2)} د.ل</td>
      <td>${new Date(r.paid_at).toLocaleDateString('ar-LY')}</td>
    </tr>`).join('');
  const total = receipts.reduce((s, r) => s + r.amount, 0);
  win.document.write(`<html dir="rtl"><head><meta charset="utf-8"><title>كشف الإيصالات</title>
<style>
  body{font-family:Arial,sans-serif;direction:rtl;margin:0;padding:16px;font-size:11px;color:#111}
  h2{text-align:center;color:#1a5276;margin-bottom:4px;font-size:15px}
  .sub{text-align:center;color:#666;font-size:10px;margin-bottom:12px}
  table{width:100%;border-collapse:collapse}
  th{background:#1a5276;color:#fff;padding:6px 8px;text-align:right;font-size:11px}
  td{padding:5px 8px;border-bottom:1px solid #eee}
  .alt{background:#f7fbff}
  .rnum{background:#1a5276;color:#fff;padding:1px 8px;border-radius:10px;font-size:10px;font-weight:700}
  .amount{font-weight:700;color:#1e8449}
  .total-row td{background:#eaf4fb;font-weight:700;border-top:2px solid #1a5276}
  @media print{@page{size:A4 landscape;margin:8mm}}
</style></head><body>
<h2>معهد القمة للعلوم الطبية والإدارية</h2>
<p class="sub">كشف إيصالات الدفع — ${receipts.length} إيصال — إجمالي: ${total.toFixed(2)} د.ل — ${new Date().toLocaleDateString('ar-LY')}</p>
<table>
  <thead><tr><th>#</th><th>رقم الإيصال</th><th>الطالب</th><th>الدبلوم</th><th>التخصص</th><th>نوع الدفع</th><th>البيان</th><th>المبلغ</th><th>التاريخ</th></tr></thead>
  <tbody>${rows}</tbody>
  <tfoot><tr class="total-row"><td colspan="7">الإجمالي</td><td class="amount">${total.toFixed(2)} د.ل</td><td></td></tr></tfoot>
</table>
<script>window.onload=()=>{window.print();}</script>
</body></html>`);
  win.document.close();
}

// ══════════════════════════════════════════════
// الصفحة الرئيسية
// ══════════════════════════════════════════════
const PAGE_SIZE = 80;

export default function ReceiptsPage() {
  const navigate = useNavigate();

  // بيانات الصفحة الحالية (من الخادم)
  const [receipts, setReceipts]         = useState<FullReceipt[]>([]);
  const [totalCount, setTotalCount]     = useState(0);
  const [page, setPage]                 = useState(0); // صفحة صفرية
  const [loading, setLoading]           = useState(true);

  // حالة الفلاتر (مُطبَّقة — تُرسَل للخادم)
  const [search, setSearch]             = useState('');
  const [diplomaFilter, setDiplomaFilter]           = useState('عالي');
  const [specializationFilter, setSpecializationFilter] = useState('all');
  const [paymentTypeFilter, setPaymentTypeFilter]   = useState('all');
  const [dateFromFilter, setDateFromFilter]         = useState('');
  const [dateToFilter, setDateToFilter]             = useState('');

  // حالة خانة البحث المحلية (قبل debounce)
  const [searchInput, setSearchInput]   = useState('');
  const searchTimer                     = useRef<ReturnType<typeof setTimeout> | null>(null);

  const [showSONumbers, setShowSONumbers] = useState(false);

  // ── بناء كائن الفلاتر لإرساله للخادم ──
  const serverFilters = useMemo((): ReceiptFilters => ({
    search:      search || undefined,
    diploma:     diplomaFilter !== 'all' ? diplomaFilter : undefined,
    paymentType: paymentTypeFilter !== 'all' ? paymentTypeFilter : undefined,
    dateFrom:    dateFromFilter || undefined,
    dateTo:      dateToFilter   || undefined,
    limit:  PAGE_SIZE,
    offset: page * PAGE_SIZE,
  }), [search, diplomaFilter, paymentTypeFilter, dateFromFilter, dateToFilter, page]);

  const fetchReceipts = useCallback(async (filters: ReceiptFilters) => {
    setLoading(true);
    try {
      const { data, count } = await getAllReceipts(filters);
      // فلترة التخصص تتم محلياً (عدد قليل بعد باقي الفلاتر)
      const list = specializationFilter !== 'all'
        ? data.filter(r => r.student_specialization === specializationFilter)
        : data;
      setReceipts(list);
      setTotalCount(specializationFilter !== 'all' ? list.length : count);
    } catch { toast.error('خطأ في تحميل الإيصالات'); }
    finally { setLoading(false); }
  }, [specializationFilter]);

  // إعادة الجلب عند تغيّر أي فلتر أو الصفحة
  useEffect(() => { fetchReceipts(serverFilters); }, [fetchReceipts, serverFilters]);

  // إعادة الصفحة للأولى عند تغيير الفلاتر
  const resetPage = useCallback(() => setPage(0), []);

  const handleSearchChange = (v: string) => {
    setSearchInput(v);
    if (searchTimer.current) clearTimeout(searchTimer.current);
    searchTimer.current = setTimeout(() => { setSearch(v.trim()); resetPage(); }, 80);
  };

  // ── ترتيب النتائج محلياً بحسب رقم الإيصال تصاعدياً ──
  const filtered = useMemo(() => [...receipts].sort((a, b) => {
    const nA = parseInt((a.receipt_number ?? '0').replace(/\D/g, ''), 10) || 0;
    const nB = parseInt((b.receipt_number ?? '0').replace(/\D/g, ''), 10) || 0;
    return nA - nB;
  }), [receipts]);

  const totalPages = Math.ceil(totalCount / PAGE_SIZE);

  // ── تخصصات بحسب الدبلوم ──
  const specializationOptions = useMemo(() =>
    diplomaFilter !== 'all'
      ? (SPECIALIZATIONS_BY_DIPLOMA[diplomaFilter] ?? [])
      : [...new Set(Object.values(SPECIALIZATIONS_BY_DIPLOMA).flat())].sort(),
  [diplomaFilter]);

  const hasActiveFilters = specializationFilter !== 'all' || paymentTypeFilter !== 'all' || !!dateFromFilter || !!dateToFilter;
  const clearFilters = () => {
    setDiplomaFilter('عالي'); setSpecializationFilter('all');
    setPaymentTypeFilter('all'); setDateFromFilter(''); setDateToFilter('');
    resetPage();
  };

  // ── إحصاءات (تعمل على الصفحة الحالية المعروضة) ──
  const stats = useMemo(() => {
    const total = filtered.reduce((s, r) => s + r.amount, 0);
    const todayStr = new Date().toDateString();
    const todayRecs = filtered.filter(r => new Date(r.paid_at).toDateString() === todayStr);
    const todayAmt = todayRecs.reduce((s, r) => s + r.amount, 0);
    const uniqueStudents = new Set(filtered.map(r => r.student_id)).size;
    return { total, count: totalCount, todayCount: todayRecs.length, todayAmt, uniqueStudents };
  }, [filtered, totalCount]);

  // ── تصدير Excel (يجلب الكل بدون حدّ) ──
  const handleExportExcel = async () => {
    toast.info('جارٍ تجهيز البيانات للتصدير...');
    const all = await getAllReceiptsUnpaged().catch(() => { toast.error('فشل التصدير'); return [] as FullReceipt[]; });
    const exportList = [...all].sort(compareReceipts);
    const rows = exportList.map((r, i) => ({
      '#': i + 1,
      'رقم الإيصال': r.receipt_number,
      'اسم الطالب': r.student_name,
      'الرقم الوطني': r.student_national_id,
      'الدبلوم': r.student_diploma,
      'التخصص': r.student_specialization,
      'نوع الدفع': r.payment_type,
      'البيان': r.semester_target ?? r.payment_type,
      'المبلغ': r.amount,
      'الملاحظات': r.notes ?? '',
      'التاريخ': new Date(r.paid_at).toLocaleDateString('ar-LY'),
    }));
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'الإيصالات');
    const wbOut = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    triggerDownload(
      new Blob([wbOut], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }),
      `إيصالات-معهد-القمة-${new Date().toLocaleDateString('ar-LY').replace(/\//g, '-')}.xlsx`
    );
    toast.success('تم تصدير Excel');
  };

  // ── تصدير PDF (يجلب الكل بدون حدّ) ──
  const handleExportPDF = async () => {
    toast.info('جارٍ تجهيز بيانات PDF...');
    const all = await getAllReceiptsUnpaged().catch(() => { toast.error('فشل التصدير'); return [] as FullReceipt[]; });
    const exportList = [...all].sort(compareReceipts);
    const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
    const cols = ['#', 'رقم الإيصال', 'الطالب', 'الدبلوم', 'التخصص', 'نوع الدفع', 'البيان', 'المبلغ', 'التاريخ'];
    const rows = exportList.map((r, i) => [
      i + 1, r.receipt_number, r.student_name, `دبلوم ${r.student_diploma}`,
      r.student_specialization, r.payment_type, r.semester_target ?? '—',
      `${r.amount.toFixed(2)} د.ل`, new Date(r.paid_at).toLocaleDateString('ar-LY'),
    ]);
    const total = exportList.reduce((s, r) => s + r.amount, 0);
    autoTable(doc, {
      head: [cols], body: rows,
      foot: [['', '', '', '', '', '', 'الإجمالي', `${total.toFixed(2)} د.ل`, '']],
      styles: { fontSize: 8, halign: 'right' },
      headStyles: { fillColor: [26, 82, 118], textColor: 255, fontStyle: 'bold' },
      footStyles: { fillColor: [234, 244, 251], textColor: 26, fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [247, 251, 255] },
      margin: { top: 22 },
      didDrawPage: () => {
        doc.setFontSize(12); doc.setTextColor(26, 82, 118);
        doc.text('إيصالات الدفع — معهد القمة للعلوم الطبية والإدارية', doc.internal.pageSize.width / 2, 13, { align: 'center' });
        doc.setFontSize(8); doc.setTextColor(150);
        doc.text(`${exportList.length} إيصال | إجمالي: ${total.toFixed(2)} د.ل | ${new Date().toLocaleDateString('ar-LY')}`, 10, 19);
      },
    });
    triggerDownload(
      doc.output('blob'),
      `إيصالات-معهد-القمة-${new Date().toLocaleDateString('ar-LY').replace(/\//g, '-')}.pdf`
    );
    toast.success('تم تصدير PDF');
  };

  return (
    <MainLayout>
      <div className="space-y-4">

        {/* ── الترويسة ── */}
        <div className="relative rounded-2xl overflow-hidden" style={{ boxShadow: 'var(--shadow-lg)' }}>
          <div className="absolute inset-0 bg-gradient-to-br from-indigo-700/90 via-indigo-700/85 to-primary/80" />
          <div className="absolute inset-0 opacity-[0.06]"
            style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '24px 24px' }} />
          <div className="relative px-5 py-4 md:px-7 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <button onClick={() => navigate('/')}
                className="w-9 h-9 rounded-xl bg-white/15 border border-white/20 flex items-center justify-center shrink-0 hover:bg-white/25 transition-colors">
                <ChevronRight className="w-4 h-4 text-white" />
              </button>
              <div className="w-10 h-10 rounded-xl bg-white/15 border border-white/20 flex items-center justify-center shrink-0">
                <ReceiptIcon className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-white">إيصالات الدفع</h1>
                <p className="text-white/60 text-xs mt-0.5">
                  {loading ? 'جاري التحميل...' : `${stats.count} إيصال — إجمالي ${stats.total.toFixed(2)} د.ل`}
                </p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2 shrink-0">
              <button onClick={() => setShowSONumbers(true)}
                className="inline-flex items-center gap-2 h-9 px-4 rounded-xl text-[12px] font-semibold bg-white/15 text-white border border-white/20 hover:bg-white/25 transition-all">
                <ListOrdered className="w-4 h-4" /> أرقام المعاملات
              </button>
              <button onClick={() => printAllReceipts(filtered)}
                className="inline-flex items-center gap-2 h-9 px-4 rounded-xl text-[12px] font-semibold bg-white/15 text-white border border-white/20 hover:bg-white/25 transition-all">
                <Printer className="w-4 h-4" /> طباعة الكل
              </button>
              <button onClick={handleExportExcel}
                className="inline-flex items-center gap-2 h-9 px-4 rounded-xl text-[12px] font-semibold bg-emerald-500 text-white shadow-sm shadow-emerald-500/25 hover:bg-emerald-600 transition-all">
                <FileSpreadsheet className="w-4 h-4" /> Excel
              </button>
              <button onClick={handleExportPDF}
                className="inline-flex items-center gap-2 h-9 px-4 rounded-xl text-[12px] font-semibold bg-red-500 text-white shadow-sm shadow-red-500/20 hover:bg-red-600 transition-all">
                <FileDown className="w-4 h-4" /> PDF
              </button>
              <RefreshButton
                onRefresh={() => fetchReceipts(serverFilters)}
                loading={loading}
                variant="white"
                label="تحديث"
              />
            </div>
          </div>
        </div>

        {/* ── بطاقات الإحصاءات ── */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <StatCard icon={ReceiptIcon} label="إجمالي الإيصالات" value={`${stats.count}`} sub="إيصال مسجل"
            gradient="bg-gradient-to-br from-indigo-600/80 to-indigo-700 border-indigo-600/20" />
          <StatCard icon={BadgeDollarSign} label="إجمالي المحصل" value={`${(stats.total / 1000).toFixed(1)}k`} sub="دينار ليبي"
            gradient="bg-gradient-to-br from-chart-2/80 to-chart-2 border-chart-2/20" />
          <StatCard icon={Clock} label="إيصالات اليوم" value={`${stats.todayCount}`} sub={`${stats.todayAmt.toFixed(0)} د.ل`}
            gradient="bg-gradient-to-br from-amber-500/80 to-amber-600 border-amber-500/20" />
          <StatCard icon={Users} label="الطلاب المشمولون" value={`${stats.uniqueStudents}`} sub="طالب فريد"
            gradient="bg-gradient-to-br from-primary/80 to-primary border-primary/20" />
        </div>

        {/* ── لوحة البحث والفلاتر ── */}
        <Card className="shadow-sm border-border/60 overflow-hidden">
          <div className="border-b border-border/50 bg-muted/10">

            {/* ── شريط البحث النصي ── */}
            <div className="px-4 pt-3.5 pb-3 border-b border-border/30">
              <div className="flex items-center gap-2">
                <div className="relative flex-1">
                  <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                  <Input
                    placeholder="ابحث بالاسم أو رقم الإيصال أو الرقم الوطني أو التخصص أو الهاتف..."
                    value={searchInput}
                    onChange={e => handleSearchChange(e.target.value)}
                    className="pr-9 h-10 text-sm bg-background"
                  />
                </div>
                {searchInput && (
                  <button onClick={() => { setSearchInput(''); setSearch(''); }}
                    className="h-10 px-2.5 rounded-lg text-muted-foreground hover:text-destructive hover:bg-destructive/8 transition-colors">
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {/* ── شبكة الفلاتر ── */}
            <div className="px-4 py-3 space-y-3">
              <div className="flex items-center gap-2 mb-1">
                <Filter className="w-3.5 h-3.5 text-muted-foreground" />
                <span className="text-xs font-semibold text-muted-foreground">تصفية النتائج</span>
                {hasActiveFilters && (
                  <span className="inline-flex items-center gap-1 text-[10px] font-bold text-primary bg-primary/10 border border-primary/20 px-2 py-0.5 rounded-full mr-1">
                    {[diplomaFilter !== 'all', specializationFilter !== 'all', paymentTypeFilter !== 'all', !!dateFromFilter, !!dateToFilter].filter(Boolean).length} فلتر نشط
                  </span>
                )}
              </div>

              {/* صف أول: دبلوم + تخصص + نوع الدفع */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {/* الدبلوم — زرّا اختيار */}
                <div className="space-y-1">
                  <label className="text-[11px] font-semibold text-muted-foreground flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-primary inline-block" /> نوع الدبلوم
                  </label>
                  <div className="flex gap-1.5">
                    {(['عالي', 'متوسط'] as const).map(v => (
                      <button key={v}
                        onClick={() => { setDiplomaFilter(v); setSpecializationFilter('all'); resetPage(); }}
                        className={`flex-1 h-9 px-3 rounded-lg text-[12px] font-bold border transition-all ${
                          diplomaFilter === v
                            ? v === 'عالي'
                              ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                              : 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                            : 'bg-background text-muted-foreground border-border hover:border-primary/40'
                        }`}>
                        {v === 'عالي' ? 'دبلوم عالي' : 'دبلوم متوسط'}
                      </button>
                    ))}
                  </div>
                </div>

                {/* التخصص */}
                <div className="space-y-1">
                  <label className="text-[11px] font-semibold text-muted-foreground flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-chart-4 inline-block" /> التخصص
                  </label>
                  <Select value={specializationFilter} onValueChange={v => { setSpecializationFilter(v); resetPage(); }}>
                    <SelectTrigger className={`h-9 text-xs bg-background w-full ${specializationFilter !== 'all' ? 'border-chart-4/50 ring-1 ring-chart-4/20 text-chart-4 font-semibold' : ''}`}>
                      <SelectValue placeholder="كل التخصصات" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">كل التخصصات</SelectItem>
                      {specializationOptions.map(sp => (
                        <SelectItem key={sp} value={sp}>{sp}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* نوع الدفع */}
                <div className="space-y-1">
                  <label className="text-[11px] font-semibold text-muted-foreground flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-chart-2 inline-block" /> نوع الدفع
                  </label>
                  <Select value={paymentTypeFilter} onValueChange={v => { setPaymentTypeFilter(v); resetPage(); }}>
                    <SelectTrigger className={`h-9 text-xs bg-background w-full ${paymentTypeFilter !== 'all' ? 'border-chart-2/50 ring-1 ring-chart-2/20 text-chart-2 font-semibold' : ''}`}>
                      <SelectValue placeholder="كل أنواع الدفع" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">كل أنواع الدفع</SelectItem>
                      {PAYMENT_TYPES.map(pt => (
                        <SelectItem key={pt} value={pt}>{pt}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* صف ثانٍ: الفترة الزمنية + إجراءات */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 items-end">
                {/* من تاريخ */}
                <div className="space-y-1">
                  <label className="text-[11px] font-semibold text-muted-foreground flex items-center gap-1">
                    <Calendar className="w-3 h-3" /> من تاريخ
                  </label>
                  <Input type="date" value={dateFromFilter} onChange={e => { setDateFromFilter(e.target.value); resetPage(); }}
                    className={`h-9 text-xs bg-background w-full ${dateFromFilter ? 'border-amber-400/50 ring-1 ring-amber-400/20' : ''}`} />
                </div>

                {/* إلى تاريخ */}
                <div className="space-y-1">
                  <label className="text-[11px] font-semibold text-muted-foreground flex items-center gap-1">
                    <Calendar className="w-3 h-3" /> إلى تاريخ
                  </label>
                  <Input type="date" value={dateToFilter} onChange={e => { setDateToFilter(e.target.value); resetPage(); }}
                    className={`h-9 text-xs bg-background w-full ${dateToFilter ? 'border-amber-400/50 ring-1 ring-amber-400/20' : ''}`} />
                </div>

                {/* نتائج + مسح */}
                <div className="flex items-end gap-2 pb-0.5">
                  {!loading && (
                    <div className={`flex-1 rounded-lg px-3 py-2 border text-center ${
                      filtered.length === 0 ? 'bg-muted/30 border-border/40' :
                      hasActiveFilters ? 'bg-primary/8 border-primary/20' : 'bg-muted/30 border-border/40'
                    }`}>
                      <p className="text-[10px] text-muted-foreground leading-none">النتائج</p>
                      <p className="text-sm font-black text-foreground mt-0.5 leading-none">{filtered.length}</p>
                      {filtered.length > 0 && (
                        <p className="text-[10px] text-chart-2 font-semibold mt-0.5 leading-none">
                          {filtered.reduce((s, r) => s + r.amount, 0).toFixed(0)} د.ل
                        </p>
                      )}
                    </div>
                  )}
                  {hasActiveFilters && (
                    <button onClick={clearFilters}
                      className="inline-flex items-center gap-1.5 h-[58px] px-3 rounded-xl text-[11px] font-semibold text-destructive bg-destructive/8 border border-destructive/25 hover:bg-destructive hover:text-white transition-all whitespace-nowrap">
                      <X className="w-3 h-3" /> مسح الكل
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* ── جدول الإيصالات ── */}
          <CardContent className="p-0">
            {loading ? (
              <div className="p-4 space-y-2">
                {Array(8).fill(0).map((_, i) => (
                  <div key={i} className="flex items-center gap-3 h-10">
                    <Skeleton className="h-5 w-20 rounded-md" />
                    <Skeleton className="h-4 w-32" />
                    <Skeleton className="h-4 flex-1" />
                    <Skeleton className="h-5 w-16 rounded-full" />
                    <Skeleton className="h-4 w-16" />
                    <Skeleton className="h-7 w-16 rounded-lg" />
                  </div>
                ))}
              </div>
            ) : filtered.length === 0 ? (
              <div className="flex flex-col items-center py-16 gap-3">
                <div className="w-16 h-16 rounded-full bg-muted/40 flex items-center justify-center">
                  <ReceiptIcon className="w-7 h-7 text-muted-foreground/40" />
                </div>
                <p className="text-sm font-medium text-muted-foreground">لا توجد إيصالات مطابقة</p>
                {(search || hasActiveFilters) && (
                  <button onClick={() => { setSearchInput(''); setSearch(''); clearFilters(); }}
                    className="text-xs text-primary hover:underline">مسح كل الفلاتر</button>
                )}              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-right min-w-max">
                  <thead>
                    <tr className="bg-muted/30 border-b border-border/40">
                      {['#', 'رقم الإيصال', 'الطالب', 'الدبلوم / التخصص', 'نوع الدفع', 'البيان', 'المبلغ', 'التاريخ', 'إجراء'].map(h => (
                        <th key={h} className="px-3 py-2.5 text-[11px] font-bold text-muted-foreground whitespace-nowrap first:pr-4 last:pl-4">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map((r, i) => (
                      <tr key={r.id}
                        className={`border-b border-border/20 hover:bg-indigo-500/4 transition-colors group ${i % 2 !== 0 ? 'bg-muted/8' : ''}`}>
                        {/* # */}
                        <td className="pr-4 py-2.5 text-[11px] text-muted-foreground/60 font-mono">{i + 1}</td>

                        {/* رقم الإيصال */}
                        <td className="px-3 py-2.5 whitespace-nowrap">
                          <span className="font-mono text-[11px] font-black text-indigo-600 bg-indigo-500/10 border border-indigo-400/20 px-2 py-0.5 rounded-md">
                            {r.receipt_number}
                          </span>
                        </td>

                        {/* الطالب */}
                        <td className="px-3 py-2.5 whitespace-nowrap">
                          <p className="text-[12px] font-bold text-foreground leading-tight">{r.student_name}</p>
                          <p className="text-[10px] font-mono text-muted-foreground/60 mt-0.5">{r.student_national_id}</p>
                        </td>

                        {/* الدبلوم / التخصص */}
                        <td className="px-3 py-2.5 whitespace-nowrap">
                          <div className="flex items-center gap-1.5">
                            <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md border ${
                              r.student_diploma === 'عالي' ? 'bg-blue-50 text-blue-700 border-blue-200' : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            }`}>{r.student_diploma}</span>
                            <span className="text-[11px] text-foreground/80">{r.student_specialization}</span>
                          </div>
                        </td>

                        {/* نوع الدفع */}
                        <td className="px-3 py-2.5 whitespace-nowrap">
                          <span className={`inline-flex items-center text-[10px] font-bold px-2 py-0.5 rounded-full border ${paymentTypeBadge(r.payment_type)}`}>
                            {r.payment_type}
                          </span>
                        </td>

                        {/* البيان */}
                        <td className="px-3 py-2.5 text-[11px] text-muted-foreground">
                          {r.semester_target ?? '—'}
                        </td>

                        {/* المبلغ */}
                        <td className="px-3 py-2.5 whitespace-nowrap">
                          <span className="text-[13px] font-black text-chart-2 font-mono">{r.amount.toFixed(2)}</span>
                          <span className="text-[10px] text-chart-2/60 mr-0.5">د.ل</span>
                        </td>

                        {/* التاريخ */}
                        <td className="px-3 py-2.5 whitespace-nowrap">
                          <div className="text-[11px] text-muted-foreground">
                            {new Date(r.paid_at).toLocaleDateString('ar-LY')}
                          </div>
                          <div className="text-[10px] text-muted-foreground/50 mt-0.5">
                            {new Date(r.paid_at).toLocaleTimeString('ar-LY', { hour: '2-digit', minute: '2-digit' })}
                          </div>
                        </td>

                        {/* إجراء */}
                        <td className="pl-4 py-2.5 whitespace-nowrap">
                          <button onClick={() => printReceipt(r)}
                            className="inline-flex items-center gap-1 h-7 px-2.5 rounded-lg text-[10px] font-semibold bg-slate-500/8 text-slate-600 hover:bg-slate-600 hover:text-white transition-all border border-slate-400/20 opacity-0 group-hover:opacity-100">
                            <Printer className="w-3 h-3" /> طباعة
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  {/* ── تذييل الجدول + ترقيم الصفحات ── */}
                  {filtered.length > 1 && (
                    <tfoot>
                      <tr className="bg-indigo-500/8 border-t-2 border-indigo-400/30">
                        <td colSpan={6} className="px-3 py-2.5 text-xs font-bold text-muted-foreground text-right pr-4">
                          الإجمالي ({filtered.length} إيصال{totalPages > 1 ? ` — صفحة ${page + 1} من ${totalPages}` : ''})
                        </td>
                        <td className="px-3 py-2.5 whitespace-nowrap">
                          <span className="text-base font-black text-chart-2 font-mono">
                            {filtered.reduce((s, r) => s + r.amount, 0).toFixed(2)}
                          </span>
                          <span className="text-[10px] text-chart-2/60 mr-0.5">د.ل</span>
                        </td>
                        <td colSpan={2} />
                      </tr>
                    </tfoot>
                  )}
                </table>
              </div>
            )}
            {/* ── أزرار الصفحات ── */}
            {totalPages > 1 && !loading && (
              <div className="flex items-center justify-center gap-2 px-4 py-3 border-t border-border/30">
                <button
                  disabled={page === 0}
                  onClick={() => setPage(p => p - 1)}
                  className="h-8 px-3 rounded-lg text-xs font-semibold border border-border/50 bg-background hover:bg-muted/40 disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
                  ← السابق
                </button>
                <span className="text-xs text-muted-foreground font-mono tabular-nums">
                  {page + 1} / {totalPages}
                </span>
                <button
                  disabled={page >= totalPages - 1}
                  onClick={() => setPage(p => p + 1)}
                  className="h-8 px-3 rounded-lg text-xs font-semibold border border-border/50 bg-background hover:bg-muted/40 disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
                  التالي →
                </button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* نافذة أرقام أوامر التوريد */}
      <SupplyOrderNumbersDialog open={showSONumbers} onClose={() => setShowSONumbers(false)} />
    </MainLayout>
  );
}
