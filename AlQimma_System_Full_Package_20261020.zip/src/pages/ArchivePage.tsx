// صفحة الأرشيف — الطلاب الخريجون (لقطة مجمّدة احترافية)
import { useEffect, useState, useMemo, useCallback, useRef } from 'react';
import {
  Archive, Search, Trash2, RefreshCw, GraduationCap,
  User, BookOpen, DollarSign, Calendar, Phone, MapPin,
  ShieldAlert, Users, BadgeCheck, Printer, Eye,
  AlertCircle, CheckCircle2, FileText, CreditCard,
  ChevronDown, ChevronUp, Award, X, FileDown,
} from 'lucide-react';
import { toast } from 'sonner';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { getArchivedStudents, getArchivedStudentDetails, getArchiveStats, clearArchive, compareReceipts, type ArchivedStudentLean, type ArchiveStats } from '@/lib/api';
import { SYSTEM_PASSWORD, SEMESTER_LABELS } from '@/types/index';
import { StudentAvatar } from '@/components/ui/StudentAvatar';
import { RefreshButton } from '@/components/ui/RefreshButton';
import { printTable, exportPDF, LOGO_URL, INSTITUTE_NAME } from '@/lib/printUtils';

type ArchivedStudent = ArchivedStudentLean;

const AR_MONTHS = ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];function fmtDate(iso: string | null | undefined) {
  if (!iso) return '—';
  const d = new Date(iso);
  return `${d.getDate()} ${AR_MONTHS[d.getMonth()]} ${d.getFullYear()}`;
}
function fmtTime(iso: string | null | undefined) {
  if (!iso) return '';
  const d = new Date(iso);
  return d.toLocaleTimeString('ar-LY', { hour: '2-digit', minute: '2-digit' });
}
function fmtMoney(v: number) { return v.toLocaleString('ar-LY', { minimumFractionDigits: 2 }) + ' د.ل'; }

// ── بيان الإيصال: أولوية: semester_target → payment_type → notes → 'دفعة'
function receiptLabel(r: any): string {
  if (r.semester_target && r.semester_target.trim()) return r.semester_target.trim();
  if (r.payment_type === 'تسجيل' || r.payment_type === 'registration') return 'رسوم التسجيل';
  if (r.payment_type === 'مشروع تخرج') return 'مشروع التخرج';
  if (r.payment_type === 'فصلي' && r.semester_number)
    return SEMESTER_LABELS[r.semester_number] ?? `الفصل ${r.semester_number}`;
  if (r.notes && !r.notes.startsWith('تخفيض:')) return r.notes;
  return 'دفعة';
}

// ── رقم الإيصال المنسّق
function fmtReceiptNo(r: any): string {
  const n = r.receipt_number ?? r.supply_order_number ?? '';
  if (!n || n === 'null' || n === 'undefined') return '—';
  const num = parseInt(String(n), 10);
  return isNaN(num) ? String(n) : String(num).padStart(5, '0');
}

// ── طباعة إيصال واحد من بيانات snapshot (بدون Student object)
function printReceiptFromSnapshot(student: ArchivedStudent, r: any) {
  const receiptNo  = fmtReceiptNo(r);
  const payDate    = fmtDate(r.paid_at);
  const payTime    = fmtTime(r.paid_at);
  const now        = new Date().toISOString();
  const printDate  = fmtDate(now);
  const printTime  = fmtTime(now);
  const purpose    = receiptLabel(r);
  const amt        = parseFloat(r.amount ?? 0);
  const amtInt     = Math.floor(amt);
  const amtFrac    = Math.round((amt - amtInt) * 1000);
  const payMethod  = r.payment_method ?? 'كاش';
  const diplLabel  = student.diploma_type === 'عالي' ? 'دبلوم عالٍ' : 'دبلوم متوسط';

  const html = `<!DOCTYPE html><html dir="rtl" lang="ar"><head><meta charset="UTF-8"/>
<title>إيصال #${receiptNo}</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',Tahoma,Arial,sans-serif;background:#f0f4f8;color:#1a1a2e;direction:rtl}
@media print{body{background:#fff}.no-print{display:none!important}@page{size:A5 portrait;margin:8mm}}
.page{max-width:560px;margin:10px auto;background:#fff;border-radius:14px;overflow:hidden;box-shadow:0 4px 24px rgba(15,39,68,.15)}
.hdr{display:flex;align-items:center;gap:12px;background:linear-gradient(135deg,#0f2744,#1a3c5e,#1e5a94);padding:14px 18px}
.hdr img{width:58px;height:58px;border-radius:50%;border:2.5px solid rgba(255,255,255,.85);background:#fff}
.hdr-text{flex:1}.hdr-text h1{font-size:13px;font-weight:900;color:#fff;line-height:1.3}
.hdr-text .sub{font-size:10px;color:rgba(255,255,255,.65);margin-top:2px}
.badge{text-align:center;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);border-radius:10px;padding:6px 12px}
.badge .copy-tag{font-size:9px;color:rgba(255,255,255,.7);font-weight:700;letter-spacing:.5px}
.badge .rlabel{font-size:11px;font-weight:900;color:#fff}
.badge .rnum{font-size:16px;font-weight:900;color:#fbbf24;font-family:monospace}
.datebar{display:flex;justify-content:space-between;background:#f1f5fb;padding:7px 18px;font-size:10px;color:#4a5568;border-bottom:1px solid #e2e8f0}
.body{padding:14px 18px;display:flex;flex-direction:column;gap:12px}
.card{background:#f8faff;border:1px solid #e2e8f0;border-radius:10px;overflow:hidden}
.card-title{background:#1a3c5e;color:#fff;font-size:10px;font-weight:800;padding:5px 12px;letter-spacing:.3px}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:1px;background:#e2e8f0}
.cell{background:#fff;padding:7px 10px}
.cell .k{font-size:9px;color:#718096;font-weight:600;margin-bottom:2px}
.cell .v{font-size:11px;font-weight:700;color:#1a1a2e}
.pay-row{display:flex;align-items:center;gap:10px;padding:8px 12px;border-bottom:1px solid #f1f5fb}
.pay-row:last-child{border-bottom:none}
.pay-icon{font-size:16px;width:28px;text-align:center;flex-shrink:0}
.pay-k{font-size:9px;color:#718096;font-weight:600}
.pay-v{font-size:12px;font-weight:800;color:#1a1a2e}
.amt-box{background:linear-gradient(135deg,#0f2744,#1a3c5e);border-radius:10px;padding:14px 18px;text-align:center}
.amt-label{font-size:10px;color:rgba(255,255,255,.7);font-weight:700;margin-bottom:6px}
.amt-val{font-size:28px;font-weight:900;color:#fbbf24;font-family:monospace}
.amt-cur{font-size:14px;font-weight:700;color:rgba(255,255,255,.85);margin-right:4px}
.sig-row{display:flex;justify-content:space-between;padding:8px 18px 14px;border-top:1px dashed #e2e8f0}
.sig-box{text-align:center}.sig-line{border-bottom:1.5px solid #aaa;width:110px;height:24px}
.sig-lbl{font-size:9px;color:#718096;font-weight:600;margin-top:4px}
.print-btn{display:block;width:calc(100% - 36px);margin:0 18px 14px;padding:10px;background:#1a3c5e;color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit}
</style></head><body>
<div class="page">
  <div class="hdr">
    <img src="${LOGO_URL}" alt="شعار" crossorigin="anonymous"/>
    <div class="hdr-text">
      <h1>${INSTITUTE_NAME}</h1>
      <div class="sub">إدارة الشؤون المالية</div>
    </div>
    <div class="badge">
      <div class="copy-tag">نسخة المعهد</div>
      <div class="rlabel">إيصال قبض</div>
      <div class="rnum">#${receiptNo}</div>
    </div>
  </div>
  <div class="datebar">
    <span>📅 تاريخ الدفع: <b>${payDate}</b>${payTime ? ` — <b>${payTime}</b>` : ''}</span>
    <span>🖨️ طُبع: <b>${printDate}</b> — <b>${printTime}</b></span>
  </div>
  <div class="body">
    <div class="card">
      <div class="card-title">بيانات الطالب</div>
      <div class="grid">
        <div class="cell"><div class="k">الاسم</div><div class="v">${student.full_name}</div></div>
        <div class="cell"><div class="k">الرقم الوطني</div><div class="v">${student.national_id ?? '—'}</div></div>
        <div class="cell"><div class="k">نوع الدبلوم</div><div class="v">${diplLabel}</div></div>
        <div class="cell"><div class="k">التخصص</div><div class="v">${student.specialization ?? '—'}</div></div>
      </div>
    </div>
    <div class="card">
      <div class="card-title">تفاصيل الدفعة</div>
      <div class="pay-row"><div class="pay-icon">📋</div><div><div class="pay-k">البيان</div><div class="pay-v">${purpose}</div></div></div>
      <div class="pay-row"><div class="pay-icon">💳</div><div><div class="pay-k">طريقة الدفع</div><div class="pay-v">${payMethod}</div></div></div>
      ${r.notes && !r.notes.startsWith('تخفيض:') ? `<div class="pay-row"><div class="pay-icon">📝</div><div><div class="pay-k">ملاحظات</div><div class="pay-v">${r.notes}</div></div></div>` : ''}
    </div>
    <div class="amt-box">
      <div class="amt-label">إجمالي المبلغ المستلم</div>
      <div><span class="amt-val">${amtInt.toLocaleString('ar-LY')}${amtFrac > 0 ? ',' + String(amtFrac).padStart(3,'0') : ''}</span>
      <span class="amt-cur">دينار ليبي</span></div>
    </div>
    <div class="sig-row">
      <div class="sig-box"><div class="sig-line"></div><div class="sig-lbl">المحاسب</div></div>
      <div class="sig-box"><div class="sig-line"></div><div class="sig-lbl">توقيع الطالب</div></div>
      <div class="sig-box"><div class="sig-line"></div><div class="sig-lbl">المدير</div></div>
    </div>
  </div>
  <button class="print-btn no-print" onclick="window.print()">🖨️ طباعة الإيصال</button>
</div>
<script>setTimeout(()=>window.print(),600)</script>
</body></html>`;

  const win = window.open('about:blank', '_blank', 'width=620,height=750,menubar=no,toolbar=no');
  if (!win) {
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url  = URL.createObjectURL(blob);
    const a    = Object.assign(document.createElement('a'), { href: url, target: '_blank' });
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 10000);
    return;
  }
  win.document.open(); win.document.write(html); win.document.close();
}

// ── مكوّن بطاقة الطالب الاحترافية ──────────────────────────────────────────
function StudentArchiveCard({ s, onClick }: { s: ArchivedStudent; onClick: () => void }) {
  const paid    = s.total_paid ?? 0;
  const charged = s.total_charged ?? 0;
  const rem     = s.remaining_amount ?? 0;
  const pct     = charged > 0 ? Math.min(100, (paid / charged) * 100) : 100;
  const isHigh  = s.diploma_type === 'عالي';
  const settled = rem <= 0.01;
  const isExam  = (s as any).is_exam_only;

  return (
    <button
      onClick={onClick}
      className="group w-full text-right rounded-2xl overflow-hidden border transition-all duration-200
                 hover:shadow-xl hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1a3c5e]/40
                 bg-gradient-to-br from-[#0f2744] via-[#1a3c5e] to-[#1d4e7a] border-[#1a3c5e]/60">
      <div className="p-4">
        {/* الصف الأول: الصورة + المعلومات */}
        <div className="flex items-start gap-3 mb-3">
          <div className="shrink-0 relative">
            <StudentAvatar photoUrl={s.photo_url} name={s.full_name} size="lg" variant="rounded" />
            <span className={`absolute -bottom-1 -left-1 w-4 h-4 rounded-full border-2 border-[#1a3c5e] ${settled ? 'bg-emerald-400' : 'bg-amber-400'}`} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2 mb-1">
              <p className="font-black text-sm text-white leading-tight line-clamp-2 flex-1">{s.full_name}</p>
              <div className="flex flex-col items-end gap-1 shrink-0">
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${isHigh
                  ? 'bg-blue-400/20 text-blue-200 border-blue-400/40'
                  : 'bg-emerald-400/20 text-emerald-200 border-emerald-400/40'}`}>{s.diploma_type}</span>
              </div>
            </div>
            {s.specialization && (
              <p className="text-[11px] text-white/60 flex items-center gap-1 mb-0.5">
                <BookOpen className="w-3 h-3 shrink-0" /><span className="truncate">{s.specialization}</span>
              </p>
            )}
            {s.national_id && (
              <p className="text-[10px] font-mono text-white/35 tracking-wider">{s.national_id}</p>
            )}
          </div>
        </div>

        {/* فاصل */}
        <div className="border-t border-white/10 my-2.5" />

        {/* شريط التقدم المالي */}
        <div className="mb-2.5">
          <div className="flex justify-between items-center mb-1">
            <span className="text-[10px] text-white/55">نسبة السداد</span>
            <span className={`text-[11px] font-black tabular-nums ${settled ? 'text-emerald-300' : 'text-amber-300'}`}>{pct.toFixed(0)}%</span>
          </div>
          <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
            <div className={`h-full rounded-full transition-all duration-500 ${settled
              ? 'bg-gradient-to-l from-emerald-300 to-emerald-500'
              : 'bg-gradient-to-l from-amber-300 to-amber-500'}`}
              style={{ width: `${pct}%` }} />
          </div>
        </div>

        {/* الصف السفلي */}
        <div className="flex items-center justify-between gap-2">
          {settled
            ? <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-300 bg-emerald-400/15 border border-emerald-400/30 px-2 py-0.5 rounded-full">
                <CheckCircle2 className="w-3 h-3" />سداد كامل
              </span>
            : <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-300 bg-amber-400/15 border border-amber-400/30 px-2 py-0.5 rounded-full">
                <AlertCircle className="w-3 h-3" />متبقي {fmtMoney(rem)}
              </span>
          }
          <div className="text-left">
            <p className="text-xs font-black text-white tabular-nums">{fmtMoney(paid)}</p>
            <p className="text-[10px] text-white/40 flex items-center gap-0.5 justify-end">
              <Calendar className="w-2.5 h-2.5 shrink-0" />{fmtDate(s.archived_at)}
            </p>
          </div>
        </div>
      </div>

      {/* شريط الإجراء السفلي */}
      <div className="border-t border-white/10 px-4 py-2 flex items-center justify-between
                      bg-black/20 group-hover:bg-black/30 transition-colors">
        <span className="text-[10px] text-white/40 flex items-center gap-1">
          <Archive className="w-3 h-3" />خريج
        </span>
        <span className="text-[11px] font-semibold text-white/70 group-hover:text-white flex items-center gap-1 transition-colors">
          <Eye className="w-3.5 h-3.5" />فتح الملف
        </span>
      </div>
    </button>
  );
}

// ── مساعد: رأس القسم ─────────────────────────────────────────────────────────
function SectionHeader({ icon: Icon, title, color }: {
  icon: React.ElementType; title: string;
  color: 'blue' | 'indigo' | 'emerald' | 'violet' | 'amber';
}) {
  const cls: Record<string, string> = {
    blue:    'bg-blue-500/10 text-blue-600',
    indigo:  'bg-indigo-500/10 text-indigo-600',
    emerald: 'bg-emerald-500/10 text-emerald-600',
    violet:  'bg-violet-500/10 text-violet-600',
    amber:   'bg-amber-500/10 text-amber-600',
  };
  return (
    <div className="flex items-center gap-2 mb-3">
      <div className={`w-7 h-7 rounded-xl flex items-center justify-center shrink-0 ${cls[color]}`}>
        <Icon className="w-4 h-4" />
      </div>
      <h3 className="text-sm font-black text-foreground">{title}</h3>
      <div className="flex-1 h-px bg-border/50" />
    </div>
  );
}

// ── مكوّن خلية بيانات ────────────────────────────────────────────────────────
function InfoCell({ label, value, mono, full }: { label: string; value: string; mono?: boolean; full?: boolean }) {
  return (
    <div className={`bg-muted/30 rounded-xl p-3 border border-border/30 ${full ? 'col-span-full' : ''}`}>
      <p className="text-[9px] text-muted-foreground/60 uppercase tracking-wide font-semibold mb-1">{label}</p>
      <p className={`text-xs font-bold text-foreground break-words leading-snug ${mono ? 'font-mono' : ''}`}>{value || '—'}</p>
    </div>
  );
}

// ── مكوّن نافذة الملف الأرشيفي الكامل ──────────────────────────────────────
function ArchiveFileDialog({ s, onClose }: { s: ArchivedStudent; onClose: () => void }) {
  const [tab, setTab] = useState<'personal' | 'academic' | 'financial' | 'receipts' | 'files'>('personal');
  const receipts = useMemo(() =>
    [...(s.receipts_snapshot ?? [])].sort((a: any, b: any) => {
      const numA = parseInt((a.receipt_number ?? '0').replace(/\D/g, ''), 10) || 0;
      const numB = parseInt((b.receipt_number ?? '0').replace(/\D/g, ''), 10) || 0;
      if (numA !== numB) return numA - numB;
      return new Date(a.paid_at ?? 0).getTime() - new Date(b.paid_at ?? 0).getTime();
    }),
  [s]);
  const charges  = s.charges_snapshot ?? [];
  const files    = (s as any).files_snapshot ?? [];
  const settled  = (s.remaining_amount ?? 0) <= 0.01;
  const isHigh   = s.diploma_type === 'عالي';
  const isExam   = (s as any).is_exam_only;
  const paid     = s.total_paid ?? 0;
  const charged  = s.total_charged ?? 0;
  const pct      = charged > 0 ? Math.min(100, (paid / charged) * 100) : 100;

  const handlePrint = () => {
    const LOGO = 'https://miaoda-conversation-file.s3cdn.medo.dev/user-cim4m3x63pxc/app-f6avantw6h35/20261018/FB_IMG_1780949707596.jpg';
    const win = window.open('', '_blank', 'width=900,height=750');
    if (!win) return;
    const today   = new Date().toLocaleDateString('ar-LY');
    const debtAmt = s.remaining_amount ?? 0;
    const paidPct = charged > 0 ? Math.round((paid / charged) * 100) : 100;

    // صف معلومة
    const infoRow = (label: string, val: string | number | null | undefined, mono = false) =>
      `<div class="ic"><div class="il">${label}</div><div class="iv${mono ? ' mono' : ''}">${val ?? '—'}</div></div>`;

    // صف وثيقة
    const docRow = (label: string, ok: boolean) =>
      `<div class="dr"><span class="di ${ok ? 'ok' : 'ms'}">${ok ? '✓' : '✗'}</span>
       <span class="dl">${label}</span>
       <span class="db ${ok ? 'bok' : 'bms'}">${ok ? 'مكتمل' : 'ناقص'}</span></div>`;

    const chargesHtml = charges.length === 0
      ? '<tr><td colspan="6" style="text-align:center;color:#94a3b8;padding:8px">لا توجد بنود</td></tr>'
      : charges.map((c: any, i: number) => {
          const label = c.charge_type === 'تسجيل' ? 'رسوم التسجيل'
            : c.charge_type === 'مشروع تخرج' ? 'مشروع التخرج'
            : c.charge_type === 'معادلة' ? `رسوم معادلة ${SEMESTER_LABELS[c.semester_number] ?? `الفصل ${c.semester_number}`}`
            : c.charge_type === 'فصلي' ? (SEMESTER_LABELS[c.semester_number] ?? `الفصل ${c.semester_number}`)
            : (c.charge_type ?? '—');
          const eff   = (c.charge_amount ?? 0) - (c.discount_amount ?? 0);
          const paidC = c.paid_amount ?? 0;
          const remC  = c.remaining_amount ?? Math.max(0, eff - paidC);
          return `<tr>
            <td>${i + 1}</td>
            <td>${label}</td>
            <td style="text-align:center">${Number(c.charge_amount ?? 0).toLocaleString('ar-LY')} د.ل</td>
            <td style="text-align:center;color:#7c3aed">${c.discount_amount > 0 ? Number(c.discount_amount).toLocaleString('ar-LY') + ' د.ل' : '—'}</td>
            <td style="text-align:center;color:#16a34a;font-weight:800">${Number(paidC).toLocaleString('ar-LY')} د.ل</td>
            <td style="text-align:center;color:${remC > 0.01 ? '#dc2626' : '#16a34a'};font-weight:800">${remC > 0.01 ? Number(remC).toLocaleString('ar-LY') + ' د.ل' : '✓ مسدد'}</td>
            <td style="text-align:center"><span style="padding:2px 7px;border-radius:20px;font-size:9px;font-weight:700;background:${c.is_cleared ? '#dcfce7' : '#fef3c7'};color:${c.is_cleared ? '#15803d' : '#92400e'};border:1px solid ${c.is_cleared ? '#86efac' : '#fcd34d'}">${c.is_cleared ? '✓ مسدد' : 'متبقي'}</span></td>
          </tr>`;
        }).join('');

    const receiptsHtml = receipts.length === 0
      ? '<p style="text-align:center;color:#94a3b8;font-size:11px;padding:8px 0">لا توجد إيصالات</p>'
      : receipts.map((r: any, i: number) => {
          const label = r.payment_type === 'تقسيط'
            ? (r.semester_target ? `فصل ${r.semester_target}` : 'دفعة')
            : (r.payment_type ?? 'دفعة');
          return `<tr>
            <td>${i + 1}</td>
            <td><span class="mono" style="font-size:9.5px">#${r.receipt_number ?? '—'}</span></td>
            <td>${label}</td>
            <td>${new Date(r.paid_at).toLocaleDateString('ar-LY')}</td>
            <td style="color:#16a34a;font-weight:800">${Number(r.amount ?? 0).toLocaleString('ar-LY')} د.ل</td>
            <td>${r.payment_method ?? '—'}</td>
          </tr>`;
        }).join('');

    win.document.write(`<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<title>ملف الأرشيف — ${s.full_name}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;900&display=swap');
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:'Cairo',sans-serif;direction:rtl;background:#f0f4f8;color:#1a2332;font-size:12px;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .page{width:210mm;min-height:297mm;margin:0 auto;padding:9mm 11mm;background:#f0f4f8}

  /* رأس الصفحة */
  .hdr{background:linear-gradient(135deg,#0f2744 0%,#1a3c5e 55%,#1e5a94 100%);border-radius:13px;padding:13px 17px;margin-bottom:9px;display:flex;align-items:center;gap:13px;position:relative;overflow:hidden;box-shadow:0 4px 18px rgba(15,39,68,.35)}
  .hdr::before{content:'';position:absolute;inset:0;background:repeating-linear-gradient(45deg,rgba(255,255,255,.025) 0,rgba(255,255,255,.025) 1px,transparent 1px,transparent 18px)}
  .hdr-logo{width:65px;height:65px;border-radius:50%;border:3px solid rgba(255,255,255,.85);overflow:hidden;flex-shrink:0;background:#fff;box-shadow:0 0 0 4px rgba(255,255,255,.14),0 4px 14px rgba(0,0,0,.28);z-index:1;position:relative}
  .hdr-logo img{width:100%;height:100%;object-fit:cover}
  .hdr-text{flex:1;z-index:1;position:relative}
  .hdr-text h1{font-size:16px;font-weight:900;color:#fff;margin-bottom:3px}
  .hdr-text .s1{font-size:10.5px;color:rgba(165,210,255,.95);font-weight:600;margin-bottom:1px}
  .hdr-text .s2{font-size:9.5px;color:rgba(180,215,255,.7)}
  .hdr-r{text-align:center;flex-shrink:0;z-index:1;position:relative}
  .hdr-date{background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);border-radius:8px;padding:6px 12px}
  .hdr-date .dl{font-size:8px;color:rgba(180,215,255,.8);display:block;margin-bottom:2px}
  .hdr-date .dv{font-size:11px;font-weight:900;color:#fff}

  /* بطاقة الطالب */
  .sc{background:#fff;border-radius:11px;padding:12px 15px;margin-bottom:7px;box-shadow:0 2px 9px rgba(15,39,68,.10);border:1px solid #e2e8f0;display:flex;gap:13px;align-items:flex-start}
  .sp{width:76px;height:76px;border-radius:9px;overflow:hidden;flex-shrink:0;border:2px solid #e2e8f0;background:#f8faff}
  .sp img{width:100%;height:100%;object-fit:cover}
  .sp .np{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:26px;color:#94a3b8;background:#f1f5f9}
  .sm{flex:1;min-width:0}
  .sn{font-size:15px;font-weight:900;color:#0f2744;margin-bottom:3px}
  .sid{font-size:9.5px;color:#94a3b8;font-family:monospace;margin-bottom:5px}
  .sb{display:flex;flex-wrap:wrap;gap:4px;margin-bottom:5px}
  .badge{display:inline-block;padding:2px 8px;border-radius:20px;font-size:9.5px;font-weight:700;white-space:nowrap}
  .ba{background:#dcfce7;color:#15803d;border:1px solid #86efac}
  .bh{background:#dbeafe;color:#1d4ed8;border:1px solid #93c5fd}
  .bm{background:#f0fdf4;color:#15803d;border:1px solid #86efac}
  .be{background:#f3e8ff;color:#7e22ce;border:1px solid #d8b4fe}
  .br{background:#e0f2fe;color:#0369a1;border:1px solid #7dd3fc}
  .sl{display:flex;gap:14px;flex-wrap:wrap;font-size:10px;color:#475569}
  .sl span{display:flex;align-items:center;gap:3px}

  /* بطاقة عامة */
  .card{background:#fff;border-radius:11px;padding:11px 14px;margin-bottom:7px;box-shadow:0 2px 9px rgba(15,39,68,.09);border:1px solid #e2e8f0}
  .st{font-size:10.5px;font-weight:800;color:#1a3c5e;margin-bottom:9px;padding-bottom:4px;border-bottom:2px solid #e2e8f0;display:flex;align-items:center;gap:4px;letter-spacing:.3px}
  .st::before{content:'';display:inline-block;width:3.5px;height:13px;background:#1e5a94;border-radius:2px;flex-shrink:0}

  /* شبكة المعلومات */
  .ig{display:grid;grid-template-columns:repeat(3,1fr);gap:5px 14px}
  .ic{padding:4px 7px;border-radius:5px;background:#f8faff;border:1px solid #e8eef7}
  .il{font-size:8px;color:#94a3b8;font-weight:600;margin-bottom:1px}
  .iv{font-size:10.5px;font-weight:700;color:#1a3c5e}.iv.mono{font-family:monospace;font-size:10px}

  /* المالية */
  .fg{display:grid;grid-template-columns:repeat(4,1fr);gap:7px;margin-bottom:9px}
  .fb{border-radius:7px;padding:7px 9px;text-align:center}
  .fb .fl{font-size:8px;font-weight:600;margin-bottom:1px}
  .fb .fv{font-size:13px;font-weight:900}
  .fch{background:#eff6ff;border:1px solid #bfdbfe}.fch .fl{color:#1d4ed8}.fch .fv{color:#1d4ed8}
  .fpa{background:#f0fdf4;border:1px solid #86efac}.fpa .fl{color:#15803d}.fpa .fv{color:#15803d}
  .fde{background:#fef2f2;border:1px solid #fca5a5}.fde .fl{color:#dc2626}.fde .fv{color:#dc2626}
  .fok{background:#f0fdf4;border:1px solid #86efac}.fok .fl{color:#15803d}.fok .fv{color:#15803d}
  .fpct{background:#f5f3ff;border:1px solid #c4b5fd}.fpct .fl{color:#7c3aed}.fpct .fv{color:#7c3aed}
  .pw{background:#e5e7eb;border-radius:3px;height:6px;overflow:hidden}
  .pb{height:6px;border-radius:3px}

  /* الأوراق الثبوتية */
  .dg{display:grid;grid-template-columns:repeat(2,1fr);gap:4px}
  .dr{display:flex;align-items:center;gap:5px;padding:4px 7px;border-radius:5px;background:#f8faff;border:1px solid #e8eef7}
  .di{font-size:10px;font-weight:900;width:14px;text-align:center}.di.ok{color:#16a34a}.di.ms{color:#dc2626}
  .dl{flex:1;font-size:10px;color:#374151}
  .db{padding:1px 6px;border-radius:20px;font-size:8.5px;font-weight:700}
  .bok{background:#dcfce7;color:#15803d;border:1px solid #86efac}
  .bms{background:#fee2e2;color:#dc2626;border:1px solid #fca5a5}

  /* جدول الإيصالات */
  table{width:100%;border-collapse:collapse;font-size:10px}
  thead tr{background:#1a3c5e}
  th{color:#fff;padding:6px 9px;font-size:9.5px;font-weight:700;text-align:right;border:1px solid #1a3c5e;white-space:nowrap}
  td{padding:5.5px 9px;border:1px solid #e5e7eb;text-align:right;white-space:nowrap}
  tr:nth-child(even) td{background:#f6faff}
  .mono{font-family:monospace}

  /* التذييل */
  .ftr{margin-top:9px;background:#fff;border-radius:11px;padding:11px 18px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 2px 8px rgba(15,39,68,.08);border-top:3px solid #1a3c5e}
  .ftr-l{display:flex;align-items:center;gap:7px}
  .ftr-logo{width:34px;height:34px;border-radius:50%;overflow:hidden;border:2px solid #1a3c5e}
  .ftr-logo img{width:100%;height:100%;object-fit:cover}
  .ftr-copy{font-size:8.5px;color:#94a3b8;line-height:1.9}
  .sig{text-align:center}
  .sig-box{border:1.5px solid #1a3c5e;border-radius:7px;padding:5px 18px;margin-bottom:4px;background:#f8faff}
  .sig-box .role{font-size:10px;font-weight:800;color:#1a3c5e;display:block}
  .sig-box .dept{font-size:8.5px;color:#475569;display:block;margin-top:1px}
  .sig-line{border-bottom:1.5px dashed #94a3b8;width:160px;height:22px;margin:0 auto 3px}
  .sig-s{font-size:8px;color:#94a3b8}

  /* علامة مائية */
  .wm{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%) rotate(-35deg);font-size:60px;font-weight:900;color:rgba(30,90,148,.03);pointer-events:none;z-index:0;letter-spacing:5px}

  @media print{
    @page{size:A4 portrait;margin:5mm}
    body{background:#fff}
    .page{background:#fff;padding:5mm 6mm}
    .hdr,.fb,.badge,.ic,.dr{-webkit-print-color-adjust:exact;print-color-adjust:exact}
    thead tr{background:#1a3c5e !important}
    th{background:#1a3c5e !important;color:#fff !important}
  }
</style>
</head>
<body>
<div class="wm">معهد القمة</div>
<div class="page">

  <!-- الرأس -->
  <div class="hdr">
    <div class="hdr-logo"><img src="${LOGO}" crossorigin="anonymous" alt=""/></div>
    <div class="hdr-text">
      <h1>معهد القمة للعلوم الطبية والإدارية</h1>
      <div class="s1">ملف الطالب المُرشَّف — وثيقة رسمية</div>
      <div class="s2">يُرجى الاحتفاظ بهذه الوثيقة في السجلات الرسمية للمعهد</div>
    </div>
    <div class="hdr-r">
      <div class="hdr-date"><span class="dl">تاريخ الإصدار</span><span class="dv">${today}</span></div>
    </div>
  </div>

  <!-- بطاقة الطالب -->
  <div class="sc">
    <div class="sp">
      ${s.photo_url
        ? `<img src="${s.photo_url}" crossorigin="anonymous" alt="${s.full_name}"/>`
        : `<div class="np">👤</div>`}
    </div>
    <div class="sm">
      <div class="sn">${s.full_name}</div>
      <div class="sid">${s.national_id ?? '—'}</div>
      <div class="sb">
        <span class="badge ba">خريج</span>
        <span class="badge ${s.diploma_type === 'عالي' ? 'bh' : 'bm'}">${s.diploma_type}</span>
        <span class="badge ${isExam ? 'be' : 'br'}">${isExam ? 'طالب 100' : 'نظامي'}</span>
        ${s.batch_number != null ? `<span class="badge" style="background:#fef9c3;color:#854d0e;border:1px solid #fde68a">دفعة ${s.batch_number}</span>` : ''}
      </div>
      <div class="sl">
        <span>📚 ${s.specialization ?? '—'}</span>
        <span>🎓 الفصل ${s.current_semester ?? '—'}</span>
        ${s.phone ? `<span>📞 ${s.phone}</span>` : ''}
      </div>
    </div>
  </div>

  <!-- البيانات الشخصية والأكاديمية -->
  <div class="card">
    <div class="st">البيانات الشخصية والأكاديمية</div>
    <div class="ig">
      ${infoRow('الاسم الكامل', s.full_name)}
      ${infoRow('الرقم الوطني', s.national_id, true)}
      ${infoRow('نوع الدبلوم', s.diploma_type)}
      ${infoRow('التخصص', s.specialization)}
      ${infoRow('الفصل الأخير', `الفصل ${s.current_semester ?? '—'}`)}
      ${infoRow('سنة التخرج', s.graduation_year ?? fmtDate(s.archived_at))}
      ${infoRow('نوع القيد', isExam ? 'طالب 100' : 'نظامي')}
      ${infoRow('تاريخ الالتحاق', fmtDate(s.enrollment_date))}
      ${infoRow('تاريخ الأرشفة', fmtDate(s.archived_at))}
      ${infoRow('رقم الهاتف', s.phone)}
      ${infoRow('الجنس', (s as any).gender)}
      ${infoRow('العنوان', (s as any).address)}
    </div>
    ${s.notes ? `<div style="margin-top:7px;padding:6px 9px;background:#fffbeb;border:1px solid #fcd34d;border-radius:6px;font-size:10px;color:#92400e"><b>ملاحظات:</b> ${s.notes}</div>` : ''}
  </div>

  <!-- الوضع المالي -->
  <div class="card">
    <div class="st">الوضع المالي</div>
    <div class="fg">
      <div class="fb fch"><div class="fl">إجمالي الرسوم</div><div class="fv">${charged.toLocaleString('ar-LY',{maximumFractionDigits:0})}</div><div style="font-size:7.5px;color:#1d4ed8;margin-top:1px">د.ل</div></div>
      <div class="fb fpa"><div class="fl">المدفوع</div><div class="fv">${paid.toLocaleString('ar-LY',{maximumFractionDigits:0})}</div><div style="font-size:7.5px;color:#15803d;margin-top:1px">د.ل</div></div>
      <div class="fb ${debtAmt > 0 ? 'fde' : 'fok'}"><div class="fl">المتبقي</div><div class="fv">${debtAmt > 0 ? debtAmt.toLocaleString('ar-LY',{maximumFractionDigits:0}) : '✓'}</div><div style="font-size:7.5px;margin-top:1px;color:${debtAmt > 0 ? '#dc2626' : '#15803d'}">${debtAmt > 0 ? 'د.ل' : 'مسدد'}</div></div>
      <div class="fb fpct"><div class="fl">نسبة السداد</div><div class="fv">${paidPct}%</div><div style="font-size:7.5px;color:#7c3aed;margin-top:1px">من الإجمالي</div></div>
    </div>
    <div class="pw"><div class="pb" style="width:${paidPct}%;background:${debtAmt<=0?'#16a34a':paidPct>60?'#f59e0b':'#dc2626'}"></div></div>
  </div>

  <!-- الأوراق الثبوتية -->
  <div class="card">
    <div class="st">الأوراق الثبوتية</div>
    <div class="dg">
      ${docRow('شهادة الميلاد', !!(s as any).has_birth_certificate)}
      ${docRow('شهادة التسجيل', !!(s as any).has_registration_certificate)}
      ${docRow('ملف المعلق', !!(s as any).has_suspended_file)}
      ${docRow(`الصور الشخصية (${(s as any).photos_received ?? 0}/${(s as any).photos_required ?? 6})`, ((s as any).photos_received ?? 0) >= ((s as any).photos_required ?? 6))}
    </div>
  </div>

  <!-- البيان المالي التفصيلي -->
  <div class="card">
    <div class="st">البيان المالي التفصيلي (${charges.length} بند)</div>
    <table>
      <thead><tr><th>#</th><th>البند</th><th style="text-align:center">الرسوم</th><th style="text-align:center">التخفيض</th><th style="text-align:center">المدفوع</th><th style="text-align:center">المتبقي</th><th style="text-align:center">الحالة</th></tr></thead>
      <tbody>${chargesHtml}</tbody>
      <tfoot>
        <tr style="background:#f0f4f8;font-weight:900;font-size:10px">
          <td colspan="2" style="font-weight:900;color:#1a3c5e">الإجمالي</td>
          <td style="text-align:center;color:#1d4ed8">${charged.toLocaleString('ar-LY')} د.ل</td>
          <td style="text-align:center;color:#7c3aed">${charges.reduce((s:number,c:any)=>s+(c.discount_amount??0),0)>0 ? charges.reduce((s:number,c:any)=>s+(c.discount_amount??0),0).toLocaleString('ar-LY')+' د.ل':'—'}</td>
          <td style="text-align:center;color:#16a34a;font-weight:900">${paid.toLocaleString('ar-LY')} د.ل</td>
          <td style="text-align:center;color:${debtAmt>0.01?'#dc2626':'#16a34a'};font-weight:900">${debtAmt>0.01?debtAmt.toLocaleString('ar-LY')+' د.ل':'✓ مسدد'}</td>
          <td></td>
        </tr>
      </tfoot>
    </table>
  </div>

  <!-- الإيصالات -->
  <div class="card">
    <div class="st">سجل الإيصالات (${receipts.length} إيصال)</div>
    <table>
      <thead><tr><th>#</th><th>رقم الإيصال</th><th>البند</th><th>التاريخ</th><th>المبلغ</th><th>طريقة الدفع</th></tr></thead>
      <tbody>${receiptsHtml}</tbody>
    </table>
  </div>

  <!-- التذييل -->
  <div class="ftr">
    <div class="ftr-l">
      <div class="ftr-logo"><img src="${LOGO}" crossorigin="anonymous" alt=""/></div>
      <div class="ftr-copy">
        <div style="font-weight:700;color:#1a3c5e;font-size:9.5px">معهد القمة للعلوم الطبية والإدارية</div>
        <div>جميع الحقوق محفوظة &copy; ${new Date().getFullYear()}</div>
        <div>صدر بتاريخ: ${today}</div>
      </div>
    </div>
    <div class="sig">
      <div class="sig-box"><span class="role">مدير شؤون الطلاب</span><span class="dept">معهد القمة للعلوم الطبية والإدارية</span></div>
      <div class="sig-line"></div>
      <div class="sig-s">التوقيع والختم الرسمي</div>
    </div>
  </div>

</div>
<script>window.onload = () => window.print();</script>
</body>
</html>`);
    win.document.close();
  };

  // ── تصدير PDF بنفس التنسيق عبر jsPDF ──
  const handleExportPDF = () => {
    const LOGO = 'https://miaoda-conversation-file.s3cdn.medo.dev/user-cim4m3x63pxc/app-f6avantw6h35/20261018/FB_IMG_1780949707596.jpg';
    // نفتح نافذة الطباعة لكن بدل window.print نحفظها كـ PDF عبر print dialog
    // الطريقة الأكثر توافقاً: نفس HTML لكن مع CSS خاص بـ @page A4 وبدون print trigger
    const win = window.open('', '_blank', 'width=900,height=750');
    if (!win) return;
    const today   = new Date().toLocaleDateString('ar-LY');
    const debtAmt = s.remaining_amount ?? 0;
    const paidPct = charged > 0 ? Math.round((paid / charged) * 100) : 100;

    const infoRow = (label: string, val: string | number | null | undefined, mono = false) =>
      `<div class="ic"><div class="il">${label}</div><div class="iv${mono ? ' mono' : ''}">${val ?? '—'}</div></div>`;
    const docRow = (label: string, ok: boolean) =>
      `<div class="dr"><span class="di ${ok ? 'ok' : 'ms'}">${ok ? '✓' : '✗'}</span>
       <span class="dl">${label}</span>
       <span class="db ${ok ? 'bok' : 'bms'}">${ok ? 'مكتمل' : 'ناقص'}</span></div>`;

    const chargesHtmlPdf = charges.length === 0
      ? '<tr><td colspan="7" style="text-align:center;color:#94a3b8;padding:8px">لا توجد بنود</td></tr>'
      : charges.map((c: any, i: number) => {
          const label = c.charge_type === 'تسجيل' ? 'رسوم التسجيل'
            : c.charge_type === 'مشروع تخرج' ? 'مشروع التخرج'
            : c.charge_type === 'معادلة' ? `رسوم معادلة ${SEMESTER_LABELS[c.semester_number] ?? `الفصل ${c.semester_number}`}`
            : c.charge_type === 'فصلي' ? (SEMESTER_LABELS[c.semester_number] ?? `الفصل ${c.semester_number}`)
            : (c.charge_type ?? '—');
          const eff   = (c.charge_amount ?? 0) - (c.discount_amount ?? 0);
          const paidC = c.paid_amount ?? 0;
          const remC  = c.remaining_amount ?? Math.max(0, eff - paidC);
          return `<tr>
            <td>${i + 1}</td>
            <td>${label}</td>
            <td style="text-align:center">${Number(c.charge_amount ?? 0).toLocaleString('ar-LY')} د.ل</td>
            <td style="text-align:center;color:#7c3aed">${c.discount_amount > 0 ? Number(c.discount_amount).toLocaleString('ar-LY') + ' د.ل' : '—'}</td>
            <td style="text-align:center;color:#16a34a;font-weight:800">${Number(paidC).toLocaleString('ar-LY')} د.ل</td>
            <td style="text-align:center;color:${remC > 0.01 ? '#dc2626' : '#16a34a'};font-weight:800">${remC > 0.01 ? Number(remC).toLocaleString('ar-LY') + ' د.ل' : '✓'}</td>
            <td style="text-align:center"><span style="padding:1.5px 6px;border-radius:20px;font-size:8.5px;font-weight:700;background:${c.is_cleared ? '#dcfce7' : '#fef3c7'};color:${c.is_cleared ? '#15803d' : '#92400e'};border:1px solid ${c.is_cleared ? '#86efac' : '#fcd34d'}">${c.is_cleared ? '✓ مسدد' : 'متبقي'}</span></td>
          </tr>`;
        }).join('');

    const receiptsHtml = receipts.length === 0
      ? '<tr><td colspan="6" style="text-align:center;color:#94a3b8;padding:10px">لا توجد إيصالات</td></tr>'
      : receipts.map((r: any, i: number) => {
          const label = r.payment_type === 'تقسيط'
            ? (r.semester_target ? `فصل ${r.semester_target}` : 'دفعة')
            : (r.payment_type ?? 'دفعة');
          return `<tr>
            <td>${i + 1}</td>
            <td class="mono" style="font-size:9px">#${r.receipt_number ?? '—'}</td>
            <td>${label}</td>
            <td>${new Date(r.paid_at).toLocaleDateString('ar-LY')}</td>
            <td style="color:#16a34a;font-weight:800">${Number(r.amount ?? 0).toLocaleString('ar-LY')} د.ل</td>
            <td>${r.payment_method ?? '—'}</td>
          </tr>`;
        }).join('');

    // نفس الـ CSS + تعليمات إضافية لضمان أن "Save as PDF" في print dialog ينتج A4 صحيح
    win.document.write(`<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<title>PDF — ملف الأرشيف — ${s.full_name}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;900&display=swap');
  *{box-sizing:border-box;margin:0;padding:0}
  html,body{background:#fff;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  body{font-family:'Cairo',sans-serif;direction:rtl;color:#1a2332;font-size:12px}
  .page{width:210mm;margin:0 auto;padding:8mm 10mm}
  .hdr{background:linear-gradient(135deg,#0f2744 0%,#1a3c5e 55%,#1e5a94 100%);border-radius:12px;padding:12px 16px;margin-bottom:8px;display:flex;align-items:center;gap:12px;position:relative;overflow:hidden;box-shadow:0 4px 16px rgba(15,39,68,.35)}
  .hdr::before{content:'';position:absolute;inset:0;background:repeating-linear-gradient(45deg,rgba(255,255,255,.025) 0,rgba(255,255,255,.025) 1px,transparent 1px,transparent 18px)}
  .hdr-logo{width:60px;height:60px;border-radius:50%;border:2.5px solid rgba(255,255,255,.85);overflow:hidden;flex-shrink:0;background:#fff;z-index:1;position:relative}
  .hdr-logo img{width:100%;height:100%;object-fit:cover}
  .hdr-text{flex:1;z-index:1;position:relative}
  .hdr-text h1{font-size:15px;font-weight:900;color:#fff;margin-bottom:2px}
  .hdr-text .s1{font-size:10px;color:rgba(165,210,255,.95);font-weight:600}
  .hdr-r{text-align:center;flex-shrink:0;z-index:1;position:relative}
  .hdr-date{background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);border-radius:7px;padding:5px 11px}
  .hdr-date .dl{font-size:7.5px;color:rgba(180,215,255,.8);display:block;margin-bottom:2px}
  .hdr-date .dv{font-size:10.5px;font-weight:900;color:#fff}
  .sc{background:#fff;border-radius:10px;padding:11px 14px;margin-bottom:6px;box-shadow:0 2px 8px rgba(15,39,68,.10);border:1px solid #e2e8f0;display:flex;gap:12px;align-items:flex-start}
  .sp{width:70px;height:70px;border-radius:8px;overflow:hidden;flex-shrink:0;border:2px solid #e2e8f0;background:#f8faff}
  .sp img{width:100%;height:100%;object-fit:cover}
  .sp .np{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:24px;color:#94a3b8;background:#f1f5f9}
  .sm{flex:1;min-width:0}
  .sn{font-size:14px;font-weight:900;color:#0f2744;margin-bottom:3px}
  .sid{font-size:9px;color:#94a3b8;font-family:monospace;margin-bottom:4px}
  .sb{display:flex;flex-wrap:wrap;gap:4px;margin-bottom:4px}
  .badge{display:inline-block;padding:1.5px 7px;border-radius:20px;font-size:9px;font-weight:700;white-space:nowrap}
  .ba{background:#dcfce7;color:#15803d;border:1px solid #86efac}
  .bh{background:#dbeafe;color:#1d4ed8;border:1px solid #93c5fd}
  .bm{background:#f0fdf4;color:#15803d;border:1px solid #86efac}
  .be{background:#f3e8ff;color:#7e22ce;border:1px solid #d8b4fe}
  .br{background:#e0f2fe;color:#0369a1;border:1px solid #7dd3fc}
  .sl{display:flex;gap:12px;flex-wrap:wrap;font-size:9.5px;color:#475569}
  .card{background:#fff;border-radius:10px;padding:10px 13px;margin-bottom:6px;box-shadow:0 2px 8px rgba(15,39,68,.09);border:1px solid #e2e8f0}
  .st{font-size:10px;font-weight:800;color:#1a3c5e;margin-bottom:8px;padding-bottom:4px;border-bottom:2px solid #e2e8f0;display:flex;align-items:center;gap:4px}
  .st::before{content:'';display:inline-block;width:3px;height:12px;background:#1e5a94;border-radius:2px;flex-shrink:0}
  .ig{display:grid;grid-template-columns:repeat(3,1fr);gap:4px 12px}
  .ic{padding:4px 6px;border-radius:5px;background:#f8faff;border:1px solid #e8eef7}
  .il{font-size:7.5px;color:#94a3b8;font-weight:600;margin-bottom:1px}
  .iv{font-size:10px;font-weight:700;color:#1a3c5e}.iv.mono{font-family:monospace;font-size:9.5px}
  .fg{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-bottom:8px}
  .fb{border-radius:6px;padding:6px 8px;text-align:center}
  .fb .fl{font-size:7.5px;font-weight:600;margin-bottom:1px}
  .fb .fv{font-size:12px;font-weight:900}
  .fch{background:#eff6ff;border:1px solid #bfdbfe}.fch .fl{color:#1d4ed8}.fch .fv{color:#1d4ed8}
  .fpa{background:#f0fdf4;border:1px solid #86efac}.fpa .fl{color:#15803d}.fpa .fv{color:#15803d}
  .fde{background:#fef2f2;border:1px solid #fca5a5}.fde .fl{color:#dc2626}.fde .fv{color:#dc2626}
  .fok{background:#f0fdf4;border:1px solid #86efac}.fok .fl{color:#15803d}.fok .fv{color:#15803d}
  .fpct{background:#f5f3ff;border:1px solid #c4b5fd}.fpct .fl{color:#7c3aed}.fpct .fv{color:#7c3aed}
  .pw{background:#e5e7eb;border-radius:3px;height:5px;overflow:hidden}
  .pb{height:5px;border-radius:3px}
  .dg{display:grid;grid-template-columns:repeat(2,1fr);gap:4px}
  .dr{display:flex;align-items:center;gap:5px;padding:3.5px 6px;border-radius:5px;background:#f8faff;border:1px solid #e8eef7}
  .di{font-size:9.5px;font-weight:900;width:13px;text-align:center}.di.ok{color:#16a34a}.di.ms{color:#dc2626}
  .dl{flex:1;font-size:9.5px;color:#374151}
  .db{padding:1px 5px;border-radius:20px;font-size:8px;font-weight:700}
  .bok{background:#dcfce7;color:#15803d;border:1px solid #86efac}
  .bms{background:#fee2e2;color:#dc2626;border:1px solid #fca5a5}
  table{width:100%;border-collapse:collapse;font-size:9.5px}
  thead tr{background:#1a3c5e}
  th{color:#fff;padding:5.5px 8px;font-size:9px;font-weight:700;text-align:right;border:1px solid #1a3c5e;white-space:nowrap}
  td{padding:5px 8px;border:1px solid #e5e7eb;text-align:right;white-space:nowrap}
  tr:nth-child(even) td{background:#f6faff}
  .mono{font-family:monospace}
  .ftr{margin-top:8px;background:#fff;border-radius:10px;padding:10px 16px;display:flex;justify-content:space-between;align-items:center;border-top:3px solid #1a3c5e}
  .ftr-l{display:flex;align-items:center;gap:6px}
  .ftr-logo{width:30px;height:30px;border-radius:50%;overflow:hidden;border:2px solid #1a3c5e}
  .ftr-logo img{width:100%;height:100%;object-fit:cover}
  .ftr-copy{font-size:8px;color:#94a3b8;line-height:1.9}
  .sig{text-align:center}
  .sig-box{border:1.5px solid #1a3c5e;border-radius:6px;padding:4px 16px;margin-bottom:3px;background:#f8faff}
  .sig-box .role{font-size:9.5px;font-weight:800;color:#1a3c5e;display:block}
  .sig-box .dept{font-size:8px;color:#475569;display:block}
  .sig-line{border-bottom:1.5px dashed #94a3b8;width:140px;height:20px;margin:0 auto 3px}
  .sig-s{font-size:7.5px;color:#94a3b8}
  /* زر الحفظ لا يظهر عند الطباعة */
  .save-btn{display:block;width:200px;margin:12px auto;padding:10px;background:#1a3c5e;color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;font-family:'Cairo',sans-serif}
  @media print{
    @page{size:A4 portrait;margin:5mm}
    .save-btn{display:none!important}
    thead tr{background:#1a3c5e !important}
    th{background:#1a3c5e !important;color:#fff !important}
    .hdr,.fb,.badge,.ic,.dr{-webkit-print-color-adjust:exact !important;print-color-adjust:exact !important}
  }
</style>
</head>
<body>
<div class="page">
  <div class="hdr">
    <div class="hdr-logo"><img src="${LOGO}" crossorigin="anonymous" alt=""/></div>
    <div class="hdr-text">
      <h1>معهد القمة للعلوم الطبية والإدارية</h1>
      <div class="s1">ملف الطالب المُرشَّف — وثيقة رسمية</div>
    </div>
    <div class="hdr-r">
      <div class="hdr-date"><span class="dl">تاريخ الإصدار</span><span class="dv">${today}</span></div>
    </div>
  </div>

  <div class="sc">
    <div class="sp">
      ${s.photo_url ? `<img src="${s.photo_url}" crossorigin="anonymous" alt="${s.full_name}"/>` : `<div class="np">👤</div>`}
    </div>
    <div class="sm">
      <div class="sn">${s.full_name}</div>
      <div class="sid">${s.national_id ?? '—'}</div>
      <div class="sb">
        <span class="badge ba">خريج</span>
        <span class="badge ${s.diploma_type === 'عالي' ? 'bh' : 'bm'}">${s.diploma_type}</span>
        <span class="badge ${isExam ? 'be' : 'br'}">${isExam ? 'طالب 100' : 'نظامي'}</span>
        ${s.batch_number != null ? `<span class="badge" style="background:#fef9c3;color:#854d0e;border:1px solid #fde68a">دفعة ${s.batch_number}</span>` : ''}
      </div>
      <div class="sl">
        <span>📚 ${s.specialization ?? '—'}</span>
        <span>🎓 الفصل ${s.current_semester ?? '—'}</span>
        ${s.phone ? `<span>📞 ${s.phone}</span>` : ''}
      </div>
    </div>
  </div>

  <div class="card">
    <div class="st">البيانات الشخصية والأكاديمية</div>
    <div class="ig">
      ${infoRow('الاسم الكامل', s.full_name)}
      ${infoRow('الرقم الوطني', s.national_id, true)}
      ${infoRow('نوع الدبلوم', s.diploma_type)}
      ${infoRow('التخصص', s.specialization)}
      ${infoRow('الفصل الأخير', `الفصل ${s.current_semester ?? '—'}`)}
      ${infoRow('سنة التخرج', s.graduation_year ?? fmtDate(s.archived_at))}
      ${infoRow('نوع القيد', isExam ? 'طالب 100' : 'نظامي')}
      ${infoRow('تاريخ الالتحاق', fmtDate(s.enrollment_date))}
      ${infoRow('تاريخ الأرشفة', fmtDate(s.archived_at))}
      ${infoRow('رقم الهاتف', s.phone)}
      ${infoRow('الجنس', (s as any).gender)}
      ${infoRow('العنوان', (s as any).address)}
    </div>
    ${s.notes ? `<div style="margin-top:6px;padding:5px 8px;background:#fffbeb;border:1px solid #fcd34d;border-radius:5px;font-size:9.5px;color:#92400e"><b>ملاحظات:</b> ${s.notes}</div>` : ''}
  </div>

  <div class="card">
    <div class="st">الوضع المالي</div>
    <div class="fg">
      <div class="fb fch"><div class="fl">إجمالي الرسوم</div><div class="fv">${charged.toLocaleString('ar-LY',{maximumFractionDigits:0})}</div><div style="font-size:7px;color:#1d4ed8;margin-top:1px">د.ل</div></div>
      <div class="fb fpa"><div class="fl">المدفوع</div><div class="fv">${paid.toLocaleString('ar-LY',{maximumFractionDigits:0})}</div><div style="font-size:7px;color:#15803d;margin-top:1px">د.ل</div></div>
      <div class="fb ${debtAmt > 0 ? 'fde' : 'fok'}"><div class="fl">المتبقي</div><div class="fv">${debtAmt > 0 ? debtAmt.toLocaleString('ar-LY',{maximumFractionDigits:0}) : '✓'}</div><div style="font-size:7px;margin-top:1px;color:${debtAmt > 0 ? '#dc2626' : '#15803d'}">${debtAmt > 0 ? 'د.ل' : 'مسدد'}</div></div>
      <div class="fb fpct"><div class="fl">نسبة السداد</div><div class="fv">${paidPct}%</div></div>
    </div>
    <div class="pw"><div class="pb" style="width:${paidPct}%;background:${debtAmt<=0?'#16a34a':paidPct>60?'#f59e0b':'#dc2626'}"></div></div>
  </div>

  <div class="card">
    <div class="st">الأوراق الثبوتية</div>
    <div class="dg">
      ${docRow('شهادة الميلاد', !!(s as any).has_birth_certificate)}
      ${docRow('شهادة التسجيل', !!(s as any).has_registration_certificate)}
      ${docRow('ملف المعلق', !!(s as any).has_suspended_file)}
      ${docRow(`الصور الشخصية (${(s as any).photos_received ?? 0}/${(s as any).photos_required ?? 6})`, ((s as any).photos_received ?? 0) >= ((s as any).photos_required ?? 6))}
    </div>
  </div>

  <div class="card">
    <div class="st">البيان المالي التفصيلي (${charges.length} بند)</div>
    <table>
      <thead><tr><th>#</th><th>البند</th><th style="text-align:center">الرسوم</th><th style="text-align:center">التخفيض</th><th style="text-align:center">المدفوع</th><th style="text-align:center">المتبقي</th><th style="text-align:center">الحالة</th></tr></thead>
      <tbody>${chargesHtmlPdf}</tbody>
      <tfoot>
        <tr style="background:#f0f4f8;font-weight:900;font-size:9.5px">
          <td colspan="2" style="font-weight:900;color:#1a3c5e">الإجمالي</td>
          <td style="text-align:center;color:#1d4ed8">${charged.toLocaleString('ar-LY')} د.ل</td>
          <td style="text-align:center;color:#7c3aed">${charges.reduce((s:number,c:any)=>s+(c.discount_amount??0),0)>0 ? charges.reduce((s:number,c:any)=>s+(c.discount_amount??0),0).toLocaleString('ar-LY')+' د.ل':'—'}</td>
          <td style="text-align:center;color:#16a34a;font-weight:900">${paid.toLocaleString('ar-LY')} د.ل</td>
          <td style="text-align:center;color:${debtAmt>0.01?'#dc2626':'#16a34a'};font-weight:900">${debtAmt>0.01?debtAmt.toLocaleString('ar-LY')+' د.ل':'✓ مسدد'}</td>
          <td></td>
        </tr>
      </tfoot>
    </table>
  </div>

  <div class="card">
    <div class="st">سجل الإيصالات (${receipts.length} إيصال)</div>
    <table>
      <thead><tr><th>#</th><th>رقم الإيصال</th><th>البند</th><th>التاريخ</th><th>المبلغ</th><th>طريقة الدفع</th></tr></thead>
      <tbody>${receiptsHtml}</tbody>
    </table>
  </div>

  <div class="ftr">
    <div class="ftr-l">
      <div class="ftr-logo"><img src="${LOGO}" crossorigin="anonymous" alt=""/></div>
      <div class="ftr-copy">
        <div style="font-weight:700;color:#1a3c5e;font-size:9px">معهد القمة للعلوم الطبية والإدارية</div>
        <div>جميع الحقوق محفوظة &copy; ${new Date().getFullYear()} — صدر بتاريخ: ${today}</div>
      </div>
    </div>
    <div class="sig">
      <div class="sig-box"><span class="role">مدير شؤون الطلاب</span><span class="dept">معهد القمة للعلوم الطبية والإدارية</span></div>
      <div class="sig-line"></div>
      <div class="sig-s">التوقيع والختم الرسمي</div>
    </div>
  </div>

</div>
<button class="save-btn" onclick="window.print()">💾 حفظ كـ PDF</button>
<script>window.onload = () => setTimeout(() => window.print(), 600);</script>
</body>
</html>`);
    win.document.close();
  };

  const TABS = [
    { id: 'personal'  as const, label: 'الشخصية',   icon: User },
    { id: 'academic'  as const, label: 'الأكاديمية', icon: BookOpen },
    { id: 'financial' as const, label: 'المالية',    icon: DollarSign },
    { id: 'receipts'  as const, label: `إيصالات (${receipts.length})`, icon: FileText },
    { id: 'files'     as const, label: `الأوراق (${files.length})`,    icon: Award },
  ];

  // طباعة ملف واحد مرفوع
  const handlePrintSingleFile = (f: any) => {
    if (!f.file_url) return;
    const isImage = f.file_type === 'image';
    const win = window.open('', '_blank', 'width=900,height=700');
    if (!win) return;

    if (isImage) {
      // صورة: تُعرض بحجم A4 كامل بدون أي عناصر إضافية
      win.document.write(`<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="utf-8">
<title>${f.label || f.file_name || 'صورة'}</title>
<style>
  *{margin:0;padding:0;box-sizing:border-box}
  html,body{width:210mm;height:297mm;background:#fff;overflow:hidden}
  img{display:block;width:210mm;height:297mm;object-fit:contain;background:#fff;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .print-bar{position:fixed;bottom:0;left:0;right:0;padding:8px 12px;background:rgba(0,0,0,.7);display:flex;justify-content:center;gap:10px;z-index:999}
  .btn{padding:7px 20px;border:none;border-radius:6px;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit}
  .btn-print{background:#1a3c5e;color:#fff}
  .btn-close{background:#e2e8f0;color:#333}
  @page{size:A4 portrait;margin:0}
  @media print{.print-bar{display:none!important}img{width:100vw;height:100vh}}
</style>
</head>
<body>
<img src="${f.file_url}" alt="${f.label || ''}" />
<div class="print-bar">
  <button class="btn btn-print" onclick="window.print()">🖨️ طباعة</button>
  <button class="btn btn-close" onclick="window.close()">✕ إغلاق</button>
</div>
<script>
  var img = document.querySelector('img');
  img.onload = function(){ setTimeout(function(){ window.print(); }, 400); };
  img.onerror = function(){ /* لم تُحمَّل الصورة، انتظر المستخدم */ };
</script>
</body>
</html>`);
    } else {
      // مستند/PDF: يُعرض في iframe يملأ صفحة A4 كاملة
      win.document.write(`<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="utf-8">
<title>${f.label || f.file_name || 'مستند'}</title>
<style>
  *{margin:0;padding:0;box-sizing:border-box}
  html,body{width:100%;height:100%;background:#fff;overflow:hidden}
  iframe{display:block;width:100%;height:calc(100vh - 52px);border:none}
  .print-bar{position:fixed;bottom:0;left:0;right:0;height:52px;padding:8px 12px;background:#1a3c5e;display:flex;align-items:center;justify-content:center;gap:10px;z-index:999}
  .btn{padding:7px 20px;border:none;border-radius:6px;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit}
  .btn-print{background:#fff;color:#1a3c5e}
  .btn-close{background:rgba(255,255,255,.15);color:#fff;border:1px solid rgba(255,255,255,.3)}
  @page{size:A4 portrait;margin:0}
  @media print{.print-bar{display:none!important}iframe{height:100vh}}
</style>
</head>
<body>
<iframe src="${f.file_url}" id="doc-frame"></iframe>
<div class="print-bar">
  <button class="btn btn-print" onclick="printDoc()">🖨️ طباعة المستند</button>
  <button class="btn btn-close" onclick="window.close()">✕ إغلاق</button>
</div>
<script>
  function printDoc(){
    var fr = document.getElementById('doc-frame');
    try {
      fr.contentWindow.focus();
      fr.contentWindow.print();
    } catch(e){
      window.print();
    }
  }
</script>
</body>
</html>`);
    }
    win.document.close();
  };

  // طباعة الأوراق المرفوعة
  const handlePrintFiles = () => {
    if (files.length === 0) return;
    const win = window.open('', '_blank', 'width=900,height=700');
    if (!win) return;
    const today = new Date().toLocaleDateString('ar-LY');

    const filesHtml = files.map((f: any, i: number) => {
      const isImage = f.file_type === 'image';
      const date = f.created_at ? new Date(f.created_at).toLocaleDateString('ar-LY') : '—';
      return `
        <div class="file-row">
          <div class="file-num">${i + 1}</div>
          <div class="file-icon ${isImage ? 'img-icon' : 'doc-icon'}">${isImage ? '🖼' : '📄'}</div>
          <div class="file-info">
            <div class="file-label">${f.label || f.file_name || '—'}</div>
            <div class="file-meta">
              <span class="file-type-badge ${isImage ? 'type-img' : 'type-doc'}">${isImage ? 'صورة' : 'مستند'}</span>
              <span class="file-date">${date}</span>
            </div>
          </div>
          <div class="file-status ${f.file_url ? 'ok' : 'miss'}">${f.file_url ? '✓ مرفوع' : '✗ ناقص'}</div>
        </div>
        ${isImage && f.file_url ? `<div class="img-preview"><img src="${f.file_url}" alt="${f.label || ''}" /></div>` : ''}
      `;
    }).join('');

    win.document.write(`<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<title>أوراق الطالب — ${s.full_name}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap');
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:'Cairo',sans-serif;direction:rtl;background:#f0f4f8;color:#1a2332;font-size:12px;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .page{width:210mm;min-height:297mm;margin:0 auto;padding:10mm 12mm;background:#f0f4f8}
  /* رأس */
  .hdr{background:linear-gradient(135deg,#0f2744 0%,#1a3c5e 60%,#1e5a94 100%);border-radius:13px;padding:13px 17px;margin-bottom:10px;display:flex;align-items:center;gap:13px;position:relative;overflow:hidden;box-shadow:0 4px 18px rgba(15,39,68,.35)}
  .hdr::before{content:'';position:absolute;inset:0;background:repeating-linear-gradient(45deg,rgba(255,255,255,.025) 0,rgba(255,255,255,.025) 1px,transparent 1px,transparent 18px)}
  .hdr-logo{width:64px;height:64px;border-radius:50%;border:3px solid rgba(255,255,255,.85);overflow:hidden;flex-shrink:0;background:#fff;box-shadow:0 0 0 4px rgba(255,255,255,.14);z-index:1}
  .hdr-logo img{width:100%;height:100%;object-fit:cover}
  .hdr-text{flex:1;z-index:1}
  .hdr-text h1{font-size:15px;font-weight:900;color:#fff;margin-bottom:3px}
  .hdr-text .s1{font-size:10px;color:rgba(165,210,255,.95);font-weight:600}
  .hdr-r{text-align:center;flex-shrink:0;z-index:1}
  .hdr-date{background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);border-radius:8px;padding:6px 12px}
  .hdr-date .dl{font-size:8px;color:rgba(180,215,255,.8);display:block;margin-bottom:2px}
  .hdr-date .dv{font-size:11px;font-weight:900;color:#fff}
  /* بطاقة الطالب */
  .sc{background:#fff;border-radius:11px;padding:11px 14px;margin-bottom:9px;display:flex;align-items:center;gap:12px;box-shadow:0 2px 9px rgba(15,39,68,.10);border:1px solid #e2e8f0}
  .sc-name{font-size:14px;font-weight:900;color:#0f2744}
  .sc-sub{font-size:10px;color:#64748b;margin-top:2px}
  .badge{display:inline-flex;align-items:center;gap:3px;font-size:9px;font-weight:700;padding:2px 8px;border-radius:20px;margin-left:4px}
  .b-green{background:#dcfce7;color:#15803d;border:1px solid #86efac}
  /* عنوان القسم */
  .section-title{font-size:12px;font-weight:900;color:#0f2744;padding:8px 12px;background:linear-gradient(to left,#e8f0fe,#f0f7ff);border-right:3px solid #1a3c5e;border-radius:7px;margin-bottom:8px;display:flex;align-items:center;justify-content:space-between}
  /* صف ملف */
  .file-row{display:flex;align-items:center;gap:10px;background:#fff;border:1px solid #e2e8f0;border-radius:9px;padding:9px 12px;margin-bottom:6px;box-shadow:0 1px 4px rgba(15,39,68,.06)}
  .file-num{width:22px;height:22px;border-radius:50%;background:#1a3c5e;color:#fff;font-size:9px;font-weight:900;display:flex;align-items:center;justify-content:center;flex-shrink:0}
  .file-icon{width:34px;height:34px;border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0}
  .img-icon{background:#eff6ff;border:1px solid #bfdbfe}
  .doc-icon{background:#fffbeb;border:1px solid #fde68a}
  .file-info{flex:1;min-width:0}
  .file-label{font-size:11px;font-weight:700;color:#0f2744;margin-bottom:3px}
  .file-meta{display:flex;align-items:center;gap:6px}
  .file-type-badge{font-size:8.5px;font-weight:700;padding:1px 7px;border-radius:20px}
  .type-img{background:#eff6ff;color:#1d4ed8;border:1px solid #bfdbfe}
  .type-doc{background:#fffbeb;color:#92400e;border:1px solid #fde68a}
  .file-date{font-size:9px;color:#94a3b8}
  .file-status{font-size:9.5px;font-weight:800;padding:3px 10px;border-radius:20px;flex-shrink:0}
  .ok{background:#dcfce7;color:#15803d;border:1px solid #86efac}
  .miss{background:#fee2e2;color:#991b1b;border:1px solid #fca5a5}
  /* معاينة الصور */
  .img-preview{padding:0 10px 8px 10px;margin-top:-4px}
  .img-preview img{width:100%;max-height:160px;object-fit:cover;border-radius:8px;border:1px solid #e2e8f0}
  /* إحصاء */
  .summary{background:#fff;border-radius:10px;padding:10px 14px;margin-top:10px;display:flex;gap:14px;box-shadow:0 1px 5px rgba(15,39,68,.08);border:1px solid #e2e8f0}
  .sum-item{flex:1;text-align:center}
  .sum-val{font-size:18px;font-weight:900;color:#0f2744}
  .sum-lbl{font-size:9px;color:#64748b;margin-top:2px}
  /* زر طباعة */
  .print-btn{display:block;width:calc(100% - 36px);margin:12px 18px;padding:10px;background:#1a3c5e;color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit}
  @media print{.print-btn{display:none!important}body{background:#fff}.page{box-shadow:none;padding:6mm 8mm}}
</style>
</head>
<body>
<div class="page">
  <!-- رأس الصفحة -->
  <div class="hdr">
    <div class="hdr-logo"><img src="${LOGO_URL}" alt="شعار"/></div>
    <div class="hdr-text">
      <h1>${INSTITUTE_NAME}</h1>
      <div class="s1">كشف الأوراق الثبوتية للطالب</div>
    </div>
    <div class="hdr-r">
      <div class="hdr-date">
        <span class="dl">تاريخ الطباعة</span>
        <span class="dv">${today}</span>
      </div>
    </div>
  </div>
  <!-- بطاقة الطالب -->
  <div class="sc">
    <div>
      <div class="sc-name">${s.full_name}</div>
      <div class="sc-sub">
        ${s.diploma_type} · ${s.specialization} · ${s.current_semester != null ? (SEMESTER_LABELS[s.current_semester] ?? `الفصل ${s.current_semester}`) : '—'}
        <span class="badge b-green">✓ مكتمل السداد</span>
      </div>
    </div>
  </div>
  <!-- عنوان القسم -->
  <div class="section-title">
    <span>الأوراق الثبوتية المرفوعة</span>
    <span style="font-size:10px;font-weight:600;color:#64748b">${files.length} ورقة</span>
  </div>
  <!-- قائمة الأوراق -->
  ${filesHtml}
  <!-- ملخص -->
  <div class="summary">
    <div class="sum-item">
      <div class="sum-val">${files.length}</div>
      <div class="sum-lbl">إجمالي الأوراق</div>
    </div>
    <div class="sum-item">
      <div class="sum-val" style="color:#15803d">${files.filter((f: any) => f.file_type === 'image').length}</div>
      <div class="sum-lbl">صور مرفوعة</div>
    </div>
    <div class="sum-item">
      <div class="sum-val" style="color:#92400e">${files.filter((f: any) => f.file_type !== 'image').length}</div>
      <div class="sum-lbl">مستندات</div>
    </div>
  </div>
</div>
<button class="print-btn no-print" onclick="window.print()">🖨️ طباعة الأوراق</button>
<script>setTimeout(() => window.print(), 600);</script>
</body>
</html>`);
    win.document.close();
  };

  return (
    <div className="flex flex-col h-full min-h-0" dir="rtl">
      {/* ── رأس النافذة — ارتفاع ثابت shrink-0 ── */}
      <div className="relative bg-gradient-to-bl from-[#0f2744] via-[#1a3c5e] to-[#1d4e7a] px-4 pt-3 pb-0 rounded-t-2xl overflow-hidden shrink-0">
        <div className="absolute inset-0 opacity-[0.07]"
          style={{ backgroundImage: 'repeating-linear-gradient(45deg,#fff 0,#fff 1px,transparent 0,transparent 50%)', backgroundSize: '12px 12px' }} />
        <div className="relative">

          {/* شريط علوي: صورة + اسم + أزرار */}
          <div className="flex items-center gap-2.5 mb-2">
            <div className="shrink-0 relative">
              <StudentAvatar photoUrl={s.photo_url} name={s.full_name} size="md" variant="rounded" />
              <span className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-[#1a3c5e] flex items-center justify-center ${settled ? 'bg-emerald-500' : 'bg-amber-500'}`}>
                {settled ? <CheckCircle2 className="w-2.5 h-2.5 text-white" /> : <AlertCircle className="w-2.5 h-2.5 text-white" />}
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <h2 className="text-sm font-black text-white leading-tight line-clamp-2 break-words">{s.full_name}</h2>
              {s.specialization && (
                <p className="text-white/60 text-[11px] truncate mt-0.5">{s.specialization}</p>
              )}
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              <button onClick={handlePrint}
                className="h-8 px-2.5 rounded-lg border border-white/20 text-white/70 hover:bg-white/15 transition-colors flex items-center justify-center gap-1.5 text-[10px] font-bold">
                <Printer className="w-3.5 h-3.5" />
                <span>طباعة</span>
              </button>
              <button onClick={handleExportPDF}
                className="h-8 px-2.5 rounded-lg border border-blue-300/40 text-blue-200 hover:bg-blue-500/20 transition-colors flex items-center justify-center gap-1.5 text-[10px] font-bold">
                <FileDown className="w-3.5 h-3.5" />
                <span>PDF</span>
              </button>
              <button onClick={onClose}
                className="h-8 w-8 rounded-lg border border-white/20 text-white/70 hover:bg-white/20 transition-colors flex items-center justify-center">
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* شارات الحالة — صف واحد قابل للتمرير */}
          <div className="flex gap-1 mb-2 overflow-x-auto scrollbar-hide">
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border shrink-0 ${isHigh
              ? 'bg-blue-400/20 text-blue-200 border-blue-400/40'
              : 'bg-emerald-400/20 text-emerald-200 border-emerald-400/40'}`}>{s.diploma_type}</span>
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border shrink-0 ${isExam
              ? 'bg-purple-400/20 text-purple-200 border-purple-400/40'
              : 'bg-sky-400/20 text-sky-200 border-sky-400/40'}`}>{isExam ? 'طالب 100' : 'نظامي'}</span>
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border shrink-0 ${settled
              ? 'bg-emerald-400/20 text-emerald-200 border-emerald-400/40'
              : 'bg-amber-400/20 text-amber-200 border-amber-400/40'}`}>{settled ? 'سداد كامل' : `متبقي ${fmtMoney(s.remaining_amount ?? 0)}`}</span>
            <span className="text-[10px] text-white/45 flex items-center gap-1 shrink-0">
              <Archive className="w-2.5 h-2.5 shrink-0" />أُرشف {fmtDate(s.archived_at)}
            </span>
          </div>

          {/* شريط تقدم */}
          <div className="mb-1">
            <div className="flex justify-between text-[10px] text-white/60 mb-1">
              <span>نسبة السداد</span>
              <span className="font-bold text-white/80">{pct.toFixed(0)}%</span>
            </div>
            <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
              <div className={`h-full rounded-full ${settled ? 'bg-emerald-400' : 'bg-amber-400'}`} style={{ width: `${pct}%` }} />
            </div>
          </div>

          {/* تبويبات — قابلة للتمرير أفقياً */}
          <div className="flex gap-0 mt-2 -mb-px overflow-x-auto scrollbar-hide">
            {TABS.map(t => (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={`flex items-center gap-1 px-3 py-2.5 text-[11px] font-bold border-b-2 transition-all whitespace-nowrap shrink-0 ${
                  tab === t.id ? 'border-white text-white' : 'border-transparent text-white/50 hover:text-white/75'
                }`}>
                <t.icon className="w-3 h-3" />{t.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ── محتوى التبويبات — flex-1 min-h-0 overflow-y-auto ── */}
      <div className="flex-1 min-h-0 overflow-y-auto">
        <div className="p-4">

          {/* ── الشخصية ── */}
          {tab === 'personal' && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <InfoCell label="الرقم الوطني" value={s.national_id ?? '—'} mono />
                <InfoCell label="الجنس" value={s.gender ?? '—'} />
                <InfoCell label="رقم الهاتف" value={s.phone ?? '—'} mono />
                <InfoCell label="تاريخ التسجيل" value={fmtDate(s.enrollment_date)} />
                {s.address && <InfoCell label="العنوان" value={s.address} full />}
              </div>
              {s.phone && (
                <div className="flex items-center gap-3 p-3 bg-emerald-50 border border-emerald-200 rounded-xl">
                  <div className="w-8 h-8 bg-emerald-500 rounded-full flex items-center justify-center shrink-0">
                    <Phone className="w-3.5 h-3.5 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[10px] text-emerald-600 font-semibold">رقم التواصل</p>
                    <p className="text-sm font-black font-mono text-emerald-800 break-all">{s.phone}</p>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ── الأكاديمية ── */}
          {tab === 'academic' && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <InfoCell label="نوع الدبلوم"    value={s.diploma_type} />
                <InfoCell label="التخصص"          value={s.specialization ?? '—'} />
                <InfoCell label="الفصل الأخير"    value={`الفصل ${s.current_semester ?? '—'}`} />
                <InfoCell label="سنة التخرج"      value={s.graduation_year ? String(s.graduation_year) : fmtDate(s.archived_at).split(' ').pop() ?? '—'} />
                <InfoCell label="نوع الطالب"      value={isExam ? 'طالب 100' : 'نظامي'} />
                <InfoCell label="معادلة"           value={s.is_equivalency ? 'نعم' : 'لا'} />
                <InfoCell label="تاريخ الالتحاق"  value={fmtDate(s.enrollment_date)} />
                <InfoCell label="تاريخ الأرشفة"   value={fmtDate(s.archived_at)} />
              </div>
              {s.notes && (
                <div className="bg-amber-50 border border-amber-200 rounded-xl p-3">
                  <p className="text-[10px] text-amber-600 font-semibold mb-1">ملاحظات</p>
                  <p className="text-xs text-amber-900">{s.notes}</p>
                </div>
              )}
              <div className="flex items-center gap-3 p-3 bg-[#1a3c5e]/5 border border-[#1a3c5e]/20 rounded-xl">
                <div className="w-9 h-9 bg-[#1a3c5e] rounded-xl flex items-center justify-center shrink-0">
                  <GraduationCap className="w-4.5 h-4.5 text-white" />
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-black text-[#1a3c5e]">خريج رسمي — معهد القمة للعلوم الطبية والإدارية</p>
                  <p className="text-[11px] text-[#1a3c5e]/70 truncate">{s.diploma_type === 'عالي' ? 'دبلوم عالٍ' : 'دبلوم متوسط'} · {s.specialization}</p>
                </div>
              </div>
            </div>
          )}

          {/* ── المالية ── */}
          {tab === 'financial' && (
            <div className="space-y-3">
              {/* ثلاث بطاقات مالية بعرض كامل على الهاتف */}
              <div className="grid grid-cols-3 gap-2">
                {[
                  { label: 'إجمالي الرسوم', value: fmtMoney(s.total_charged), cls: 'text-foreground',  bg: 'bg-muted/40 border-border/30' },
                  { label: 'المدفوع', value: fmtMoney(s.total_paid),   cls: 'text-emerald-600', bg: 'bg-emerald-50 border-emerald-200' },
                  { label: 'المتبقي', value: fmtMoney(s.remaining_amount ?? 0),
                    cls: (s.remaining_amount ?? 0) > 0.01 ? 'text-red-600' : 'text-emerald-600',
                    bg: (s.remaining_amount ?? 0) > 0.01 ? 'bg-red-50 border-red-200' : 'bg-emerald-50 border-emerald-200' },
                ].map(f => (
                  <div key={f.label} className={`rounded-xl p-2 border text-center ${f.bg}`}>
                    <p className="text-[8px] text-muted-foreground/70 font-semibold mb-1 leading-tight">{f.label}</p>
                    <p className={`text-[10px] font-black tabular-nums leading-tight ${f.cls}`}>{f.value}</p>
                  </div>
                ))}
              </div>
              {/* شريط التقدم */}
              <div className="bg-muted/30 rounded-xl p-3 border border-border/30">
                <div className="flex justify-between text-xs mb-2">
                  <span className="text-muted-foreground">نسبة السداد</span>
                  <span className={`font-black ${settled ? 'text-emerald-600' : 'text-amber-600'}`}>{pct.toFixed(1)}%</span>
                </div>
                <div className="h-2.5 bg-muted rounded-full overflow-hidden">
                  <div className={`h-full rounded-full ${settled ? 'bg-gradient-to-l from-emerald-400 to-emerald-600' : 'bg-gradient-to-l from-amber-400 to-amber-600'}`}
                    style={{ width: `${pct}%` }} />
                </div>
                <div className="flex justify-between text-[10px] text-muted-foreground mt-1.5">
                  <span>{fmtMoney(paid)} مدفوع</span>
                  <span>{fmtMoney(charged)} إجمالي</span>
                </div>
              </div>
              {/* جدول الرسوم */}
              {charges.length > 0 && (
                <div>
                  <p className="text-xs font-bold text-muted-foreground mb-2 flex items-center gap-1">
                    <CreditCard className="w-3.5 h-3.5" />جدول الرسوم ({charges.length} بند)
                  </p>
                  <div className="space-y-1.5">
                    {charges.map((c: any, i: number) => (
                      <div key={i} className="flex items-center justify-between gap-2 px-3 py-2.5
                                              bg-background rounded-xl border border-border/40">
                        <span className="text-xs font-semibold text-foreground truncate flex-1 min-w-0">
                          {c.charge_type === 'تسجيل' ? 'رسوم التسجيل'
                            : c.charge_type === 'مشروع تخرج' ? 'مشروع التخرج'
                            : c.charge_type === 'معادلة' ? `رسوم معادلة ${SEMESTER_LABELS[c.semester_number] ?? `الفصل ${c.semester_number}`}`
                            : SEMESTER_LABELS[c.semester_number] ?? `الفصل ${c.semester_number}`}
                        </span>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <span className="text-xs tabular-nums font-bold whitespace-nowrap">{fmtMoney(c.charge_amount ?? 0)}</span>
                          <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full border whitespace-nowrap ${c.is_cleared
                            ? 'text-emerald-700 bg-emerald-50 border-emerald-200'
                            : 'text-amber-700 bg-amber-50 border-amber-200'}`}>
                            {c.is_cleared ? '✓' : 'متبقي'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ── الإيصالات ── */}
          {tab === 'receipts' && (
            <div className="space-y-2">
              {receipts.length === 0
                ? <div className="text-center py-12 text-muted-foreground text-sm">لا توجد إيصالات مسجّلة</div>
                : receipts.map((r: any, i: number) => {
                    const label   = receiptLabel(r);
                    const rNo     = fmtReceiptNo(r);
                    const hasNote = r.notes && !r.notes.startsWith('تخفيض:');
                    return (
                      <div key={i} className="bg-background rounded-xl border border-border/50 overflow-hidden hover:shadow-sm hover:border-[#1a3c5e]/30 transition-all">
                        <div className="flex items-center gap-2.5 px-3 py-2.5">
                          {/* رقم تسلسلي */}
                          <div className="w-7 h-7 rounded-lg bg-[#1a3c5e]/8 flex items-center justify-center shrink-0 border border-[#1a3c5e]/15">
                            <span className="text-[10px] font-black text-[#1a3c5e]">{i + 1}</span>
                          </div>
                          {/* المعلومات */}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap mb-0.5">
                              <span className="text-xs font-bold text-foreground">{label}</span>
                              <span className="text-[10px] font-mono font-bold text-primary bg-primary/8 px-1.5 py-0.5 rounded-md border border-primary/20">#{rNo}</span>
                            </div>
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="text-[10px] text-muted-foreground/70">{fmtDate(r.paid_at)}</span>
                              {r.payment_method && (
                                <span className="text-[9px] bg-muted px-1.5 py-0.5 rounded-full text-muted-foreground border border-border/40">{r.payment_method}</span>
                              )}
                            </div>
                            {hasNote && <p className="text-[10px] text-muted-foreground/60 mt-0.5 italic truncate">{r.notes}</p>}
                          </div>
                          {/* المبلغ + الطباعة */}
                          <div className="shrink-0 flex flex-col items-end gap-1">
                            <p className="text-sm font-black text-emerald-600 tabular-nums whitespace-nowrap">{fmtMoney(parseFloat(r.amount ?? 0))}</p>
                            <button onClick={() => printReceiptFromSnapshot(s, r)}
                              className="w-7 h-7 rounded-lg bg-[#1a3c5e]/8 hover:bg-[#1a3c5e] text-[#1a3c5e] hover:text-white
                                         border border-[#1a3c5e]/20 flex items-center justify-center transition-all duration-150">
                              <Printer className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })
              }
            </div>
          )}
          {/* ── الأوراق المرفوعة ── */}
          {tab === 'files' && (
            <div className="space-y-2">
              {/* شريط رأس + زر طباعة الكل */}
              {files.length > 0 && (
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-[#1a3c5e]/10 border border-[#1a3c5e]/20 flex items-center justify-center">
                      <Award className="w-3.5 h-3.5 text-[#1a3c5e]" />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-foreground leading-tight">الأوراق الثبوتية</p>
                      <p className="text-[10px] text-muted-foreground">{files.length} ورقة مرفوعة</p>
                    </div>
                  </div>
                  <button
                    onClick={handlePrintFiles}
                    className="inline-flex items-center gap-1.5 text-[11px] font-bold px-3 py-1.5 rounded-xl bg-[#1a3c5e] text-white hover:bg-[#0f2744] active:scale-95 transition-all shadow-sm"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    طباعة الكل
                  </button>
                </div>
              )}
              {files.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground text-sm flex flex-col items-center gap-2">
                  <Award className="w-8 h-8 opacity-30" />
                  <span>لا توجد أوراق مرفوعة لهذا الطالب</span>
                </div>
              ) : (
                files.map((f: any, i: number) => {
                  const isImage = f.file_type === 'image';
                  return (
                    <div key={i} className="bg-background rounded-xl border border-border/50 overflow-hidden hover:shadow-sm hover:border-[#1a3c5e]/30 transition-all">
                      <div className="flex items-center gap-2.5 px-3 py-2.5">
                        {/* رقم الملف */}
                        <div className="w-6 h-6 rounded-full bg-[#1a3c5e] text-white text-[9px] font-black flex items-center justify-center shrink-0">
                          {i + 1}
                        </div>
                        {/* أيقونة النوع */}
                        <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border ${
                          isImage ? 'bg-blue-50 border-blue-200' : 'bg-amber-50 border-amber-200'
                        }`}>
                          {isImage
                            ? <Eye className="w-4 h-4 text-blue-600" />
                            : <FileText className="w-4 h-4 text-amber-600" />}
                        </div>
                        {/* اسم الملف */}
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-bold text-foreground truncate">{f.label || f.file_name}</p>
                          <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                            <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full border ${
                              isImage ? 'bg-blue-50 text-blue-700 border-blue-200' : 'bg-amber-50 text-amber-700 border-amber-200'
                            }`}>{isImage ? 'صورة' : 'مستند'}</span>
                            <span className="text-[10px] text-muted-foreground/60">{fmtDate(f.created_at)}</span>
                          </div>
                        </div>
                        {/* أزرار: طباعة + عرض */}
                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            onClick={() => handlePrintSingleFile(f)}
                            className="w-8 h-8 rounded-lg bg-[#1a3c5e]/8 hover:bg-[#1a3c5e] text-[#1a3c5e] hover:text-white border border-[#1a3c5e]/20 flex items-center justify-center transition-all duration-150"
                            title="طباعة هذه الورقة"
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>
                          <a
                            href={f.file_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="w-8 h-8 rounded-lg bg-[#1a3c5e]/8 hover:bg-[#1a3c5e] text-[#1a3c5e] hover:text-white border border-[#1a3c5e]/20 flex items-center justify-center transition-all duration-150"
                            title="فتح / تنزيل"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </a>
                        </div>
                      </div>
                      {/* معاينة الصور */}
                      {isImage && (
                        <div className="px-3 pb-3">
                          <img
                            src={f.file_url}
                            alt={f.label || f.file_name}
                            className="w-full max-h-40 object-cover rounded-lg border border-border/30"
                            loading="lazy"
                          />
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          )}

        </div>
      </div>

      {/* ── تذييل النافذة ── */}
      <div className="border-t border-border/40 px-4 py-3 flex items-center justify-between bg-muted/20 rounded-b-2xl shrink-0">
        <span className="text-[10px] text-muted-foreground/60 flex items-center gap-1 truncate">
          <Archive className="w-3 h-3 shrink-0" />أُرشف في {fmtDate(s.archived_at)}
        </span>
        <button onClick={onClose}
          className="h-8 px-4 rounded-lg text-xs font-semibold bg-[#1a3c5e] text-white hover:bg-[#1e4d78] transition-colors shrink-0 mr-2">
          إغلاق
        </button>
      </div>
    </div>
  );
}

// ── الصفحة الرئيسية ──────────────────────────────────────────────────────────
export default function ArchivePage() {
  const [students, setStudents]             = useState<ArchivedStudent[]>([]);
  const [loading, setLoading]               = useState(true);
  const PAGE_SIZE = 36;
  const [page, setPage]                     = useState(0);
  const [totalCount, setTotalCount]         = useState(0);
  const [searchInput, setSearchInput]       = useState('');
  const [search, setSearch]                 = useState('');
  const [filterDiploma, setFilterDiploma]   = useState<'الكل' | 'عالي' | 'متوسط'>('الكل');
  const [filterBatch, setFilterBatch]       = useState<'الكل'>('الكل');
  const [detailStudent, setDetailStudent]   = useState<ArchivedStudent | null>(null);
  const [loadingDetail, setLoadingDetail]   = useState(false);
  const [showClearDialog, setShowClearDialog] = useState(false);
  const [clearPassword, setClearPassword]   = useState('');
  const [clearError, setClearError]         = useState('');
  const [clearing, setClearing]             = useState(false);
  const [stats, setStats]                   = useState<ArchiveStats>({ total: 0, highDiploma: 0, midDiploma: 0, totalPaid: 0 });
  const searchTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const load = useCallback(async (targetPage = page, searchTerm = search, diploma = filterDiploma) => {
    setLoading(true);
    try {
      const [{ data, count }, st] = await Promise.all([
        getArchivedStudents({
          search: searchTerm,
          diplomaType: diploma === 'الكل' ? undefined : diploma,
          limit: PAGE_SIZE,
          offset: targetPage * PAGE_SIZE,
        }),
        getArchiveStats({
          search: searchTerm,
          diplomaType: diploma === 'الكل' ? undefined : diploma,
        }),
      ]);
      setStudents(data);
      setTotalCount(count);
      setStats(st);
    }
    catch { toast.error('فشل في تحميل الأرشيف'); }
    finally { setLoading(false); }
  }, [page, search, filterDiploma]);

  useEffect(() => {
    load(page, search, filterDiploma);
  }, [page, search, filterDiploma, load]);

  const handleSearchChange = (val: string) => {
    setSearchInput(val);
    if (searchTimer.current) clearTimeout(searchTimer.current);
    searchTimer.current = setTimeout(() => {
      setSearch(val.trim());
      setPage(0);
    }, 300);
  };

  const handleDiplomaChange = (d: 'الكل' | 'عالي' | 'متوسط') => {
    setFilterDiploma(d);
    setPage(0);
  };

  const handleOpenDetail = async (s: ArchivedStudent) => {
    setDetailStudent(s);
    if (!s.receipts_snapshot || s.receipts_snapshot.length === 0) {
      setLoadingDetail(true);
      try {
        const full = await getArchivedStudentDetails(s.id);
        if (full) setDetailStudent(full);
      } catch {
        // use basic s
      } finally {
        setLoadingDetail(false);
      }
    }
  };

  const totalPages = Math.ceil(totalCount / PAGE_SIZE) || 1;

  const handleClearArchive = async () => {
    if (clearPassword !== SYSTEM_PASSWORD) { setClearError('كلمة المرور غير صحيحة'); return; }
    setClearing(true);
    try {
      await clearArchive();
      toast.success('تم مسح الأرشيف بالكامل');
      setShowClearDialog(false); setClearPassword(''); setClearError('');
      setPage(0);
      await load(0, search, filterDiploma);
    } catch { toast.error('فشل في مسح الأرشيف'); }
    finally { setClearing(false); }
  };

  const handleExportPDF = () => {
    if (!students.length) return;
    exportPDF({
      title: 'أرشيف الطلاب الخريجين',
      subtitle: `معهد القمة للعلوم الطبية والإدارية — إجمالي ${totalCount} خريج (الصفحة ${page + 1})`,
      columns: ['#', 'الاسم', 'الدبلوم', 'التخصص', 'الإجمالي', 'المدفوع', 'المتبقي', 'تاريخ الأرشفة'],
      rows: students.map((s, i) => [
        String(page * PAGE_SIZE + i + 1), s.full_name, s.diploma_type,
        s.specialization ?? '—',
        fmtMoney(s.total_charged), fmtMoney(s.total_paid),
        fmtMoney(s.remaining_amount ?? 0), fmtDate(s.archived_at),
      ]),
      accentColor: '#1a3c5e',
      filename: 'أرشيف-الطلاب-الخريجين',
    });
  };

  return (
    <MainLayout>
      <div className="min-h-screen bg-muted/20" dir="rtl">

        {/* ── شريط الرأس ── */}
        <div className="bg-[#1a3c5e] px-4 py-4 md:px-8 md:py-5">
          <div className="max-w-6xl mx-auto">
            {/* الصف الأول: أيقونة + عنوان */}
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 shrink-0 rounded-xl bg-white/10 border border-white/20 flex items-center justify-center">
                <Archive className="w-5 h-5 text-white" />
              </div>
              <div className="min-w-0 flex-1">
                <h1 className="text-lg md:text-2xl font-black text-white tracking-tight leading-tight">أرشيف الطلاب الخريجين</h1>
                <p className="text-white/50 text-[11px] mt-0.5 hidden md:block">سجل دائم — الملفات الشخصية والأكاديمية والمالية</p>
              </div>
            </div>
            {/* الصف الثاني: الأزرار بعرض كامل */}
            <div className="flex items-center gap-2">
              <RefreshButton onRefresh={load} loading={loading} variant="ghost" />
              <button
                onClick={() => { setShowClearDialog(true); setClearPassword(''); setClearError(''); }}
                className="h-9 w-9 shrink-0 rounded-xl border border-red-400/40 bg-red-500/20 hover:bg-red-500/40
                           text-red-300 flex items-center justify-center transition-colors"
                title="مسح الأرشيف">
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        <div className="max-w-6xl mx-auto px-3 md:px-8 py-4 md:py-6 space-y-4">

          {/* ── بطاقات الإحصاء ── */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-3">
            {[
              { label: 'إجمالي الأرشيف', value: stats.total,       icon: Users,         bar: 'bg-[#1a3c5e]', accent: 'bg-[#1a3c5e]/8 text-[#1a3c5e]' },
              { label: 'دبلوم عالي',     value: stats.highDiploma, icon: GraduationCap, bar: 'bg-blue-500',  accent: 'bg-blue-500/8 text-blue-600' },
              { label: 'دبلوم متوسط',   value: stats.midDiploma,  icon: BadgeCheck,    bar: 'bg-emerald-500', accent: 'bg-emerald-500/8 text-emerald-600' },
              { label: 'إجمالي المدفوع', value: stats.totalPaid.toFixed(0), icon: DollarSign, bar: 'bg-amber-500', accent: 'bg-amber-500/8 text-amber-600', suffix: 'د.ل' },
            ].map(stat => (
              <Card key={stat.label} className="border border-border/40 overflow-hidden h-full">
                <div className={`h-0.5 w-full ${stat.bar}`} />
                <CardContent className="p-3 md:p-4 flex items-center gap-2 md:gap-3">
                  <div className={`w-8 h-8 md:w-10 md:h-10 rounded-xl flex items-center justify-center shrink-0 ${stat.accent}`}>
                    <stat.icon className="w-4 h-4 md:w-5 md:h-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-[10px] md:text-[11px] text-muted-foreground font-medium leading-tight">{stat.label}</p>
                    <p className="text-lg md:text-xl font-black text-foreground tabular-nums leading-tight">
                      {loading ? <span className="text-muted-foreground/40">…</span> : stat.value}
                      {(stat as any).suffix && <span className="text-[10px] font-normal text-muted-foreground mr-1">{(stat as any).suffix}</span>}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* ── شريط البحث والفلترة ── */}
          <Card className="border border-border/40">
            <CardContent className="p-2.5 md:p-3 space-y-2">
              {/* صف البحث */}
              <div className="flex flex-col md:flex-row gap-2">
                <div className="relative flex-1">
                  <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                  <Input placeholder="بحث بالاسم أو الرقم الوطني أو التخصص..."
                    value={searchInput} onChange={e => handleSearchChange(e.target.value)}
                    className="pr-9 h-9 md:h-10 text-sm bg-muted/30 border-border/50 focus:bg-background" />
                </div>
                {/* فلتر الدبلوم */}
                <div className="flex gap-1.5 shrink-0">
                  {(['الكل', 'عالي', 'متوسط'] as const).map(d => (
                    <button key={d} onClick={() => handleDiplomaChange(d)}
                      className={`flex-1 md:flex-none h-9 md:h-10 px-3 md:px-4 rounded-lg text-xs md:text-sm font-semibold border transition-all ${
                        filterDiploma === d
                          ? 'bg-[#1a3c5e] text-white border-[#1a3c5e] shadow-sm'
                          : 'bg-background text-muted-foreground border-border/60 hover:border-[#1a3c5e]/40 hover:text-[#1a3c5e]'
                      }`}>{d}</button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* ── العداد ── */}
          <div className="flex items-center justify-between px-0.5">
            <p className="text-xs md:text-sm font-bold text-[#1a3c5e]">
              {loading ? 'جاري التحميل...' : <>{totalCount.toLocaleString('ar-LY')} <span className="font-normal text-muted-foreground">طالب مؤرشف (سجلات مضغوطة فائقة السرعة)</span></>}
            </p>
            <div className="flex items-center gap-2 flex-wrap">
              {search && (
                <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full">"{search}"</span>
              )}
            </div>
          </div>

          {/* ── شبكة البطاقات ── */}
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {Array(6).fill(0).map((_, i) => (
                <div key={i} className="bg-background border border-border/40 rounded-2xl p-4 space-y-3">
                  <div className="flex gap-3 items-start">
                    <Skeleton className="w-12 h-12 rounded-xl shrink-0" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-4 w-40" />
                      <Skeleton className="h-3 w-28" />
                    </div>
                  </div>
                  <Skeleton className="h-2 w-full rounded-full" />
                  <Skeleton className="h-3 w-24" />
                </div>
              ))}
            </div>
          ) : students.length === 0 ? (
            <div className="flex flex-col items-center py-16 gap-4">
              <div className="w-16 h-16 rounded-3xl bg-muted flex items-center justify-center">
                <Archive className="w-8 h-8 text-muted-foreground/30" />
              </div>
              <p className="text-sm font-semibold text-muted-foreground">لا توجد سجلات في الأرشيف</p>
              {search && <p className="text-xs text-muted-foreground/60">جرّب مصطلح بحث مختلف</p>}
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {students.map(s => (
                  <StudentArchiveCard key={s.id} s={s} onClick={() => handleOpenDetail(s)} />
                ))}
              </div>

              {/* ── شريط ترقيم الصفحات السريع للأرشيف الضخم (+100 ألف طالب) ── */}
              {totalPages > 1 && (
                <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-card border border-border/50 rounded-xl px-4 py-3 shadow-sm mt-4">
                  <div className="text-xs text-muted-foreground">
                    عرض <span className="font-bold text-foreground">{(page * PAGE_SIZE + 1).toLocaleString('ar-LY')}</span> إلى{' '}
                    <span className="font-bold text-foreground">{Math.min((page + 1) * PAGE_SIZE, totalCount).toLocaleString('ar-LY')}</span> من إجمالي{' '}
                    <span className="font-bold text-foreground">{totalCount.toLocaleString('ar-LY')}</span> طالب مؤرشف
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={page === 0 || loading}
                      onClick={() => setPage(0)}
                      className="h-8 px-2.5 text-xs"
                    >
                      الأولى
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={page === 0 || loading}
                      onClick={() => setPage(p => Math.max(0, p - 1))}
                      className="h-8 px-2.5 text-xs"
                    >
                      السابق
                    </Button>
                    <span className="text-xs font-semibold px-2 bg-muted/40 py-1 rounded-md">
                      {page + 1} / {totalPages}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={page >= totalPages - 1 || loading}
                      onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))}
                      className="h-8 px-2.5 text-xs"
                    >
                      التالي
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={page >= totalPages - 1 || loading}
                      onClick={() => setPage(totalPages - 1)}
                      className="h-8 px-2.5 text-xs"
                    >
                      الأخيرة
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* ── نافذة الملف الأرشيفي الكامل ── */}
      <Dialog open={!!detailStudent} onOpenChange={v => { if (!v) setDetailStudent(null); }}>
        <DialogContent
          className="max-w-[calc(100%-1rem)] md:max-w-xl h-[92dvh] max-h-[92dvh] overflow-hidden p-0 rounded-2xl [&>button:last-child]:hidden flex flex-col"
          dir="rtl">
          {detailStudent && (
            <ArchiveFileDialog s={detailStudent} onClose={() => setDetailStudent(null)} />
          )}
        </DialogContent>
      </Dialog>

      {/* ── نافذة تأكيد مسح الأرشيف ── */}
      <AlertDialog open={showClearDialog}
        onOpenChange={v => { if (!v) { setShowClearDialog(false); setClearPassword(''); setClearError(''); } }}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md p-0 overflow-hidden" dir="rtl">
          <div className="bg-destructive/5 border-b border-destructive/20 px-5 py-4">
            <AlertDialogHeader>
              <AlertDialogTitle className="flex items-center gap-2 text-destructive text-base font-black">
                <ShieldAlert className="w-5 h-5" />مسح الأرشيف بالكامل
              </AlertDialogTitle>
              <AlertDialogDescription className="text-right text-xs text-muted-foreground mt-1">
                سيتم حذف جميع سجلات الأرشيف نهائياً ولا يمكن التراجع عن هذا الإجراء.
              </AlertDialogDescription>
            </AlertDialogHeader>
          </div>
          <div className="px-5 py-4 space-y-3">
            <p className="text-xs font-medium text-foreground">أدخل كلمة المرور للمتابعة:</p>
            <Input type="password" placeholder="كلمة المرور السرية" value={clearPassword}
              onChange={e => { setClearPassword(e.target.value); setClearError(''); }}
              onKeyDown={e => e.key === 'Enter' && handleClearArchive()}
              className={`h-10 ${clearError ? 'border-destructive' : ''}`} />
            {clearError && (
              <p className="text-xs text-destructive font-semibold flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />{clearError}
              </p>
            )}
          </div>
          <AlertDialogFooter className="px-5 pb-5 gap-2">
            <AlertDialogCancel className="h-10 flex-1"
              onClick={() => { setClearPassword(''); setClearError(''); }}>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              onClick={e => { e.preventDefault(); handleClearArchive(); }}
              disabled={clearing || !clearPassword}
              className="h-10 flex-1 bg-destructive hover:bg-destructive/90 text-destructive-foreground gap-2">
              {clearing
                ? <><RefreshCw className="w-4 h-4 animate-spin" />جاري المسح...</>
                : <><Trash2 className="w-4 h-4" />مسح الأرشيف</>}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </MainLayout>
  );
}
