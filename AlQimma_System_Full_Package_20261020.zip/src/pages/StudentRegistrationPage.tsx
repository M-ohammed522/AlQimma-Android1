// تسجيل طالب جديد - منظومة معهد القمة
import React, { useEffect, useState, useRef } from 'react';
import ImageEditorModal from '@/components/ui/ImageEditorModal';
import { useNavigate } from 'react-router-dom';
import {
  UserPlus, ChevronRight, Info, User, BookOpen,
  FileText, Banknote, CheckCircle2, AlertCircle, Phone, Scissors, Clock,
  Camera, FolderOpen, X as XIcon,
} from 'lucide-react';
import { toast } from 'sonner';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import {
  getSpecializations, createStudent, getSettings, getNextReceiptNumber,
  peekCurrentReceiptNumber, createSemesterCharge, checkAndCreateDocumentNotification,
  processPayment, getSemesterCharges, applyDiscount, createReceipt,
  uploadStudentAvatar, checkNationalIdExists, updateStudent,
} from '@/lib/api';
import { printRegistrationForm, type PrintRegistrationData } from '@/lib/printRegistrationForm';
import type { DiplomaType, Specialization } from '@/types/index';
import { SEMESTER_LABELS, SETTINGS_KEYS, ARAB_NATIONALITIES, DEFAULT_NATIONALITY } from '@/types/index';
import { compressImageIfNeeded } from '@/lib/imageUtils';
import { useDeviceRole } from '@/contexts/DeviceRoleContext';

interface FormData {
  full_name: string;
  nationality: string;
  national_id: string;
  registration_number: string;
  phone: string;
  guardian_phone: string;
  address: string;
  diploma_type: DiplomaType | '';
  specialization: string;
  photos_required: number;
  photos_received: number;
  has_birth_certificate: boolean;
  has_registration_certificate: boolean;
  has_suspended_file: boolean;
  is_equivalency: boolean;
  equivalency_start_semester: number;
  initial_payment: string;
  receipt_number: string;
  // تخفيض رسوم التسجيل
  final_reg_amount: string;
  discount_reg_reason: string;
}

// تخفيض منفصل لكل فصل دراسي
interface SemDiscountEntry {
  enabled: boolean;
  finalAmount: string;  // المبلغ النهائي = أصلي - تخفيض
  reason: string;
}

const initialForm: FormData = {
  full_name: '',
  nationality: DEFAULT_NATIONALITY,
  national_id: '',
  registration_number: '',
  phone: '',
  guardian_phone: '',
  address: '',
  diploma_type: '',
  specialization: '',
  photos_required: 6,
  photos_received: 0,
  has_birth_certificate: false,
  has_registration_certificate: false,
  has_suspended_file: false,
  is_equivalency: false,
  equivalency_start_semester: 1,
  final_reg_amount: '',
  discount_reg_reason: '',
  initial_payment: '',
  receipt_number: '',
};

const ALL_SEMESTERS = [1, 2, 3, 4, 5, 6] as const;

function buildInitialSemDiscounts(semFeeBase: number): Record<number, SemDiscountEntry> {
  return Object.fromEntries(
    ALL_SEMESTERS.map(s => [s, { enabled: false, finalAmount: String(semFeeBase), reason: '' }])
  );
}

// ── مكوّنات مساعدة خارج الصفحة لتجنب إعادة الإنشاء عند كل تحديث ──

// حقل إدخال موحد
function Field({ label, required, error, subtitle, children }: {
  label: string; required?: boolean; error?: string; subtitle?: string; children: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <Label className="text-sm font-medium text-foreground">
          {label} {required && <span className="text-destructive">*</span>}
        </Label>
        {subtitle && <span className="text-[11px] text-muted-foreground">{subtitle}</span>}
      </div>
      {children}
      {error && (
        <p className="text-xs text-destructive flex items-center gap-1">
          <AlertCircle className="w-3 h-3 shrink-0" />{error}
        </p>
      )}
    </div>
  );
}

// رأس القسم — ملوّن احترافي
function SectionHeader({ icon: Icon, title, subtitle, color = 'blue' }: {
  icon: React.ElementType; title: string; subtitle?: string;
  color?: 'blue' | 'green' | 'amber' | 'purple';
}) {
  const palette = {
    blue:   { bg: 'bg-primary/10',   icon: 'text-primary',       bar: 'bg-primary',       text: 'text-primary' },
    green:  { bg: 'bg-emerald-500/10', icon: 'text-emerald-600',  bar: 'bg-emerald-500',   text: 'text-emerald-700' },
    amber:  { bg: 'bg-amber-400/10',  icon: 'text-amber-600',     bar: 'bg-amber-500',     text: 'text-amber-700' },
    purple: { bg: 'bg-violet-500/10', icon: 'text-violet-600',    bar: 'bg-violet-500',    text: 'text-violet-700' },
  }[color];
  return (
    <div className="flex items-center gap-3 mb-5">
      <div className={`w-9 h-9 rounded-xl ${palette.bg} flex items-center justify-center shrink-0 shadow-sm`}>
        <Icon className={`w-4.5 h-4.5 ${palette.icon}`} />
      </div>
      <div className="flex-1 min-w-0">
        <h2 className={`text-sm font-bold ${palette.text}`}>{title}</h2>
        {subtitle && <p className="text-xs text-muted-foreground">{subtitle}</p>}
      </div>
      <div className={`h-0.5 w-12 rounded-full ${palette.bar} opacity-40 shrink-0`} />
    </div>
  );
}

export default function StudentRegistrationPage() {
  const navigate = useNavigate();
  const { can } = useDeviceRole();
  const [form, setForm] = useState<FormData>(initialForm);
  const [specializations, setSpecializations] = useState<Specialization[]>([]);
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState<Partial<Record<keyof FormData, string>>>({});
  // تخفيضات الفصول الدراسية (1-6) بشكل منفرد
  const [semDiscounts, setSemDiscounts] = useState<Record<number, SemDiscountEntry>>({});

  // صورة الطالب (محلية قبل الرفع)
  const [photoFile, setPhotoFile]         = useState<File | null>(null);
  const [photoPreview, setPhotoPreview]   = useState<string | null>(null);
  const [photoUploading, setPhotoUploading] = useState(false);
  const fileInputRef   = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  // محرر الصور
  const [editorOpen, setEditorOpen]   = useState(false);
  const [editorSrc,  setEditorSrc]    = useState('');

  useEffect(() => {
    const init = async () => {
      const [specs, cfg] = await Promise.all([
        getSpecializations(),
        getSettings(),
      ]);
      setSpecializations(specs);
      setSettings(cfg);
      const requiredPhotos = parseInt(cfg[SETTINGS_KEYS.REQUIRED_PHOTOS_COUNT] ?? '6');
      setForm(prev => ({ ...prev, photos_required: requiredPhotos }));
    };
    init().catch(console.error);
  }, []);

  // تحديث رقم الإيصال وقيم التخفيض الافتراضية عند تغيير نوع الدبلوم
  useEffect(() => {
    if (!form.diploma_type || !Object.keys(settings).length) return;
    const regFee = parseFloat(settings[SETTINGS_KEYS.REGISTRATION_FEE] ?? '100');
    const semFee = form.diploma_type === 'عالي'
      ? parseFloat(settings[SETTINGS_KEYS.HIGH_DIPLOMA_FEE] ?? '600')
      : parseFloat(settings[SETTINGS_KEYS.MID_DIPLOMA_FEE] ?? '550');
    peekCurrentReceiptNumber(form.diploma_type as DiplomaType)
      .then(num => setForm(prev => ({
        ...prev,
        receipt_number: num,
        final_reg_amount: String(regFee),
      })))
      .catch(console.error);
    setSemDiscounts(buildInitialSemDiscounts(semFee));
  }, [form.diploma_type, settings]);

  // فلترة التخصصات حسب نوع الدبلوم
  const filteredSpecs = form.diploma_type
    ? specializations.filter(s => s.diploma_type === form.diploma_type)
    : [];

  // حساب رسوم المعادلة
  // equivSemesters = عدد الفصول المعادلة = equivalency_start_semester (شامل الفصل الأول)
  // مثال: يبدأ من الفصل الأول   → 1 فصل معادلة × 250 + 100 = 350
  //        يبدأ من الفصل الثاني  → 2 فصل معادلة × 250 + 100 = 600  (← وهكذا)
  //        يبدأ من الفصل الثالث  → 3 فصل معادلة × 250 + 100 = 850
  const equivalencyFeeCalc = (() => {
    if (!form.is_equivalency || !form.equivalency_start_semester) return null;
    const equivSemesters = form.equivalency_start_semester; // شامل الفصل الأول
    const semFee = parseFloat(settings[SETTINGS_KEYS.EQUIVALENCY_SEMESTER_FEE] ?? '250');
    const regFee = parseFloat(settings[SETTINGS_KEYS.EQUIVALENCY_REGISTRATION_FEE] ?? '100');
    const total = equivSemesters * semFee + regFee;
    return { equivSemesters, semFee, regFee, total };
  })();

  // النواقص
  const missingDocs = (() => {
    const m: string[] = [];
    if (form.photos_received < form.photos_required)
      m.push(`${form.photos_required - form.photos_received} صور شخصية`);
    if (!form.has_birth_certificate) m.push('شهادة ميلاد');
    if (!form.has_registration_certificate) m.push('شهادة التسجيل');
    if (!form.has_suspended_file) m.push('ملف معلق');
    return m;
  })();

  const validate = (): boolean => {
    const e: Partial<Record<keyof FormData, string>> = {};
    if (!form.full_name.trim()) e.full_name = 'الاسم الرباعي مطلوب';
    if (form.national_id.trim() && !/^\d{12}$/.test(form.national_id))
      e.national_id = 'الرقم الوطني يجب أن يكون 12 رقماً (أو اتركه فارغاً)';
    if (!form.diploma_type) e.diploma_type = 'نوع الدبلوم مطلوب';
    if (!form.specialization) e.specialization = 'التخصص مطلوب';
    const payAmt = parseFloat(form.initial_payment) || 0;
    if (payAmt > 0 && !form.receipt_number.trim()) {
      e.receipt_number = 'رقم الإيصال مطلوب عند تسجيل دفعة مالية';
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async () => {
    if (!validate()) { toast.error('يرجى تصحيح الأخطاء قبل الحفظ'); return; }
    setSaving(true);
    try {
      // التحقق من الرقم الوطني فقط إذا تم إدخاله
      if (form.national_id.trim()) {
        const exists = await checkNationalIdExists(form.national_id);
        if (exists) {
          setErrors(prev => ({ ...prev, national_id: 'هذا الرقم الوطني مسجل مسبقاً في المنظومة' }));
          setSaving(false);
          return;
        }
      }

      // عدد فصول المعادلة = equivalency_start_semester (شامل الفصل الأول نفسه)
      const equivSemesters = form.is_equivalency ? form.equivalency_start_semester : 0;
      const equivSemestersList = form.is_equivalency
        ? Array.from({ length: equivSemesters }, (_, i) => i + 1)
        : [];

      const student = await createStudent({
        full_name: form.full_name.trim(),
        nationality: form.nationality.trim() || DEFAULT_NATIONALITY,
        national_id: form.national_id.trim(),
        registration_number: form.registration_number.trim() || null,
        phone: form.phone.trim() || null,
        guardian_phone: form.guardian_phone.trim() || null,
        address: form.address.trim() || null,
        gender: null,
        enrollment_date: new Date().toISOString().slice(0, 10),
        notes: null,
        diploma_type: form.diploma_type as DiplomaType,
        specialization: form.specialization,
        // الفصل الدراسي الأول الفعلي = عدد فصول المعادلة + 1
        // مثال: معادلة 3 فصول → current_semester = 4
        current_semester: form.is_equivalency ? form.equivalency_start_semester + 1 : 1,
        status: 'نشط',
        is_equivalency: form.is_equivalency,
        equivalency_start_semester: form.is_equivalency ? form.equivalency_start_semester : null,
        equivalency_equivalent_semesters: form.is_equivalency ? equivSemestersList : null,
        photos_required: form.photos_required,
        photos_received: form.photos_received,
        has_birth_certificate: form.has_birth_certificate,
        has_registration_certificate: form.has_registration_certificate,
        has_suspended_file: form.has_suspended_file,
        registration_fee_paid: false,
        photo_url: null,
        is_exam_only: false,
        project_name: null,
        project_summary: null,
        project_supervisor: null,
        ...((() => {
          const futureSems = ALL_SEMESTERS.filter(s => s > 1 && semDiscounts[s]?.enabled);
          if (!futureSems.length) return {};
          const semFeeBase2 = form.diploma_type === 'عالي'
            ? parseFloat(settings[SETTINGS_KEYS.HIGH_DIPLOMA_FEE] ?? '600')
            : parseFloat(settings[SETTINGS_KEYS.MID_DIPLOMA_FEE] ?? '550');
          const minDiscount = Math.min(...futureSems.map(s => {
            const fa = parseFloat(semDiscounts[s].finalAmount) || semFeeBase2;
            return semFeeBase2 - Math.min(fa, semFeeBase2);
          }));
          const representativeReason = semDiscounts[futureSems[0]].reason.trim();
          return minDiscount > 0 ? {
            default_semester_discount: minDiscount,
            default_semester_discount_reason: representativeReason || null,
          } : {};
        })()),
      });

      const regFeeAmount = parseFloat(settings[SETTINGS_KEYS.REGISTRATION_FEE] ?? '100');
      const semFee = student.diploma_type === 'عالي'
        ? parseFloat(settings[SETTINGS_KEYS.HIGH_DIPLOMA_FEE] ?? '600')
        : parseFloat(settings[SETTINGS_KEYS.MID_DIPLOMA_FEE] ?? '550');

      // ── إنشاء الرسوم بشكل متوازٍ ──────────────────────────────────────────
      if (form.is_equivalency && equivalencyFeeCalc) {
        // رسوم التسجيل + قيد منفصل لكل فصل معادلة (250 د.ل لكل فصل) + الفصل الدراسي الأول
        const equivCharges = Array.from({ length: equivalencyFeeCalc.equivSemesters }, (_, i) => ({
          student_id: student.id,
          semester_number: i + 1,           // الفصل 1، 2، 3... حسب عدد فصول المعادلة
          charge_amount: equivalencyFeeCalc.semFee,
          paid_amount: 0,
          charge_type: 'معادلة' as const,
          is_cleared: false,
          is_locked: false,
        }));
        await createSemesterCharge({
          student_id: student.id, semester_number: -1,
          charge_amount: regFeeAmount, paid_amount: 0,
          charge_type: 'تسجيل', is_cleared: false, is_locked: false,
        });
        // إنشاء قيد معادلة لكل فصل بشكل متسلسل (لضمان الترتيب الصحيح)
        for (const ec of equivCharges) await createSemesterCharge(ec);
        await Promise.all([
          updateStudent(student.id, {
            total_charged: regFeeAmount + equivalencyFeeCalc.total + semFee,
          }),
          // الفصل الدراسي الأول الفعلي = بعد الفصول المعادلة مباشرة
          // مثال: معادلة 3 فصول → الفصل الدراسي = 4
          createSemesterCharge({
            student_id: student.id,
            semester_number: form.equivalency_start_semester + 1,
            charge_amount: semFee, paid_amount: 0,
            charge_type: 'فصلي', is_cleared: false, is_locked: false,
          }),
        ]);
      } else {
        // رسوم التسجيل + الفصل الأول معاً
        await Promise.all([
          createSemesterCharge({
            student_id: student.id, semester_number: -1,
            charge_amount: regFeeAmount, paid_amount: 0,
            charge_type: 'تسجيل', is_cleared: false, is_locked: false,
          }),
          createSemesterCharge({
            student_id: student.id, semester_number: 1,
            charge_amount: semFee, paid_amount: 0,
            charge_type: 'فصلي', is_cleared: false, is_locked: false,
          }),
          updateStudent(student.id, { total_charged: regFeeAmount + semFee }),
        ]);
      }

      // جلب الرسوم المُنشأة للتخفيضات
      const allChargesBeforePay = await getSemesterCharges(student.id);
      const regChargeB = allChargesBeforePay.find(c => c.charge_type === 'تسجيل');
      const semChargeB = allChargesBeforePay.find(c => c.charge_type === 'فصلي');

      const regFeeBase = parseFloat(settings[SETTINGS_KEYS.REGISTRATION_FEE] ?? '100');
      const semFeeBase = student.diploma_type === 'عالي'
        ? parseFloat(settings[SETTINGS_KEYS.HIGH_DIPLOMA_FEE] ?? '600')
        : parseFloat(settings[SETTINGS_KEYS.MID_DIPLOMA_FEE] ?? '550');

      // ── تطبيق التخفيضات بشكل متوازٍ ────────────────────────────────────────
      const discountTasks: Promise<void>[] = [];

      const finalReg = form.final_reg_amount !== ''
        ? Math.max(0, Math.min(parseFloat(form.final_reg_amount) || 0, regFeeBase))
        : regFeeBase;
      const discountReg = regFeeBase - finalReg;
      if (regChargeB && discountReg > 0) {
        discountTasks.push(applyDiscount(regChargeB.id, student.id, discountReg, form.discount_reg_reason.trim()));
      }

      const sem1Entry = semDiscounts[1];
      if (semChargeB && sem1Entry?.enabled) {
        const finalSem1 = Math.max(0, Math.min(parseFloat(sem1Entry.finalAmount) || 0, semFeeBase));
        const discSem1 = semFeeBase - finalSem1;
        if (discSem1 > 0) {
          discountTasks.push(applyDiscount(semChargeB.id, student.id, discSem1, sem1Entry.reason.trim()));
        }
      }

      if (discountTasks.length > 0) await Promise.all(discountTasks);

      // الدفعة الأولى (بعد تطبيق التخفيضات) — يتم تسجيل الإيصال وزيادة العداد فقط إذا كان هناك دفع حقيقي
      const paymentAmount = parseFloat(form.initial_payment) || 0;
      if (paymentAmount > 0) {
        await processPayment({
          studentId: student.id,
          amount: paymentAmount,
          receiptNumber: form.receipt_number.trim() || undefined,
        });
      }

      // ── إشعار الوثائق + رفع الصورة بشكل متوازٍ ─────────────────────────────
      const updatedStudent = { ...student, photos_required: form.photos_required, photos_received: form.photos_received };
      const postTasks: Promise<unknown>[] = [
        checkAndCreateDocumentNotification(updatedStudent as typeof student),
      ];

      if (photoFile) {
        setPhotoUploading(true);
        postTasks.push(
          (async () => {
            try {
              const { file: finalFile, compressed } = await compressImageIfNeeded(photoFile);
              await uploadStudentAvatar(student.id, finalFile);
              if (compressed) toast.success(`تم رفع الصورة بعد الضغط التلقائي (${(finalFile.size / 1024).toFixed(0)} KB)`);
            } catch {
              toast.error('فشل رفع الصورة — يمكن إضافتها لاحقاً من ملف الطالب');
            } finally {
              setPhotoUploading(false);
            }
          })()
        );
      }

      await Promise.all(postTasks);

      // ── فتح وطباعة استمارة تسجيل الطالب تلقائياً وبشكل احترافي مع الأختام الثلاثة ──
      try {
        const regFeeAmount = parseFloat(settings[SETTINGS_KEYS.REGISTRATION_FEE] ?? '100');
        const semFee = student.diploma_type === 'عالي'
          ? parseFloat(settings[SETTINGS_KEYS.HIGH_DIPLOMA_FEE] ?? '600')
          : parseFloat(settings[SETTINGS_KEYS.MID_DIPLOMA_FEE] ?? '550');
        const paymentAmount = parseFloat(form.initial_payment) || 0;

        const printData: PrintRegistrationData = {
          student: {
            ...student,
            full_name: form.full_name.trim(),
            nationality: form.nationality.trim() || DEFAULT_NATIONALITY,
            national_id: form.national_id.trim(),
            registration_number: form.registration_number.trim() || null,
            phone: form.phone.trim() || null,
            guardian_phone: form.guardian_phone.trim() || null,
            address: form.address.trim() || null,
            diploma_type: form.diploma_type as string,
            specialization: form.specialization,
            current_semester: student.current_semester,
            enrollment_date: student.enrollment_date,
            is_equivalency: form.is_equivalency,
            equivalency_start_semester: form.equivalency_start_semester,
            photos_required: form.photos_required,
            photos_received: form.photos_received,
            has_birth_certificate: form.has_birth_certificate,
            has_registration_certificate: form.has_registration_certificate,
            has_suspended_file: form.has_suspended_file,
            photo_url: student.photo_url,
          },
          financial: {
            registrationFee: regFeeAmount,
            semesterFee: semFee,
            initialPayment: paymentAmount > 0 ? paymentAmount : 0,
            receiptNumber: paymentAmount > 0 ? (form.receipt_number.trim() || null) : null,
          },
          photoPreviewUrl: photoPreview,
        };

        printRegistrationForm(printData);
      } catch (printErr) {
        console.error('فشل في فتح نافذة طباعة الاستمارة تلقائياً:', printErr);
      }

      toast.success(`تم تسجيل ${student.full_name} بنجاح وجارٍ فتح استمارة التسجيل للطباعة`);
      navigate(`/student/${student.id}`);
    } catch (err) {
      console.error(err);
      toast.error('حدث خطأ أثناء التسجيل');
    } finally {
      setSaving(false);
    }
  };

  // معالج اختيار الصورة → يفتح المحرر أولاً
  const handlePhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = '';
    const src = URL.createObjectURL(file);
    setEditorSrc(src);
    setEditorOpen(true);
  };

  // تأكيد المحرر → استخدام الصورة المعدّلة كـ preview
  const handleEditorConfirm = (editedFile: File, preview: string) => {
    if (editorSrc) URL.revokeObjectURL(editorSrc);
    setEditorOpen(false);
    if (photoPreview) URL.revokeObjectURL(photoPreview);
    setPhotoPreview(preview);
    setPhotoFile(editedFile);
  };

  const handleEditorCancel = () => {
    if (editorSrc) URL.revokeObjectURL(editorSrc);
    setEditorOpen(false);
  };

  const clearPhoto = () => {
    if (photoPreview) URL.revokeObjectURL(photoPreview);
    setPhotoPreview(null);
    setPhotoFile(null);
  };

  // حالة نافذة التخفيضات
  const [showDiscountModal, setShowDiscountModal] = useState(false);

  const semFeePreview = form.diploma_type
    ? (form.diploma_type === 'عالي'
      ? parseFloat(settings[SETTINGS_KEYS.HIGH_DIPLOMA_FEE] ?? '600')
      : parseFloat(settings[SETTINGS_KEYS.MID_DIPLOMA_FEE] ?? '550'))
    : null;

  return (
    <>
    <MainLayout>
      <div className="max-w-2xl mx-auto space-y-5 pb-10">

        {/* ── ترويسة الصفحة — Hero Banner ── */}
        <div className="relative rounded-2xl overflow-hidden" style={{ boxShadow: 'var(--shadow-lg)' }}>
          <div className="absolute inset-0 bg-gradient-to-br from-primary via-primary/90 to-blue-700/80" />
          <div className="absolute inset-0 opacity-[0.07]"
            style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '22px 22px' }} />
          <div className="relative px-5 py-5 flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/')}
              className="h-8 w-8 shrink-0 border border-white/30 text-white hover:bg-white/15">
              <ChevronRight className="w-4 h-4" />
            </Button>
            <div className="w-11 h-11 rounded-xl bg-white/15 border border-white/25 flex items-center justify-center shrink-0">
              <UserPlus className="w-6 h-6 text-white" />
            </div>
            <div className="min-w-0 flex-1">
              <h1 className="text-lg font-bold text-white text-balance">تسجيل طالب جديد</h1>
              <p className="text-xs text-white/65 mt-0.5">أدخل بيانات الطالب لإتمام التسجيل في المنظومة</p>
            </div>
          </div>
        </div>

        {/* ١. البيانات الشخصية */}
        <Card className="shadow-card border-t-4 border-t-primary overflow-hidden">
          <CardContent className="px-5 pt-5 pb-6">
            <SectionHeader icon={User} title="البيانات الشخصية" subtitle="المعلومات الأساسية للطالب" color="blue" />

            {/* ── صورة الطالب ── */}
            <div className="mb-5 p-4 rounded-xl bg-muted/30 border border-border">
              <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide block mb-3">صورة الطالب (اختياري)</Label>
              <div className="flex items-center gap-4">
                <div className="relative w-24 h-24 rounded-2xl border-2 border-dashed border-primary/30 bg-primary/5 overflow-hidden shrink-0 flex items-center justify-center">
                  {photoPreview ? (
                    <>
                      <img src={photoPreview} alt="معاينة" className="w-full h-full object-cover" />
                      <button type="button" onClick={clearPhoto}
                        className="absolute top-1 left-1 w-5 h-5 bg-destructive rounded-full flex items-center justify-center hover:bg-destructive/80 transition-colors">
                        <XIcon className="w-3 h-3 text-white" />
                      </button>
                    </>
                  ) : (
                    <User className="w-9 h-9 text-primary/25" />
                  )}
                </div>
                <div className="flex flex-col gap-2 flex-1 min-w-0">
                  <button type="button" onClick={() => cameraInputRef.current?.click()}
                    className="flex items-center gap-2 h-9 px-3 rounded-lg border border-primary/30 bg-primary/5 text-sm font-medium text-primary hover:bg-primary/10 transition-colors w-full">
                    <Camera className="w-4 h-4 shrink-0" />التقاط من الكاميرا
                  </button>
                  <button type="button" onClick={() => fileInputRef.current?.click()}
                    className="flex items-center gap-2 h-9 px-3 rounded-lg border border-border bg-background text-sm font-medium text-foreground hover:bg-muted/50 transition-colors w-full">
                    <FolderOpen className="w-4 h-4 text-muted-foreground shrink-0" />رفع من الملفات
                  </button>
                  <p className="text-[11px] text-muted-foreground truncate">
                    {photoFile ? `${photoFile.name} — ${(photoFile.size / 1024).toFixed(0)} KB` : 'JPEG / PNG / WEBP — حد أقصى 5 MB'}
                  </p>
                </div>
              </div>
              <input ref={cameraInputRef} type="file" accept="image/*" capture="user" className="hidden" onChange={handlePhotoSelect} />
              <input ref={fileInputRef}   type="file" accept="image/*"               className="hidden" onChange={handlePhotoSelect} />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <Field label="الاسم الرباعي" required error={errors.full_name}>
                  <Input value={form.full_name}
                    onChange={e => setForm(p => ({ ...p, full_name: e.target.value }))}
                    placeholder="أدخل الاسم الرباعي كاملاً"
                    className={errors.full_name ? 'border-destructive' : ''} />
                </Field>
              </div>
              <Field label="الجنسية (افتراضياً: ليبي)">
                <Select
                  value={form.nationality}
                  onValueChange={v => setForm(p => ({ ...p, nationality: v }))}
                >
                  <SelectTrigger className="bg-background">
                    <SelectValue placeholder="اختر الجنسية" />
                  </SelectTrigger>
                  <SelectContent className="max-h-60">
                    {ARAB_NATIONALITIES.map(nat => (
                      <SelectItem key={nat.value} value={nat.value}>
                        <div className="flex items-center gap-2">
                          <span className="text-base">{nat.flag}</span>
                          <span className="text-sm font-medium">{nat.label}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>
              <Field label="الرقم الوطني (اختياري)" error={errors.national_id}>
                <Input value={form.national_id}
                  onChange={e => setForm(p => ({ ...p, national_id: e.target.value.replace(/\D/g, '').slice(0, 12) }))}
                  placeholder="000000000000" className={`font-mono text-center tracking-wider ${errors.national_id ? 'border-destructive' : ''}`}
                  maxLength={12} inputMode="numeric" pattern="[0-9]*" />
              </Field>
              <Field label="رقم قيد الطالب (اختياري)">
                <Input value={form.registration_number}
                  onChange={e => setForm(p => ({ ...p, registration_number: e.target.value }))}
                  placeholder="مثال: 2026/0145 (أو اتركه لتعيينه لاحقاً)" className="font-mono text-sm"
                  inputMode="tel" pattern="[0-9/]*" />
              </Field>
              <Field label="العنوان السكني">
                <Input value={form.address}
                  onChange={e => setForm(p => ({ ...p, address: e.target.value }))}
                  placeholder="المدينة / الحي" />
              </Field>
              <Field label="رقم هاتف الطالب">
                <div className="relative">
                  <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground pointer-events-none" />
                  <Input value={form.phone} onChange={e => setForm(p => ({ ...p, phone: e.target.value.replace(/\D/g, '') }))}
                    placeholder="09xxxxxxxx" className="pr-9 font-mono" inputMode="tel" pattern="[0-9]*" />
                </div>
              </Field>
              <Field label="رقم هاتف ولي الأمر">
                <div className="relative">
                  <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground pointer-events-none" />
                  <Input value={form.guardian_phone} onChange={e => setForm(p => ({ ...p, guardian_phone: e.target.value.replace(/\D/g, '') }))}
                    placeholder="09xxxxxxxx" className="pr-9 font-mono" inputMode="tel" pattern="[0-9]*" />
                </div>
              </Field>
            </div>
          </CardContent>
        </Card>

        {/* ٢. البيانات الأكاديمية */}
        <Card className="shadow-card border-t-4 border-t-violet-500 overflow-hidden">
          <CardContent className="px-5 pt-5 pb-6">
            <SectionHeader icon={BookOpen} title="البيانات الأكاديمية" subtitle="نوع الدبلوم والتخصص" color="purple" />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Field label="نوع الدبلوم" required error={errors.diploma_type}>
                <Select value={form.diploma_type}
                  onValueChange={v => setForm(p => ({ ...p, diploma_type: v as DiplomaType, specialization: '', is_equivalency: false }))}>
                  <SelectTrigger className={errors.diploma_type ? 'border-destructive' : ''}>
                    <SelectValue placeholder="اختر نوع الدبلوم" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="عالي">دبلوم عالي</SelectItem>
                    <SelectItem value="متوسط">دبلوم متوسط</SelectItem>
                  </SelectContent>
                </Select>
              </Field>
              <Field label="التخصص" required error={errors.specialization}>
                <Select value={form.specialization} onValueChange={v => setForm(p => ({ ...p, specialization: v }))}
                  disabled={!form.diploma_type}>
                  <SelectTrigger className={errors.specialization ? 'border-destructive' : ''}>
                    <SelectValue placeholder={form.diploma_type ? 'اختر التخصص' : 'حدد نوع الدبلوم أولاً'} />
                  </SelectTrigger>
                  <SelectContent>
                    {filteredSpecs.map(s => <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Field>
            </div>

            {semFeePreview !== null && (
              <div className="mt-4 flex items-center gap-2.5 bg-violet-500/8 border border-violet-300/40 rounded-xl px-4 py-3">
                <div className="w-7 h-7 rounded-lg bg-violet-500/15 flex items-center justify-center shrink-0">
                  <Info className="w-3.5 h-3.5 text-violet-600" />
                </div>
                <p className="text-xs text-violet-700">
                  رسوم الفصل الأول: <strong className="font-bold">{semFeePreview} دينار</strong>
                  <span className="text-violet-500 mr-1">({form.diploma_type === 'عالي' ? 'دبلوم عالي' : 'دبلوم متوسط'})</span>
                </p>
              </div>
            )}

            {form.diploma_type === 'عالي' && (
              <div className="mt-4 border-2 border-dashed border-violet-200 rounded-xl overflow-hidden">
                <div className="flex items-center justify-between px-4 py-3 bg-violet-500/5">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-lg bg-violet-500/15 flex items-center justify-center">
                      <BookOpen className="w-3.5 h-3.5 text-violet-600" />
                    </div>
                    <span className="text-sm font-semibold text-violet-700">نظام المعادلة</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Label htmlFor="is_equivalency" className="text-xs text-muted-foreground cursor-pointer">
                      {form.is_equivalency ? 'مفعّل' : 'غير مفعّل'}
                    </Label>
                    <Checkbox id="is_equivalency" checked={form.is_equivalency}
                      onCheckedChange={v => setForm(p => ({ ...p, is_equivalency: !!v }))} />
                  </div>
                </div>
                {form.is_equivalency && (
                  <div className="px-4 pb-4 pt-3 space-y-3">
                    <Field label="الفصل الذي سيبدأ منه الطالب">
                      <Select value={String(form.equivalency_start_semester)}
                        onValueChange={v => setForm(p => ({ ...p, equivalency_start_semester: parseInt(v) }))}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {[1, 2, 3, 4, 5, 6].map(s => <SelectItem key={s} value={String(s)}>{SEMESTER_LABELS[s]}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </Field>
                    {equivalencyFeeCalc && (
                      <div className="bg-violet-500/8 border border-violet-300/40 rounded-xl p-3 space-y-1.5">
                        <p className="text-xs font-bold text-violet-700">ملخص المعادلة التلقائي</p>
                        <div className="text-xs text-muted-foreground space-y-1">
                          <p>الفصول المعادلة: {Array.from({ length: equivalencyFeeCalc.equivSemesters }, (_, i) => SEMESTER_LABELS[i + 1]).join(' ← ')}</p>
                          <p>{equivalencyFeeCalc.equivSemesters} فصول × {equivalencyFeeCalc.semFee} = {equivalencyFeeCalc.equivSemesters * equivalencyFeeCalc.semFee} دينار</p>
                          <p>+ رسوم تسجيل معادلة: {equivalencyFeeCalc.regFee} دينار</p>
                          <Separator className="my-1" />
                          <p className="font-bold text-violet-700 text-sm">الإجمالي: {equivalencyFeeCalc.total} دينار</p>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* ٣. الأوراق الثبوتية */}
        <Card className="shadow-card border-t-4 border-t-emerald-500 overflow-hidden">
          <CardContent className="px-5 pt-5 pb-6">
            <SectionHeader icon={FileText} title="الأوراق الثبوتية" subtitle="الوثائق المطلوبة للتسجيل" color="green" />

            {/* الصور الشخصية */}
            <div className="mb-4 p-3 rounded-xl bg-muted/30 border border-border">
              <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide block mb-3">الصور الشخصية</Label>
              <div className="flex flex-wrap items-center gap-3">
                <div className="flex items-center gap-1 border border-border rounded-lg px-2 py-1.5 bg-background">
                  <Button type="button" variant="ghost" size="icon" className="h-6 w-6 text-muted-foreground"
                    onClick={() => setForm(p => ({ ...p, photos_required: Math.max(1, p.photos_required - 1) }))}>−</Button>
                  <span className="text-xs text-muted-foreground px-1">مطلوب:</span>
                  <span className="w-6 text-center text-sm font-bold">{form.photos_required}</span>
                  <Button type="button" variant="ghost" size="icon" className="h-6 w-6 text-muted-foreground"
                    onClick={() => setForm(p => ({ ...p, photos_required: p.photos_required + 1 }))}>+</Button>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">المستلم:</span>
                  <Input type="text" inputMode="numeric" pattern="[0-9]*"
                    value={form.photos_received}
                    onChange={e => setForm(p => ({ ...p, photos_received: Math.min(parseInt(e.target.value) || 0, p.photos_required) }))}
                    className="w-14 text-sm text-center h-8 px-2" />
                </div>
                {form.photos_received >= form.photos_required
                  ? <Badge className="bg-emerald-500/15 text-emerald-700 border-emerald-300 text-xs">مكتملة</Badge>
                  : <Badge variant="outline" className="text-destructive border-destructive/40 text-xs">ناقص {form.photos_required - form.photos_received}</Badge>
                }
              </div>
            </div>

            {/* الوثائق */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5">
              {[
                { key: 'has_birth_certificate' as const, label: 'شهادة ميلاد' },
                { key: 'has_registration_certificate' as const, label: 'شهادة التسجيل' },
                { key: 'has_suspended_file' as const, label: 'ملف معلق' },
              ].map(doc => (
                <label key={doc.key}
                  className={`flex items-center gap-2.5 min-h-12 rounded-xl border-2 px-3 cursor-pointer transition-all
                    ${form[doc.key]
                      ? 'border-emerald-400 bg-emerald-50 dark:bg-emerald-950/20 shadow-sm'
                      : 'border-border bg-background hover:border-emerald-200 hover:bg-emerald-50/30'}`}>
                  <Checkbox id={doc.key} checked={form[doc.key]}
                    onCheckedChange={v => setForm(p => ({ ...p, [doc.key]: !!v }))} />
                  <span className="text-sm font-medium select-none">{doc.label}</span>
                  {form[doc.key] && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 mr-auto shrink-0" />}
                </label>
              ))}
            </div>

            {missingDocs.length > 0 && (
              <div className="mt-3 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 rounded-xl p-3 flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 text-amber-600 mt-0.5 shrink-0" />
                <div>
                  <p className="text-xs font-bold text-amber-700 dark:text-amber-400">نواقص الملف (سيُنشأ تنبيه تلقائياً)</p>
                  <p className="text-xs text-amber-600 dark:text-amber-500 mt-0.5">{missingDocs.join(' | ')}</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* ٤. الدفعة المالية الأولية + التخفيض */}
        {(can('registration', 'initial_payment') || can('student_finance', 'view')) && (
          <Card className="shadow-card border-t-4 border-t-amber-500 overflow-hidden">
          <CardContent className="px-5 pt-5 pb-6">
            <SectionHeader icon={Banknote} title="الدفعة المالية الأولية" subtitle="اختياري — يمكن إضافة دفعات لاحقاً" color="amber" />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Field label="المبلغ المدفوع عند القيد (دينار)" subtitle="اتركه 0.00 إذا لم يسدد الطالب عند التسجيل">
                <Input type="text" inputMode="decimal" value={form.initial_payment}
                  onChange={e => {
                    const val = e.target.value;
                    setForm(p => ({ ...p, initial_payment: val }));
                    const amt = parseFloat(val) || 0;
                    if (amt > 0 && !form.receipt_number && form.diploma_type) {
                      peekCurrentReceiptNumber(form.diploma_type as DiplomaType).then(n => setForm(p => ({ ...p, receipt_number: n })));
                    }
                  }}
                  placeholder="0.00 (غير مسدد)" />
              </Field>

              <Field
                label="رقم الإيصال"
                required={(parseFloat(form.initial_payment) || 0) > 0}
                error={errors.receipt_number}
                subtitle={(parseFloat(form.initial_payment) || 0) > 0 ? 'مطلوب لوجود دفعة نقدية' : 'لن يصدر إيصال عند عدم السداد'}
              >
                <div className="relative">
                  <Input value={form.receipt_number}
                    onChange={e => setForm(p => ({ ...p, receipt_number: e.target.value.replace(/\D/g, '') }))}
                    placeholder={(parseFloat(form.initial_payment) || 0) > 0 ? "000001" : "لا يوجد دفع — لن يصدر إيصال"}
                    className={`font-mono ${errors.receipt_number ? 'border-destructive' : ''} ${(parseFloat(form.initial_payment) || 0) <= 0 ? 'bg-muted/40' : ''}`} />
                  {form.diploma_type && (parseFloat(form.initial_payment) || 0) > 0 && (
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[10px] font-bold px-1.5 py-0.5 rounded
                      bg-amber-100 text-amber-700 shrink-0 pointer-events-none">
                      {form.diploma_type === 'عالي' ? 'عالي' : 'متوسط'}
                    </span>
                  )}
                </div>
                {form.diploma_type && (
                  <p className="text-[11px] text-muted-foreground">
                    {(parseFloat(form.initial_payment) || 0) > 0
                      ? <>رقم الإيصال التالي تلقائياً لـ <strong>دبلوم {form.diploma_type}</strong> (يُستهلك فقط عند تأكيد السداد)</>
                      : 'يبقى رقم الإيصال ثابتاً ولا يتغير إلا عند حدوث عملية دفع نقدية فعلية'}
                  </p>
                )}
              </Field>
            </div>

            {form.is_equivalency && equivalencyFeeCalc && (
              <div className="mt-3 flex items-center gap-2.5 bg-amber-500/8 border border-amber-300/40 rounded-xl px-4 py-3">
                <Info className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                <p className="text-xs text-amber-700">
                  إجمالي رسوم المعادلة المستحقة: <strong>{equivalencyFeeCalc.total} دينار</strong>
                </p>
              </div>
            )}

            {form.diploma_type && (() => {
              const regFeeBase = parseFloat(settings[SETTINGS_KEYS.REGISTRATION_FEE] ?? '100');
              const semFeeBase = form.diploma_type === 'عالي'
                ? parseFloat(settings[SETTINGS_KEYS.HIGH_DIPLOMA_FEE] ?? '600')
                : parseFloat(settings[SETTINGS_KEYS.MID_DIPLOMA_FEE] ?? '550');
              const maxSem = form.diploma_type === 'عالي' ? 6 : 4;

              const enteredReg = form.final_reg_amount !== '' ? Math.max(0, Math.min(parseFloat(form.final_reg_amount) || 0, regFeeBase)) : regFeeBase;
              const discReg = regFeeBase - enteredReg;
              const activeSems = ALL_SEMESTERS.filter(s => s <= maxSem && semDiscounts[s]?.enabled);
              const totalSemDiscount = activeSems.reduce((acc, s) => {
                const fa = parseFloat(semDiscounts[s]?.finalAmount ?? String(semFeeBase));
                return acc + Math.max(0, semFeeBase - Math.min(isNaN(fa) ? semFeeBase : fa, semFeeBase));
              }, 0);
              const totalDiscount = discReg + totalSemDiscount;
              const visibleSems = ALL_SEMESTERS.filter(s => s <= maxSem);
              const setSemField = (s: number, field: keyof SemDiscountEntry, value: boolean | string) =>
                setSemDiscounts(prev => ({ ...prev, [s]: { ...prev[s], [field]: value } }));

              const totalOriginal = regFeeBase + visibleSems.length * semFeeBase;
              const totalFinal = totalOriginal - totalDiscount;

              return (
                <>
                  <div className="mt-4 flex items-center gap-3">
                    <button type="button" onClick={() => setShowDiscountModal(true)}
                      className="flex items-center gap-2 h-9 px-4 rounded-xl border-2 border-amber-300 bg-amber-50 text-amber-800 text-sm font-semibold hover:bg-amber-100 transition-colors">
                      <Scissors className="w-4 h-4 shrink-0" />
                      إدارة التخفيضات
                    </button>
                    {totalDiscount > 0 && (
                      <Badge className="bg-amber-100 text-amber-800 border border-amber-300 font-mono">
                        خصم {totalDiscount.toFixed(0)} د.ل
                      </Badge>
                    )}
                  </div>

                  <Dialog open={showDiscountModal} onOpenChange={setShowDiscountModal}>
                    <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto p-0">
                      <div className="relative bg-gradient-to-br from-amber-600 via-amber-500 to-orange-500 px-5 py-4 rounded-t-lg">
                        <div className="absolute inset-0 opacity-10 rounded-t-lg"
                          style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '20px 20px' }} />
                        <DialogHeader className="relative">
                          <DialogTitle className="text-white flex items-center gap-2 text-base">
                            <Scissors className="w-4 h-4" /> إدارة التخفيضات
                          </DialogTitle>
                          <p className="text-[11px] text-white/70 mt-0.5">أدخل المبلغ النهائي — التخفيض = الأصلي − النهائي</p>
                        </DialogHeader>
                      </div>

                      <div className="p-5 space-y-4">
                        <div className={`rounded-xl border-2 p-3 transition-all ${discReg > 0 ? 'border-amber-400/80 bg-amber-50/70' : 'border-border/50 bg-muted/20'}`}>
                          <div className="flex items-center justify-between gap-2 mb-3">
                            <div className="flex items-center gap-2">
                              <div className={`w-5 h-5 rounded flex items-center justify-center shrink-0 ${discReg > 0 ? 'bg-amber-100' : 'bg-muted'}`}>
                                <FileText className={`w-3 h-3 ${discReg > 0 ? 'text-amber-600' : 'text-muted-foreground'}`} />
                              </div>
                              <span className={`text-xs font-semibold ${discReg > 0 ? 'text-amber-800' : 'text-foreground'}`}>رسوم التسجيل</span>
                            </div>
                            {discReg > 0
                              ? <span className="text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-1.5 py-0.5 rounded-md shrink-0">−{discReg.toFixed(0)} د.ل</span>
                              : <span className="text-xs font-mono text-muted-foreground shrink-0">{regFeeBase} د.ل</span>}
                          </div>
                          <div className="grid grid-cols-2 gap-2 mb-2">
                            <div className="space-y-1">
                              <Label className="text-xs font-medium text-muted-foreground">المبلغ النهائي (د.ل)</Label>
                              <Input type="text" inputMode="decimal"
                                value={form.final_reg_amount}
                                onChange={e => setForm(p => ({ ...p, final_reg_amount: e.target.value.replace(/[^\d.]/g, '') }))}
                                placeholder={String(regFeeBase)}
                                className={`h-8 text-sm font-mono font-bold ${discReg > 0 ? 'border-amber-300' : ''}`} />
                            </div>
                            <div className="space-y-1">
                              <Label className="text-xs font-medium text-muted-foreground">السبب</Label>
                              <Input placeholder="اختياري" value={form.discount_reg_reason}
                                onChange={e => setForm(p => ({ ...p, discount_reg_reason: e.target.value }))}
                                className={`h-8 text-xs ${discReg > 0 ? 'border-amber-300' : ''}`} />
                            </div>
                          </div>
                          <div className="flex gap-1.5 flex-wrap">
                            {[0, Math.round(regFeeBase * 0.5), regFeeBase].map(v => (
                              <button key={v} type="button"
                                onClick={() => setForm(p => ({ ...p, final_reg_amount: String(v) }))}
                                className={`h-7 px-2.5 text-xs font-semibold rounded-lg border transition-colors
                                  ${parseFloat(form.final_reg_amount) === v
                                    ? 'bg-amber-500 text-white border-amber-500'
                                    : 'bg-background text-amber-700 border-amber-300/70 hover:bg-amber-500 hover:text-white'}`}>
                                {v === 0 ? 'إعفاء كامل' : v === regFeeBase ? 'بدون تخفيض' : `${v} د.ل`}
                              </button>
                            ))}
                          </div>
                          {discReg > 0 && (
                            <div className="flex items-center gap-2 text-[10px] text-emerald-700 mt-2">
                              <CheckCircle2 className="w-3 h-3 shrink-0" />
                              <span>سيُصدر إيصال تخفيض مستقل بمبلغ <strong className="font-mono">{discReg.toFixed(0)} د.ل</strong></span>
                            </div>
                          )}
                        </div>

                        <div className="flex items-center gap-3">
                          <div className="flex-1 h-px bg-border" />
                          <div className="flex items-center gap-3">
                            <span className="text-xs font-semibold text-muted-foreground">الفصول الدراسية</span>
                            <button type="button"
                              onClick={() => setSemDiscounts(prev => { const n = { ...prev }; visibleSems.forEach(s => { n[s] = { ...n[s], enabled: true }; }); return n; })}
                              className="text-xs font-semibold text-primary hover:underline">تحديد الكل</button>
                            <span className="text-border text-xs">|</span>
                            <button type="button"
                              onClick={() => setSemDiscounts(prev => { const n = { ...prev }; visibleSems.forEach(s => { n[s] = { ...n[s], enabled: false }; }); return n; })}
                              className="text-xs font-semibold text-muted-foreground hover:underline">إلغاء الكل</button>
                          </div>
                          <div className="flex-1 h-px bg-border" />
                        </div>

                        <div className="grid grid-cols-2 gap-2">
                          {visibleSems.map(s => {
                            const entry = semDiscounts[s] ?? { enabled: false, finalAmount: String(semFeeBase), reason: '' };
                            const fa = parseFloat(entry.finalAmount);
                            const disc = isNaN(fa) ? 0 : Math.max(0, semFeeBase - Math.min(fa, semFeeBase));
                            const isFirst = s === 1;
                            return (
                              <div key={s} className={`rounded-xl border-2 p-3 transition-all ${entry.enabled ? 'border-amber-400/80 bg-amber-50/70 shadow-sm' : 'border-border/50 bg-muted/20'}`}>
                                <div className="flex items-center gap-2 mb-2">
                                  <button type="button" onClick={() => setSemField(s, 'enabled', !entry.enabled)}
                                    className={`w-5 h-5 rounded border-2 flex items-center justify-center shrink-0 transition-colors ${entry.enabled ? 'bg-amber-500 border-amber-500' : 'border-border bg-background'}`}>
                                    {entry.enabled && <CheckCircle2 className="w-3 h-3 text-white" />}
                                  </button>
                                  <span className={`flex-1 text-xs font-semibold truncate min-w-0 ${entry.enabled ? 'text-amber-800' : 'text-foreground'}`}>
                                    {SEMESTER_LABELS[s] ?? `الفصل ${s}`}
                                  </span>
                                  {disc > 0 && entry.enabled
                                    ? <span className="text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-1.5 py-0.5 rounded-md shrink-0">−{disc.toFixed(0)}</span>
                                    : <span className="text-xs font-mono text-muted-foreground shrink-0">{semFeeBase}</span>}
                                </div>
                                {entry.enabled && (
                                  <div className="space-y-2 pt-2 border-t border-amber-200/70">
                                    <div className="space-y-1">
                                      <Label className="text-xs font-medium text-muted-foreground">المبلغ النهائي (د.ل)</Label>
                                      <Input type="text" inputMode="decimal"
                                        value={entry.finalAmount}
                                        onChange={e => setSemField(s, 'finalAmount', e.target.value.replace(/[^\d.]/g, ''))}
                                        placeholder={String(semFeeBase)}
                                        className="h-8 text-sm font-mono font-bold border-amber-300" />
                                    </div>
                                    <div className="space-y-1">
                                      <Label className="text-xs font-medium text-muted-foreground">السبب</Label>
                                      <Input value={entry.reason}
                                        onChange={e => setSemField(s, 'reason', e.target.value)}
                                        placeholder="اختياري" className="h-8 text-xs border-amber-300" />
                                    </div>
                                    <div className="flex gap-1.5">
                                      <button type="button" onClick={() => setSemField(s, 'finalAmount', '0')}
                                        className="h-7 px-2.5 text-xs font-semibold rounded-lg border border-amber-300/70 bg-background text-amber-700 hover:bg-amber-500 hover:text-white transition-colors">
                                        إعفاء كامل
                                      </button>
                                      <button type="button" onClick={() => setSemField(s, 'finalAmount', String(semFeeBase))}
                                        className="h-7 px-2.5 text-xs font-semibold rounded-lg border border-amber-300/70 bg-background text-amber-700 hover:bg-amber-500 hover:text-white transition-colors">
                                        {semFeeBase} د.ل
                                      </button>
                                    </div>
                                    <p className={`text-[10px] flex items-center gap-1 ${isFirst ? 'text-emerald-700' : 'text-blue-600'}`}>
                                      {isFirst
                                        ? <><CheckCircle2 className="w-3 h-3 shrink-0" /> سيصدر إيصال تخفيض مستقل</>
                                        : <><Clock className="w-3 h-3 shrink-0" /> يُطبَّق تلقائياً عند الترحيل</>}
                                    </p>
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>

                        <div className="rounded-2xl border border-amber-200 bg-amber-50/60 p-4 space-y-2.5">
                          <p className="text-sm font-bold text-amber-800 flex items-center gap-2">
                            <Banknote className="w-4 h-4" /> الملخص المالي الشامل
                          </p>
                          <div className="space-y-1.5 text-xs">
                            <div className="flex items-center justify-between">
                              <span className="text-muted-foreground">رسوم التسجيل (أصلي)</span>
                              <span className="font-mono font-semibold">{regFeeBase} د.ل</span>
                            </div>
                            {visibleSems.map(s => {
                              const entry = semDiscounts[s];
                              const fa = entry?.enabled ? parseFloat(entry.finalAmount ?? String(semFeeBase)) : semFeeBase;
                              const disc = entry?.enabled ? Math.max(0, semFeeBase - Math.min(isNaN(fa) ? semFeeBase : fa, semFeeBase)) : 0;
                              return (
                                <div key={s} className="flex items-center justify-between">
                                  <span className="text-muted-foreground">{SEMESTER_LABELS[s] ?? `الفصل ${s}`}</span>
                                  <span className="font-mono font-semibold flex items-center gap-1">
                                    {semFeeBase} د.ل
                                    {disc > 0 && <span className="text-emerald-700 text-[10px]">(−{disc.toFixed(0)})</span>}
                                  </span>
                                </div>
                              );
                            })}
                          </div>
                          <Separator className="my-1 bg-amber-200/60" />
                          <div className="space-y-1 text-xs">
                            <div className="flex items-center justify-between">
                              <span className="text-muted-foreground">الإجمالي قبل التخفيض</span>
                              <span className="font-mono font-semibold">{totalOriginal.toFixed(0)} د.ل</span>
                            </div>
                            {totalDiscount > 0 && (
                              <div className="flex items-center justify-between">
                                <span className="text-emerald-700 font-medium">إجمالي الإعفاء</span>
                                <span className="font-mono font-bold text-emerald-700">−{totalDiscount.toFixed(0)} د.ل</span>
                              </div>
                            )}
                          </div>
                          <div className="flex items-center justify-between pt-2 border-t border-amber-200/60">
                            <span className="text-sm font-bold text-amber-800">الإجمالي بعد التخفيض</span>
                            <span className="font-mono font-bold text-lg text-amber-700">{totalFinal.toFixed(0)} د.ل</span>
                          </div>
                        </div>
                      </div>

                      <DialogFooter className="px-5 pb-5 pt-0">
                        <Button onClick={() => setShowDiscountModal(false)} className="w-full h-10 text-sm font-semibold">
                          <CheckCircle2 className="w-4 h-4 ml-2" /> تطبيق وإغلاق
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </>
              );
            })()}
          </CardContent>
        </Card>
        )}

        {/* ── أزرار الحفظ ── */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3">
          <Button onClick={handleSubmit} disabled={saving}
            className="flex-1 h-12 text-sm font-bold rounded-xl"
            style={{ background: 'var(--gradient-primary)', boxShadow: 'var(--shadow-hover)' }}>
            {saving ? (
              <span className="flex items-center gap-2">
                <span className="w-4 h-4 border-2 border-primary-foreground/40 border-t-primary-foreground rounded-full animate-spin" />
                جاري الحفظ...
              </span>
            ) : (
              <span className="flex items-center gap-2">
                <UserPlus className="w-4 h-4" /> حفظ وتسجيل الطالب
              </span>
            )}
          </Button>
          <Button variant="outline" onClick={() => navigate('/')} disabled={saving} className="h-12 md:w-28 rounded-xl">
            إلغاء
          </Button>
        </div>
      </div>
    </MainLayout>

    {/* محرر الصور — يظهر عند اختيار صورة الطالب قبل التسجيل */}
    <ImageEditorModal
      open={editorOpen}
      imageSrc={editorSrc}
      aspectRatio={1}
      title="تعديل صورة الطالب"
      onConfirm={handleEditorConfirm}
      onCancel={handleEditorCancel}
    />
    </>
  );

}
