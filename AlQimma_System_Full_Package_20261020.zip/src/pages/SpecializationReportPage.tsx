// توزيع الطلاب حسب التخصص وطباعة التقارير - منظومة معهد القمة
import { useEffect, useState, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  BarChart3, Printer, ChevronRight, Users,
  GraduationCap, FileText, Eye, AlertTriangle,
  TrendingUp, BookOpen, Award, Search, X,
} from 'lucide-react';
import { toast } from 'sonner';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { getSpecializationStats, getStudents } from '@/lib/api';
import { printTable } from '@/lib/printUtils';
import type { Student } from '@/types/index';
import { SEMESTER_LABELS } from '@/types/index';
import { StudentAvatar } from '@/components/ui/StudentAvatar';

// استعلام الحقول الضرورية فقط لتفادي جلب أعمدة ثقيلة لآلاف الطلاب
const SPEC_STUDENT_FIELDS = 'id,full_name,national_id,current_semester,status,is_exam_only,total_charged,total_paid,photo_url';

interface SpecStat {
  specialization: string;
  diploma_type: string;
  count: number;
}

/* ألوان دوارة لبطاقات التخصصات */
const SPEC_COLORS = [
  { gradient: 'from-primary/80 to-primary', iconBg: 'bg-white/20' },
  { gradient: 'from-chart-2/75 to-chart-2', iconBg: 'bg-white/20' },
  { gradient: 'from-chart-4/75 to-chart-4', iconBg: 'bg-white/20' },
  { gradient: 'from-chart-3/75 to-chart-3', iconBg: 'bg-white/20' },
  { gradient: 'from-chart-1/75 to-chart-1', iconBg: 'bg-white/20' },
  { gradient: 'from-destructive/70 to-destructive', iconBg: 'bg-white/20' },
];

export default function SpecializationReportPage() {
  const navigate = useNavigate();
  const [stats, setStats] = useState<SpecStat[]>([]);
  const [selectedSpec, setSelectedSpec] = useState<string | null>(null);
  const [selectedDiploma, setSelectedDiploma] = useState<string>('');
  const [specStudents, setSpecStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingStudents, setLoadingStudents] = useState(false);
  const [studentSearch, setStudentSearch] = useState('');
  const [visibleCount, setVisibleCount] = useState(40);

  const fetchStats = useCallback(async () => {
    setLoading(true);
    try {
      const data = await getSpecializationStats();
      setStats(data);
    } catch {
      toast.error('خطأ في تحميل الإحصائيات');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchStats(); }, [fetchStats]);

  const handleSpecClick = useCallback(async (spec: string, diploma: string) => {
    setSelectedSpec(spec);
    setSelectedDiploma(diploma);
    setStudentSearch('');
    setVisibleCount(40);
    setLoadingStudents(true);
    try {
      const { data } = await getStudents({
        specialization: spec,
        diplomaType: diploma as 'عالي' | 'متوسط',
        limit: 12000,
        fields: SPEC_STUDENT_FIELDS,
      });
      setSpecStudents(data);
    } catch {
      toast.error('خطأ في تحميل الطلاب');
    } finally {
      setLoadingStudents(false);
    }
  }, []);

  // ── فلترة سريعة فورية في الذاكرة لطلاب التخصص
  const filteredSpecStudents = useMemo(() => {
    if (!studentSearch.trim()) return specStudents;
    const q = studentSearch.trim().toLowerCase();
    return specStudents.filter(s =>
      s.full_name?.toLowerCase().includes(q) ||
      s.national_id?.includes(q)
    );
  }, [specStudents, studentSearch]);

  // تقطيع عرض الجدول (DOM Slicing) لمنع تجمد المتصفح عند وجود +1000 طالب
  const displayedSpecStudents = useMemo(() => {
    return filteredSpecStudents.slice(0, visibleCount);
  }, [filteredSpecStudents, visibleCount]);

  const highStats = stats.filter(s => s.diploma_type === 'عالي');
  const midStats  = stats.filter(s => s.diploma_type === 'متوسط');
  const totalHigh = highStats.reduce((sum, s) => sum + s.count, 0);
  const totalMid  = midStats.reduce((sum, s) => sum + s.count, 0);
  const totalAll  = totalHigh + totalMid;

  // طباعة التقرير الإجمالي
  const handlePrintAll = () => {
    const rows = [...highStats, ...midStats].map((s, i) => [
      i + 1, s.specialization, s.diploma_type === 'عالي' ? 'دبلوم عالي' : 'دبلوم متوسط', s.count,
    ]);
    const totalRow = ['', 'الإجمالي الكلي', `${highStats.length + midStats.length} تخصص`, totalAll];
    printTable({
      title: 'تقرير التخصصات وتوزيع الطلاب',
      subtitle: `دبلوم عالي: ${totalHigh} طالب | دبلوم متوسط: ${totalMid} طالب | الإجمالي: ${totalAll} طالب`,
      columns: ['م', 'التخصص', 'نوع الدبلوم', 'عدد الطلاب'],
      rows,
      totalRow,
      landscape: false,
      sig1: 'توقيع المسؤول',
      sig2: 'اعتماد المدير',
    });
  };

  // طباعة قائمة تخصص محدد
  const handlePrintSpec = () => {
    if (!selectedSpec || specStudents.length === 0) return;
    const rows = specStudents.map((s, i) => [
      i + 1, s.full_name, s.national_id,
      SEMESTER_LABELS[s.current_semester] ?? `الفصل ${s.current_semester}`,
      s.status,
      s.is_exam_only ? 'طالب 100' : 'نظامي',
      (s.total_charged - s.total_paid) > 0
        ? `${(s.total_charged - s.total_paid).toLocaleString('ar-LY', { maximumFractionDigits: 0 })} د.ل`
        : '✓ مسدد',
    ]);
    const debtCount = specStudents.filter(s => s.total_charged - s.total_paid > 0).length;
    printTable({
      title: `كشف طلاب تخصص ${selectedSpec}`,
      subtitle: `${selectedDiploma === 'عالي' ? 'دبلوم عالي' : 'دبلوم متوسط'} — ${specStudents.length} طالب — ${debtCount} لديهم مديونيات`,
      columns: ['م', 'الاسم الكامل', 'الرقم الوطني', 'الفصل الدراسي', 'الحالة', 'نوع الطالب', 'المديونية'],
      rows,
      totalRow: ['', `${specStudents.length} طالب`, '', '', '', '', `${debtCount} مديون`],
      landscape: false,
      sig1: 'توقيع المسؤول',
      sig2: 'اعتماد المدير',
    });
  };

  return (
    <MainLayout>
      <div className="space-y-5">

        {/* ── ترويسة الصفحة ── */}
        <div className="relative rounded-2xl overflow-hidden no-print" style={{ boxShadow: 'var(--shadow-lg)' }}>
          <div className="absolute inset-0 bg-gradient-to-br from-chart-1/90 via-primary/95 to-primary/80" />
          <div className="absolute inset-0 opacity-[0.06]"
            style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '24px 24px' }} />
          <div className="absolute -top-10 -left-10 w-36 h-36 bg-white/5 rounded-full blur-2xl pointer-events-none" />

          <div className="relative px-5 py-5 md:px-7 md:py-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <button onClick={() => navigate('/')}
                className="w-9 h-9 rounded-xl bg-white/15 border border-white/20 flex items-center justify-center shrink-0 hover:bg-white/25 transition-colors">
                <ChevronRight className="w-4 h-4 text-white" />
              </button>
              <div className="w-11 h-11 rounded-xl bg-white/15 border border-white/20 flex items-center justify-center shrink-0">
                <BarChart3 className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-lg md:text-xl font-bold text-white text-balance leading-snug">
                  التخصصات والتقارير
                </h1>
                <p className="text-white/60 text-xs mt-0.5">توزيع الطلاب حسب التخصص — اضغط على تخصص لعرض قائمته</p>
              </div>
            </div>
            <Button size="sm" onClick={handlePrintAll}
              className="bg-white text-foreground hover:bg-white/90 gap-1.5 font-semibold shadow-md h-9 shrink-0">
              <Printer className="w-4 h-4" />
              طباعة التقرير
            </Button>
          </div>
        </div>

        {/* ── بطاقات الإجماليات ── */}
        <div className="grid grid-cols-3 gap-3 md:gap-4">
          {[
            { label: 'إجمالي الطلاب', value: totalAll, icon: Users, gradient: 'from-primary/85 to-primary', sub: 'جميع الأقسام' },
            { label: 'دبلوم عالي', value: totalHigh, icon: Award, gradient: 'from-chart-2/80 to-chart-2', sub: `${highStats.length} تخصص` },
            { label: 'دبلوم متوسط', value: totalMid, icon: BookOpen, gradient: 'from-chart-4/80 to-chart-4', sub: `${midStats.length} تخصص` },
          ].map(card => {
            const Icon = card.icon;
            return (
              <div key={card.label} className={`relative rounded-xl overflow-hidden bg-gradient-to-br ${card.gradient} p-4 shadow-md`}>
                <div className="absolute -bottom-4 -left-4 w-16 h-16 bg-white/5 rounded-full pointer-events-none" />
                <div className="relative flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-white/70 text-xs font-medium leading-tight mb-1">{card.label}</p>
                    <p className="text-white text-2xl font-bold leading-none">{loading ? '—' : card.value}</p>
                    <p className="text-white/50 text-xs mt-1.5">{card.sub}</p>
                  </div>
                  <div className="w-9 h-9 rounded-lg bg-white/15 border border-white/15 flex items-center justify-center shrink-0">
                    <Icon className="w-4 h-4 text-white" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* ── توزيع التخصصات ── */}
        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-xl bg-muted" />)}
          </div>
        ) : (
          <Tabs defaultValue="عالي">
            <div className="flex items-center justify-between gap-3 mb-4 no-print">
              <TabsList className="bg-muted/60 border border-border/50 p-1 rounded-xl h-auto gap-1">
                <TabsTrigger value="عالي"
                  className="rounded-lg px-4 py-2 text-sm font-semibold data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-sm transition-all">
                  الدبلوم العالي
                  <span className="mr-1.5 bg-white/20 text-current text-xs px-1.5 py-0.5 rounded-md font-bold">{totalHigh}</span>
                </TabsTrigger>
                <TabsTrigger value="متوسط"
                  className="rounded-lg px-4 py-2 text-sm font-semibold data-[state=active]:bg-chart-4 data-[state=active]:text-white data-[state=active]:shadow-sm transition-all">
                  الدبلوم المتوسط
                  <span className="mr-1.5 bg-white/20 text-current text-xs px-1.5 py-0.5 rounded-md font-bold">{totalMid}</span>
                </TabsTrigger>
              </TabsList>
            </div>

            {['عالي', 'متوسط'].map(diploma => (
              <TabsContent key={diploma} value={diploma}>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {(diploma === 'عالي' ? highStats : midStats).map((stat, idx) => {
                    const color = SPEC_COLORS[idx % SPEC_COLORS.length];
                    const isSelected = selectedSpec === stat.specialization && selectedDiploma === diploma;
                    return (
                      <button
                        key={stat.specialization}
                        onClick={() => handleSpecClick(stat.specialization, diploma)}
                        className={`relative text-right rounded-xl overflow-hidden transition-all hover:shadow-lg ${
                          isSelected ? 'ring-2 ring-primary ring-offset-2 shadow-lg' : 'shadow-sm hover:shadow-md'
                        }`}
                      >
                        <div className={`absolute inset-0 bg-gradient-to-br ${color.gradient}`} />
                        <div className="absolute inset-0 opacity-[0.07]"
                          style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '16px 16px' }} />
                        {isSelected && (
                          <div className="absolute top-2 left-2 w-5 h-5 rounded-full bg-white flex items-center justify-center">
                            <span className="text-primary text-xs font-black">✓</span>
                          </div>
                        )}
                        <div className="relative p-4">
                          <div className="flex items-start justify-between gap-2 mb-3">
                            <div className={`w-9 h-9 rounded-lg ${color.iconBg} border border-white/15 flex items-center justify-center shrink-0`}>
                              <GraduationCap className="w-4 h-4 text-white" />
                            </div>
                            <span className="text-white text-2xl font-black leading-none">{stat.count}</span>
                          </div>
                          <p className="text-white font-bold text-sm leading-snug text-balance">{stat.specialization}</p>
                          <p className="text-white/60 text-[11px] mt-1 flex items-center gap-1">
                            <FileText className="w-3 h-3" />
                            {diploma === 'عالي' ? 'دبلوم عالي' : 'دبلوم متوسط'} · اضغط للعرض
                          </p>
                        </div>
                      </button>
                    );
                  })}
                  {(diploma === 'عالي' ? highStats : midStats).length === 0 && (
                    <div className="col-span-full text-center py-12 text-muted-foreground">
                      <div className="w-14 h-14 rounded-full bg-muted mx-auto mb-3 flex items-center justify-center">
                        <Users className="w-7 h-7 opacity-30" />
                      </div>
                      <p className="text-sm font-medium">لا يوجد طلاب مسجلون في هذا القسم</p>
                    </div>
                  )}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        )}

        {/* ── قائمة طلاب التخصص المحدد ── */}
        {selectedSpec && (
          <Card className="shadow-sm border-border/60 overflow-hidden">
            {/* رأس القائمة */}
            <div className="px-5 py-4 border-b border-border/60 bg-gradient-to-l from-primary/5 to-transparent">
              <div className="flex items-center justify-between flex-wrap gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
                    <Users className="w-4 h-4 text-primary" />
                  </div>
                  <div>
                    <p className="text-base font-bold text-foreground">
                      تخصص {selectedSpec}
                    </p>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {selectedDiploma === 'عالي' ? 'دبلوم عالي' : 'دبلوم متوسط'} ·{' '}
                      <span className="font-semibold text-primary">{specStudents.length} طالب</span>
                      {filteredSpecStudents.length !== specStudents.length && (
                        <span className="text-muted-foreground mr-1"> (مطابق للبحث: {filteredSpecStudents.length})</span>
                      )}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  {/* بحث سريع داخل طلاب التخصص */}
                  <div className="relative w-64">
                    <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground pointer-events-none" />
                    <Input
                      placeholder="بحث بالاسم أو الرقم الوطني..."
                      value={studentSearch}
                      onChange={e => { setStudentSearch(e.target.value); setVisibleCount(40); }}
                      className="pr-9 h-9 text-xs rounded-xl bg-background border-border/70"
                    />
                    {studentSearch && (
                      <button
                        onClick={() => setStudentSearch('')}
                        className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-muted flex items-center justify-center hover:bg-muted-foreground/20"
                      >
                        <X className="w-2.5 h-2.5 text-muted-foreground" />
                      </button>
                    )}
                  </div>
                  <Button size="sm" onClick={handlePrintSpec}
                    className="gap-1.5 h-9 bg-blue-600 text-white hover:bg-blue-700 shadow-sm font-semibold">
                    <Printer className="w-3.5 h-3.5" /> طباعة هذه القائمة
                  </Button>
                </div>
              </div>
            </div>

            <CardContent className="px-0 pb-4">
              {loadingStudents ? (
                <div className="space-y-2 px-5 pt-4">
                  {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-12 bg-muted rounded-lg" />)}
                </div>
              ) : filteredSpecStudents.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <div className="w-14 h-14 rounded-full bg-muted mx-auto mb-3 flex items-center justify-center">
                    <Users className="w-7 h-7 opacity-30" />
                  </div>
                  <p className="text-sm font-medium">لا يوجد طلاب مطابقون في هذا التخصص</p>
                </div>
              ) : (
                <div className="w-full max-w-full overflow-x-auto bg-card">
                  <table className="w-full min-w-max">
                    <thead>
                      <tr className="bg-gradient-to-l from-muted/60 to-muted/30 border-b-2 border-border/60">
                        <th className="text-sm font-bold text-muted-foreground px-5 py-3.5 text-right whitespace-nowrap">#</th>
                        <th className="text-sm font-bold text-muted-foreground px-5 py-3.5 text-right whitespace-nowrap">الاسم الكامل</th>
                        <th className="text-sm font-bold text-muted-foreground px-5 py-3.5 text-right whitespace-nowrap">الرقم الوطني</th>
                        <th className="text-sm font-bold text-muted-foreground px-5 py-3.5 text-right whitespace-nowrap">الفصل</th>
                        <th className="text-sm font-bold text-muted-foreground px-5 py-3.5 text-right whitespace-nowrap">الحالة</th>
                        <th className="text-sm font-bold text-muted-foreground px-5 py-3.5 text-right whitespace-nowrap">نوع الطالب</th>
                        <th className="text-sm font-bold text-muted-foreground px-5 py-3.5 text-right whitespace-nowrap">المديونية</th>
                        <th className="text-sm font-bold text-muted-foreground px-5 py-3.5 text-right whitespace-nowrap no-print">إجراءات</th>
                      </tr>
                    </thead>
                    <tbody>
                      {displayedSpecStudents.map((s, idx) => {
                        const debt = s.total_charged - s.total_paid;
                        return (
                          <tr key={s.id}
                            className={`border-b border-border/40 hover:bg-primary/5 transition-colors ${idx % 2 === 0 ? 'bg-card' : 'bg-muted/15'}`}>
                            <td className="px-5 py-4 whitespace-nowrap">
                              <span className="text-sm font-mono text-muted-foreground/60">{idx + 1}</span>
                            </td>
                            <td className="px-5 py-4 whitespace-nowrap">
                              <div className="flex items-center gap-2.5">
                                <StudentAvatar
                                  photoUrl={s.photo_url}
                                  name={s.full_name}
                                  size="xs"
                                  variant="circle"
                                />
                                <span className="text-sm font-bold text-foreground">{s.full_name}</span>
                              </div>
                            </td>
                            <td className="px-5 py-4 whitespace-nowrap">
                              <span className="text-sm font-mono font-semibold text-muted-foreground bg-muted px-2 py-0.5 rounded-md">
                                {s.national_id}
                              </span>
                            </td>
                            <td className="px-5 py-4 whitespace-nowrap">
                              <span className="text-sm font-semibold text-primary bg-primary/8 px-2.5 py-1 rounded-lg border border-primary/15">
                                {SEMESTER_LABELS[s.current_semester] ?? `الفصل ${s.current_semester}`}
                              </span>
                            </td>
                            <td className="px-5 py-4 whitespace-nowrap">
                              <span className={`inline-flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full font-semibold border ${
                                s.status === 'نشط'
                                  ? 'bg-chart-2/10 text-chart-2 border-chart-2/25'
                                  : 'bg-warning/10 text-warning border-warning/25'
                              }`}>
                                <span className={`w-2 h-2 rounded-full ${s.status === 'نشط' ? 'bg-chart-2' : 'bg-warning'}`} />
                                {s.status}
                              </span>
                            </td>
                            <td className="px-5 py-4 whitespace-nowrap">
                              <span className={`inline-flex items-center gap-1 text-xs font-bold px-2.5 py-1 rounded-full border ${
                                s.is_exam_only
                                  ? 'bg-purple-100 text-purple-700 border-purple-300'
                                  : 'bg-sky-100 text-sky-700 border-sky-300'
                              }`}>
                                {s.is_exam_only ? 'طالب 100' : 'نظامي'}
                              </span>
                            </td>
                            <td className="px-5 py-4 whitespace-nowrap">
                              {debt > 0 ? (
                                <span className="inline-flex items-center gap-1 text-xs font-bold text-destructive bg-destructive/8 px-2.5 py-1 rounded-full border border-destructive/20">
                                  <AlertTriangle className="w-3 h-3" />
                                  {debt.toFixed(0)} د.ل
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 text-xs font-bold text-chart-2 bg-chart-2/8 px-2.5 py-1 rounded-full border border-chart-2/20">
                                  ✓ مسدد
                                </span>
                              )}
                            </td>
                            <td className="px-5 py-4 whitespace-nowrap no-print">
                              <button
                                onClick={() => navigate(`/student/${s.id}`)}
                                className="inline-flex items-center gap-1.5 h-8 px-3 rounded-lg text-xs font-semibold bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground transition-all border border-primary/20 hover:border-primary">
                                <Eye className="w-3.5 h-3.5" />
                                عرض الملف
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                    <tfoot>
                      <tr className="bg-muted/40 border-t-2 border-border/60">
                        <td colSpan={2} className="px-5 py-3 text-sm font-bold">
                          الإجمالي: {specStudents.length} طالب
                          {filteredSpecStudents.length !== specStudents.length && ` (المطابق: ${filteredSpecStudents.length})`}
                        </td>
                        <td colSpan={5} className="px-5 py-3 text-sm font-bold text-destructive">
                          {specStudents.filter(s => (s.total_charged - s.total_paid) > 0).length > 0
                            ? `${specStudents.filter(s => (s.total_charged - s.total_paid) > 0).length} طالب لديهم مديونيات`
                            : 'جميع الطلاب مسددون'}
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                  {filteredSpecStudents.length > displayedSpecStudents.length && (
                    <div className="p-3 text-center bg-muted/20 border-t border-border/40">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setVisibleCount(prev => prev + 40)}
                        className="gap-2 text-xs font-bold text-primary border-primary/30 hover:bg-primary/5"
                      >
                        عرض المزيد (+40 طالب) — معروض {displayedSpecStudents.length} من أصل {filteredSpecStudents.length}
                      </Button>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        )}

      </div>
    </MainLayout>
  );
}
