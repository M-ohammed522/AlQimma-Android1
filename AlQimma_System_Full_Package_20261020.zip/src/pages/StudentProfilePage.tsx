// الملف الشامل للطالب - منظومة معهد القمة
import { useEffect, useState, useCallback, useRef } from 'react';
import { motion } from 'motion/react';
import ImageEditorModal from '@/components/ui/ImageEditorModal';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import {
  ChevronRight, Edit, PauseCircle, PlayCircle, Trash2, Printer,
  DollarSign, FileText, AlertTriangle, CheckCircle, User,
  BookOpen, Save, X, Camera, Upload, Eye, Paperclip,
  Phone, MapPin, CreditCard, GraduationCap, Calendar,
  FileUp, Trash, PhoneCall, Receipt as ReceiptIcon, FolderOpen,
  ClipboardList, Hash, RefreshCw, UserCog, Edit3, FileCheck,
  ShieldCheck, ShieldAlert, Sparkles, Plus, Minus, Check,
  CheckCheck, Users, School, Layers,
} from 'lucide-react';
import { toast } from 'sonner';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import {
  getStudentById, getReceipts, getSemesterCharges,
  updateStudent, deleteStudent, suspendStudent, activateStudent,
  getSettings, getNextReceiptNumber, peekCurrentReceiptNumber,
  processPayment, uploadStudentAvatar, getStudentFiles, uploadStudentFile,
  deleteStudentFile, getSpecializations, compareReceipts, sortReceiptsOldestFirst,
  getNextLetterNumber, updateStudentRegistrationNumber,
} from '@/lib/api';
import { printRegistrationForm } from '@/lib/printRegistrationForm';
import type { Student, Receipt, SemesterCharge, StudentFile, Specialization, DiplomaType } from '@/types/index';
import { SYSTEM_PASSWORD, SEMESTER_LABELS, SETTINGS_KEYS, ARAB_NATIONALITIES, DEFAULT_NATIONALITY } from '@/types/index';
import { compressImageIfNeeded } from '@/lib/imageUtils';
import { SmartDateInput } from '@/components/ui/SmartDateInput';
import { printFinancialRecord } from '@/lib/printReceipt';
import { useDeviceRole } from '@/contexts/DeviceRoleContext';

const STATUS_CONFIG: Record<string, { label: string; className: string }> = {
  'نشط':       { label: 'نشط',       className: 'bg-emerald-500/15 text-emerald-600 border-emerald-500/30' },
  'موقوف قيد': { label: 'موقوف قيد', className: 'bg-amber-500/15 text-amber-600 border-amber-500/30' },
  'متخرج':     { label: 'متخرج',     className: 'bg-primary/15 text-primary border-primary/30' },
};

// ── دوال الطباعة (خارج المكوّن لتجنّب تحليل JSX الخاطئ للـ Template Literals) ──

function buildPrintStyles(): string {
  return [
    "@import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap');",
    '* { box-sizing: border-box; margin: 0; padding: 0; }',
    "body { font-family: 'Cairo', sans-serif; padding: 24px; color: #1a1a1a; direction: rtl; }",
    '.print-header { text-align: center; border-bottom: 2px solid #e5e7eb; padding-bottom: 12px; margin-bottom: 18px; }',
    '.print-header h1 { font-size: 16px; font-weight: 700; }',
    '.print-header p { font-size: 12px; color: #6b7280; margin-top: 4px; }',
    'table { width: 100%; border-collapse: collapse; font-size: 13px; }',
    'th { background: #f3f4f6; text-align: right; padding: 8px 12px; font-weight: 600; border: 1px solid #e5e7eb; }',
    'td { padding: 8px 12px; border: 1px solid #e5e7eb; }',
    'tr:nth-child(even) td { background: #fafafa; }',
    '.badge-ok { background:#dcfce7; color:#166534; padding:2px 8px; border-radius:999px; font-size:11px; }',
    '.badge-err { background:#fee2e2; color:#991b1b; padding:2px 8px; border-radius:999px; font-size:11px; }',
    '.summary { display:flex; gap:16px; margin-bottom:16px; }',
    '.summary-box { flex:1; border:1px solid #e5e7eb; border-radius:8px; padding:10px; text-align:center; }',
    '.summary-box .label { font-size:11px; color:#6b7280; margin-bottom:4px; }',
    '.summary-box .value { font-size:15px; font-weight:700; }',
    '.footer-sigs { display:grid; grid-template-columns:1fr 1fr; gap:40px; margin-top:40px; }',
    '.footer-sigs div { text-align:center; border-top:1px solid #d1d5db; padding-top:8px; font-size:12px; color:#6b7280; }',
    'img { max-width:100%; border-radius:8px; }',
    '.info-grid { display:grid; grid-template-columns:1fr 1fr; gap:12px 32px; margin-bottom:12px; }',
    '.info-row .lbl { font-size:11px; color:#6b7280; }',
    '.info-row .val { font-size:13px; font-weight:600; }',
  ].join('\n');
}

function printSection(elementId: string, title: string): void {
  const el = document.getElementById(elementId);
  if (!el) return;
  const win = window.open('', '_blank', 'width=900,height=700');
  if (!win) return;
  const date = new Date().toLocaleDateString('ar-LY');
  const html = [
    '<!DOCTYPE html>',
    '<html dir="rtl" lang="ar">',
    '<head>',
    '<meta charset="UTF-8"/>',
    '<title>' + title + '</title>',
    '<style>' + buildPrintStyles() + '</style>',
    '</head>',
    '<body>',
    '<div class="print-header">',
    '<h1>معهد القمة للعلوم الطبية والإدارية</h1>',
    '<p>' + title + ' — ' + date + '</p>',
    '</div>',
    el.innerHTML,
    '<div class="footer-sigs">',
    '<div>ختم المعهد</div>',
    '<div>توقيع الإدارة المسؤولة</div>',
    '</div>',
    '</body>',
    '</html>',
  ].join('');
  win.document.write(html);
  win.document.close();
  win.focus();
  setTimeout(() => { win.print(); win.close(); }, 600);
}

function printSingleReceipt(
  receiptNumber: string,
  paidAt: string,
  amount: number,
  paymentType: string,
  semesterTarget: string | null | undefined,
  studentName: string,
): void {
  const win = window.open('', '_blank', 'width=600,height=500');
  if (!win) return;
  const date = new Date(paidAt).toLocaleString('ar-LY', { dateStyle: 'medium', timeStyle: 'short' });
  const html = [
    '<!DOCTYPE html>',
    '<html dir="rtl" lang="ar">',
    '<head>',
    '<meta charset="UTF-8"/>',
    '<title>إيصال ' + receiptNumber + '</title>',
    '<style>',
    "@import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap');",
    'body { font-family: Cairo, sans-serif; margin: 0; padding: 32px; color: #1a1a1a; direction: rtl; background: #fff; }',
    '.receipt { max-width: 400px; margin: 0 auto; border: 2px solid #e5e7eb; border-radius: 12px; overflow: hidden; }',
    '.receipt-header { background: linear-gradient(135deg,#1e40af,#3b82f6); color: #fff; padding: 20px; text-align: center; }',
    '.receipt-header h1 { font-size: 15px; font-weight: 700; margin: 0 0 4px; }',
    '.receipt-header p { font-size: 11px; opacity: .8; margin: 0; }',
    '.receipt-body { padding: 20px; }',
    '.receipt-num { text-align: center; font-size: 28px; font-weight: 700; color: #1e40af; letter-spacing: 4px; margin-bottom: 20px; background: #eff6ff; border-radius: 8px; padding: 12px; }',
    '.row { display: flex; justify-content: space-between; align-items: center; padding: 10px 0; border-bottom: 1px dashed #e5e7eb; }',
    '.row:last-child { border-bottom: none; }',
    '.lbl { font-size: 12px; color: #6b7280; }',
    '.val { font-size: 13px; font-weight: 600; color: #1a1a1a; }',
    '.amount { font-size: 22px; font-weight: 700; color: #16a34a; }',
    '.receipt-footer { border-top: 2px solid #e5e7eb; padding: 16px 20px; display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }',
    '.sig { text-align: center; }',
    '.sig p { font-size: 11px; color: #9ca3af; border-top: 1px solid #d1d5db; padding-top: 8px; margin-top: 32px; }',
    '</style>',
    '</head>',
    '<body>',
    '<div class="receipt">',
    '<div class="receipt-header"><h1>معهد القمة للعلوم الطبية والإدارية</h1><p>إيصال دفع رسمي</p></div>',
    '<div class="receipt-body">',
    '<div class="receipt-num">' + receiptNumber + '</div>',
    '<div class="row"><span class="lbl">اسم الطالب</span><span class="val">' + studentName + '</span></div>',
    '<div class="row"><span class="lbl">التاريخ والوقت</span><span class="val">' + date + '</span></div>',
    '<div class="row"><span class="lbl">نوع الدفعة</span><span class="val">' + (semesterTarget ?? paymentType) + '</span></div>',
    '<div class="row"><span class="lbl">المبلغ المدفوع</span><span class="amount">' + amount.toFixed(0) + ' د.ل</span></div>',
    '</div>',
    '<div class="receipt-footer">',
    '<div class="sig"><p>توقيع المحاسب</p></div>',
    '<div class="sig"><p>ختم المعهد</p></div>',
    '</div></div>',
    '</body></html>',
  ].join('');
  win.document.write(html);
  win.document.close();
  win.focus();
  setTimeout(() => { win.print(); win.close(); }, 700);
}

function printSingleFile(fileUrl: string, fileName: string, fileType: string): void {
  const win = window.open('', '_blank', 'width=800,height=600');
  if (!win) return;
  const mediaHtml = fileType === 'image'
    ? '<img src="' + fileUrl + '" style="max-width:90vw;max-height:90vh;border-radius:8px;box-shadow:0 4px 20px rgba(0,0,0,0.15);" />'
    : '<iframe src="' + fileUrl + '" style="width:90vw;height:90vh;border:none;border-radius:8px;"></iframe>';
  const html = [
    '<!DOCTYPE html>',
    '<html dir="rtl" lang="ar">',
    '<head>',
    '<meta charset="UTF-8"/>',
    '<title>' + fileName + '</title>',
    '<style>body{margin:0;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#f3f4f6;font-family:sans-serif;} img{max-width:90vw;max-height:90vh;border-radius:8px;}</style>',
    '</head>',
    '<body>' + mediaHtml + '</body>',
    '</html>',
  ].join('');
  win.document.write(html);
  win.document.close();
  win.focus();
  setTimeout(() => { win.print(); }, 800);
}

export default function StudentProfilePage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { can } = useDeviceRole();
  const [searchParams] = useSearchParams();
  const isEditMode = searchParams.get('edit') === 'true';

  const [student, setStudent] = useState<Student | null>(null);
  const [receipts, setReceipts] = useState<Receipt[]>([]);
  const [charges, setCharges] = useState<SemesterCharge[]>([]);
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [studentFiles, setStudentFiles] = useState<StudentFile[]>([]);
  const [specializations, setSpecializations] = useState<Specialization[]>([]);
  const [loading, setLoading] = useState(true);
  const [editMode, setEditMode] = useState(isEditMode);
  const [editForm, setEditForm] = useState<Partial<Student>>({});

  // وضع استعادة أمر توريد محذوف
  const [restoreSONum, setRestoreSONum] = useState<string | null>(
    () => sessionStorage.getItem('restore_supply_order_num')
  );
  const clearRestoreMode = () => {
    sessionStorage.removeItem('restore_supply_order_num');
    sessionStorage.removeItem('restore_supply_order_diploma');
    setRestoreSONum(null);
    toast.info('تم إلغاء وضع الاستعادة');
  };

  // حوارات
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [deletePassword, setDeletePassword] = useState('');
  const [deleteError, setDeleteError] = useState('');
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState('');
  const [paymentReceiptNum, setPaymentReceiptNum] = useState('');
  const [paymentNotes, setPaymentNotes] = useState('');
  const [paymentDate, setPaymentDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [actionLoading, setActionLoading] = useState(false);
  const [avatarLoading, setAvatarLoading] = useState(false);
  const [fileUploading, setFileUploading] = useState(false);
  const [previewFile, setPreviewFile] = useState<StudentFile | null>(null);

  // حوار تعديل الأوراق الثبوتية
  const [showDocsDialog, setShowDocsDialog] = useState(false);
  const [docsForm, setDocsForm] = useState({
    photos_received: 0,
    photos_required: 6,
    has_birth_certificate: false,
    has_registration_certificate: false,
    has_suspended_file: false,
  });
  const [docsSaving, setDocsSaving] = useState(false);

  // حوار تعديل البيانات الشخصية والأكاديمية
  const [editPersonalModalOpen, setEditPersonalModalOpen] = useState(false);
  const [personalSaving, setPersonalSaving] = useState(false);
  const [editErrors, setEditErrors] = useState<{ national_id?: string; full_name?: string }>({});

  // حوار إضافة / تعديل رقم قيد الطالب
  const [regNumberModalOpen, setRegNumberModalOpen] = useState(false);
  const [newRegNumber, setNewRegNumber] = useState('');
  const [savingRegNumber, setSavingRegNumber] = useState(false);

  const handleSaveRegistrationNumber = async () => {
    if (!student) return;
    setSavingRegNumber(true);
    try {
      const trimmed = newRegNumber.trim();
      await updateStudentRegistrationNumber(student.id, trimmed);
      setStudent(prev => prev ? { ...prev, registration_number: trimmed.length > 0 ? trimmed : null } : null);
      toast.success(trimmed.length > 0 ? 'تم حفظ رقم قيد الطالب بنجاح' : 'تم تفريغ رقم قيد الطالب');
      setRegNumberModalOpen(false);
    } catch (err: any) {
      toast.error(err?.message || 'تعذر حفظ رقم قيد الطالب');
    } finally {
      setSavingRegNumber(false);
    }
  };

  // حوار الاتصال الهاتفي
  const [callTarget, setCallTarget] = useState<{ phone: string; label: string } | null>(null);

  // ── تنظيف رقم الهاتف لرابط tel: (يُزيل المسافات والشرطات ويُضيف +218 إذا لزم)
  const buildTelHref = (raw: string) => {
    // أزل كل شيء عدا الأرقام و +
    let digits = raw.replace(/[^\d+]/g, '');
    // إذا بدأ بـ 00218 → +218
    if (digits.startsWith('00218')) digits = '+' + digits.slice(2);
    // إذا بدأ بـ 0 → +218 + باقي الرقم
    else if (digits.startsWith('0')) digits = '+218' + digits.slice(1);
    // إذا لا يبدأ بـ + ولا 218 → أضف +218
    else if (!digits.startsWith('+')) digits = '+218' + digits;
    return `tel:${digits}`;
  };

  // مراجع رفع الملفات
  const avatarInputRef   = useRef<HTMLInputElement>(null);
  const avatarCameraRef  = useRef<HTMLInputElement>(null);
  const filePickRef = useRef<HTMLInputElement>(null);
  const cameraRef = useRef<HTMLInputElement>(null);

  // حالة محرر الصور
  const [editorOpen,    setEditorOpen]    = useState(false);
  const [editorSrc,     setEditorSrc]     = useState('');
  const [editorMode,    setEditorMode]    = useState<'avatar' | 'file'>('avatar');
  const [editorAspect,  setEditorAspect]  = useState<number | null>(1);
  const pendingFileRef  = useRef<File | null>(null);

  // فتح المحرر بعد اختيار ملف/صورة
  const openEditorFor = (file: File, mode: 'avatar' | 'file') => {
    const src = URL.createObjectURL(file);
    pendingFileRef.current = file;
    setEditorSrc(src);
    setEditorMode(mode);
    setEditorAspect(mode === 'avatar' ? 1 : null); // الصورة الشخصية مربعة، الملفات حرة
    setEditorOpen(true);
  };

  // حماية من الاستدعاء المتعدد المتزامن
  const fetchingRef = useRef(false);
  const fetchData = useCallback(async () => {
    if (!id || fetchingRef.current) return;
    fetchingRef.current = true;
    setLoading(true);
    try {
      const [s, r, c, cfg] = await Promise.all([
        getStudentById(id),
        getReceipts(id),
        getSemesterCharges(id),
        getSettings(),
      ]);
      setStudent(s);
      setReceipts(r);
      setCharges(c);
      setSettings(cfg);
      if (s) {
        setEditForm(s);
        getSpecializations(s.diploma_type).then(setSpecializations).catch(() => {});
      }
      getStudentFiles(id).then(setStudentFiles).catch(() => {});
    } catch (err) {
      console.error('fetchData error:', err);
      toast.error('خطأ في تحميل بيانات الطالب');
    } finally {
      setLoading(false);
      fetchingRef.current = false;
    }
  }, [id]);

  useEffect(() => { fetchData(); }, [fetchData]);

  useEffect(() => {
    if (!showPaymentDialog) return;
    peekCurrentReceiptNumber(student?.diploma_type as DiplomaType ?? 'عالي').then(n => setPaymentReceiptNum(n)).catch(console.error);
  }, [showPaymentDialog]);

  const handleSaveEdit = async () => {
    if (!student || !id) return;
    setActionLoading(true);
    try {
      await updateStudent(id, editForm);
      toast.success('تم تحديث البيانات بنجاح');
      setEditMode(false);
      fetchData();
    } catch {
      toast.error('فشل في تحديث البيانات');
    } finally {
      setActionLoading(false);
    }
  };

  // فتح نافذة تعديل البيانات الشخصية الشاملة
  const openEditPersonalModal = () => {
    if (!student) return;
    setEditForm({ ...student });
    setEditErrors({});
    if (student.diploma_type) {
      getSpecializations(student.diploma_type).then(setSpecializations).catch(() => {});
    }
    setEditPersonalModalOpen(true);
  };

  // حفظ البيانات الشخصية من النافذة المنبثقة
  const handleSavePersonalModal = async () => {
    if (!student || !id) return;
    const errors: { national_id?: string; full_name?: string } = {};

    if (!editForm.full_name || editForm.full_name.trim().length < 3) {
      errors.full_name = 'الرجاء إدخال الاسم الرباعي بشكل صحيح';
    }

    if (editForm.national_id) {
      const cleanNID = editForm.national_id.replace(/\D/g, '');
      if (cleanNID.length !== 12) {
        errors.national_id = 'الرقم الوطني يجب أن يتكون من 12 رقماً تماماً';
      }
    }

    if (Object.keys(errors).length > 0) {
      setEditErrors(errors);
      toast.error('يرجى تصحيح الأخطاء قبل الحفظ');
      return;
    }

    setPersonalSaving(true);
    try {
      await updateStudent(id, editForm);
      toast.success('تم تحديث البيانات الشخصية والأكاديمية بنجاح');
      setEditPersonalModalOpen(false);
      fetchData();
    } catch (err: any) {
      toast.error(err?.message || 'فشل في حفظ البيانات الشخصية');
    } finally {
      setPersonalSaving(false);
    }
  };

  // فتح حوار تعديل الأوراق الثبوتية مع القيم الحالية
  const openDocsDialog = () => {
    if (!student) return;
    setDocsForm({
      photos_received: student.photos_received ?? 0,
      photos_required: student.photos_required ?? 6,
      has_birth_certificate: student.has_birth_certificate ?? false,
      has_registration_certificate: student.has_registration_certificate ?? false,
      has_suspended_file: student.has_suspended_file ?? false,
    });
    setShowDocsDialog(true);
  };

  const handleSaveDocs = async () => {
    if (!id) return;
    setDocsSaving(true);
    try {
      await updateStudent(id, docsForm);
      toast.success('تم تحديث موقف الأوراق الثبوتية');
      setShowDocsDialog(false);
      fetchData();
    } catch {
      toast.error('فشل في تحديث الأوراق الثبوتية');
    } finally {
      setDocsSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!student || !id) return;
    if (deletePassword !== SYSTEM_PASSWORD) { setDeleteError('كلمة المرور غير صحيحة'); return; }
    setActionLoading(true);
    try {
      await deleteStudent(id);
      toast.success('تم حذف الملف نهائياً');
      navigate('/');
    } catch {
      toast.error('فشل في حذف الملف');
    } finally {
      setActionLoading(false);
    }
  };

  const handleSuspend = async () => {
    if (!id || !student) return;
    setActionLoading(true);
    // Optimistic UI — تحديث فوري بدون إعادة تحميل الصفحة
    setStudent(prev => prev ? { ...prev, status: 'موقوف قيد' } : prev);
    try {
      await suspendStudent(id);
      toast.warning('تم إيقاف قيد الطالب', {
        style: { background: '#fffbeb', border: '1px solid #fcd34d', color: '#92400e' },
      });
    } catch {
      // تراجع عند الفشل
      setStudent(prev => prev ? { ...prev, status: 'نشط' } : prev);
      toast.error('فشل في إيقاف القيد');
    } finally { setActionLoading(false); }
  };

  const handleActivate = async () => {
    if (!id || !student) return;
    setActionLoading(true);
    // Optimistic UI — تحديث فوري بدون إعادة تحميل الصفحة
    setStudent(prev => prev ? { ...prev, status: 'نشط' } : prev);
    try {
      await activateStudent(id);
      toast.success('تم تنشيط القيد بنجاح', {
        style: { background: '#f0fdf4', border: '1px solid #86efac', color: '#166534' },
      });
    } catch {
      // تراجع عند الفشل
      setStudent(prev => prev ? { ...prev, status: 'موقوف قيد' } : prev);
      toast.error('فشل في تنشيط القيد');
    } finally { setActionLoading(false); }
  };

  const handleToggleExamOnly = async () => {
    if (!student || !id) return;
    const newVal = !student.is_exam_only;
    // تحديث فوري للواجهة (Optimistic UI) — بدون إعادة تحميل الصفحة
    setStudent(prev => prev ? { ...prev, is_exam_only: newVal } : prev);
    try {
      await updateStudent(id, { is_exam_only: newVal });
      if (newVal) {
        toast.success('تم التحديث: طالب 100', {
          style: { background: '#f3e8ff', border: '1px solid #c084fc', color: '#6b21a8' },
        });
      } else {
        toast.success('تم التحديث: نظامي', {
          style: { background: '#e0f2fe', border: '1px solid #38bdf8', color: '#0369a1' },
        });
      }
    } catch {
      // تراجع عند الفشل
      setStudent(prev => prev ? { ...prev, is_exam_only: !newVal } : prev);
      toast.error('فشل في تحديث نوع الطالب');
    }
  };

  const handlePayment = async () => {
    if (!student || !id) return;
    const amount = parseFloat(paymentAmount);
    if (!amount || amount <= 0) { toast.error('أدخل مبلغاً صحيحاً'); return; }
    if (!paymentReceiptNum.trim()) { toast.error('رقم الإيصال مطلوب'); return; }
    setActionLoading(true);
    try {
      // استخدام رقم المعاملة المجبر في وضع الاستعادة إن وُجد
      const overrideSONum = sessionStorage.getItem('restore_supply_order_num') ?? undefined;
      const { receipts: recs } = await processPayment({
        studentId: id, amount,
        notes: paymentNotes || undefined,
        paidAt: paymentDate ? new Date(paymentDate).toISOString() : undefined,
        overrideSupplyOrderNumber: overrideSONum,
      });
      const summary = recs.map(r => `${r.amount.toFixed(0)} د.ل ${r.semester_target ?? r.payment_type}`).join(' | ');
      const restoreNote = overrideSONum ? ` — استعادة ${overrideSONum}` : '';
      toast.success(`دفعة ${amount} دينار — ${summary}${restoreNote}`);
      setShowPaymentDialog(false); setPaymentAmount(''); setPaymentNotes('');
      setPaymentDate(new Date().toISOString().slice(0, 10));
      fetchData();
    } catch { toast.error('فشل في تسجيل الدفعة'); }
    finally { setActionLoading(false); }
  };

  // يُفتح المحرر عند اختيار الصورة الشخصية
  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !id) return;
    e.target.value = '';
    // إذا كان الملف صورة → افتح المحرر، وإلا ارفعه مباشرة
    if (file.type.startsWith('image/')) {
      openEditorFor(file, 'avatar');
    } else {
      doUploadAvatar(file);
    }
  };

  // الرفع الفعلي للصورة الشخصية بعد التعديل
  const doUploadAvatar = async (file: File) => {
    if (!id) return;
    setAvatarLoading(true);
    try {
      const { file: finalFile, compressed } = await compressImageIfNeeded(file);
      await uploadStudentAvatar(id, finalFile);
      if (compressed)
        toast.success(`تم تحديث الصورة (مضغوطة — ${(finalFile.size / 1024).toFixed(0)} KB)`);
      else
        toast.success('تم تحديث الصورة الشخصية');
      fetchData();
    } catch { toast.error('فشل في رفع الصورة'); }
    finally { setAvatarLoading(false); }
  };

  // يُفتح المحرر عند اختيار ملف
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !id) return;
    e.target.value = '';
    if (file.size > 5 * 1024 * 1024) { toast.error('حجم الملف يجب أن لا يتجاوز 5 ميجابايت'); return; }
    if (file.type.startsWith('image/')) {
      openEditorFor(file, 'file');
    } else {
      doUploadFile(file);
    }
  };

  // الرفع الفعلي للملف بعد التعديل (أو مباشرة للـ PDF)
  const doUploadFile = async (file: File) => {
    if (!id) return;
    setFileUploading(true);
    try {
      await uploadStudentFile(id, file);
      toast.success('تم رفع الملف بنجاح');
      getStudentFiles(id).then(setStudentFiles).catch(() => {});
    } catch { toast.error('فشل في رفع الملف'); }
    finally { setFileUploading(false); }
  };

  // تأكيد المحرر → رفع حسب الوضع
  const handleEditorConfirm = async (editedFile: File) => {
    setEditorOpen(false);
    if (editorSrc) URL.revokeObjectURL(editorSrc);
    if (editorMode === 'avatar') {
      await doUploadAvatar(editedFile);
    } else {
      await doUploadFile(editedFile);
    }
  };

  const handleDeleteFile = async (fileId: string) => {
    try {
      await deleteStudentFile(fileId);
      setStudentFiles(prev => prev.filter(f => f.id !== fileId));
      toast.success('تم حذف الملف');
    } catch { toast.error('فشل في حذف الملف'); }
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="space-y-4 max-w-4xl mx-auto">
          <Skeleton className="h-40 bg-muted rounded-xl" />
          <Skeleton className="h-64 bg-muted rounded-xl" />
          <Skeleton className="h-48 bg-muted rounded-xl" />
        </div>
      </MainLayout>
    );
  }

  if (!student) {
    return (
      <MainLayout>
        <div className="text-center py-16 text-muted-foreground">
          <User className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p>الطالب غير موجود</p>
          <Button variant="outline" className="mt-4" onClick={() => navigate('/')}>العودة للوحة التحكم</Button>
        </div>
      </MainLayout>
    );
  }

  const debt = student.total_charged - student.total_paid;
  const missingDocs: string[] = [];
  if (student.photos_received < student.photos_required) missingDocs.push(`${student.photos_required - student.photos_received} صور`);
  if (!student.has_birth_certificate) missingDocs.push('شهادة ميلاد');
  if (!student.has_registration_certificate) missingDocs.push('شهادة التسجيل');
  if (!student.has_suspended_file) missingDocs.push('ملف معلق');
  const statusCfg = STATUS_CONFIG[student.status] ?? STATUS_CONFIG['نشط'];

  // ── طباعة تعريف الطالب (نموذج رسمي A4 محسّن) ──
  const handlePrintStudentID = async () => {
    const LOGO = 'https://miaoda-conversation-file.s3cdn.medo.dev/user-cim4m3x63pxc/app-f6avantw6h35/20261018/FB_IMG_1780949707596.jpg';
    const now  = new Date();
    // صيغة التاريخ: يوم\شهر\سنة (مثل 12\1\2026)
    const fmt  = (d: Date) =>
      `${d.getDate()}\\${d.getMonth() + 1}\\${d.getFullYear()}`;
    const issueDate   = fmt(now);
    const expireDate  = fmt(new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000));
    const semLbl      = SEMESTER_LABELS[student.current_semester] ?? `الفصل ${student.current_semester}`;

    // رقم الإفادة التسلسلي من قاعدة البيانات: 0001/2026 → 0002/2026 ...
    let refNum = '0001/' + now.getFullYear();
    try {
      refNum = await getNextLetterNumber();
    } catch { /* نكمل برقم افتراضي */ }

    // العام الدراسي
    const y = now.getFullYear();
    const academicYear = now.getMonth() >= 8
      ? `${y} / ${y + 1}`
      : `${y - 1} / ${y}`;

    // رقم قيد الطالب — يعتمد على الحقل الفعلي إن وُجد، أو يشمل سنة التسجيل + جزء من ID
    const enrollYear = student.enrollment_date
      ? new Date(student.enrollment_date).getFullYear()
      : new Date(student.created_at).getFullYear();
    const enrollNum = student.registration_number?.trim() || `${String(Math.floor(10000 + Math.abs(student.id.charCodeAt(0) * 1234) % 90000))}/${enrollYear}`;

    // جنس الطالب
    const isFemale = student.gender === 'أنثى' || student.gender === 'انثى' || student.gender === 'female';
    const nameTitle    = isFemale ? 'الطالبة' : 'الطالب';
    const pronoun1     = isFemale ? 'المقيدة'  : 'المقيد';
    const pronoun2     = isFemale ? 'إحدى'     : 'أحد';
    const pronoun3     = isFemale ? 'تتمتع'    : 'يتمتع';
    const pronoun4     = isFemale ? 'دراستها'  : 'دراسته';
    const pronoun5     = isFemale ? 'طلبها'    : 'طلبه';
    const pronoun6     = isFemale ? 'لها'      : 'له';
    const genderSuffix = isFemale ? 'ة' : '';
    const examType     = student.is_exam_only ? 'طالب امتحانات 100' : 'منتظم';

    // QR يشير لـ /v/<token> — صفحة HTML مستقلة في public/v/ خارج المنظومة تماماً
    const verifyToken = student.verify_token ?? student.id;
    const verifyUrl   = `${window.location.origin}/v/${verifyToken}`;
    let qrDataUrl = '';
    try {
      const QRCode = (await import('qrcode')).default;
      qrDataUrl = await QRCode.toDataURL(verifyUrl, {
        width: 120, margin: 1,
        color: { dark: '#07173a', light: '#ffffff' },
        errorCorrectionLevel: 'M',
      });
    } catch { /* نكمل بدون QR */ }

    const win = window.open('', '_blank', 'width=900,height=800');
    if (!win) return;

    const html = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<title>تعريف طالب — ${student.full_name}</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800;900&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{
  font-family:'Cairo',Arial,sans-serif;
  direction:rtl;background:#c8cdd8;
  -webkit-print-color-adjust:exact;print-color-adjust:exact;
  display:flex;justify-content:center;align-items:flex-start;
  padding:12mm 0;min-height:100vh;
}
/* ── ورقة A4 ── */
.page{
  width:210mm;min-height:297mm;
  background:#fff;
  display:flex;flex-direction:column;
  position:relative;
  box-shadow:0 20px 80px rgba(0,0,0,.35);
}
/* حاشية داخلية ذهبية خفيفة */
.page::before{
  content:'';position:absolute;inset:5mm;
  border:0.5px solid rgba(184,142,14,.18);
  pointer-events:none;z-index:5;
}

/* ════════════ رأس الوثيقة ════════════ */
.hdr{
  background:linear-gradient(150deg,#06152e 0%,#0b2147 55%,#071a38 100%);
  padding:20px 26px 0;
  position:relative;overflow:hidden;flex-shrink:0;
}
/* بقعة ضوء زخرفية */
.hdr::before{
  content:'';position:absolute;
  top:-60px;right:-60px;
  width:220px;height:220px;border-radius:50%;
  background:radial-gradient(circle,rgba(255,255,255,.05),transparent 65%);
}
.hdr-top{
  position:relative;z-index:2;
  display:flex;align-items:stretch;gap:0;
}
/* عمود أرقام التواصل */
.hdr-contact{
  display:flex;flex-direction:column;justify-content:center;
  gap:7px;padding-left:18px;
  border-left:1px solid rgba(255,255,255,.1);
  min-width:105px;
}
.contact-item{
  display:flex;align-items:center;gap:6px;
}
.contact-icon{
  width:22px;height:22px;border-radius:50%;
  display:flex;align-items:center;justify-content:center;
  flex-shrink:0;font-size:12px;
}
.contact-icon.phone{background:rgba(255,255,255,.15)}
.contact-icon.whatsapp{background:#25d366}
.contact-item .c-num{font-size:10px;font-weight:700;color:#fff;direction:ltr;letter-spacing:.3px}
.contact-item .c-lbl{font-size:7.5px;color:rgba(200,220,255,.5);font-weight:600}
/* عمود اسم المعهد */
.hdr-title{
  flex:1;min-width:0;
  display:flex;flex-direction:column;align-items:center;justify-content:center;
  padding:0 16px;
  text-align:center;
}
.hdr-title .inst-ar{
  font-size:17px;font-weight:900;color:#fff;
  line-height:1.45;text-align:center;
}
.hdr-title .branch-ar{
  font-size:12px;font-weight:700;
  color:rgba(240,200,80,.9);
  margin-top:3px;
}
.hdr-title .inst-en{
  font-size:8.5px;font-weight:500;
  color:rgba(170,200,255,.5);
  margin-top:2px;letter-spacing:.4px;
}
/* عمود الشعار */
.hdr-logo{
  display:flex;align-items:center;justify-content:center;
  padding-right:18px;
  border-right:1px solid rgba(255,255,255,.1);
}
.logo-wrap{
  width:78px;height:78px;border-radius:50%;
  background:#fff;overflow:hidden;
  border:3px solid rgba(255,255,255,.9);
  box-shadow:0 0 0 5px rgba(255,255,255,.1),0 8px 20px rgba(0,0,0,.5);
}
.logo-wrap img{width:100%;height:100%;object-fit:cover}
/* شريط الفرع */
.hdr-branch{
  position:relative;z-index:2;
  border-top:1px solid rgba(255,255,255,.12);
  padding:8px 0 6px;
  display:flex;align-items:center;justify-content:center;gap:8px;
  margin-top:14px;
  background:linear-gradient(90deg,transparent,rgba(232,195,60,.07) 30%,rgba(232,195,60,.13) 50%,rgba(232,195,60,.07) 70%,transparent);
}
.br-dot{
  width:5px;height:5px;border-radius:50%;
  background:radial-gradient(circle,#f5d060 30%,#a06800 100%);
  box-shadow:0 0 5px 1px rgba(240,190,40,.6);
}
.br-diamond{
  width:5px;height:5px;
  background:linear-gradient(135deg,#f5d060,#c8920a);
  transform:rotate(45deg);
  box-shadow:0 0 4px rgba(240,190,40,.7);
  flex-shrink:0;
}
.br-txt{
  font-size:10px;font-weight:800;
  color:rgba(248,220,100,.92);
  letter-spacing:.6px;
  text-shadow:0 0 8px rgba(240,190,40,.5);
}
/* شريط ذهبي */
.gold-bar{
  height:5px;flex-shrink:0;
  background:linear-gradient(90deg,
    transparent 0%,
    #3d2400 4%,
    #a06a00 15%,
    #d4a520 28%,
    #f5d96e 42%,
    #fff5b0 50%,
    #f5d96e 58%,
    #d4a520 72%,
    #a06a00 85%,
    #3d2400 96%,
    transparent 100%);
  position:relative;
}
.gold-bar::after{
  content:'';position:absolute;inset:0;
  background:linear-gradient(90deg,transparent 0%,rgba(255,255,255,.45) 50%,transparent 100%);
  animation:goldShimmer 3s ease-in-out infinite;
}
@keyframes goldShimmer{
  0%,100%{opacity:0;transform:scaleX(0) translateX(-100%)}
  40%{opacity:1;transform:scaleX(1) translateX(0%)}
  70%{opacity:0;transform:scaleX(1) translateX(100%)}
}

/* ════════════ شريط رقم الإفادة ════════════ */
.meta-bar{
  display:grid;grid-template-columns:repeat(3,1fr);
  border-bottom:1px solid #e4ecf6;
  padding:10px 24px;gap:4px;
}
.meta-item{
  display:flex;flex-direction:column;align-items:center;gap:2px;
}
.meta-item .mi-wrap{
  display:flex;align-items:center;gap:6px;
}
.meta-item .mi-icon{
  width:26px;height:26px;border-radius:6px;
  background:linear-gradient(135deg,#07173a,#1a3a6e);
  display:flex;align-items:center;justify-content:center;
  font-size:12px;color:#f0cc50;flex-shrink:0;
}
.meta-item .mi-lbl{font-size:8px;font-weight:700;color:#8a9ec0;letter-spacing:.3px}
.meta-item .mi-val{font-size:11px;font-weight:800;color:#07173a;direction:ltr;letter-spacing:.5px}

/* ════════════ جسم الوثيقة ════════════ */
.body{
  flex:1;padding:16px 26px 14px;
  display:flex;flex-direction:column;gap:12px;
}
/* عنوان */
.doc-title{text-align:center;padding:6px 0 2px;position:relative}
.doc-title::before,.doc-title::after{
  content:'';position:absolute;top:50%;
  width:55px;height:1px;background:linear-gradient(90deg,transparent,#c8960a);
}
.doc-title::before{right:calc(50% + 84px)}
.doc-title::after{left:calc(50% + 84px);background:linear-gradient(90deg,#c8960a,transparent)}
.doc-title h2{
  display:inline-block;font-size:19px;font-weight:900;
  color:#07173a;letter-spacing:3px;
  border-bottom:2.5px solid #c8960a;padding-bottom:4px;
}
/* كرت البيانات */
.data-card{border:1px solid #d0dcf0;border-radius:9px;overflow:hidden;box-shadow:0 1px 6px rgba(7,23,58,.05)}
.data-card-hdr{
  background:linear-gradient(135deg,#07173a,#153060);
  padding:6px 14px;display:flex;align-items:center;gap:7px;
}
.data-card-hdr .dc-dot{width:7px;height:7px;border-radius:50%;background:linear-gradient(135deg,#f0cc50,#c8960a)}
.data-card-hdr span{font-size:10px;font-weight:800;color:#fff;letter-spacing:.4px}
.data-grid{display:grid;grid-template-columns:1fr 1fr}
.data-cell{
  padding:8px 14px;
  border-bottom:1px solid #e6edf8;border-left:1px solid #e6edf8;
  display:flex;align-items:center;gap:14px;
}
.data-cell:nth-child(odd){border-left:none;background:#f6f9fd}
.data-cell:nth-child(even){background:#fff}
.data-cell:nth-last-child(1),.data-cell:nth-last-child(2){border-bottom:none}
.cell-lbl{
  font-size:9px;font-weight:700;color:#5a7aaa;
  min-width:74px;flex-shrink:0;letter-spacing:.2px;
}
.cell-val{font-size:12px;font-weight:700;color:#0a1e42;flex:1;text-align:left}
.cell-val.ltr{direction:ltr;font-family:'Courier New',monospace;font-size:11px;letter-spacing:.4px}
.cell-val.big{font-size:13px;font-weight:900}
/* الإفادة الرسمية */
.official{border:1.5px solid #07173a;border-radius:9px;overflow:hidden;box-shadow:0 1px 6px rgba(7,23,58,.07)}
.official-hdr{
  background:linear-gradient(135deg,#07173a,#153060);
  padding:7px 14px;display:flex;align-items:center;gap:7px;
}
.official-hdr .oh-dot{width:7px;height:7px;border-radius:50%;background:linear-gradient(135deg,#f0cc50,#c8960a)}
.official-hdr span{font-size:10px;font-weight:800;color:#fff;letter-spacing:.4px}
.official-body{padding:14px 18px 12px;background:#fdfeff}
.body-text{font-size:13px;font-weight:500;color:#1a2e4a;line-height:2.1;text-align:justify}
.emp{font-weight:800;color:#07173a}
.sep{border:none;border-top:1px dashed #c8d8ee;margin:10px 0}
/* تنبيهات */
.notices-card{border:1px solid #e0eaf8;border-radius:9px;overflow:hidden}
.notices-hdr{
  background:linear-gradient(135deg,#fef9ec,#fdf4d8);
  padding:6px 14px;display:flex;align-items:center;gap:7px;
  border-bottom:1px solid #e8d88a;
}
.notices-hdr .nh-dot{width:7px;height:7px;border-radius:50%;background:#c8960a}
.notices-hdr span{font-size:9.5px;font-weight:800;color:#7a5500;letter-spacing:.3px}
.notices-body{padding:10px 14px;background:#fffdf5}
.notice{display:flex;align-items:flex-start;gap:7px;padding:3px 0;font-size:9.5px;font-weight:500;color:#4a5a6a;line-height:1.7}
.notice-icon{
  flex-shrink:0;margin-top:3px;
  width:13px;height:13px;border-radius:50%;
  background:linear-gradient(135deg,#f0cc50,#c8960a);
  display:flex;align-items:center;justify-content:center;
  font-size:7px;color:#fff;font-weight:900;
}
/* منطقة التوقيع */
.sig-area{
  display:grid;grid-template-columns:1fr 1fr 1fr;
  border:1px solid #d0dcf0;border-radius:9px;overflow:hidden;
  box-shadow:0 1px 6px rgba(7,23,58,.04);
}
.qr-block{
  padding:10px 8px;
  background:linear-gradient(180deg,#f6f9fd,#eef3fb);
  display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;
  border-left:1px solid #d0dcf0;
}
.qr-block img{display:block;width:80px;height:80px;border-radius:4px}
.qr-block .qr-lbl{font-size:7px;font-weight:700;color:#334e7a;letter-spacing:.3px;text-align:center}
.sig-block{
  padding:14px 12px 10px;
  background:linear-gradient(180deg,#f7f9fd,#fff);
  display:flex;flex-direction:column;align-items:center;gap:4px;
  border-left:1px solid #d0dcf0;
}
.sig-block .sig-title{font-size:10px;font-weight:800;color:#07173a;text-align:center}
.sig-block .sig-dept{font-size:8px;color:#64748b;text-align:center;margin-bottom:2px}
.sig-line{width:75%;height:1px;background:linear-gradient(90deg,transparent,#07173a,transparent);margin:14px 0 3px}
.sig-block .sig-name{font-size:9px;font-weight:700;color:#07173a;text-align:center}
.stamp-block{
  padding:12px 10px;
  background:linear-gradient(180deg,#eef3fb,#f4f7fd);
  display:flex;flex-direction:column;align-items:center;justify-content:center;gap:5px;
}
.stamp-outer{
  width:76px;height:76px;border-radius:50%;
  border:2px solid #07173a;
  display:flex;align-items:center;justify-content:center;
  background:rgba(7,23,58,.02);
}
.stamp-inner{
  width:58px;height:58px;border-radius:50%;
  border:1px dashed rgba(7,23,58,.4);
  display:flex;align-items:center;justify-content:center;
}
.stamp-inner img{width:44px;height:44px;object-fit:contain;opacity:.6}
.stamp-lbl{font-size:7px;color:#64748b;font-weight:600;text-align:center}

/* ════════════ تذييل ════════════ */
.footer{
  background:linear-gradient(150deg,#06152e,#0b2147);
  padding:8px 24px;
  display:flex;align-items:center;justify-content:space-between;
  flex-shrink:0;gap:8px;
}
.ft-item{display:flex;align-items:center;gap:5px}
.ft-icon{font-size:10px;opacity:.6}
.ft-txt{font-size:7.5px;color:rgba(180,205,255,.55);font-weight:500;letter-spacing:.3px}
.ft-txt.email{direction:ltr}

@media print{
  @page{size:A4 portrait;margin:0}
  body{background:#fff;padding:0;display:block}
  .page{width:210mm;min-height:297mm;box-shadow:none}
  *{-webkit-print-color-adjust:exact;print-color-adjust:exact}
}
</style>
</head>
<body>
<div class="page">

  <!-- رأس الوثيقة -->
  <div class="hdr">
    <div class="hdr-top">
      <!-- الشعار -->
      <div class="hdr-logo">
        <div class="logo-wrap"><img src="${LOGO}" alt="شعار المعهد"/></div>
      </div>
      <!-- اسم المعهد -->
      <div class="hdr-title">
        <div class="inst-ar">معهد القمة للعلوم الطبية والإدارية</div>
        <div class="inst-en">Al-Qimma Institute for Medical &amp; Administrative Sciences</div>
      </div>
      <!-- التواصل -->
      <div class="hdr-contact">
        <div class="contact-item">
          <div class="contact-icon phone">📞</div>
          <div>
            <div class="c-num">0925040851</div>
            <div class="c-lbl">هاتف</div>
          </div>
        </div>
        <div class="contact-item">
          <div class="contact-icon phone">📍</div>
          <div>
            <div class="c-num" style="font-size:9.5px;">سوق السبت</div>
            <div class="c-lbl">المقر</div>
          </div>
        </div>
      </div>
    </div>
    <div class="hdr-branch">
      <div class="br-diamond"></div>
      <div class="br-txt">✦ &nbsp; دبلوم ${student.diploma_type} &nbsp;·&nbsp; تخصص ${student.specialization ?? 'المحاسبة'} &nbsp; ✦</div>
      <div class="br-diamond"></div>
    </div>
  </div>
  <div class="gold-bar"></div>

  <!-- شريط رقم الإفادة -->
  <div class="meta-bar">
    <div class="meta-item">
      <div class="mi-wrap">
        <div class="mi-icon">📋</div>
        <div>
          <div class="mi-lbl">رقم الإفادة</div>
          <div class="mi-val">${refNum}</div>
        </div>
      </div>
    </div>
    <div class="meta-item">
      <div class="mi-wrap">
        <div class="mi-icon">📅</div>
        <div>
          <div class="mi-lbl">تاريخ الإصدار</div>
          <div class="mi-val">${issueDate}</div>
        </div>
      </div>
    </div>
    <div class="meta-item">
      <div class="mi-wrap">
        <div class="mi-icon">⏳</div>
        <div>
          <div class="mi-lbl">تاريخ انتهاء الصلاحية</div>
          <div class="mi-val">${expireDate}</div>
        </div>
      </div>
    </div>
  </div>

  <!-- جسم الوثيقة -->
  <div class="body">

    <!-- عنوان -->
    <div class="doc-title"><h2>تعريف ${nameTitle}</h2></div>

    <!-- كرت البيانات -->
    <div class="data-card">
      <div class="data-card-hdr">
        <div class="dc-dot"></div>
        <span>بيانات ${nameTitle}</span>
      </div>
      <div class="data-grid">
        <div class="data-cell">
          <span class="cell-lbl">اسم الطالب</span>
          <span class="cell-val big">${student.full_name}</span>
        </div>
        <div class="data-cell">
          <span class="cell-lbl">الرقم الوطني</span>
          <span class="cell-val ltr">${student.national_id ?? '—'}</span>
        </div>
        <div class="data-cell">
          <span class="cell-lbl">رقم قيد الطالب</span>
          <span class="cell-val ltr">${enrollNum}</span>
        </div>
        <div class="data-cell">
          <span class="cell-lbl">التخصص</span>
          <span class="cell-val">دبلوم ${student.diploma_type} - تخصص ${student.specialization ?? 'المحاسبة'}</span>
        </div>
        <div class="data-cell">
          <span class="cell-lbl">الفصل الدراسي</span>
          <span class="cell-val">${semLbl}</span>
        </div>
        <div class="data-cell">
          <span class="cell-lbl">الحالة الدراسية</span>
          <span class="cell-val">${examType}</span>
        </div>
        <div class="data-cell" style="grid-column:1/-1">
          <span class="cell-lbl">العام الدراسي</span>
          <span class="cell-val ltr">${academicYear} م</span>
        </div>
      </div>
    </div>

    <!-- نص الإفادة -->
    <div class="official">
      <div class="official-hdr">
        <div class="oh-dot"></div>
        <span>الإفادة الرسمية</span>
      </div>
      <div class="official-body">
        <p class="body-text">
          تشهد إدارة <span class="emp">معهد القمة للعلوم الطبية والإدارية</span> بأن ${nameTitle} الموضح اسمه وبياناته أعلاه <span class="emp">${pronoun2} الطلاب ${pronoun1}ين لدينا</span>. علماً بأن${isFemale ? 'ها' : 'ه'} ${pronoun3} بأخلاق وسيرة حسنة طيلت ${pronoun4} بالمعهد.
        </p>
        <p class="body-text" style="margin-top:8px">
          وبناءً على ${pronoun5} أُعطي${isFemale ? 'ت' : ''} هذا التعريف لتقديمه إلى <span class="emp">مَن يهمه الأمر</span>، دون أن تتحمل إدارة المعهد أدنى مسؤولية حيال ذلك.
        </p>
        <p class="body-text" style="margin-top:6px;text-align:left;font-weight:700;color:#07173a">
          والله الموفق ؛؛؛؛
        </p>
      </div>
    </div>

    <!-- التنبيهات -->
    <div class="notices-card">
      <div class="notices-hdr">
        <div class="nh-dot"></div>
        <span>تنبيهات</span>
      </div>
      <div class="notices-body">
        <div class="notice"><div class="notice-icon">✓</div>لا يُعتدّ بهذه الإفادة إلا إذا كانت مختومة بالختم الرسمي للمعهد وموقعة من الجهة المختصة.</div>
        <div class="notice"><div class="notice-icon">✓</div>تصدر هذه الإفادة استناداً إلى البيانات المسجلة بمنظومة شؤون الدراسة والامتحانات بالمعهد.</div>
        <div class="notice"><div class="notice-icon">✓</div>صلاحية هذه الإفادة (30) يوماً من تاريخ إصدارها ما لم يُنص على خلاف ذلك.</div>
      </div>
    </div>

    <!-- التوقيع والختم -->
    <div class="sig-area">
      <div class="sig-block">
        <div class="sig-title">يعتمد</div>
        <div class="sig-dept">رئيس مكتب الشؤون الإدارية والمالية</div>
        <div class="sig-line"></div>
      </div>
      <div class="qr-block">
        ${qrDataUrl
          ? `<img src="${qrDataUrl}" alt="QR التحقق"/>`
          : `<div style="width:80px;height:80px;background:#e8eef8;border-radius:4px;display:flex;align-items:center;justify-content:center;font-size:7px;color:#5a7aaa;text-align:center;">رمز التحقق</div>`}
        <div class="qr-lbl">امسح للتحقق<br/>من صحة الإفادة</div>
      </div>
      <div class="stamp-block">
        <div class="stamp-outer">
          <div class="stamp-inner">
            <img src="${LOGO}" alt="ختم"/>
          </div>
        </div>
        <div class="stamp-lbl">الختم الرسمي للمعهد</div>
      </div>
    </div>

  </div><!-- /body -->

  <!-- تذييل -->
  <div class="footer">
    <div class="ft-item"><span class="ft-icon">📍</span><span class="ft-txt">سوق السبت – ليبيا</span></div>
    <div class="ft-item"><span class="ft-icon">📞</span><span class="ft-txt">0925040851</span></div>
    <div class="ft-item"><span class="ft-icon">✉</span><span class="ft-txt email">alkema2024@gmail.com</span></div>
    <div class="ft-item"><span class="ft-icon">🌐</span><span class="ft-txt email">http://www.alkima.edu.ly</span></div>
  </div>

</div><!-- /page -->
<script>window.onload=function(){setTimeout(function(){window.print();},400);};</script>
</body>
</html>`;
    win.document.write(html);
    win.document.close();
  };


  // ── طباعة ملف الطالب الاحترافية ──
  const handlePrintProfile = () => {
    const LOGO = 'https://miaoda-conversation-file.s3cdn.medo.dev/user-cim4m3x63pxc/app-f6avantw6h35/20261018/FB_IMG_1780949707596.jpg';
    const win = window.open('', '_blank', 'width=900,height=700');
    if (!win) return;

    const today   = new Date().toLocaleDateString('ar-LY');
    const semLbl  = SEMESTER_LABELS[student.current_semester] ?? `الفصل ${student.current_semester}`;
    const paidPct = student.total_charged > 0
      ? Math.round((student.total_paid / student.total_charged) * 100) : 100;
    const debtAmt = student.total_charged - student.total_paid;

    // صف معلومة واحدة
    const infoRow = (label: string, value: string | number | null, mono = false) =>
      `<div class="info-cell">
        <div class="info-lbl">${label}</div>
        <div class="info-val${mono ? ' mono' : ''}">${value ?? '—'}</div>
      </div>`;

    // صف حالة وثيقة
    const docRow = (label: string, ok: boolean) =>
      `<div class="doc-row">
        <span class="doc-icon ${ok ? 'ok' : 'miss'}">${ok ? '✓' : '✗'}</span>
        <span class="doc-lbl">${label}</span>
        <span class="doc-badge ${ok ? 'badge-ok' : 'badge-miss'}">${ok ? 'مكتمل' : 'ناقص'}</span>
      </div>`;

    win.document.write(`<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<title>ملف الطالب — ${student.full_name}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;900&display=swap');
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:'Cairo',sans-serif;direction:rtl;background:#f0f4f8;color:#1a2332;font-size:12px;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .page{width:210mm;min-height:297mm;margin:0 auto;padding:10mm 12mm;background:#f0f4f8}

  /* ══ الرأس ══ */
  .hdr{background:linear-gradient(135deg,#0f2744 0%,#1a3c5e 50%,#1e5a94 100%);border-radius:14px;padding:14px 18px;margin-bottom:10px;display:flex;align-items:center;gap:14px;position:relative;overflow:hidden;box-shadow:0 4px 20px rgba(15,39,68,.35)}
  .hdr::before{content:'';position:absolute;inset:0;background:repeating-linear-gradient(45deg,rgba(255,255,255,.02) 0,rgba(255,255,255,.02) 1px,transparent 1px,transparent 18px)}
  .hdr-logo{width:68px;height:68px;border-radius:50%;border:3px solid rgba(255,255,255,.85);overflow:hidden;flex-shrink:0;background:#fff;box-shadow:0 0 0 4px rgba(255,255,255,.15),0 4px 14px rgba(0,0,0,.3);z-index:1;position:relative}
  .hdr-logo img{width:100%;height:100%;object-fit:cover}
  .hdr-text{flex:1;z-index:1;position:relative}
  .hdr-text h1{font-size:17px;font-weight:900;color:#fff;margin-bottom:3px;text-shadow:0 2px 6px rgba(0,0,0,.2)}
  .hdr-text .sub1{font-size:11px;color:rgba(165,210,255,.95);font-weight:600;margin-bottom:1px}
  .hdr-text .sub2{font-size:10px;color:rgba(180,215,255,.7)}
  .hdr-right{text-align:center;flex-shrink:0;z-index:1;position:relative}
  .hdr-date{background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);border-radius:8px;padding:7px 14px}
  .hdr-date .lbl{font-size:8.5px;color:rgba(180,215,255,.8);display:block;margin-bottom:2px}
  .hdr-date .val{font-size:12px;font-weight:900;color:#fff}

  /* ══ بطاقة الطالب ══ */
  .student-card{background:#fff;border-radius:12px;padding:14px 16px;margin-bottom:8px;box-shadow:0 2px 10px rgba(15,39,68,.10);border:1px solid #e2e8f0;display:flex;gap:14px;align-items:flex-start}
  .student-photo{width:80px;height:80px;border-radius:10px;overflow:hidden;flex-shrink:0;border:2px solid #e2e8f0;background:#f8faff}
  .student-photo img{width:100%;height:100%;object-fit:cover}
  .student-photo .no-photo{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:28px;color:#94a3b8;background:#f1f5f9}
  .student-meta{flex:1;min-width:0}
  .student-name{font-size:16px;font-weight:900;color:#0f2744;margin-bottom:4px}
  .student-id{font-size:10px;color:#94a3b8;font-family:monospace;margin-bottom:6px;direction:ltr;text-align:right}
  .student-badges{display:flex;flex-wrap:wrap;gap:5px;margin-bottom:6px}
  .badge{display:inline-block;padding:2px 9px;border-radius:20px;font-size:10px;font-weight:700;white-space:nowrap}
  .badge-active{background:#dcfce7;color:#15803d;border:1px solid #86efac}
  .badge-hold{background:#ffedd5;color:#c2410c;border:1px solid #fed7aa}
  .badge-high{background:#dbeafe;color:#1d4ed8;border:1px solid #93c5fd}
  .badge-mid{background:#f0fdf4;color:#15803d;border:1px solid #86efac}
  .badge-exam{background:#f3e8ff;color:#7e22ce;border:1px solid #d8b4fe}
  .badge-regular{background:#e0f2fe;color:#0369a1;border:1px solid #7dd3fc}
  .student-line{display:flex;gap:16px;flex-wrap:wrap;font-size:10.5px;color:#475569}
  .student-line span{display:flex;align-items:center;gap:4px}

  /* ══ بطاقة المالية ══ */
  .finance-card{background:#fff;border-radius:12px;padding:12px 16px;margin-bottom:8px;box-shadow:0 2px 10px rgba(15,39,68,.10);border:1px solid #e2e8f0}
  .section-title{font-size:11px;font-weight:800;color:#1a3c5e;margin-bottom:10px;padding-bottom:5px;border-bottom:2px solid #e2e8f0;display:flex;align-items:center;gap:5px;letter-spacing:.3px}
  .section-title::before{content:'';display:inline-block;width:4px;height:14px;background:#1e5a94;border-radius:2px;flex-shrink:0}
  .fin-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:10px}
  .fin-box{border-radius:8px;padding:8px 10px;text-align:center}
  .fin-box .f-lbl{font-size:8.5px;font-weight:600;margin-bottom:2px}
  .fin-box .f-val{font-size:14px;font-weight:900}
  .fin-charged{background:#eff6ff;border:1px solid #bfdbfe}.fin-charged .f-lbl{color:#1d4ed8}.fin-charged .f-val{color:#1d4ed8}
  .fin-paid{background:#f0fdf4;border:1px solid #86efac}.fin-paid .f-lbl{color:#15803d}.fin-paid .f-val{color:#15803d}
  .fin-debt{background:#fef2f2;border:1px solid #fca5a5}.fin-debt .f-lbl{color:#dc2626}.fin-debt .f-val{color:#dc2626}
  .fin-pct{background:#f5f3ff;border:1px solid #c4b5fd}.fin-pct .f-lbl{color:#7c3aed}.fin-pct .f-val{color:#7c3aed}
  .fin-zero{background:#f0fdf4;border:1px solid #86efac}.fin-zero .f-lbl{color:#15803d}.fin-zero .f-val{color:#15803d}
  .progress-wrap{background:#e5e7eb;border-radius:4px;height:7px;overflow:hidden}
  .progress-bar{height:7px;border-radius:4px}

  /* ══ شبكة المعلومات ══ */
  .info-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:6px 16px}
  .info-cell{padding:5px 8px;border-radius:6px;background:#f8faff;border:1px solid #e8eef7}
  .info-lbl{font-size:8.5px;color:#94a3b8;font-weight:600;margin-bottom:1px}
  .info-val{font-size:11px;font-weight:700;color:#1a3c5e}.info-val.mono{font-family:monospace;font-size:10.5px}

  /* ══ الأوراق الثبوتية ══ */
  .docs-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:5px}
  .doc-row{display:flex;align-items:center;gap:6px;padding:4px 8px;border-radius:6px;background:#f8faff;border:1px solid #e8eef7}
  .doc-icon{font-size:11px;font-weight:900;width:16px;text-align:center}.doc-icon.ok{color:#16a34a}.doc-icon.miss{color:#dc2626}
  .doc-lbl{flex:1;font-size:10.5px;color:#374151}
  .badge-ok{background:#dcfce7;color:#15803d;padding:1px 7px;border-radius:20px;font-size:9px;font-weight:700;border:1px solid #86efac}
  .badge-miss{background:#fee2e2;color:#dc2626;padding:1px 7px;border-radius:20px;font-size:9px;font-weight:700;border:1px solid #fca5a5}

  /* ══ التذييل ══ */
  .footer{margin-top:10px;background:#fff;border-radius:12px;padding:12px 20px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 2px 8px rgba(15,39,68,.08);border-top:3px solid #1a3c5e}
  .footer-logo-wrap{display:flex;align-items:center;gap:8px}
  .footer-logo{width:36px;height:36px;border-radius:50%;overflow:hidden;border:2px solid #1a3c5e}
  .footer-logo img{width:100%;height:100%;object-fit:cover}
  .footer-copy{font-size:9px;color:#94a3b8;line-height:1.8}
  .sig-block{text-align:center}
  .sig-box{border:1.5px solid #1a3c5e;border-radius:7px;padding:6px 22px;margin-bottom:5px;background:#f8faff}
  .sig-box .role{font-size:10.5px;font-weight:800;color:#1a3c5e;display:block}
  .sig-box .dept{font-size:9px;color:#475569;display:block;margin-top:1px}
  .sig-line{border-bottom:1.5px dashed #94a3b8;width:180px;height:24px;margin:0 auto 4px}
  .sig-stamp{font-size:8.5px;color:#94a3b8}

  /* watermark */
  .watermark{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%) rotate(-35deg);font-size:64px;font-weight:900;color:rgba(30,90,148,.03);white-space:nowrap;pointer-events:none;z-index:0;letter-spacing:5px}

  @media print{
    @page{size:A4 portrait;margin:5mm}
    body{background:#fff}
    .page{background:#fff;padding:5mm 7mm}
    .hdr,.fin-charged,.fin-paid,.fin-debt,.fin-pct,.fin-zero,.badge,.info-cell,.doc-row{-webkit-print-color-adjust:exact;print-color-adjust:exact}
  }
</style>
</head>
<body>
<div class="watermark">معهد القمة</div>
<div class="page">

  <!-- الرأس -->
  <div class="hdr">
    <div class="hdr-logo"><img src="${LOGO}" alt="شعار معهد القمة"/></div>
    <div class="hdr-text">
      <h1>معهد القمة للعلوم الطبية والإدارية</h1>
      <div class="sub1">الملف الشامل للطالب — وثيقة رسمية</div>
      <div class="sub2">يُرجى الاحتفاظ بهذه الوثيقة في السجلات الرسمية للمعهد</div>
    </div>
    <div class="hdr-right">
      <div class="hdr-date"><span class="lbl">تاريخ الإصدار</span><span class="val">${today}</span></div>
    </div>
  </div>

  <!-- بطاقة الطالب -->
  <div class="student-card">
    <div class="student-photo">
      ${student.photo_url
        ? `<img src="${student.photo_url}" alt="${student.full_name}" crossorigin="anonymous"/>`
        : `<div class="no-photo">👤</div>`}
    </div>
    <div class="student-meta">
      <div class="student-name">${student.full_name}</div>
      <div class="student-id">${student.national_id}</div>
      <div class="student-badges">
        <span class="badge ${student.status === 'نشط' ? 'badge-active' : 'badge-hold'}">${student.status}</span>
        <span class="badge ${student.diploma_type === 'عالي' ? 'badge-high' : 'badge-mid'}">${student.diploma_type}</span>
        <span class="badge ${student.is_exam_only ? 'badge-exam' : 'badge-regular'}">${student.is_exam_only ? 'طالب 100' : 'نظامي'}</span>
      </div>
      <div class="student-line">
        <span>📚 ${student.specialization}</span>
        <span>🎓 ${semLbl}</span>
        ${student.phone ? `<span>📞 ${student.phone}</span>` : ''}
        ${student.gender ? `<span>👤 ${student.gender}</span>` : ''}
      </div>
    </div>
  </div>

  <!-- البيانات الشخصية -->
  <div class="finance-card">
    <div class="section-title">البيانات الشخصية والأكاديمية</div>
    <div class="info-grid">
      ${infoRow('الاسم الرباعي', student.full_name)}
      ${infoRow('الرقم الوطني', student.national_id, true)}
      ${infoRow('الجنسية', student.nationality || 'ليبي')}
      ${infoRow('تاريخ التسجيل', student.enrollment_date ? new Date(student.enrollment_date).toLocaleDateString('ar-LY') : null)}
      ${infoRow('نوع الدبلوم', student.diploma_type)}
      ${infoRow('التخصص', student.specialization)}
      ${infoRow('الفصل الحالي', semLbl)}
      ${infoRow('الحالة الدراسية', student.status)}
      ${infoRow('نوع القيد', student.is_exam_only ? 'طالب 100 (امتحانات فقط)' : 'نظامي')}
      ${infoRow('رقم الهاتف', student.phone)}
      ${infoRow('هاتف ولي الأمر', student.guardian_phone)}
      ${infoRow('الجنس', student.gender)}
      ${infoRow('العنوان', student.address)}
    </div>
  </div>

  <!-- الوضع المالي -->
  <div class="finance-card">
    <div class="section-title">الوضع المالي</div>
    <div class="fin-grid">
      <div class="fin-box fin-charged">
        <div class="f-lbl">إجمالي المستحق</div>
        <div class="f-val">${student.total_charged.toLocaleString('ar-LY', { maximumFractionDigits: 0 })}</div>
        <div style="font-size:8.5px;color:#1d4ed8;margin-top:1px">دينار ليبي</div>
      </div>
      <div class="fin-box fin-paid">
        <div class="f-lbl">إجمالي المدفوع</div>
        <div class="f-val">${student.total_paid.toLocaleString('ar-LY', { maximumFractionDigits: 0 })}</div>
        <div style="font-size:8.5px;color:#15803d;margin-top:1px">دينار ليبي</div>
      </div>
      <div class="fin-box ${debtAmt > 0 ? 'fin-debt' : 'fin-zero'}">
        <div class="f-lbl">المتبقي</div>
        <div class="f-val">${debtAmt > 0 ? debtAmt.toLocaleString('ar-LY', { maximumFractionDigits: 0 }) : '✓ مسدد'}</div>
        <div style="font-size:8.5px;margin-top:1px;color:${debtAmt > 0 ? '#dc2626' : '#15803d'}">${debtAmt > 0 ? 'دينار ليبي' : 'بالكامل'}</div>
      </div>
      <div class="fin-box fin-pct">
        <div class="f-lbl">نسبة التحصيل</div>
        <div class="f-val">${paidPct}%</div>
        <div style="font-size:8.5px;color:#7c3aed;margin-top:1px">من إجمالي المستحق</div>
      </div>
    </div>
    <div class="progress-wrap">
      <div class="progress-bar" style="width:${paidPct}%;background:${debtAmt <= 0 ? '#16a34a' : paidPct > 60 ? '#f59e0b' : '#dc2626'}"></div>
    </div>
  </div>

  <!-- الأوراق الثبوتية -->
  <div class="finance-card">
    <div class="section-title">الأوراق الثبوتية</div>
    <div class="docs-grid">
      ${docRow('شهادة الميلاد', !!student.has_birth_certificate)}
      ${docRow('شهادة التسجيل', !!student.has_registration_certificate)}
      ${docRow('ملف المعلق', !!student.has_suspended_file)}
      ${docRow(`الصور الشخصية (${student.photos_received}/${student.photos_required})`, student.photos_received >= student.photos_required)}
    </div>
    ${student.notes ? `<div style="margin-top:8px;padding:7px 10px;background:#fffbeb;border:1px solid #fcd34d;border-radius:7px;font-size:10.5px;color:#92400e"><b>ملاحظات:</b> ${student.notes}</div>` : ''}
  </div>

  <!-- التذييل -->
  <div class="footer">
    <div class="footer-logo-wrap">
      <div class="footer-logo"><img src="${LOGO}" alt=""/></div>
      <div class="footer-copy">
        <div style="font-weight:700;color:#1a3c5e;font-size:10px">معهد القمة للعلوم الطبية والإدارية</div>
        <div>جميع الحقوق محفوظة &copy; ${new Date().getFullYear()}</div>
        <div>صدر بتاريخ: ${today}</div>
      </div>
    </div>
    <div class="sig-block">
      <div class="sig-box">
        <span class="role">مدير شؤون الطلاب</span>
        <span class="dept">معهد القمة للعلوم الطبية والإدارية</span>
      </div>
      <div class="sig-line"></div>
      <div class="sig-stamp">التوقيع والختم الرسمي</div>
    </div>
  </div>

</div>
<script>window.onload = function(){ setTimeout(function(){ window.print(); }, 400); };</script>
</body>
</html>`);
    win.document.close();
  };

  return (
    <MainLayout>
      <div className="space-y-5 max-w-4xl mx-auto pb-10" id="print-area">

        {/* ── شريط التنقل الاحترافي ── */}
        <div className="no-print flex items-center gap-0 bg-card border border-border/70 rounded-2xl px-2 py-1.5 shadow-md shadow-black/5 backdrop-blur-sm">
          {/* زر الرجوع */}
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-muted-foreground hover:text-foreground hover:bg-muted/70 transition-all duration-150 text-[13px] font-semibold shrink-0 group"
          >
            <ChevronRight className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform duration-150" />
            <span className="hidden sm:inline">لوحة التحكم</span>
          </button>

          {/* فاصل */}
          <ChevronRight className="w-3 h-3 text-border shrink-0 mx-0.5" />

          {/* اسم الطالب + أيقونة */}
          <div className="flex items-center gap-2 flex-1 min-w-0 px-1">
            <div className="w-6 h-6 rounded-lg bg-primary/15 flex items-center justify-center shrink-0 ring-1 ring-primary/20">
              <User className="w-3.5 h-3.5 text-primary" />
            </div>
            <span className="text-[13px] font-bold text-foreground truncate">{student.full_name}</span>
          </div>

          {/* keyframes للوميض الذهبي ووميض رقم القيد */}
          <style>{`
            @keyframes goldPulse {
              0%,100% { box-shadow: 0 0 8px 2px rgba(232,190,60,.35), 0 4px 10px rgba(100,60,0,.35); }
              50%      { box-shadow: 0 0 22px 7px rgba(248,210,60,.65), 0 4px 16px rgba(140,80,0,.5); }
            }
            @keyframes regPulse {
              0%,100% { box-shadow: 0 0 10px 2px rgba(245, 158, 11, 0.4), 0 4px 12px rgba(217, 119, 6, 0.35); }
              50%      { box-shadow: 0 0 24px 8px rgba(245, 158, 11, 0.75), 0 6px 18px rgba(234, 88, 12, 0.55); }
            }
          `}</style>
        </div>

        {/* ── شريط وضع الاستعادة ── */}
        {restoreSONum && (
          <div className="no-print flex items-center gap-3 px-4 py-3 rounded-xl border-2 border-orange-400/60 bg-orange-50">
            <div className="w-8 h-8 rounded-lg bg-orange-500/15 flex items-center justify-center shrink-0">
              <AlertTriangle className="w-4 h-4 text-orange-600" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-[13px] font-bold text-orange-800 leading-tight">
                وضع استعادة المعاملة — رقم <span className="font-mono">{restoreSONum}</span>
              </p>
              <p className="text-[11px] text-orange-600/80 mt-0.5">
                أي دفعة تضيفها لهذا الطالب ستُسجَّل تحت رقم المعاملة المحذوفة أعلاه
              </p>
            </div>
            <button onClick={clearRestoreMode}
              className="shrink-0 inline-flex items-center gap-1 h-7 px-2.5 rounded-lg text-[11px] font-semibold text-orange-700 border border-orange-300 bg-white hover:bg-orange-100 transition-colors">
              <X className="w-3 h-3" /> إلغاء
            </button>
          </div>
        )}

        {/* ── بطاقة الهوية الرئيسية ── */}
        <div className="relative rounded-2xl overflow-hidden shadow-lg">
          {/* خلفية متدرجة */}
          <div className="absolute inset-0 bg-gradient-to-br from-primary via-primary/90 to-primary/70" />
          <div className="absolute inset-0 opacity-10"
            style={{ backgroundImage: 'radial-gradient(circle at 20% 80%, white 1px, transparent 1px), radial-gradient(circle at 80% 20%, white 1px, transparent 1px)', backgroundSize: '30px 30px' }} />

          <div className="relative p-5 md:p-6">
            <div className="flex flex-col md:flex-row gap-5 items-start md:items-center">

              {/* الصورة الشخصية */}
              <div className="relative shrink-0">
                <div className="w-24 h-24 md:w-28 md:h-28 rounded-2xl overflow-hidden border-2 border-white/40 shadow-xl bg-white/10 ring-4 ring-white/10">
                  {student.photo_url ? (
                    <img src={student.photo_url} alt={student.full_name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center gap-1 bg-white/5">
                      <User className="w-9 h-9 text-white/50" />
                      <span className="text-[9px] text-white/40 font-medium">لا توجد صورة</span>
                    </div>
                  )}
                </div>
                {/* أزرار تغيير الصورة */}
                <div className="absolute -bottom-2 -left-2 flex gap-1 no-print">
                  {/* التقاط من الكاميرا */}
                  <button
                    onClick={() => avatarCameraRef.current?.click()}
                    disabled={avatarLoading}
                    title="التقاط من الكاميرا"
                    className="w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-md hover:bg-white/90 transition-colors"
                  >
                    {avatarLoading
                      ? <div className="w-3.5 h-3.5 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                      : <Camera className="w-3.5 h-3.5 text-primary" />}
                  </button>
                  {/* رفع من الملفات */}
                  <button
                    onClick={() => avatarInputRef.current?.click()}
                    disabled={avatarLoading}
                    title="رفع من الملفات"
                    className="w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-md hover:bg-white/90 transition-colors"
                  >
                    <FolderOpen className="w-3.5 h-3.5 text-primary" />
                  </button>
                </div>
                {/* مدخلات مخفية */}
                <input ref={avatarCameraRef} type="file" accept="image/*" capture="user" className="hidden" onChange={handleAvatarChange} />
                <input ref={avatarInputRef}  type="file" accept="image/*"               className="hidden" onChange={handleAvatarChange} />
              </div>

              {/* بيانات الطالب الرئيسية */}
              <div className="flex-1 min-w-0 text-white">
                <div className="flex flex-wrap items-start gap-2 mb-1">
                  <h1 className="text-xl md:text-2xl font-bold text-balance">{student.full_name}</h1>
                  <Badge className={`text-xs border ${statusCfg.className} bg-transparent shrink-0`}>
                    {statusCfg.label}
                  </Badge>
                  {student.is_exam_only && (
                    <Badge className="text-xs border border-purple-300/60 bg-purple-500/20 text-purple-100 shrink-0 flex items-center gap-1">
                      <ClipboardList className="w-3 h-3" /> طالب 100
                    </Badge>
                  )}
                  {!student.is_exam_only && (
                    <Badge className="text-xs border border-sky-300/60 bg-sky-500/20 text-sky-100 shrink-0 flex items-center gap-1">
                      <ClipboardList className="w-3 h-3" /> نظامي
                    </Badge>
                  )}
                </div>
                <div className="flex items-center gap-2 mb-3 flex-wrap">
                  <p className="text-white/70 text-sm font-mono">{student.national_id}</p>
                  <span className="text-white/30">•</span>
                  {student.registration_number ? (
                    <button
                      type="button"
                      onClick={() => {
                        setNewRegNumber(student.registration_number ?? '');
                        setRegNumberModalOpen(true);
                      }}
                      className="no-print inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-white/20 hover:bg-white/30 border border-white/30 text-white text-xs font-mono font-bold transition-all hover:scale-105 active:scale-95 shadow-sm"
                      title="انقر لتعديل رقم القيد"
                    >
                      <Hash className="w-3 h-3 text-amber-300" />
                      <span>رقم القيد: {student.registration_number}</span>
                      <Edit className="w-2.5 h-2.5 opacity-80 mr-0.5" />
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        setNewRegNumber('');
                        setRegNumberModalOpen(true);
                      }}
                      className="no-print inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white text-xs font-black shadow-lg border border-amber-300 transition-all hover:scale-105 active:scale-95"
                      style={{
                        animation: 'regPulse 2s ease-in-out infinite',
                      }}
                    >
                      <Hash className="w-3.5 h-3.5" />
                      <span>إضافة رقم قيد الطالب</span>
                      <span className="w-1.5 h-1.5 rounded-full bg-white shadow-sm" style={{ animation: 'ping 1.5s cubic-bezier(0, 0, 0.2, 1) infinite' }} />
                    </button>
                  )}
                </div>

                <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-white/80">
                  <span className="flex items-center gap-1.5">
                    <GraduationCap className="w-3.5 h-3.5 shrink-0" />
                    {student.diploma_type} — {student.specialization}
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 shrink-0" />
                    {SEMESTER_LABELS[student.current_semester] ?? `الفصل ${student.current_semester}`}
                  </span>
                  {student.phone && (
                    <span className="flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 shrink-0" />{student.phone}
                    </span>
                  )}
                </div>

                {/* المؤشر المالي السريع */}
                <div className={`mt-3 inline-flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full border ${debt > 0 ? 'bg-red-500/20 border-red-300/30 text-red-100' : 'bg-emerald-500/20 border-emerald-300/30 text-emerald-100'}`}>
                  {debt > 0 ? <AlertTriangle className="w-3 h-3" /> : <CheckCircle className="w-3 h-3" />}
                  {debt > 0 ? `مديونية: ${debt.toFixed(0)} د.ل` : 'الحساب مسدد بالكامل'}
                </div>
              </div>

              {/* أزرار الإجراءات والخدمات السريعة (تنسيق منظم يمنع التداخل نهائياً) */}
              <div className="w-full md:w-auto shrink-0 flex flex-col gap-2 no-print">
                {editMode ? (
                  <div className="flex flex-col gap-2 min-w-[140px]">
                    <motion.div whileTap={{ scale: 0.95 }} whileHover={{ y: -1 }} transition={{ type: 'spring', stiffness: 400, damping: 20 }}>
                      <Button size="sm" onClick={handleSaveEdit} disabled={actionLoading}
                        className="gap-1.5 font-bold bg-white text-foreground
                          shadow-[0_2px_10px_-2px_rgba(255,255,255,0.5)]
                          hover:bg-white/90 hover:shadow-[0_4px_16px_-2px_rgba(255,255,255,0.6)]
                          transition-all duration-200 w-full h-9 rounded-xl">
                        <Save className="w-3.5 h-3.5 text-primary" /> حفظ التعديلات
                      </Button>
                    </motion.div>
                    <motion.div whileTap={{ scale: 0.95 }} whileHover={{ y: -1 }} transition={{ type: 'spring', stiffness: 400, damping: 20 }}>
                      <Button size="sm" onClick={() => { setEditMode(false); setEditForm(student); }}
                        className="gap-1.5 bg-white/15 text-white border border-white/25
                          hover:bg-white/25 hover:border-white/40 hover:shadow-sm
                          transition-all duration-200 w-full h-9 rounded-xl">
                        <X className="w-3.5 h-3.5" /> إلغاء
                      </Button>
                    </motion.div>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-2 min-w-[270px]">
                    {/* زر تعديل البيانات */}
                    {can('student_profile', 'edit') && (
                      <motion.div whileTap={{ scale: 0.95 }} whileHover={{ y: -1 }}>
                        <Button
                          size="sm"
                          onClick={openEditPersonalModal}
                          className="w-full h-9 gap-1.5 font-bold bg-white text-slate-800 border border-white/40 hover:bg-white/95 hover:shadow-md transition-all text-xs rounded-xl shadow-sm"
                        >
                          <UserCog className="w-3.5 h-3.5 text-primary" />
                          <span>تعديل البيانات</span>
                        </Button>
                      </motion.div>
                    )}

                    {/* زر المالية */}
                    {can('student_finance', 'view') && (
                      <motion.div whileTap={{ scale: 0.95 }} whileHover={{ y: -1 }}>
                        <Button
                          size="sm"
                          onClick={() => navigate(`/finance?student=${id}`)}
                          className="w-full h-9 gap-1.5 font-bold bg-emerald-500/95 text-white border border-emerald-400/50 hover:bg-emerald-600 shadow-sm transition-all text-xs rounded-xl"
                        >
                          <DollarSign className="w-3.5 h-3.5" />
                          <span>المالية</span>
                        </Button>
                      </motion.div>
                    )}

                    {/* زر طباعة السجل */}
                    {can('student_profile', 'print') && (
                      <motion.div whileTap={{ scale: 0.95 }} whileHover={{ y: -1 }}>
                        <Button
                          size="sm"
                          onClick={handlePrintProfile}
                          className="w-full h-9 gap-1.5 font-semibold bg-white/15 text-white border border-white/25 hover:bg-white/25 hover:border-white/40 text-xs rounded-xl shadow-sm"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          <span>طباعة السجل</span>
                        </Button>
                      </motion.div>
                    )}

                    {/* زر تعريف الطالب الفاخر */}
                    <motion.div whileTap={{ scale: 0.95 }} whileHover={{ y: -1 }}>
                      <button
                        onClick={handlePrintStudentID}
                        className="w-full h-9 flex items-center justify-center gap-1.5 px-2.5 rounded-xl text-xs font-bold shadow-md cursor-pointer transition-all active:scale-95"
                        style={{
                          background: 'linear-gradient(135deg, #7a5500 0%, #b8892a 20%, #e8c84a 40%, #fde97a 52%, #e8c84a 65%, #b8892a 82%, #7a5500 100%)',
                          border: '1px solid rgba(255,235,130,.8)',
                          color: '#2d1800',
                          textShadow: '0 1px 0 rgba(255,220,80,.6)',
                        }}
                        title="طباعة بطاقة تعريف الطالب"
                      >
                        <FileCheck className="w-3.5 h-3.5 text-amber-950 shrink-0" />
                        <span className="whitespace-nowrap">تعريف الطالب</span>
                      </button>
                    </motion.div>

                    {/* زر طباعة استمارة التسجيل الرسمية */}
                    <motion.div whileTap={{ scale: 0.95 }} whileHover={{ y: -1 }}>
                      <button
                        onClick={() => {
                          if (!student) return;
                          printRegistrationForm({
                            student: {
                              ...student,
                              photos_required: student.photos_required ?? 6,
                              photos_received: student.photos_received ?? 0,
                              has_birth_certificate: !!student.has_birth_certificate,
                              has_registration_certificate: !!student.has_registration_certificate,
                              has_suspended_file: !!student.has_suspended_file,
                            },
                            financial: {
                              registrationFee: 100,
                              semesterFee: student.diploma_type === 'عالي' ? 600 : 550,
                              initialPayment: 0,
                              receiptNumber: null,
                            },
                            photoPreviewUrl: student.photo_url,
                          });
                        }}
                        className="w-full h-9 flex items-center justify-center gap-1.5 px-2.5 rounded-xl text-xs font-bold shadow-md cursor-pointer transition-all active:scale-95 bg-gradient-to-r from-blue-700 via-indigo-600 to-blue-700 text-white border border-blue-400/40"
                        title="طباعة استمارة التسجيل الرسمية بالأختام الثلاثة"
                      >
                        <FileText className="w-3.5 h-3.5 text-blue-200 shrink-0" />
                        <span className="whitespace-nowrap">استمارة التسجيل</span>
                      </button>
                    </motion.div>

                    {/* زر واتساب */}
                    {student.phone ? (
                      <motion.div whileTap={{ scale: 0.95 }} whileHover={{ y: -1 }}>
                        <a
                          href={`https://wa.me/${student.phone.replace(/[\s\-()]/g, '').replace(/^0/, '218')}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          title={`واتساب — ${student.phone}`}
                          className="w-full h-9 flex items-center justify-center gap-1.5 px-2.5 rounded-xl bg-[#25D366] hover:bg-[#20BD5C] active:scale-95 transition-all shadow-md text-white text-xs font-bold"
                        >
                          <svg viewBox="0 0 32 32" className="w-3.5 h-3.5 fill-white shrink-0" xmlns="http://www.w3.org/2000/svg">
                            <path d="M16 .5C7.44.5.5 7.44.5 16c0 2.76.72 5.36 1.97 7.62L.5 31.5l8.1-2.12A15.45 15.45 0 0 0 16 31.5C24.56 31.5 31.5 24.56 31.5 16S24.56.5 16 .5zm0 28.3a13.2 13.2 0 0 1-6.72-1.84l-.48-.29-4.98 1.3 1.33-4.84-.31-.5A13.16 13.16 0 0 1 2.7 16C2.7 9.17 8.17 3.7 16 3.7S29.3 9.17 29.3 16 23.83 28.8 16 28.8zm7.23-9.88c-.4-.2-2.34-1.15-2.7-1.28-.36-.13-.62-.2-.88.2s-1.01 1.28-1.24 1.54c-.23.26-.46.3-.86.1a10.84 10.84 0 0 1-3.19-1.97 11.96 11.96 0 0 1-2.21-2.74c-.23-.4-.02-.61.17-.81.18-.18.4-.46.6-.69.2-.23.26-.4.4-.66.13-.26.06-.5-.03-.69-.1-.2-.88-2.12-1.2-2.9-.32-.76-.64-.66-.88-.67l-.75-.01c-.26 0-.69.1-1.05.5s-1.38 1.35-1.38 3.29 1.41 3.82 1.61 4.08c.2.26 2.78 4.25 6.74 5.95.94.41 1.68.65 2.25.83.95.3 1.81.26 2.49.16.76-.11 2.34-.96 2.67-1.88.33-.93.33-1.72.23-1.89-.1-.17-.36-.27-.76-.47z"/>
                          </svg>
                          <span className="whitespace-nowrap">واتساب</span>
                        </a>
                      </motion.div>
                    ) : (
                      <div className="hidden md:block" />
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* ── شريط الإجراءات الثانوية ── */}
        <div className="flex flex-wrap gap-2 no-print">
          {can('students', 'edit') && (
            student.status === 'نشط' ? (
              <motion.button
                onClick={handleSuspend}
                disabled={actionLoading}
                whileTap={actionLoading ? {} : { scale: 0.94 }}
                whileHover={actionLoading ? {} : { scale: 1.04 }}
                transition={{ type: 'spring', stiffness: 450, damping: 22 }}
                className="inline-flex items-center gap-2 h-9 px-4 rounded-lg text-[13px] font-semibold
                  bg-amber-500 text-white border-0
                  shadow-[0_2px_8px_rgba(245,158,11,0.45)]
                  hover:bg-amber-600 hover:shadow-[0_4px_16px_rgba(245,158,11,0.55)]
                  disabled:opacity-50 disabled:cursor-not-allowed
                  transition-[background,box-shadow] duration-150 select-none">
                {actionLoading
                  ? <div className="w-3.5 h-3.5 border-2 border-white/50 border-t-white rounded-full animate-spin" />
                  : <PauseCircle className="w-3.5 h-3.5 shrink-0" />}
                إيقاف القيد
              </motion.button>
            ) : (
              <motion.button
                onClick={handleActivate}
                disabled={actionLoading}
                whileTap={actionLoading ? {} : { scale: 0.94 }}
                whileHover={actionLoading ? {} : { scale: 1.04 }}
                transition={{ type: 'spring', stiffness: 450, damping: 22 }}
                className="inline-flex items-center gap-2 h-9 px-4 rounded-lg text-[13px] font-semibold
                  bg-emerald-500 text-white border-0
                  shadow-[0_2px_8px_rgba(16,185,129,0.45)]
                  hover:bg-emerald-600 hover:shadow-[0_4px_16px_rgba(16,185,129,0.55)]
                  disabled:opacity-50 disabled:cursor-not-allowed
                  transition-[background,box-shadow] duration-150 select-none">
                {actionLoading
                  ? <div className="w-3.5 h-3.5 border-2 border-white/50 border-t-white rounded-full animate-spin" />
                  : <PlayCircle className="w-3.5 h-3.5 shrink-0" />}
                تنشيط القيد
              </motion.button>
            )
          )}

          {/* زر طالب 100 / نظامي */}
          {can('students', 'edit') && (
            <motion.button
              onClick={handleToggleExamOnly}
              whileTap={{ scale: 0.94 }}
              whileHover={{ scale: 1.04 }}
              transition={{ type: 'spring', stiffness: 450, damping: 22 }}
              className={`inline-flex items-center gap-2 h-9 px-4 rounded-lg text-[13px] font-semibold
                text-white border-0 select-none
                transition-[background,box-shadow] duration-150
                ${student.is_exam_only
                  ? 'bg-violet-600 shadow-[0_2px_8px_rgba(124,58,237,0.45)] hover:bg-violet-700 hover:shadow-[0_4px_16px_rgba(124,58,237,0.55)]'
                  : 'bg-sky-500 shadow-[0_2px_8px_rgba(14,165,233,0.4)] hover:bg-sky-600 hover:shadow-[0_4px_16px_rgba(14,165,233,0.55)]'}`}>
              <ClipboardList className="w-3.5 h-3.5 shrink-0" />
              {student.is_exam_only ? 'طالب 100' : 'نظامي'}
              {/* toggle pill */}
              <span dir="ltr" className="relative inline-flex items-center w-8 h-4 rounded-full bg-white/25 shrink-0">
                <span className={`absolute w-3 h-3 rounded-full bg-white shadow transition-transform duration-300
                  ${student.is_exam_only ? 'translate-x-[18px]' : 'translate-x-[2px]'}`} />
              </span>
            </motion.button>
          )}

          {can('students', 'delete') && (
            <motion.button
              onClick={() => { setShowDeleteDialog(true); setDeletePassword(''); setDeleteError(''); }}
              whileTap={{ scale: 0.94 }}
              whileHover={{ scale: 1.04 }}
              transition={{ type: 'spring', stiffness: 450, damping: 22 }}
              className="inline-flex items-center gap-2 h-9 px-4 rounded-lg text-[13px] font-semibold
                bg-red-500 text-white border-0
                shadow-[0_2px_8px_rgba(239,68,68,0.4)]
                hover:bg-red-600 hover:shadow-[0_4px_16px_rgba(239,68,68,0.55)]
                transition-[background,box-shadow] duration-150 select-none">
              <Trash2 className="w-3.5 h-3.5 shrink-0" />
              حذف الملف
            </motion.button>
          )}
        </div>

        {/* رأسية الطباعة */}
        <div className="print-only text-center py-4 border-b border-border mb-4">
          <h2 className="text-xl font-bold">معهد القمة للعلوم الطبية والإدارية</h2>
          <p className="text-sm text-muted-foreground">الملف الشامل للطالب</p>
        </div>

        {/* ── البيانات الشخصية والأكاديمية ── */}
        <Card className="shadow-sm border-border/60">
          <CardHeader className="pb-2 pt-4 px-5">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <CardTitle className="text-sm font-semibold flex items-center gap-2 text-foreground">
                <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center">
                  <User className="w-3.5 h-3.5 text-primary" />
                </div>
                البيانات الشخصية والأكاديمية
              </CardTitle>
              {can('student_profile', 'edit') && (
                <motion.button
                  type="button"
                  onClick={openEditPersonalModal}
                  whileTap={{ scale: 0.94 }}
                  whileHover={{ scale: 1.02 }}
                  className="no-print inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold text-primary bg-primary/10 hover:bg-primary/20 border border-primary/20 hover:border-primary/35 shadow-xs transition-all cursor-pointer"
                >
                  <UserCog className="w-3.5 h-3.5 text-primary" />
                  <span>تعديل البيانات الشخصية</span>
                </motion.button>
              )}
            </div>
          </CardHeader>
          <CardContent className="px-5 pb-5">
            {editMode ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  { key: 'full_name' as const, label: 'الاسم الرباعي' },
                  { key: 'phone' as const, label: 'رقم الهاتف' },
                  { key: 'guardian_phone' as const, label: 'هاتف ولي الأمر' },
                  { key: 'address' as const, label: 'العنوان السكني' },
                ].map(field => (
                  <div key={field.key} className="space-y-1.5">
                    <Label className="text-sm font-normal">{field.label}</Label>
                    <Input value={(editForm[field.key] as string) ?? ''} className="text-sm"
                      onChange={e => setEditForm(p => ({ ...p, [field.key]: e.target.value || null }))} />
                  </div>
                ))}
                <div className="space-y-1.5">
                  <Label className="text-sm font-normal">التخصص (القسم)</Label>
                  <Select value={editForm.specialization ?? ''} onValueChange={v => setEditForm(p => ({ ...p, specialization: v }))}>
                    <SelectTrigger className="text-sm"><SelectValue placeholder="اختر التخصص" /></SelectTrigger>
                    <SelectContent>
                      {specializations.map(s => (
                        <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-sm font-normal">الصور المستلمة</Label>
                  <Input type="text" inputMode="numeric" className="text-sm"
                    value={editForm.photos_received ?? 0}
                    onChange={e => setEditForm(p => ({ ...p, photos_received: parseInt(e.target.value) || 0 }))} />
                </div>
                <div className="md:col-span-2 flex flex-wrap gap-5 pt-1">
                  {[
                    { key: 'has_birth_certificate' as const, label: 'شهادة ميلاد' },
                    { key: 'has_registration_certificate' as const, label: 'شهادة التسجيل' },
                    { key: 'has_suspended_file' as const, label: 'ملف معلق' },
                  ].map(doc => (
                    <div key={doc.key} className="flex items-center gap-2 min-h-12">
                      <Checkbox id={`edit_${doc.key}`} checked={editForm[doc.key] ?? false}
                        onCheckedChange={v => setEditForm(p => ({ ...p, [doc.key]: !!v }))} />
                      <Label htmlFor={`edit_${doc.key}`} className="text-sm font-normal cursor-pointer">{doc.label}</Label>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div id="section-personal">
                {/* معلومات شخصية */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-5">
                  {/* الاسم والرقم */}
                  <div className="md:col-span-2 flex flex-wrap gap-3">
                    <div className="flex-1 min-w-[200px] bg-primary/5 border border-primary/15 rounded-xl p-4">
                      <p className="text-xs text-muted-foreground mb-1 flex items-center gap-1.5"><User className="w-3 h-3" /> الاسم الكامل</p>
                      <p className="text-base font-bold text-foreground">{student.full_name}</p>
                    </div>
                    <div className="flex-1 min-w-[130px] bg-muted/40 border border-border/50 rounded-xl p-4">
                      <p className="text-xs text-muted-foreground mb-1 flex items-center gap-1.5"><span>🌍</span> الجنسية</p>
                      <p className="text-base font-bold text-foreground">{student.nationality || 'ليبي'}</p>
                    </div>
                    <div className="flex-1 min-w-[160px] bg-muted/50 border border-border/50 rounded-xl p-4">
                      <p className="text-xs text-muted-foreground mb-1 flex items-center gap-1.5"><CreditCard className="w-3 h-3" /> الرقم الوطني</p>
                      <p className="text-base font-bold font-mono tracking-widest text-foreground">{student.national_id}</p>
                    </div>
                  </div>

                  {/* أرقام الهاتف — قابلة للنقر */}
                  {[
                    { label: 'رقم هاتف الطالب', phone: student.phone, owner: 'الطالب' },
                    { label: 'هاتف ولي الأمر', phone: student.guardian_phone, owner: 'ولي الأمر' },
                  ].map(item => (
                    <div key={item.label}
                      onClick={() => item.phone && item.phone !== '—' && setCallTarget({ phone: item.phone, label: item.owner })}
                      className={`rounded-xl border p-4 flex items-center gap-3 transition-all ${item.phone ? 'border-emerald-200 bg-emerald-50/50 hover:bg-emerald-50 cursor-pointer hover:shadow-sm' : 'border-border/40 bg-muted/30 opacity-60'}`}
                    >
                      <div className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${item.phone ? 'bg-emerald-500 text-white' : 'bg-muted text-muted-foreground'}`}>
                        <Phone className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs text-muted-foreground">{item.label}</p>
                        <p className={`text-sm font-bold font-mono ${item.phone ? 'text-emerald-700' : 'text-muted-foreground'}`}>
                          {item.phone ?? 'غير مسجل'}
                        </p>
                      </div>
                      {item.phone && <PhoneCall className="w-3.5 h-3.5 text-emerald-500 mr-auto shrink-0" />}
                    </div>
                  ))}

                  {/* العنوان */}
                  <div className="bg-muted/30 border border-border/40 rounded-xl p-4 flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-blue-100 flex items-center justify-center shrink-0">
                      <MapPin className="w-4 h-4 text-blue-600" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs text-muted-foreground">العنوان السكني</p>
                      <p className="text-sm font-medium text-foreground truncate">{student.address ?? '—'}</p>
                    </div>
                  </div>
                </div>

                {/* البيانات الأكاديمية */}
                <div className="rounded-xl border border-border/50 bg-gradient-to-br from-primary/3 to-primary/8 p-4 mb-4">
                  <p className="text-xs font-semibold text-primary mb-3 flex items-center gap-1.5">
                    <GraduationCap className="w-3.5 h-3.5" /> البيانات الأكاديمية
                  </p>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {[
                      { label: 'نوع الدبلوم', value: student.diploma_type, accent: 'text-primary' },
                      { label: 'التخصص / القسم', value: student.specialization, accent: 'text-foreground' },
                      { label: 'الفصل الدراسي', value: SEMESTER_LABELS[student.current_semester] ?? `الفصل ${student.current_semester}`, accent: 'text-foreground' },
                    ].map(item => (
                      <div key={item.label}>
                        <p className="text-xs text-muted-foreground mb-0.5">{item.label}</p>
                        <p className={`text-sm font-semibold ${item.accent}`}>{item.value}</p>
                      </div>
                    ))}
                  </div>
                  {student.is_equivalency && (
                    <div className="mt-3 pt-3 border-t border-primary/15">
                      <p className="text-xs font-semibold text-primary mb-1">طالب معادلة — الفصول المعادلة:</p>
                      <div className="flex flex-wrap gap-1.5">
                        {(student.equivalency_equivalent_semesters ?? []).map(s => (
                          <span key={s} className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">{SEMESTER_LABELS[s]}</span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* موقف الأوراق الثبوتية والمستندات */}
                <div className="bg-muted/20 border border-border/70 rounded-2xl p-4 space-y-3.5">
                  <div className="flex items-center justify-between flex-wrap gap-2 pb-1 border-b border-border/40">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-600 dark:text-amber-400">
                        <FileText className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <p className="text-xs font-bold text-foreground flex items-center gap-1.5">
                          موقف الأوراق الثبوتية والمستندات الرسمية
                        </p>
                        <p className="text-[11px] text-muted-foreground">
                          {missingDocs.length === 0
                            ? 'جميع الأوراق الثبوتية مكتملة ومودعة بالملف الأكاديمي'
                            : `يوجد (${missingDocs.length}) من النواقص يلزم استيفاؤها`}
                        </p>
                      </div>
                    </div>
                    {can('student_profile', 'edit') && (
                      <motion.button
                        type="button"
                        onClick={openDocsDialog}
                        whileTap={{ scale: 0.95 }}
                        whileHover={{ scale: 1.03 }}
                        className="no-print inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-amber-600 via-amber-500 to-amber-600 hover:from-amber-700 hover:via-amber-600 hover:to-amber-700 shadow-md shadow-amber-500/30 border border-amber-400/40 transition-all cursor-pointer ring-2 ring-amber-400/20 active:scale-95"
                      >
                        <FileCheck className="w-4 h-4 text-white drop-shadow-xs" />
                        <span>تعديل النواقص والمستندات</span>
                        {missingDocs.length > 0 ? (
                          <span className="bg-red-600 text-white text-[10px] px-2 py-0.5 rounded-full font-extrabold shadow-xs animate-pulse">
                            {missingDocs.length} ناقص
                          </span>
                        ) : (
                          <span className="bg-emerald-600 text-white text-[10px] px-2 py-0.5 rounded-full font-bold shadow-xs">
                            مكتمل ✓
                          </span>
                        )}
                      </motion.button>
                    )}
                  </div>

                  {/* شبكة بطاقات المستندات الأربعة */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5">
                    {/* بطاقة الصور الشخصية */}
                    <div className={`flex flex-col justify-between p-3 rounded-xl border transition-all ${student.photos_received >= student.photos_required ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-800 dark:text-emerald-300' : 'bg-red-500/10 border-red-500/30 text-red-700 dark:text-red-300'}`}>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-bold flex items-center gap-1.5">
                          <Camera className="w-3.5 h-3.5" /> الصور الشخصية
                        </span>
                        {student.photos_received >= student.photos_required
                          ? <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                          : <AlertTriangle className="w-4 h-4 text-red-500 shrink-0" />}
                      </div>
                      <div className="flex items-baseline justify-between">
                        <span className="text-sm font-bold font-mono">
                          {student.photos_received} / {student.photos_required}
                        </span>
                        <span className={`text-[10px] px-2 py-0.5 rounded-md font-bold ${student.photos_received >= student.photos_required ? 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-300' : 'bg-red-500/20 text-red-600 dark:text-red-300'}`}>
                          {student.photos_received >= student.photos_required ? 'مكتملة' : `ناقص (${student.photos_required - student.photos_received})`}
                        </span>
                      </div>
                    </div>

                    {/* بطاقات المستندات الثلاثة */}
                    {[
                      { has: student.has_birth_certificate, label: 'شهادة الميلاد', icon: FileText },
                      { has: student.has_registration_certificate, label: 'شهادة التسجيل / المؤهل', icon: GraduationCap },
                      { has: student.has_suspended_file, label: 'الملف المعلق', icon: FolderOpen },
                    ].map(doc => (
                      <div
                        key={doc.label}
                        className={`flex flex-col justify-between p-3 rounded-xl border transition-all ${doc.has ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-800 dark:text-emerald-300' : 'bg-red-500/10 border-red-500/30 text-red-700 dark:text-red-300'}`}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs font-bold flex items-center gap-1.5 truncate">
                            <doc.icon className="w-3.5 h-3.5 shrink-0" />
                            <span className="truncate">{doc.label}</span>
                          </span>
                          {doc.has
                            ? <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                            : <AlertTriangle className="w-4 h-4 text-red-500 shrink-0" />}
                        </div>
                        <div className="text-left">
                          <span className={`inline-block text-[10px] px-2 py-0.5 rounded-md font-bold ${doc.has ? 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-300' : 'bg-red-500/20 text-red-600 dark:text-red-300'}`}>
                            {doc.has ? 'تم الاستلام' : 'غير مسلّم'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* شريط تفصيلي للنواقص إن وُجدت أو شارة الاكتمال */}
                  {missingDocs.length > 0 ? (
                    <div className="flex items-center gap-2.5 text-xs text-red-700 dark:text-red-300 bg-red-500/10 border border-red-500/25 rounded-xl px-3.5 py-2.5">
                      <AlertTriangle className="w-4 h-4 text-red-500 shrink-0" />
                      <div className="flex-1">
                        <span className="font-bold">المستندات المطلوبة لاستيفاء الملف: </span>
                        <span>{missingDocs.join(' • ')}</span>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 text-xs text-emerald-700 dark:text-emerald-300 bg-emerald-500/10 border border-emerald-500/25 rounded-xl px-3.5 py-2">
                      <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                      <span className="font-semibold">الملف الأكاديمي للطالب مستوفٍ لكافة الأوراق الثبوتية بنسبة 100%</span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* مشروع التخرج */}
            {student.current_semester === 6 && student.diploma_type === 'عالي' && (
              <div className="mt-4 bg-emerald-50/50 border border-emerald-200/60 rounded-lg p-4 space-y-3">
                <p className="text-xs font-semibold text-emerald-700 flex items-center gap-1.5">
                  <BookOpen className="w-3.5 h-3.5" /> بيانات مشروع التخرج
                </p>
                {editMode ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {[
                      { key: 'project_name' as const, label: 'اسم المشروع' },
                      { key: 'project_supervisor' as const, label: 'الدكتور المشرف' },
                    ].map(f => (
                      <div key={f.key} className="space-y-1">
                        <Label className="text-xs">{f.label}</Label>
                        <Input value={(editForm[f.key] as string) ?? ''} className="text-sm h-8"
                          onChange={e => setEditForm(p => ({ ...p, [f.key]: e.target.value }))} />
                      </div>
                    ))}
                    <div className="md:col-span-2 space-y-1">
                      <Label className="text-xs">نبذة عن المشروع</Label>
                      <Input value={editForm.project_summary ?? ''} className="text-sm h-8"
                        onChange={e => setEditForm(p => ({ ...p, project_summary: e.target.value }))} />
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                    <div><span className="text-muted-foreground">اسم المشروع: </span><span className="font-medium">{student.project_name ?? '—'}</span></div>
                    <div><span className="text-muted-foreground">الدكتور المشرف: </span><span className="font-medium">{student.project_supervisor ?? '—'}</span></div>
                    <div className="md:col-span-2"><span className="text-muted-foreground">النبذة: </span>{student.project_summary ?? '—'}</div>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* ── ملفات الطالب ── */}
        <Card className="shadow-sm border-border/60">
          <CardHeader className="pb-2 pt-4 px-5">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <CardTitle className="text-sm font-semibold flex items-center gap-2 text-foreground">
                <div className="w-7 h-7 rounded-lg bg-blue-500/10 flex items-center justify-center">
                  <Paperclip className="w-3.5 h-3.5 text-blue-600" />
                </div>
                ملفات الطالب
                {studentFiles.length > 0 && (
                  <Badge variant="secondary" className="text-xs">{studentFiles.length}</Badge>
                )}
              </CardTitle>
              <div className="flex gap-2 no-print">
                {studentFiles.length > 0 && (
                  <Button size="sm" onClick={() => printSection('section-files', `ملفات الطالب — ${student.full_name}`)}
                    className="gap-1.5 h-8 text-xs bg-slate-600 text-white border-slate-600 hover:bg-slate-700 hover:border-slate-700 shadow-sm font-semibold">
                    <Printer className="w-3.5 h-3.5" /> طباعة الكل
                  </Button>
                )}
                <Button size="sm" variant="outline" onClick={() => filePickRef.current?.click()} disabled={fileUploading}
                  className="gap-1.5 h-8 text-xs border-blue-500/40 text-blue-600 hover:bg-blue-50">
                  <FileUp className="w-3.5 h-3.5" /> رفع ملف
                </Button>
                <Button size="sm" variant="outline" onClick={() => cameraRef.current?.click()} disabled={fileUploading}
                  className="gap-1.5 h-8 text-xs border-emerald-500/40 text-emerald-600 hover:bg-emerald-50">
                  <Camera className="w-3.5 h-3.5" /> تصوير
                </Button>
                <input ref={filePickRef} type="file" accept="image/*,application/pdf" className="hidden" onChange={handleFileUpload} />
                <input ref={cameraRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={handleFileUpload} />
              </div>
            </div>
          </CardHeader>
          <CardContent className="px-5 pb-5">
            {fileUploading && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
                <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                جاري رفع الملف...
              </div>
            )}
            {studentFiles.length === 0 && !fileUploading ? (
              <div className="text-center py-8 text-muted-foreground">
                <Upload className="w-8 h-8 mx-auto mb-2 opacity-30" />
                <p className="text-sm">لا توجد ملفات مرفوعة بعد</p>
                <p className="text-xs mt-1">استخدم أزرار رفع ملف أو التصوير لإضافة وثائق</p>
              </div>
            ) : (
              <div id="section-files" className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {studentFiles.map((file, idx) => (
                  <div key={file.id} className="group relative rounded-xl border border-border/60 overflow-hidden bg-muted/30 hover:shadow-md transition-shadow">
                    {file.file_type === 'image' ? (
                      <div className="aspect-[4/3] overflow-hidden">
                        <img src={file.file_url} alt={file.file_name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200" />
                      </div>
                    ) : (
                      <div className="aspect-[4/3] flex flex-col items-center justify-center bg-gradient-to-br from-blue-50 to-blue-100/50 gap-1">
                        <FileText className="w-10 h-10 text-blue-400" />
                        <span className="text-xs text-blue-500 font-medium">PDF</span>
                      </div>
                    )}
                    <div className="p-2">
                      <p className="text-xs font-medium truncate">{file.label ?? file.file_name}</p>
                      <p className="text-xs text-muted-foreground">{new Date(file.created_at).toLocaleDateString('ar-LY')}</p>
                    </div>
                    {/* أزرار التحكم */}
                    <div className="absolute top-2 left-2 hidden group-hover:flex gap-1 no-print">
                      <button onClick={() => setPreviewFile(file)}
                        className="w-7 h-7 bg-white/95 rounded-full flex items-center justify-center shadow-md hover:bg-white">
                        <Eye className="w-3.5 h-3.5 text-primary" />
                      </button>
                      <button
                        onClick={() => printSingleFile(file.file_url, file.label ?? file.file_name, file.file_type)}
                        className="w-7 h-7 bg-white/95 rounded-full flex items-center justify-center shadow-md hover:bg-white"
                        title="طباعة"
                      >
                        <Printer className="w-3.5 h-3.5 text-foreground" />
                      </button>
                      <button onClick={() => handleDeleteFile(file.id)}
                        className="w-7 h-7 bg-white/95 rounded-full flex items-center justify-center shadow-md hover:bg-red-50">
                        <Trash className="w-3.5 h-3.5 text-destructive" />
                      </button>
                    </div>
                    {/* رقم الملف */}
                    <div className="absolute top-2 right-2 w-5 h-5 bg-black/40 text-white text-xs rounded-full flex items-center justify-center font-mono no-print">
                      {idx + 1}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* ── السجل المالي ── */}
        {can('student_finance', 'view') && (
          <Card className="shadow-sm border-border/60">
          <CardHeader className="pb-2 pt-4 px-5">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <CardTitle className="text-sm font-semibold flex items-center gap-2 text-foreground">
                <div className="w-7 h-7 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                  <DollarSign className="w-3.5 h-3.5 text-emerald-600" />
                </div>
                السجل المالي
              </CardTitle>
              <div className="flex items-center gap-2 flex-wrap">
                <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border ${debt > 0 ? 'bg-destructive/8 border-destructive/25 text-destructive' : 'bg-emerald-500/8 border-emerald-500/25 text-emerald-600'}`}>
                  {debt > 0 ? <AlertTriangle className="w-3 h-3" /> : <CheckCircle className="w-3 h-3" />}
                  {debt > 0 ? `مديونية: ${debt.toFixed(0)} د.ل` : 'مسدد بالكامل'}
                </div>
                <Button size="sm" onClick={() => printFinancialRecord(student, charges, receipts)}
                  className="gap-1.5 h-7 text-xs no-print bg-slate-600 text-white border-slate-600 hover:bg-slate-700 hover:border-slate-700 shadow-sm font-semibold">
                  <Printer className="w-3 h-3" /> طباعة الكل
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="px-5 pb-5 space-y-5">
            <div id="section-finance-all">
              {/* ملخص مالي */}
              <div className="grid grid-cols-3 gap-3 mb-5">
                {[
                  { label: 'إجمالي المستحق', value: student.total_charged.toFixed(0), color: 'text-foreground', bg: 'bg-muted/50', border: 'border-border/50' },
                  { label: 'المدفوع', value: student.total_paid.toFixed(0), color: 'text-emerald-700', bg: 'bg-emerald-50/80', border: 'border-emerald-200/60' },
                  { label: 'المتبقي', value: debt.toFixed(0), color: debt > 0 ? 'text-red-700' : 'text-emerald-700', bg: debt > 0 ? 'bg-red-50/80' : 'bg-emerald-50/80', border: debt > 0 ? 'border-red-200/60' : 'border-emerald-200/60' },
                ].map(item => (
                  <div key={item.label} className={`${item.bg} border ${item.border} rounded-xl p-4 text-center`}>
                    <p className="text-xs text-muted-foreground mb-1">{item.label}</p>
                    <p className={`text-lg font-bold ${item.color}`}>{item.value}</p>
                    <p className="text-xs text-muted-foreground">دينار ليبي</p>
                  </div>
                ))}
              </div>

              {/* جدول الرسوم */}
              {charges.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center no-print">
                    <p className="text-xs font-semibold text-muted-foreground flex items-center gap-1.5">
                      <FileText className="w-3.5 h-3.5" /> كشف الرسوم المفروضة
                    </p>
                  </div>
                  <div id="section-charges" className="w-full overflow-x-auto rounded-xl border border-border/50">
                    <table className="w-full min-w-max">
                      <thead>
                        <tr className="bg-gradient-to-l from-muted/60 to-muted/30 border-b border-border/50">
                          {['البند', 'الرسوم الكلية', 'المدفوع', 'المتبقي', 'الحالة'].map(h => (
                            <th key={h} className="text-xs text-muted-foreground text-right px-4 py-3 whitespace-nowrap font-semibold">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {charges.map((c, i) => (
                          <tr key={c.id} className={`border-b border-border/30 hover:bg-muted/20 transition-colors ${i % 2 === 0 ? '' : 'bg-muted/10'}`}>
                            <td className="px-4 py-3 text-xs whitespace-nowrap font-semibold">
                              {c.charge_type === 'تسجيل' ? '🔖 رسوم التسجيل' :
                                c.charge_type === 'معادلة' ? `🔄 رسوم معادلة ${SEMESTER_LABELS[c.semester_number] ?? `الفصل ${c.semester_number}`}` :
                                c.charge_type === 'مشروع تخرج' ? '🎓 رسوم مشروع التخرج' :
                                `📅 ${SEMESTER_LABELS[c.semester_number] ?? `الفصل ${c.semester_number}`}`}
                            </td>
                            <td className="px-4 py-3 text-xs font-mono whitespace-nowrap text-foreground font-semibold">{c.charge_amount.toFixed(0)} د.ل</td>
                            <td className="px-4 py-3 text-xs font-mono whitespace-nowrap text-emerald-600 font-semibold">{c.paid_amount.toFixed(0)} د.ل</td>
                            <td className="px-4 py-3 text-xs font-mono whitespace-nowrap font-semibold" style={{color: c.remaining_amount > 0 ? '#dc2626' : '#16a34a'}}>
                              {c.remaining_amount.toFixed(0)} د.ل
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap">
                              <span className={`inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded-full font-semibold ${c.is_cleared ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-600'}`}>
                                {c.is_cleared ? <CheckCircle className="w-3 h-3" /> : <AlertTriangle className="w-3 h-3" />}
                                {c.is_cleared ? 'مسدد' : 'معلق'}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                      <tfoot>
                        <tr className="bg-muted/40 border-t-2 border-border/60">
                          <td className="px-4 py-2.5 text-xs font-bold">الإجمالي</td>
                          <td className="px-4 py-2.5 text-xs font-mono font-bold">{charges.reduce((s,c)=>s+c.charge_amount,0).toFixed(0)} د.ل</td>
                          <td className="px-4 py-2.5 text-xs font-mono font-bold text-emerald-600">{charges.reduce((s,c)=>s+c.paid_amount,0).toFixed(0)} د.ل</td>
                          <td className="px-4 py-2.5 text-xs font-mono font-bold text-destructive">{charges.reduce((s,c)=>s+c.remaining_amount,0).toFixed(0)} د.ل</td>
                          <td />
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </div>
              )}

              {/* كشف الإيصالات */}
              {receipts.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center no-print">
                    <p className="text-xs font-semibold text-muted-foreground flex items-center gap-1.5">
                      <ReceiptIcon className="w-3.5 h-3.5" /> كشف الإيصالات
                    </p>
                  </div>
                  <div id="section-receipts" className="w-full overflow-x-auto rounded-xl border border-border/50">
                    <table className="w-full min-w-max">
                      <thead>
                        <tr className="bg-gradient-to-l from-emerald-50/60 to-emerald-50/20 border-b border-border/50">
                          {['رقم الإيصال', 'التاريخ والوقت', 'المبلغ', 'نوع الدفعة', 'طباعة'].map(h => (
                            <th key={h} className="text-xs text-muted-foreground text-right px-4 py-3 whitespace-nowrap font-semibold">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {sortReceiptsOldestFirst(receipts).map((r, i) => (
                          <tr key={r.id} className={`border-b border-border/30 hover:bg-muted/20 transition-colors ${i % 2 === 0 ? '' : 'bg-muted/10'}`}>
                            <td className="px-4 py-3 whitespace-nowrap">
                              <span className="text-xs font-mono font-bold text-primary bg-primary/8 px-2 py-0.5 rounded-md">{r.receipt_number}</span>
                            </td>
                            <td className="px-4 py-3 text-xs whitespace-nowrap text-muted-foreground">
                              {new Date(r.paid_at).toLocaleString('ar-LY', { dateStyle: 'medium', timeStyle: 'short' })}
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap">
                              <span className="text-sm font-bold text-emerald-600">{r.amount.toFixed(0)}</span>
                              <span className="text-xs text-muted-foreground mr-1">د.ل</span>
                            </td>
                            <td className="px-4 py-3 text-xs whitespace-nowrap">{r.semester_target ?? r.payment_type}</td>
                            <td className="px-4 py-3 whitespace-nowrap no-print">
                              <button
                                onClick={() => printSingleReceipt(r.receipt_number, r.paid_at, r.amount, r.payment_type, r.semester_target, student.full_name)}
                                className="inline-flex items-center gap-1 text-xs px-2.5 py-1.5 rounded-lg bg-slate-600 text-white hover:bg-slate-700 transition-all font-semibold shadow-sm"
                                title="طباعة الإيصال"
                              >
                                <Printer className="w-3 h-3" /> طباعة
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                      <tfoot>
                        <tr className="bg-emerald-50/60 border-t-2 border-emerald-200/60">
                          <td colSpan={2} className="px-4 py-2.5 text-xs font-bold">إجمالي المدفوعات ({receipts.length} إيصال)</td>
                          <td className="px-4 py-2.5 text-sm font-bold text-emerald-600">{receipts.reduce((s,r)=>s+r.amount,0).toFixed(0)} <span className="text-xs font-normal">د.ل</span></td>
                          <td colSpan={2} />
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
        )}

        {/* خانات الختم للطباعة */}
        <div className="print-only mt-8 grid grid-cols-2 gap-8">
          <div className="text-center border-t border-border pt-4">
            <p className="text-sm text-muted-foreground">ختم المعهد</p>
          </div>
          <div className="text-center border-t border-border pt-4">
            <p className="text-sm text-muted-foreground">توقيع الإدارة المسؤولة</p>
          </div>
        </div>
      </div>

      {/* ── حوار تسجيل الدفعة ── */}
      <Dialog open={showPaymentDialog} onOpenChange={o => { if (!o) { setShowPaymentDialog(false); setPaymentAmount(''); setPaymentNotes(''); setPaymentDate(new Date().toISOString().slice(0, 10)); } }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md p-0 overflow-hidden [&>button]:hidden" dir="rtl">
          <DialogTitle className="sr-only">تسجيل دفعة مالية</DialogTitle>

          {/* ── رأس الحوار ── */}
          <div className="relative overflow-hidden px-5 py-5" style={{ background: 'linear-gradient(135deg, #059669 0%, #047857 60%, #065f46 100%)' }}>
            {/* نقاط زخرفية */}
            <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '18px 18px' }} />
            {/* خط زخرفي */}
            <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/30 to-transparent" />
            <div className="relative flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-white/15 border border-white/20 flex items-center justify-center shadow-inner backdrop-blur-sm">
                  <DollarSign className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white tracking-wide">تسجيل دفعة مالية</h3>
                  <p className="text-[11px] text-emerald-100/80 mt-0.5 font-medium">{student?.full_name}</p>
                </div>
              </div>
              <button
                onClick={() => setShowPaymentDialog(false)}
                className="w-8 h-8 rounded-xl bg-white/10 border border-white/20 flex items-center justify-center hover:bg-white/25 transition-all active:scale-90">
                <X className="w-4 h-4 text-white" />
              </button>
            </div>
          </div>

          {/* ── المحتوى ── */}
          <div className="p-5 space-y-3.5 bg-background">

            {/* تنبيه المديونية */}
            {debt > 0 && (
              <div className="flex items-center gap-3 bg-destructive/5 border border-destructive/15 rounded-2xl p-3.5">
                <div className="w-9 h-9 rounded-xl bg-destructive/10 flex items-center justify-center shrink-0">
                  <AlertTriangle className="w-4 h-4 text-destructive" />
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-bold text-destructive">مديونية حالية: {debt.toFixed(0)} د.ل</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">سيتم توجيه الدفعة للديون الأقدم أولاً</p>
                </div>
              </div>
            )}

            {/* ── الحقلان الأفقيان: رقم الإيصال + المبلغ ── */}
            <div className="grid grid-cols-2 gap-3">
              {/* رقم الإيصال */}
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold text-muted-foreground flex items-center gap-1">
                  <CheckCircle className="w-3 h-3" />رقم الإيصال
                </Label>
                <Input
                  value={paymentReceiptNum}
                  onChange={e => setPaymentReceiptNum(e.target.value.replace(/\D/g, ''))}
                  inputMode="numeric"
                  className="text-sm font-mono text-center bg-muted/40 border-border/60 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/20 rounded-xl h-11 font-bold"
                  placeholder="000001"
                />
              </div>

              {/* المبلغ */}
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold text-muted-foreground flex items-center gap-1">
                  <DollarSign className="w-3 h-3" />المبلغ
                </Label>
                <div className="relative">
                  <Input
                    type="text"
                    inputMode="decimal"
                    value={paymentAmount}
                    onChange={e => setPaymentAmount(e.target.value)}
                    placeholder="0.00"
                    className="text-base font-black text-center pr-8 bg-muted/40 border-border/60 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/20 rounded-xl h-11 text-emerald-700"
                  />
                  <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[10px] font-black text-emerald-600/70 pointer-events-none">د.ل</span>
                </div>
              </div>
            </div>

            {/* ── تاريخ الدفع ── */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <Label className="text-xs font-semibold text-muted-foreground flex items-center gap-1">
                  <Calendar className="w-3 h-3" />تاريخ الدفع
                </Label>
                {paymentDate !== new Date().toISOString().slice(0, 10) && (
                  <button
                    type="button"
                    onClick={() => setPaymentDate(new Date().toISOString().slice(0, 10))}
                    className="text-[10px] text-emerald-600 hover:underline font-bold">
                    ← اليوم
                  </button>
                )}
              </div>
              <SmartDateInput value={paymentDate} onChange={setPaymentDate} />
              {paymentDate !== new Date().toISOString().slice(0, 10) && (
                <p className="text-[10px] text-amber-600 font-semibold flex items-center gap-1 px-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0" />
                  تاريخ مخصص — سيُسجَّل الإيصال بهذا التاريخ
                </p>
              )}
            </div>

            {/* ── الملاحظات ── */}
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold text-muted-foreground">
                ملاحظات <span className="font-normal text-muted-foreground/50">(اختياري)</span>
              </Label>
              <Input
                value={paymentNotes}
                onChange={e => setPaymentNotes(e.target.value)}
                placeholder="بيان إضافي عن الدفعة..."
                className="text-sm bg-muted/40 border-border/60 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/20 rounded-xl h-10"
              />
            </div>

            {/* ── فاصل ── */}
            <div className="h-px bg-border/40 rounded" />

            {/* ── أزرار الإجراء ── */}
            <div className="flex gap-2.5">
              <button
                onClick={() => setShowPaymentDialog(false)}
                className="flex-1 h-11 rounded-xl border border-border/60 text-sm font-semibold text-muted-foreground hover:bg-muted/60 transition-all active:scale-95">
                إلغاء
              </button>
              <button
                onClick={handlePayment}
                disabled={actionLoading}
                className="flex-[2] h-11 rounded-xl text-sm font-bold text-white transition-all active:scale-95 disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-md shadow-emerald-500/25"
                style={{ background: 'linear-gradient(135deg, #10b981 0%, #059669 60%, #047857 100%)' }}>
                {actionLoading
                  ? <><div className="w-4 h-4 border-2 border-white/80 border-t-transparent rounded-full animate-spin" />جاري الحفظ...</>
                  : <><CheckCircle className="w-4 h-4" />تأكيد وحفظ الإيصال</>
                }
              </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── حوار الحذف ── */}
      <Dialog open={showDeleteDialog} onOpenChange={o => { if (!o) { setShowDeleteDialog(false); setDeletePassword(''); setDeleteError(''); } }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md p-0 overflow-hidden">
          {/* رأس أحمر */}
          <div className="bg-gradient-to-br from-red-600 to-red-700 px-5 py-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
              <Trash2 className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white leading-tight">حذف ملف الطالب</h2>
              <p className="text-red-200 text-xs mt-0.5">إجراء لا يمكن التراجع عنه</p>
            </div>
          </div>

          <div className="px-5 py-4 space-y-4">
            {/* تحذير */}
            <div className="flex gap-3 p-3 rounded-xl bg-red-50 border border-red-200">
              <AlertTriangle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
              <p className="text-sm text-red-700 leading-relaxed">
                سيتم حذف ملف <strong className="font-bold">{student.full_name}</strong> نهائياً مع جميع بياناته وسجلاته. هذا الإجراء <strong>لا يمكن التراجع عنه</strong>.
              </p>
            </div>

            {/* حقل الرمز السري */}
            <div className="space-y-1.5">
              <Label className="text-sm font-semibold text-foreground flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-red-500 inline-block" />
                الرمز السري الأمني للتأكيد
              </Label>
              <Input
                type="password"
                inputMode="numeric"
                pattern="[0-9]*"
                autoComplete="one-time-code"
                placeholder="أدخل الرمز السري (5224410)..."
                value={deletePassword}
                onChange={e => { setDeletePassword(e.target.value.replace(/\D/g, '')); setDeleteError(''); }}
                className="text-sm font-mono text-center tracking-widest border-red-200 focus-visible:ring-red-400"
                onKeyDown={e => e.key === 'Enter' && handleDelete()}
              />
              {deleteError && (
                <p className="text-xs text-red-600 flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3" /> {deleteError}
                </p>
              )}
            </div>
          </div>

          <DialogFooter className="px-5 pb-4 gap-2 flex-row-reverse sm:flex-row-reverse">
            <Button
              variant="outline"
              onClick={() => setShowDeleteDialog(false)}
              className="flex-1 sm:flex-none">
              إلغاء
            </Button>
            <Button
              onClick={handleDelete}
              disabled={actionLoading || !deletePassword}
              className="flex-1 sm:flex-none bg-red-600 hover:bg-red-700 text-white gap-1.5 font-semibold disabled:opacity-50">
              {actionLoading
                ? <><div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" /> جاري الحذف...</>
                : <><Trash2 className="w-3.5 h-3.5" /> حذف نهائي</>}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── حوار تأكيد الاتصال الهاتفي ── */}
      <Dialog open={!!callTarget} onOpenChange={o => { if (!o) setCallTarget(null); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-emerald-700">
              <PhoneCall className="w-5 h-5" /> الاتصال بـ {callTarget?.label}
            </DialogTitle>
          </DialogHeader>
          <div className="text-center py-4 space-y-3">
            <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto">
              <Phone className="w-8 h-8 text-emerald-600" />
            </div>
            <p className="text-2xl font-bold font-mono text-foreground tracking-widest">{callTarget?.phone}</p>
            <p className="text-sm text-muted-foreground">هل تريد الاتصال بـ <strong>{callTarget?.label}</strong>؟</p>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setCallTarget(null)}>إلغاء</Button>
            <Button
              className="bg-emerald-600 hover:bg-emerald-700 text-white gap-2"
              onClick={() => {
                if (!callTarget) return;
                const href = buildTelHref(callTarget.phone);
                setCallTarget(null);
                // نفتح الرابط مباشرةً بعد إغلاق الحوار
                setTimeout(() => { window.location.href = href; }, 80);
              }}>
              <PhoneCall className="w-4 h-4" /> اتصال الآن
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── حوار معاينة الملف ── */}
      <Dialog open={!!previewFile} onOpenChange={o => { if (!o) setPreviewFile(null); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-sm">{previewFile?.label ?? previewFile?.file_name}</DialogTitle>
          </DialogHeader>
          {previewFile?.file_type === 'image' ? (
            <img src={previewFile.file_url} alt={previewFile.file_name} className="w-full rounded-lg object-contain max-h-[60vh]" />
            ) : (
              <div className="flex flex-col items-center py-8 gap-3">
                <FileText className="w-16 h-16 text-muted-foreground/40" />
                <p className="text-sm text-muted-foreground">{previewFile?.file_name}</p>
                <Button asChild variant="outline" size="sm">
                  <a href={previewFile?.file_url} target="_blank" rel="noreferrer">فتح الملف</a>
                </Button>
              </div>
            )}
          </DialogContent>
        </Dialog>

      {/* ── حوار تعديل الأوراق الثبوتية والنواقص (تصميم فاخر بألوان مميزة وتناسق تام للهاتف) ── */}
      <Dialog open={showDocsDialog} onOpenChange={o => { if (!o) setShowDocsDialog(false); }}>
        <DialogContent
          className="w-[calc(100vw-1.5rem)] max-w-lg bg-card border border-amber-500/30 p-0 rounded-2xl sm:rounded-3xl shadow-2xl max-h-[90dvh] overflow-hidden flex flex-col"
          dir="rtl"
        >
          {/* ترويسة فاخرة ذات ألوان مميزة وهوية المعهد */}
          <div className="bg-gradient-to-r from-amber-500/20 via-amber-500/10 to-primary/10 border-b border-amber-500/20 p-4 sm:p-5 shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-600 text-white flex items-center justify-center shadow-md shadow-amber-500/30 shrink-0">
                <FileCheck className="w-5 h-5 drop-shadow-xs" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <DialogTitle className="text-sm sm:text-base font-bold text-foreground">
                    تعديل الأوراق الثبوتية والنواقص
                  </DialogTitle>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-800 dark:text-amber-300 border border-amber-500/30">
                    معهد القمة
                  </span>
                </div>
                <DialogDescription className="text-xs text-muted-foreground mt-0.5 truncate">
                  ملف الطالب: <strong className="text-foreground">{student?.full_name}</strong>
                </DialogDescription>
              </div>
            </div>

            {/* شريط الإنجاز الذكي في الترويسة */}
            {(() => {
              const totalItems = 4;
              let completedItems = 0;
              if (docsForm.photos_received >= docsForm.photos_required) completedItems++;
              if (docsForm.has_birth_certificate) completedItems++;
              if (docsForm.has_registration_certificate) completedItems++;
              if (docsForm.has_suspended_file) completedItems++;
              const percent = Math.round((completedItems / totalItems) * 100);

              return (
                <div className="mt-3 pt-2.5 border-t border-amber-500/15 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5 min-w-0">
                    <span className="text-[11px] font-medium text-muted-foreground">حالة الاستيفاء:</span>
                    <span className={`text-[11px] font-bold ${completedItems === 4 ? 'text-emerald-600 dark:text-emerald-400' : 'text-amber-700 dark:text-amber-400'}`}>
                      {completedItems} من {totalItems} متطلبات مستلمة
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-20 sm:w-28 h-2 bg-muted rounded-full overflow-hidden border border-border/50">
                      <div
                        className={`h-full transition-all duration-500 ${completedItems === 4 ? 'bg-emerald-500' : 'bg-amber-500'}`}
                        style={{ width: `${percent}%` }}
                      />
                    </div>
                    <span className="text-[10px] font-bold font-mono text-muted-foreground">{percent}%</span>
                  </div>
                </div>
              );
            })()}
          </div>

          {/* محتوى النافذة القابل للتمرير بسلاسة دون قص */}
          <div className="p-4 sm:p-5 flex-1 overflow-y-auto overflow-x-hidden space-y-4">
            {/* قسم الصور الشخصية بتصميم بطاقة مميزة */}
            <div className="p-3.5 sm:p-4 rounded-2xl bg-gradient-to-br from-amber-500/5 via-card to-muted/40 border border-amber-500/25 space-y-3 shadow-2xs">
              <div className="flex items-center justify-between gap-2">
                <Label className="text-xs font-bold flex items-center gap-1.5 text-foreground">
                  <div className="w-6 h-6 rounded-lg bg-amber-500/15 flex items-center justify-center text-amber-600 dark:text-amber-400">
                    <Camera className="w-3.5 h-3.5" />
                  </div>
                  <span>الصور الشخصية المطلوبة (4x6)</span>
                </Label>
                <div className="flex items-center gap-1 shrink-0">
                  <span className="text-[11px] text-muted-foreground">المستلم:</span>
                  <span className={`text-[11px] font-bold px-2 py-0.5 rounded-md font-mono ${docsForm.photos_received >= docsForm.photos_required ? 'bg-emerald-500/20 text-emerald-800 dark:text-emerald-300 border border-emerald-500/30' : 'bg-red-500/20 text-red-700 dark:text-red-300 border border-red-500/30'}`}>
                    {docsForm.photos_received} من {docsForm.photos_required} صور
                  </span>
                </div>
              </div>

              {/* أداة التحكم الرقمي الذكية بالصور */}
              <div className="flex flex-col gap-2.5 pt-1">
                <div className="flex items-center justify-center gap-3 bg-background border border-amber-500/30 rounded-xl p-1.5 mx-auto w-fit shadow-xs">
                  <button
                    type="button"
                    onClick={() => setDocsForm(p => ({ ...p, photos_received: Math.max(0, p.photos_received - 1) }))}
                    className="w-8 h-8 rounded-lg hover:bg-amber-500/15 active:scale-90 flex items-center justify-center text-muted-foreground hover:text-amber-700 transition-all cursor-pointer"
                    title="نقصان"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <Input
                    type="text"
                    inputMode="numeric"
                    value={docsForm.photos_received}
                    onChange={e => setDocsForm(p => ({ ...p, photos_received: Math.max(0, parseInt(e.target.value.replace(/\D/g, '')) || 0) }))}
                    className="h-8 w-14 text-center font-bold text-sm border-0 focus-visible:ring-0 p-0 font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setDocsForm(p => ({ ...p, photos_received: Math.min(20, p.photos_received + 1) }))}
                    className="w-8 h-8 rounded-lg hover:bg-amber-500/15 active:scale-90 flex items-center justify-center text-muted-foreground hover:text-amber-700 transition-all cursor-pointer"
                    title="زيادة"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>

                {/* أزرار سريعة للأعداد الشائعة */}
                <div className="grid grid-cols-4 gap-1.5 w-full">
                  {[
                    { label: '6 صور (كامل)', val: 6 },
                    { label: '4 صور', val: 4 },
                    { label: '2 صور', val: 2 },
                    { label: '0 صور', val: 0 },
                  ].map(preset => (
                    <button
                      key={preset.val}
                      type="button"
                      onClick={() => setDocsForm(p => ({ ...p, photos_received: preset.val }))}
                      className={`text-[11px] py-1.5 px-1 rounded-lg border text-center transition-all cursor-pointer ${docsForm.photos_received === preset.val ? 'bg-amber-600 text-white border-amber-600 font-bold shadow-xs' : 'bg-background hover:bg-amber-500/10 border-border text-muted-foreground'}`}
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>

                {/* تمثيل بصري لكبسولات الصور الشخصية الستة */}
                <div className="grid grid-cols-6 gap-1.5 w-full pt-1">
                  {Array.from({ length: 6 }).map((_, idx) => {
                    const isReceived = idx < docsForm.photos_received;
                    return (
                      <div
                        key={idx}
                        className={`h-7 rounded-lg flex items-center justify-center border transition-all text-[10px] font-bold ${
                          isReceived
                            ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-700 dark:text-emerald-300 shadow-2xs'
                            : 'bg-muted/40 border-dashed border-border/80 text-muted-foreground/60'
                        }`}
                        title={`صورة رقم ${idx + 1}`}
                      >
                        {isReceived ? '✓' : idx + 1}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* قسم المستندات الرسمية الثلاثة ببطاقات لونية مميزة وتفاعلية */}
            <div className="space-y-2">
              <Label className="text-xs font-bold text-foreground flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                المستندات والأوراق الثبوتية الرسمية
              </Label>
              <div className="space-y-2">
                {[
                  {
                    key: 'has_birth_certificate' as const,
                    label: 'شهادة الميلاد الأصلية',
                    desc: 'شهادة ميلاد أصلية حديثة مستخرجة من السجل المدني',
                    icon: FileText,
                  },
                  {
                    key: 'has_registration_certificate' as const,
                    label: 'شهادة التسجيل / المؤهل العلمي',
                    desc: 'الشهادة الثانوية الأصلية أو شهادة التسجيل المعتمدة',
                    icon: GraduationCap,
                  },
                  {
                    key: 'has_suspended_file' as const,
                    label: 'الملف المعلق لحفظ المستندات',
                    desc: 'ملف بلاستيكي معلق لحفظ أوراق الطالب الإدارية',
                    icon: FolderOpen,
                  },
                ].map(doc => {
                  const isChecked = !!docsForm[doc.key];
                  return (
                    <div
                      key={doc.key}
                      onClick={() => setDocsForm(p => ({ ...p, [doc.key]: !p[doc.key] }))}
                      className={`flex items-center justify-between gap-2.5 p-3 sm:p-3.5 rounded-xl sm:rounded-2xl border transition-all cursor-pointer select-none active:scale-[0.99] ${
                        isChecked
                          ? 'bg-gradient-to-r from-emerald-500/15 via-emerald-500/5 to-card border-emerald-500/50 shadow-xs'
                          : 'bg-gradient-to-r from-red-500/10 via-red-500/5 to-card border-red-500/30 hover:border-red-500/50'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0 flex-1">
                        <div
                          className={`w-6 h-6 rounded-lg flex items-center justify-center transition-colors shrink-0 shadow-2xs ${
                            isChecked ? 'bg-emerald-600 text-white' : 'border-2 border-red-400/50 text-transparent'
                          }`}
                        >
                          <Check className="w-4 h-4 stroke-[3]" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className={`text-xs sm:text-sm font-bold transition-colors truncate ${isChecked ? 'text-emerald-900 dark:text-emerald-200' : 'text-foreground'}`}>
                            {doc.label}
                          </p>
                          <p className="text-[10px] sm:text-[11px] text-muted-foreground truncate">
                            {doc.desc}
                          </p>
                        </div>
                      </div>
                      <span
                        className={`text-[10px] sm:text-[11px] font-bold px-2.5 py-1 rounded-full shrink-0 shadow-2xs ${
                          isChecked
                            ? 'bg-emerald-500/20 text-emerald-800 dark:text-emerald-300 border border-emerald-500/40'
                            : 'bg-red-500/15 text-red-700 dark:text-red-300 border border-red-500/30'
                        }`}
                      >
                        {isChecked ? '✓ تم الاستلام' : '✕ غير مستلم'}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* بطاقة الملاحظات التلخيصية الذكية */}
            {(() => {
              const missingCount =
                (docsForm.photos_received < docsForm.photos_required ? 1 : 0) +
                (!docsForm.has_birth_certificate ? 1 : 0) +
                (!docsForm.has_registration_certificate ? 1 : 0) +
                (!docsForm.has_suspended_file ? 1 : 0);

              if (missingCount === 0) {
                return (
                  <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center gap-2 text-emerald-800 dark:text-emerald-300 text-xs font-semibold">
                    <CheckCircle className="w-4 h-4 shrink-0 text-emerald-600" />
                    <span>ممتاز! جميع الأوراق الثبوتية مكتملة ومودعة في ملف الطالب.</span>
                  </div>
                );
              }
              return (
                <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center gap-2 text-amber-800 dark:text-amber-300 text-xs font-semibold">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-amber-600" />
                  <span>تنبيه: يوجد ({missingCount}) من الأوراق الثبوتية غير مستلمة حتى الآن.</span>
                </div>
              );
            })()}
          </div>

          {/* تذييل النافذة الثابت المريح على الهواتف وكافة الأجهزة */}
          <div className="p-3.5 sm:p-4 bg-muted/20 border-t border-border/60 flex flex-col-reverse sm:flex-row-reverse gap-2 shrink-0">
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowDocsDialog(false)}
              disabled={docsSaving}
              className="w-full sm:w-auto rounded-xl text-xs h-9 sm:h-10"
            >
              إلغاء
            </Button>
            <Button
              type="button"
              onClick={handleSaveDocs}
              disabled={docsSaving}
              className="w-full sm:w-auto bg-gradient-to-r from-amber-600 via-amber-500 to-amber-600 hover:from-amber-700 hover:via-amber-600 hover:to-amber-700 text-white font-bold gap-1.5 rounded-xl text-xs shadow-md shadow-amber-500/25 border border-amber-400/40 h-9 sm:h-10"
            >
              {docsSaving ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white/60 border-t-white rounded-full animate-spin" />
                  <span>جارٍ الحفظ...</span>
                </>
              ) : (
                <>
                  <Save className="w-3.5 h-3.5" />
                  <span>حفظ تعديلات النواقص</span>
                </>
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── حوار تعديل البيانات الشخصية والأكاديمية (تصميم احترافي فاخر ومتجاوب) ── */}
      <Dialog open={editPersonalModalOpen} onOpenChange={setEditPersonalModalOpen}>
        <DialogContent
          className="w-[calc(100%-1.5rem)] sm:w-full max-w-[calc(100%-1.5rem)] sm:max-w-2xl bg-card border-border p-4 sm:p-6 rounded-2xl sm:rounded-3xl shadow-2xl max-h-[88dvh] overflow-y-auto overflow-x-hidden"
          dir="rtl"
        >
          <DialogHeader className="space-y-2 text-right border-b border-border/50 pb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-primary/10 border border-primary/25 flex items-center justify-center text-primary shrink-0">
                <UserCog className="w-6 h-6" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <DialogTitle className="text-base font-bold text-foreground">
                    تعديل البيانات الشخصية والأكاديمية
                  </DialogTitle>
                  <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-primary/10 text-primary border border-primary/20">
                    معهد القمة للعلوم الطبية والإدارية
                  </span>
                </div>
                <DialogDescription className="text-xs text-muted-foreground mt-0.5">
                  تعديل وتحديث السجل الأكاديمي والشخصي للطالب مع الحفظ الفوري
                </DialogDescription>
              </div>
            </div>
          </DialogHeader>

          <div className="space-y-5 py-2">
            {/* القسم الأول: البيانات الأساسية والهوية */}
            <div className="p-4 rounded-2xl bg-muted/20 border border-border/60 space-y-3.5">
              <div className="flex items-center gap-2 text-xs font-bold text-foreground pb-1 border-b border-border/40">
                <User className="w-3.5 h-3.5 text-primary" />
                <span>البيانات الأساسية والهوية</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {/* الاسم الرباعي */}
                <div className="space-y-1.5 md:col-span-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-xs font-semibold">الاسم الرباعي الكامل <span className="text-destructive">*</span></Label>
                    {editErrors.full_name && <span className="text-[11px] text-destructive">{editErrors.full_name}</span>}
                  </div>
                  <div className="relative">
                    <Input
                      value={editForm.full_name ?? ''}
                      onChange={e => {
                        setEditForm(p => ({ ...p, full_name: e.target.value }));
                        if (editErrors.full_name) setEditErrors(prev => ({ ...prev, full_name: undefined }));
                      }}
                      placeholder="أدخل الاسم الرباعي للطالب..."
                      className={`text-sm pr-9 rounded-xl ${editErrors.full_name ? 'border-destructive focus-visible:ring-destructive' : ''}`}
                    />
                    <User className="w-4 h-4 text-muted-foreground absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  </div>
                </div>

                {/* الرقم الوطني */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <Label className="text-xs font-semibold">الرقم الوطني (12 رقماً)</Label>
                    <span className="text-[10px] text-muted-foreground font-mono">
                      {(editForm.national_id ?? '').replace(/\D/g, '').length}/12
                    </span>
                  </div>
                  <div className="relative">
                    <Input
                      type="text"
                      inputMode="numeric"
                      value={editForm.national_id ?? ''}
                      maxLength={12}
                      onChange={e => {
                        const clean = e.target.value.replace(/\D/g, '').slice(0, 12);
                        setEditForm(p => ({ ...p, national_id: clean }));
                        if (editErrors.national_id) setEditErrors(prev => ({ ...prev, national_id: undefined }));
                      }}
                      placeholder="رقم وطني فريد (12 رقماً)"
                      className={`text-sm pr-9 font-mono tracking-wider rounded-xl ${editErrors.national_id ? 'border-destructive focus-visible:ring-destructive' : ''}`}
                    />
                    <CreditCard className="w-4 h-4 text-muted-foreground absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  </div>
                  {editErrors.national_id && (
                    <p className="text-[11px] text-destructive flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3 shrink-0" /> {editErrors.national_id}
                    </p>
                  )}
                </div>

                {/* رقم قيد الطالب */}
                <div className="space-y-1.5">
                  <Label className="text-xs font-semibold">رقم قيد الطالب</Label>
                  <div className="relative">
                    <Input
                      type="text"
                      inputMode="numeric"
                      value={editForm.registration_number ?? ''}
                      onChange={e => setEditForm(p => ({ ...p, registration_number: e.target.value.replace(/\D/g, '') }))}
                      placeholder="رقم القيد الأكاديمي..."
                      className="text-sm pr-9 font-mono rounded-xl"
                    />
                    <Hash className="w-4 h-4 text-muted-foreground absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  </div>
                </div>

                {/* الجنسية */}
                <div className="space-y-1.5 md:col-span-2">
                  <Label className="text-xs font-semibold">الجنسية</Label>
                  <Select
                    value={editForm.nationality ?? DEFAULT_NATIONALITY}
                    onValueChange={v => setEditForm(p => ({ ...p, nationality: v }))}
                  >
                    <SelectTrigger className="text-sm rounded-xl">
                      <SelectValue placeholder="اختر الجنسية" />
                    </SelectTrigger>
                    <SelectContent className="max-h-60">
                      {ARAB_NATIONALITIES.map(nat => (
                        <SelectItem key={nat.value} value={nat.value}>
                          <div className="flex items-center gap-2">
                            <span className="text-base">{nat.flag}</span>
                            <span className="text-sm">{nat.label}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* القسم الثاني: بيانات الاتصال والعنوان */}
            <div className="p-4 rounded-2xl bg-muted/20 border border-border/60 space-y-3.5">
              <div className="flex items-center gap-2 text-xs font-bold text-foreground pb-1 border-b border-border/40">
                <Phone className="w-3.5 h-3.5 text-primary" />
                <span>بيانات الاتصال والعنوان السكني</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {/* هاتف الطالب */}
                <div className="space-y-1.5">
                  <Label className="text-xs font-semibold">رقم هاتف الطالب</Label>
                  <div className="relative">
                    <Input
                      type="tel"
                      inputMode="tel"
                      value={editForm.phone ?? ''}
                      onChange={e => setEditForm(p => ({ ...p, phone: e.target.value.replace(/[^\d+]/g, '') }))}
                      placeholder="09XXXXXXXX"
                      className="text-sm pr-9 font-mono rounded-xl"
                    />
                    <Phone className="w-4 h-4 text-muted-foreground absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  </div>
                </div>

                {/* هاتف ولي الأمر */}
                <div className="space-y-1.5">
                  <Label className="text-xs font-semibold">هاتف ولي الأمر</Label>
                  <div className="relative">
                    <Input
                      type="tel"
                      inputMode="tel"
                      value={editForm.guardian_phone ?? ''}
                      onChange={e => setEditForm(p => ({ ...p, guardian_phone: e.target.value.replace(/[^\d+]/g, '') }))}
                      placeholder="09XXXXXXXX"
                      className="text-sm pr-9 font-mono rounded-xl"
                    />
                    <PhoneCall className="w-4 h-4 text-muted-foreground absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  </div>
                </div>

                {/* العنوان السكني */}
                <div className="space-y-1.5 md:col-span-2">
                  <Label className="text-xs font-semibold">العنوان السكني / المنطقة</Label>
                  <div className="relative">
                    <Input
                      value={editForm.address ?? ''}
                      onChange={e => setEditForm(p => ({ ...p, address: e.target.value }))}
                      placeholder="المدينة، المنطقة، الحي السكني..."
                      className="text-sm pr-9 rounded-xl"
                    />
                    <MapPin className="w-4 h-4 text-muted-foreground absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  </div>
                </div>
              </div>
            </div>

            {/* القسم الثالث: المسار الأكاديمي والتخصص */}
            <div className="p-4 rounded-2xl bg-muted/20 border border-border/60 space-y-3.5">
              <div className="flex items-center gap-2 text-xs font-bold text-foreground pb-1 border-b border-border/40">
                <GraduationCap className="w-3.5 h-3.5 text-primary" />
                <span>المسار الأكاديمي والتخصص</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {/* نوع الدبلوم */}
                <div className="space-y-1.5">
                  <Label className="text-xs font-semibold">نوع الدبلوم</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {(['عالي', 'متوسط'] as DiplomaType[]).map(dtype => (
                      <button
                        key={dtype}
                        type="button"
                        onClick={() => {
                          setEditForm(p => ({ ...p, diploma_type: dtype }));
                          getSpecializations(dtype).then(setSpecializations).catch(() => {});
                        }}
                        className={`p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${editForm.diploma_type === dtype ? 'bg-primary text-primary-foreground border-primary shadow-xs' : 'bg-background hover:bg-muted text-muted-foreground border-border'}`}
                      >
                        دبلوم {dtype}
                      </button>
                    ))}
                  </div>
                </div>

                {/* التخصص */}
                <div className="space-y-1.5">
                  <Label className="text-xs font-semibold">القسم / التخصص الأكاديمي</Label>
                  <Select
                    value={editForm.specialization ?? ''}
                    onValueChange={v => setEditForm(p => ({ ...p, specialization: v }))}
                  >
                    <SelectTrigger className="text-sm rounded-xl">
                      <SelectValue placeholder="اختر التخصص الأكاديمي" />
                    </SelectTrigger>
                    <SelectContent>
                      {specializations.map(s => (
                        <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* القسم الرابع: مشروع التخرج (إذا كان دبلوم عالي وفصل سادس) */}
            {editForm.diploma_type === 'عالي' && student?.current_semester === 6 && (
              <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 space-y-3.5">
                <div className="flex items-center gap-2 text-xs font-bold text-emerald-800 dark:text-emerald-300 pb-1 border-b border-emerald-500/20">
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>بيانات مشروع التخرج (الفصل السادس)</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                  <div className="space-y-1.5">
                    <Label className="text-xs font-semibold">عنوان / اسم المشروع</Label>
                    <Input
                      value={editForm.project_name ?? ''}
                      onChange={e => setEditForm(p => ({ ...p, project_name: e.target.value }))}
                      placeholder="عنوان مشروع التخرج..."
                      className="text-sm rounded-xl bg-background"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs font-semibold">الدكتور المشرف</Label>
                    <Input
                      value={editForm.project_supervisor ?? ''}
                      onChange={e => setEditForm(p => ({ ...p, project_supervisor: e.target.value }))}
                      placeholder="اسم المشرف الأكاديمي..."
                      className="text-sm rounded-xl bg-background"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          <DialogFooter className="gap-2 border-t border-border/50 pt-4 flex-row-reverse sm:flex-row-reverse">
            <Button
              type="button"
              variant="outline"
              onClick={() => setEditPersonalModalOpen(false)}
              disabled={personalSaving}
              className="flex-1 sm:flex-none rounded-xl"
            >
              إلغاء
            </Button>
            <Button
              type="button"
              onClick={handleSavePersonalModal}
              disabled={personalSaving}
              className="flex-1 sm:flex-none bg-primary hover:bg-primary/90 text-primary-foreground font-bold gap-2 rounded-xl shadow-md"
            >
              {personalSaving ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/60 border-t-white rounded-full animate-spin" />
                  <span>جارٍ الحفظ...</span>
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  <span>حفظ البيانات الشخصية</span>
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── حوار إضافة / تعديل رقم قيد الطالب ── */}
      <Dialog open={regNumberModalOpen} onOpenChange={setRegNumberModalOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md bg-card border-border p-6 rounded-2xl" dir="rtl">
          <DialogHeader className="space-y-2 text-right">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center mb-1 text-amber-600 dark:text-amber-400">
              <Hash className="w-6 h-6" />
            </div>
            <DialogTitle className="text-base font-bold text-foreground">
              {student?.registration_number ? 'تعديل رقم قيد الطالب' : 'إضافة رقم قيد الطالب'}
            </DialogTitle>
            <DialogDescription className="text-xs text-muted-foreground">
              أدخل رقم القيد المعتمد للطالب {student?.full_name}. سيظهر هذا الرقم في كافة الكشوفات الرسمية وشهادات التعريف وملف الطالب.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 my-2">
            <div className="p-3 rounded-xl bg-muted/40 border border-border/60 text-xs space-y-1.5">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">اسم الطالب:</span>
                <span className="font-bold text-foreground">{student?.full_name}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">الرقم الوطني:</span>
                <span className="font-mono text-foreground">{student?.national_id || '—'}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">التخصص:</span>
                <span className="font-medium text-foreground">{student?.diploma_type} — {student?.specialization}</span>
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs font-bold text-foreground">رقم القيد الأكاديمي</Label>
              <Input
                value={newRegNumber}
                onChange={e => setNewRegNumber(e.target.value)}
                placeholder="مثال: 2026/0145 أو 5410/2026"
                className="font-mono text-base h-11 text-center"
                inputMode="tel"
                pattern="[0-9/]*"
                autoFocus
                onKeyDown={e => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleSaveRegistrationNumber();
                  }
                }}
              />
              <p className="text-[11px] text-muted-foreground leading-relaxed">
                يمكن إدخال الرقم بأي صيغة معتمدة لدى شؤون الطلاب (مثال: سنة/رقم أو رقم/سنة). اتركه فارغاً إذا رغبت بإلغاء التعيين.
              </p>
            </div>
          </div>

          <DialogFooter className="flex flex-row gap-2 justify-end pt-2">
            <Button
              variant="outline"
              onClick={() => setRegNumberModalOpen(false)}
              disabled={savingRegNumber}
              className="text-xs h-9"
            >
              إلغاء
            </Button>
            <Button
              onClick={handleSaveRegistrationNumber}
              disabled={savingRegNumber}
              className="bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs h-9 gap-1.5 shadow-sm"
            >
              {savingRegNumber ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
              حفظ رقم القيد
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* محرر الصور — يظهر عند اختيار صورة شخصية أو ملف صورة */}
      <ImageEditorModal
        open={editorOpen}
        imageSrc={editorSrc}
        aspectRatio={editorAspect}
        title={editorMode === 'avatar' ? 'تعديل الصورة الشخصية' : 'تعديل الصورة قبل الرفع'}
        onConfirm={handleEditorConfirm}
        onCancel={() => { setEditorOpen(false); if (editorSrc) URL.revokeObjectURL(editorSrc); }}
      />

      </MainLayout>
    );
  }

