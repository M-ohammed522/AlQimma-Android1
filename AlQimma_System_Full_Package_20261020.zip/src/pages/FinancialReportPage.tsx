// صفحة الأرباح والتحصيل المالي — منظومة معهد القمة
import { useEffect, useState, useMemo, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ChevronRight, RefreshCw, Printer, FileSpreadsheet, FileDown,
  TrendingUp, DollarSign, AlertTriangle, CheckCircle2, BarChart3,
  Users, BookOpen, CircleDollarSign, Percent, ChevronDown, ChevronUp,
  Clock, History, UserX, Search, ExternalLink, ChevronsUpDown, ShieldCheck,
} from 'lucide-react';
import { toast } from 'sonner';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { getAllSemesterCharges } from '@/lib/api';
import { SEMESTER_LABELS } from '@/types/index';
import { RefreshButton } from '@/components/ui/RefreshButton';
import { printTable, exportPDF, exportExcel } from '@/lib/printUtils';
import type { SemesterChargeRow } from '@/lib/api';
import { FinancialAuditDialog } from '@/components/finance/FinancialAuditDialog';
import { matchSearch } from '@/lib/searchUtils';

function fmtMoney(n: number) {
  return n.toLocaleString('ar-LY', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function pct(num: number, den: number) {
  if (den === 0) return 0;
  return Math.min(100, Math.round((num / den) * 100));
}
function semLabel(n: number) {
  if (n === -1) return 'رسوم التسجيل';
  return SEMESTER_LABELS[n] ?? `الفصل ${n}`;
}
function barColor(rate: number) {
  if (rate >= 80) return 'bg-emerald-500';
  if (rate >= 50) return 'bg-amber-400';
  return 'bg-rose-500';
}
function barTextColor(rate: number) {
  if (rate >= 80) return 'text-emerald-600';
  if (rate >= 50) return 'text-amber-600';
  return 'text-rose-600';
}

// ── أنواع ──
type DebtorEntry = {
  student_id: string;
  student_name: string;
  student_status: string;
  charge_type: string;
  charged: number;
  paid: number;
  debt: number;
  debtLabel: 'current' | 'previous' | 'registration';
};

type GroupRow = {
  key: string;
  semesterNumber: number;
  semesterLabel: string;
  diplomaType: string;
  studentCount: number;
  charged: number;
  paid: number;
  debt: number;
  collectionRate: number;
  debtors: DebtorEntry[];
  currentDebtors: number;
  previousDebtors: number;
};

type DiplomaFilter = 'all' | 'عالي' | 'متوسط';

export default function FinancialReportPage() {
  const navigate = useNavigate();
  const [charges, setCharges]   = useState<SemesterChargeRow[]>([]);
  const [loading, setLoading]   = useState(true);
  const [diplomaFilter, setDiplomaFilter]   = useState<DiplomaFilter>('all');
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set());
  const [debtorSearch, setDebtorSearch]     = useState('');
  const [auditDialogOpen, setAuditDialogOpen] = useState(false);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const data = await getAllSemesterCharges();
      setCharges(data);
    } catch {
      toast.error('فشل تحميل بيانات التقرير المالي');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const filtered = useMemo(() =>
    diplomaFilter === 'all' ? charges : charges.filter(c => c.diploma_type === diplomaFilter),
    [charges, diplomaFilter]
  );

  // ── بناء مجموعات مع قوائم المديونين ──
  const groups: GroupRow[] = useMemo(() => {
    const map = new Map<string, GroupRow>();

    for (const c of filtered) {
      const key = `${c.diploma_type}__${c.semester_number}`;
      if (!map.has(key)) {
        map.set(key, {
          key, semesterNumber: c.semester_number,
          semesterLabel: semLabel(c.semester_number),
          diplomaType: c.diploma_type,
          studentCount: 0, charged: 0, paid: 0, debt: 0,
          collectionRate: 0, debtors: [], currentDebtors: 0, previousDebtors: 0,
        });
      }
      const g = map.get(key)!;
      const effectiveCharge = c.charge_amount - (c.discount_amount ?? 0);
      g.charged += effectiveCharge;
      g.paid    += c.paid_amount;
      g.debt    += c.remaining_amount;

      if (c.remaining_amount > 0.009) {
        let debtLabel: DebtorEntry['debtLabel'] = 'current';
        if (c.semester_number === -1) {
          debtLabel = 'registration';
        } else if (c.semester_number < c.student_current_semester) {
          debtLabel = 'previous';
        }
        g.debtors.push({
          student_id: c.student_id,
          student_name: c.student_name,
          student_status: c.student_status,
          charge_type: c.charge_type,
          charged: effectiveCharge,
          paid: c.paid_amount,
          debt: c.remaining_amount,
          debtLabel,
        });
      }
    }

    const studentMap = new Map<string, Set<string>>();
    for (const c of filtered) {
      const key = `${c.diploma_type}__${c.semester_number}`;
      if (!studentMap.has(key)) studentMap.set(key, new Set());
      studentMap.get(key)!.add(c.student_id);
    }
    for (const [key, g] of map) {
      g.studentCount     = studentMap.get(key)?.size ?? 0;
      g.collectionRate   = pct(g.paid, g.charged);
      g.currentDebtors   = g.debtors.filter(d => d.debtLabel === 'current' || d.debtLabel === 'registration').length;
      g.previousDebtors  = g.debtors.filter(d => d.debtLabel === 'previous').length;
      g.debtors.sort((a, b) => {
        if (a.debtLabel === 'previous' && b.debtLabel !== 'previous') return -1;
        if (b.debtLabel === 'previous' && a.debtLabel !== 'previous') return 1;
        return b.debt - a.debt;
      });
    }
    return [...map.values()].sort((a, b) => {
      if (a.diplomaType !== b.diplomaType) return a.diplomaType === 'عالي' ? -1 : 1;
      return a.semesterNumber - b.semesterNumber;
    });
  }, [filtered]);

  const totals = useMemo(() => {
    const charged  = groups.reduce((s, g) => s + g.charged, 0);
    const paid     = groups.reduce((s, g) => s + g.paid,    0);
    const debt     = groups.reduce((s, g) => s + g.debt,    0);
    const rate     = pct(paid, charged);
    const students = new Set(filtered.map(c => c.student_id)).size;
    const totalDebtors = new Set(
      filtered.filter(c => c.remaining_amount > 0.009).map(c => c.student_id)
    ).size;
    return { charged, paid, debt, rate, students, totalDebtors };
  }, [groups, filtered]);

  // إجماليات حسب الدبلوم للملخص المقارن
  const byDiploma = useMemo(() => {
    const high = groups.filter(g => g.diplomaType === 'عالي');
    const mid  = groups.filter(g => g.diplomaType === 'متوسط');
    const calc = (arr: GroupRow[]) => ({
      charged: arr.reduce((s, g) => s + g.charged, 0),
      paid:    arr.reduce((s, g) => s + g.paid, 0),
      debt:    arr.reduce((s, g) => s + g.debt, 0),
      rate:    pct(arr.reduce((s, g) => s + g.paid, 0), arr.reduce((s, g) => s + g.charged, 0)),
      debtors: arr.reduce((s, g) => s + g.debtors.length, 0),
    });
    return { high: calc(high), mid: calc(mid) };
  }, [groups]);

  const toggleGroup = (key: string) => {
    setExpandedGroups(prev => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key); else next.add(key);
      return next;
    });
  };

  const expandAll  = () => setExpandedGroups(new Set(groups.filter(g => g.debtors.length > 0).map(g => g.key)));
  const collapseAll = () => setExpandedGroups(new Set());

  // ── طباعة ──
  const handlePrint = () => {
    const summaryRows = groups.map((g, i) => [
      i + 1, g.semesterLabel, g.diplomaType, g.studentCount,
      fmtMoney(g.charged), fmtMoney(g.paid), fmtMoney(g.debt),
      `${g.collectionRate}%`, g.debtors.length,
    ]);
    const totalRow = ['', '', 'الإجمالي الكلي', totals.students, fmtMoney(totals.charged), fmtMoney(totals.paid), fmtMoney(totals.debt), `${totals.rate}%`, totals.totalDebtors];
    printTable({
      title: 'تقرير الأرباح والتحصيل المالي',
      subtitle: diplomaFilter !== 'all' ? `نوع الدبلوم: ${diplomaFilter}` : 'جميع الدبلومات',
      totalInfo: `المستحق: ${fmtMoney(totals.charged)} د.ل | المحصَّل: ${fmtMoney(totals.paid)} د.ل | الديون: ${fmtMoney(totals.debt)} د.ل`,
      columns: ['م', 'الفصل الدراسي', 'الدبلوم', 'الطلاب', 'المستحق (د.ل)', 'المحصَّل (د.ل)', 'الديون (د.ل)', 'نسبة التحصيل', 'المديونون'],
      rows: summaryRows,
      totalRow,
      sig1: 'توقيع المحاسب المسؤول',
      sig2: 'اعتماد المدير',
    });
  };

  // ── تصدير Excel ──
  const handleExcel = () => {
    const summaryRows = groups.map((g, i) => [i + 1, g.semesterLabel, g.diplomaType, g.studentCount, g.charged, g.paid, g.debt, `${g.collectionRate}%`, g.debtors.length]);
    const totalRow    = ['', '', 'الإجمالي', totals.students, totals.charged, totals.paid, totals.debt, `${totals.rate}%`, totals.totalDebtors];
    exportExcel({
      title: 'تقرير الأرباح والتحصيل المالي',
      subtitle: diplomaFilter !== 'all' ? `نوع الدبلوم: ${diplomaFilter}` : 'جميع الدبلومات',
      columns: ['م', 'الفصل الدراسي', 'نوع الدبلوم', 'عدد الطلاب', 'الرسوم المستحقة', 'المحصَّل', 'الديون', 'نسبة التحصيل', 'عدد المديونين'],
      rows: summaryRows,
      totalRow,
      filename: 'تقرير_التحصيل_المالي',
      sheetName: 'ملخص التحصيل',
    });
    toast.success('تم تصدير Excel بنجاح');
  };

  // ── تصدير PDF ──
  const handlePdf = () => {
    const summaryRows = groups.map((g, i) => [i + 1, g.semesterLabel, g.diplomaType, g.studentCount, fmtMoney(g.charged), fmtMoney(g.paid), fmtMoney(g.debt), `${g.collectionRate}%`, g.debtors.length]);
    const totalRow    = ['', '', 'الإجمالي', totals.students, fmtMoney(totals.charged), fmtMoney(totals.paid), fmtMoney(totals.debt), `${totals.rate}%`, totals.totalDebtors];
    exportPDF({
      title: 'تقرير الأرباح والتحصيل المالي',
      subtitle: diplomaFilter !== 'all' ? `نوع الدبلوم: ${diplomaFilter}` : 'جميع الدبلومات',
      totalInfo: `المستحق: ${fmtMoney(totals.charged)} | المحصَّل: ${fmtMoney(totals.paid)} | الديون: ${fmtMoney(totals.debt)}`,
      columns: ['م', 'الفصل', 'الدبلوم', 'الطلاب', 'المستحق', 'المحصَّل', 'الديون', 'التحصيل', 'المديونون'],
      rows: summaryRows,
      totalRow,
      filename: 'تقرير_التحصيل_المالي',
    });
    toast.success('تم تصدير PDF بنجاح');
  };

  // ── شارة نوع المديونية ──
  function DebtBadge({ label }: { label: DebtorEntry['debtLabel'] }) {
    if (label === 'previous')
      return (
        <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-100 text-rose-700 border border-rose-200 dark:bg-rose-500/15 dark:text-rose-300 dark:border-rose-500/25 whitespace-nowrap">
          <History className="w-2.5 h-2.5" /> فصل سابق
        </span>
      );
    if (label === 'registration')
      return (
        <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-100 text-purple-700 border border-purple-200 dark:bg-purple-500/15 dark:text-purple-300 dark:border-purple-500/25 whitespace-nowrap">
          <UserX className="w-2.5 h-2.5" /> رسوم تسجيل
        </span>
      );
    return (
      <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 border border-amber-200 dark:bg-amber-500/15 dark:text-amber-300 dark:border-amber-500/25 whitespace-nowrap">
        <Clock className="w-2.5 h-2.5" /> الفصل الحالي
      </span>
    );
  }

  // جميع المديونين (لقسم البحث السريع)
  const allDebtors = useMemo(() =>
    groups.flatMap(g => g.debtors.map(d => ({ ...d, semesterLabel: g.semesterLabel, diplomaType: g.diplomaType, groupKey: g.key })))
  , [groups]);

  const filteredDebtors = useMemo(() => {
    if (!debtorSearch.trim()) return allDebtors;
    return allDebtors.filter(d => matchSearch(d.student_name, debtorSearch));
  }, [allDebtors, debtorSearch]);

  return (
    <MainLayout>
      <div className="space-y-4" dir="rtl">

        {/* ── الترويسة ── */}
        <div className="relative rounded-2xl overflow-hidden" style={{ boxShadow: 'var(--shadow-lg)' }}>
          <div className="absolute inset-0 bg-gradient-to-br from-emerald-700/90 via-emerald-600/85 to-teal-700/80" />
          <div className="absolute inset-0 opacity-[0.06]"
            style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '24px 24px' }} />
          <div className="relative px-5 py-4 md:px-7 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <button onClick={() => navigate('/')}
                className="w-9 h-9 rounded-xl bg-white/15 border border-white/20 flex items-center justify-center shrink-0 hover:bg-white/25 transition-colors">
                <ChevronRight className="w-4 h-4 text-white" />
              </button>
              <div className="w-10 h-10 rounded-xl bg-white/15 border border-white/20 flex items-center justify-center shrink-0">
                <BarChart3 className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-white text-balance">الأرباح والتحصيل المالي</h1>
                <p className="text-white/60 text-xs mt-0.5">تقرير مالي تفصيلي — الرسوم المستحقة والمحصَّلة والديون لكل فصل</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2 shrink-0">
              <Button size="sm" onClick={() => setAuditDialogOpen(true)}
                className="bg-amber-600 text-white hover:bg-amber-700 gap-1.5 h-9 rounded-xl text-[12px] font-semibold">
                <ShieldCheck className="w-3.5 h-3.5" /> التدقيق والمطابقة
              </Button>
              <RefreshButton
                onRefresh={fetchData}
                loading={loading}
                variant="white"
                label="تحديث"
                className="h-9 rounded-xl text-[12px] font-semibold"
              />
              <Button size="sm" onClick={handleExcel} disabled={loading || groups.length === 0}
                className="bg-emerald-800 text-white hover:bg-emerald-900 gap-1.5 h-9 rounded-xl text-[12px] font-semibold">
                <FileSpreadsheet className="w-3.5 h-3.5" /> Excel
              </Button>
              <Button size="sm" onClick={handlePdf} disabled={loading || groups.length === 0}
                className="bg-rose-600 text-white hover:bg-rose-700 gap-1.5 h-9 rounded-xl text-[12px] font-semibold">
                <FileDown className="w-3.5 h-3.5" /> PDF
              </Button>
            </div>
          </div>
        </div>

        {/* ── بطاقات الإحصاء الأربع ── */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: 'إجمالي الرسوم المستحقة', value: loading ? '—' : fmtMoney(totals.charged), sub: 'دينار ليبي', gradient: 'from-[#1a3c5e] to-blue-700',   Icon: CircleDollarSign },
            { label: 'إجمالي المحصَّل',         value: loading ? '—' : fmtMoney(totals.paid),    sub: 'دينار ليبي', gradient: 'from-emerald-500 to-emerald-700', Icon: CheckCircle2 },
            { label: 'إجمالي الديون المتبقية',  value: loading ? '—' : fmtMoney(totals.debt),    sub: 'دينار ليبي', gradient: 'from-rose-500 to-rose-700',       Icon: AlertTriangle },
            { label: 'نسبة التحصيل',            value: loading ? '—' : `${totals.rate}%`,        sub: 'من الرسوم المستحقة', gradient: 'from-amber-500 to-amber-600', Icon: Percent },
          ].map(card => (
            <div key={card.label}
              className={`relative rounded-2xl p-4 bg-gradient-to-br ${card.gradient} text-white shadow-md ring-1 ring-white/10 overflow-hidden`}>
              <div className="absolute -bottom-2 -left-2 opacity-[0.12]"><card.Icon className="w-16 h-16" /></div>
              <p className="text-[10px] font-semibold text-white/70 leading-tight uppercase tracking-wide">{card.label}</p>
              {loading
                ? <div className="h-7 w-20 bg-white/20 rounded-lg mt-2 animate-pulse" />
                : <p className="text-xl md:text-2xl font-black leading-none mt-1.5 tabular-nums break-all">{card.value}</p>
              }
              <p className="text-[10px] text-white/55 mt-1">{card.sub}</p>
            </div>
          ))}
        </div>

        {/* ── شريط التحصيل الكلي + مقارنة الدبلومين ── */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {/* نسبة التحصيل الكلية */}
          <div className="md:col-span-1 rounded-2xl border border-border/50 bg-card p-4 shadow-sm flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-500/20 flex items-center justify-center">
                  <TrendingUp className="w-4 h-4 text-emerald-600" />
                </div>
                <p className="text-[12px] font-bold text-foreground">نسبة التحصيل الكلية</p>
              </div>
              <span className={`text-2xl font-black tabular-nums ${barTextColor(totals.rate)}`}>
                {loading ? '—' : `${totals.rate}%`}
              </span>
            </div>
            <div className="h-3 rounded-full bg-muted overflow-hidden">
              <div className={`h-full rounded-full transition-all duration-700 ${barColor(totals.rate)}`} style={{ width: `${totals.rate}%` }} />
            </div>
            <div className="flex justify-between text-[10px] text-muted-foreground">
              <span>محصَّل: <b className="text-emerald-600">{loading ? '—' : fmtMoney(totals.paid)}</b> د.ل</span>
              <span>متبقي: <b className="text-rose-600">{loading ? '—' : fmtMoney(totals.debt)}</b> د.ل</span>
            </div>
          </div>

          {/* مقارنة دبلوم عالي ومتوسط */}
          <div className="md:col-span-2 rounded-2xl border border-border/50 bg-card p-4 shadow-sm">
            <div className="flex items-center gap-2 mb-3">
              <BookOpen className="w-4 h-4 text-muted-foreground" />
              <p className="text-[12px] font-bold text-foreground">مقارنة الدبلومين</p>
              <div className="mr-auto flex items-center gap-1.5 text-[10px] text-muted-foreground">
                <Users className="w-3 h-3" />
                <span>إجمالي الطلاب: <b className="text-foreground">{loading ? '—' : totals.students}</b></span>
                <span className="mx-1">|</span>
                <span>بمديونيات: <b className="text-rose-600">{loading ? '—' : totals.totalDebtors}</b></span>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {[
                { label: 'دبلوم عالي', data: byDiploma.high, color: 'blue', badgeClass: 'bg-blue-100 text-blue-700 border-blue-200', barClass: 'bg-blue-500' },
                { label: 'دبلوم متوسط', data: byDiploma.mid, color: 'emerald', badgeClass: 'bg-emerald-100 text-emerald-700 border-emerald-200', barClass: 'bg-emerald-500' },
              ].map(({ label, data, badgeClass, barClass }) => (
                <div key={label} className="rounded-xl border border-border/40 bg-muted/20 p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${badgeClass}`}>{label}</span>
                    <span className={`text-[13px] font-black tabular-nums ${barTextColor(data.rate)}`}>{loading ? '—' : `${data.rate}%`}</span>
                  </div>
                  <div className="h-2 rounded-full bg-muted overflow-hidden">
                    <div className={`h-full rounded-full ${barClass}`} style={{ width: `${data.rate}%` }} />
                  </div>
                  <div className="grid grid-cols-3 gap-1 text-center">
                    {[
                      { lbl: 'المستحق', val: fmtMoney(data.charged), cls: 'text-[#1a3c5e]' },
                      { lbl: 'المحصَّل', val: fmtMoney(data.paid),    cls: 'text-emerald-600' },
                      { lbl: 'الديون',   val: fmtMoney(data.debt),    cls: 'text-rose-600' },
                    ].map(({ lbl, val, cls }) => (
                      <div key={lbl}>
                        <p className="text-[8px] text-muted-foreground">{lbl}</p>
                        <p className={`text-[10px] font-bold tabular-nums ${cls}`}>{loading ? '—' : val}</p>
                      </div>
                    ))}
                  </div>
                  {!loading && data.debtors > 0 && (
                    <p className="text-[9px] text-rose-500 font-semibold text-center">{data.debtors} مدين</p>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* ── شريط أدوات الجدول: فلتر + بحث + فتح/إغلاق الكل ── */}
        <div className="flex flex-col md:flex-row md:items-center gap-3">
          {/* فلتر الدبلوم */}
          <div className="flex items-center gap-1.5 bg-muted/50 border border-border/50 rounded-2xl p-1.5 shadow-sm shrink-0">
            {([
              { v: 'all',   label: 'الكل',         activeClass: 'bg-emerald-600 text-white shadow-emerald-500/25', dotClass: '' },
              { v: 'عالي',  label: 'دبلوم عالي',  activeClass: 'bg-blue-600 text-white shadow-blue-500/25',       dotClass: 'bg-blue-400' },
              { v: 'متوسط', label: 'دبلوم متوسط', activeClass: 'bg-emerald-500 text-white shadow-emerald-400/25', dotClass: 'bg-emerald-400' },
            ] as const).map(({ v, label, activeClass, dotClass }) => {
              const isActive = diplomaFilter === v;
              return (
                <button key={v} onClick={() => setDiplomaFilter(v)}
                  className={`flex items-center gap-2 h-8 px-3 rounded-xl text-[11px] font-semibold transition-all duration-200 ${
                    isActive ? `${activeClass} shadow-md` : 'text-muted-foreground hover:text-foreground hover:bg-background/70'
                  }`}>
                  {dotClass && <span className={`w-1.5 h-1.5 rounded-full ${isActive ? 'bg-white/80' : dotClass}`} />}
                  {label}
                </button>
              );
            })}
          </div>

          {/* دليل الألوان */}
          <div className="flex flex-wrap items-center gap-2">
            {[
              { bg: 'bg-rose-100 border-rose-200 text-rose-700', icon: <History className="w-3 h-3" />, label: 'فصول سابقة' },
              { bg: 'bg-amber-100 border-amber-200 text-amber-700', icon: <Clock className="w-3 h-3" />, label: 'الفصل الحالي' },
              { bg: 'bg-purple-100 border-purple-200 text-purple-700', icon: <UserX className="w-3 h-3" />, label: 'رسوم تسجيل' },
            ].map(({ bg, icon, label }) => (
              <span key={label} className={`inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full border ${bg}`}>
                {icon} {label}
              </span>
            ))}
          </div>

          {/* فتح/إغلاق الكل */}
          <div className="flex gap-2 md:mr-auto shrink-0">
            <button onClick={expandAll}
              className="flex items-center gap-1.5 h-8 px-3 rounded-xl text-[11px] font-semibold border border-border/50 bg-background hover:bg-muted transition-all">
              <ChevronsUpDown className="w-3.5 h-3.5" /> فتح الكل
            </button>
            <button onClick={collapseAll}
              className="flex items-center gap-1.5 h-8 px-3 rounded-xl text-[11px] font-semibold border border-border/50 bg-background hover:bg-muted transition-all">
              <ChevronUp className="w-3.5 h-3.5" /> إغلاق الكل
            </button>
          </div>
        </div>

        {/* ── بطاقات الفصول ── */}
        {loading ? (
          <div className="space-y-2">
            {Array(5).fill(0).map((_, i) => (
              <div key={i} className="rounded-2xl border border-border/50 p-4">
                <div className="flex items-center gap-3">
                  <Skeleton className="h-10 w-28 rounded-xl" />
                  <div className="flex-1 space-y-1.5">
                    <Skeleton className="h-3 w-32" />
                    <Skeleton className="h-2 w-48 rounded-full" />
                  </div>
                  <Skeleton className="h-8 w-20 rounded-xl" />
                </div>
              </div>
            ))}
          </div>
        ) : groups.length === 0 ? (
          <div className="rounded-2xl border border-border/50 bg-card py-16 flex flex-col items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-muted flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-muted-foreground/40" />
            </div>
            <p className="text-sm text-muted-foreground font-medium">لا توجد بيانات مالية</p>
          </div>
        ) : (
          <div className="space-y-2">
            {groups.map((g, idx) => {
              const isOpen = expandedGroups.has(g.key);
              const isHigh = g.diplomaType === 'عالي';
              const diplomaAccent = isHigh ? 'border-blue-200/60 dark:border-blue-500/20' : 'border-emerald-200/60 dark:border-emerald-500/20';
              const diplomaHeaderBg = isHigh ? 'bg-blue-50/60 dark:bg-blue-500/8' : 'bg-emerald-50/60 dark:bg-emerald-500/8';
              const diplomaBadge = isHigh
                ? 'bg-blue-100 text-blue-700 border-blue-200 dark:bg-blue-500/15 dark:text-blue-300'
                : 'bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-500/15 dark:text-emerald-300';

              return (
                <div key={g.key} className={`rounded-2xl border ${diplomaAccent} bg-card shadow-sm overflow-hidden transition-all`}>
                  {/* رأس المجموعة */}
                  <div className={`${diplomaHeaderBg} px-4 py-3`}>
                    <div className="flex items-center gap-3 flex-wrap">
                      <span className="inline-flex items-center justify-center w-7 h-7 rounded-xl bg-[#1a3c5e]/10 text-[#1a3c5e] text-[11px] font-black shrink-0">
                        {idx + 1}
                      </span>
                      <div className="flex items-center gap-2 flex-wrap min-w-0">
                        <span className="text-[13px] font-bold text-foreground whitespace-nowrap">{g.semesterLabel}</span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${diplomaBadge}`}>{g.diplomaType}</span>
                        {g.debtors.length > 0 && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-100 text-rose-700 border border-rose-200 dark:bg-rose-500/15 dark:text-rose-300 dark:border-rose-500/25 flex items-center gap-1">
                            <AlertTriangle className="w-2.5 h-2.5" />
                            {g.debtors.length} مدين
                            {g.previousDebtors > 0 && <span className="text-rose-500 font-black">({g.previousDebtors} سابق)</span>}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-4 mr-auto flex-wrap">
                        <div className="text-center">
                          <p className="text-[9px] text-muted-foreground">الطلاب</p>
                          <p className="text-[13px] font-black text-foreground tabular-nums">{g.studentCount}</p>
                        </div>
                        <div className="text-center hidden md:block">
                          <p className="text-[9px] text-muted-foreground">المستحق</p>
                          <p className="text-[12px] font-bold text-[#1a3c5e] tabular-nums">{fmtMoney(g.charged)}</p>
                        </div>
                        <div className="text-center hidden md:block">
                          <p className="text-[9px] text-muted-foreground">المحصَّل</p>
                          <p className="text-[12px] font-bold text-emerald-700 tabular-nums">{fmtMoney(g.paid)}</p>
                        </div>
                        <div className="text-center">
                          <p className="text-[9px] text-muted-foreground">الديون</p>
                          <p className={`text-[12px] font-bold tabular-nums ${g.debt > 0 ? 'text-rose-600' : 'text-muted-foreground'}`}>{fmtMoney(g.debt)}</p>
                        </div>
                        <div className="flex items-center gap-2 min-w-[90px]">
                          <div className="w-14 h-2 rounded-full bg-muted overflow-hidden">
                            <div className={`h-full rounded-full ${barColor(g.collectionRate)}`} style={{ width: `${g.collectionRate}%` }} />
                          </div>
                          <span className={`text-[11px] font-black tabular-nums ${barTextColor(g.collectionRate)}`}>{g.collectionRate}%</span>
                        </div>
                      </div>

                      {g.debtors.length > 0 ? (
                        <button onClick={() => toggleGroup(g.key)}
                          className="flex items-center gap-1.5 h-8 px-3 rounded-xl text-[11px] font-semibold border border-border/50 bg-background hover:bg-muted transition-all shrink-0">
                          {isOpen ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                          {isOpen ? 'إخفاء' : 'المديونون'}
                        </button>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-600 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-full dark:bg-emerald-500/10 dark:border-emerald-500/20">
                          <CheckCircle2 className="w-3 h-3" /> لا ديون
                        </span>
                      )}
                    </div>

                    {/* موبايل: المستحق والمحصَّل */}
                    <div className="flex gap-4 mt-2 md:hidden text-[11px]">
                      <span className="text-muted-foreground">مستحق: <b className="text-[#1a3c5e]">{fmtMoney(g.charged)}</b></span>
                      <span className="text-muted-foreground">محصَّل: <b className="text-emerald-700">{fmtMoney(g.paid)}</b></span>
                    </div>
                  </div>

                  {/* قائمة المديونين */}
                  {isOpen && g.debtors.length > 0 && (
                    <div className="border-t border-border/40">
                      <div className="px-4 py-2.5 bg-muted/30 flex items-center gap-2 flex-wrap">
                        <UserX className="w-4 h-4 text-rose-500 shrink-0" />
                        <p className="text-[12px] font-bold text-foreground">
                          الطلاب المديونون — {g.semesterLabel} ({g.diplomaType})
                        </p>
                        <span className="mr-auto text-[10px] font-semibold text-muted-foreground">
                          إجمالي الديون: <span className="text-rose-600 font-black">{fmtMoney(g.debt)} د.ل</span>
                        </span>
                      </div>
                      <div className="w-full overflow-x-auto">
                        <table className="w-full min-w-[600px]">
                          <thead>
                            <tr className="bg-muted/50">
                              {['م', 'اسم الطالب', 'نوع الرسوم', 'نوع المديونية', 'المستحق', 'المدفوع', 'المتبقي', ''].map(h => (
                                <th key={h} className="px-3 py-2 text-center text-[10px] font-bold text-muted-foreground whitespace-nowrap border-b border-border/40">{h}</th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {g.debtors.map((d, di) => (
                              <tr key={`${d.student_id}-${di}`}
                                className={`transition-colors hover:bg-primary/4 ${di % 2 === 0 ? 'bg-background' : 'bg-muted/10'} ${d.debtLabel === 'previous' ? 'border-r-2 border-rose-400' : ''}`}>
                                <td className="px-3 py-2 text-center">
                                  <span className="text-[10px] font-bold text-muted-foreground">{di + 1}</span>
                                </td>
                                <td className="px-3 py-2 whitespace-nowrap">
                                  <div>
                                    <p className="text-[12px] font-bold text-foreground">{d.student_name}</p>
                                    {d.student_status !== 'نشط' && (
                                      <p className="text-[9px] text-amber-600">{d.student_status}</p>
                                    )}
                                  </div>
                                </td>
                                <td className="px-3 py-2 text-center whitespace-nowrap">
                                  <span className="text-[11px] font-semibold text-foreground/70 bg-muted px-2 py-0.5 rounded-lg">{d.charge_type}</span>
                                </td>
                                <td className="px-3 py-2 text-center whitespace-nowrap">
                                  <DebtBadge label={d.debtLabel} />
                                </td>
                                <td className="px-3 py-2 text-center whitespace-nowrap">
                                  <span className="text-[11px] font-semibold text-[#1a3c5e] tabular-nums">{fmtMoney(d.charged)}</span>
                                </td>
                                <td className="px-3 py-2 text-center whitespace-nowrap">
                                  <span className="text-[11px] font-semibold text-emerald-700 tabular-nums">{fmtMoney(d.paid)}</span>
                                </td>
                                <td className="px-3 py-2 text-center whitespace-nowrap">
                                  <span className="text-[12px] font-black text-rose-600 tabular-nums">{fmtMoney(d.debt)}</span>
                                </td>
                                <td className="px-3 py-2 text-center whitespace-nowrap">
                                  <button onClick={() => navigate(`/student/${d.student_id}`)}
                                    className="inline-flex items-center gap-1 h-7 px-2 rounded-lg text-[10px] font-semibold bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground transition-all border border-primary/20"
                                    title="فتح ملف الطالب">
                                    <ExternalLink className="w-3 h-3" />
                                    <span className="hidden md:inline">ملف</span>
                                  </button>
                                </td>
                              </tr>
                            ))}
                            <tr className="bg-rose-50/60 dark:bg-rose-500/8 border-t border-rose-200/50">
                              <td colSpan={4} className="px-3 py-2 text-right">
                                <span className="text-[11px] font-black text-rose-700">مجموع ديون {g.semesterLabel}</span>
                              </td>
                              <td className="px-3 py-2 text-center">
                                <span className="text-[11px] font-black text-[#1a3c5e] tabular-nums">{fmtMoney(g.debtors.reduce((s, d) => s + d.charged, 0))}</span>
                              </td>
                              <td className="px-3 py-2 text-center">
                                <span className="text-[11px] font-black text-emerald-700 tabular-nums">{fmtMoney(g.debtors.reduce((s, d) => s + d.paid, 0))}</span>
                              </td>
                              <td className="px-3 py-2 text-center">
                                <span className="text-[12px] font-black text-rose-700 tabular-nums">{fmtMoney(g.debt)} د.ل</span>
                              </td>
                              <td />
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}

            {/* الإجمالي النهائي */}
            <div className="rounded-2xl border-2 border-[#1a3c5e]/20 bg-[#1a3c5e]/4 dark:bg-[#1a3c5e]/10 px-4 py-3.5">
              <div className="flex flex-wrap items-center gap-4">
                <div className="flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-[#1a3c5e]" />
                  <span className="text-[13px] font-black text-[#1a3c5e]">الإجمالي الكلي</span>
                </div>
                <div className="flex flex-wrap gap-6 mr-auto">
                  {[
                    { label: 'الطلاب',    value: `${totals.students}`,            color: 'text-foreground' },
                    { label: 'المستحق',   value: `${fmtMoney(totals.charged)} د.ل`, color: 'text-[#1a3c5e]' },
                    { label: 'المحصَّل',  value: `${fmtMoney(totals.paid)} د.ل`,    color: 'text-emerald-700' },
                    { label: 'الديون',    value: `${fmtMoney(totals.debt)} د.ل`,    color: 'text-rose-600' },
                    { label: 'التحصيل',   value: `${totals.rate}%`,               color: barTextColor(totals.rate) },
                    { label: 'المديونون', value: `${totals.totalDebtors}`,          color: 'text-rose-600' },
                  ].map(({ label, value, color }) => (
                    <div key={label} className="text-center">
                      <p className="text-[9px] text-muted-foreground">{label}</p>
                      <p className={`text-[13px] font-black tabular-nums ${color}`}>{value}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ── قسم البحث السريع في المديونين ── */}
        {!loading && allDebtors.length > 0 && (
          <div className="rounded-2xl border border-rose-200/50 bg-card shadow-sm overflow-hidden">
            <div className="px-4 py-3 bg-rose-50/50 dark:bg-rose-500/8 border-b border-rose-200/40 flex items-center gap-3 flex-wrap">
              <div className="flex items-center gap-2">
                <Search className="w-4 h-4 text-rose-500" />
                <p className="text-[13px] font-bold text-foreground">بحث سريع في المديونين</p>
              </div>
              <span className="text-[10px] text-rose-600 font-semibold bg-rose-100 border border-rose-200 px-2 py-0.5 rounded-full">
                {allDebtors.length} مديونية إجمالاً
              </span>
              <div className="md:mr-auto w-full md:w-64 relative">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                <input
                  type="text"
                  value={debtorSearch}
                  onChange={e => setDebtorSearch(e.target.value)}
                  placeholder="ابحث باسم الطالب..."
                  className="w-full h-8 rounded-xl border border-border bg-background pr-9 pl-3 text-xs focus:outline-none focus:ring-2 focus:ring-ring"
                />
              </div>
            </div>
            {debtorSearch.trim() && (
              <div className="w-full overflow-x-auto">
                {filteredDebtors.length === 0 ? (
                  <p className="text-center text-sm text-muted-foreground py-8">لا توجد نتائج</p>
                ) : (
                  <table className="w-full min-w-[640px]">
                    <thead>
                      <tr className="bg-muted/40">
                        {['الطالب', 'الفصل', 'الدبلوم', 'نوع المديونية', 'المستحق', 'المدفوع', 'المتبقي', ''].map(h => (
                          <th key={h} className="px-3 py-2 text-center text-[10px] font-bold text-muted-foreground whitespace-nowrap border-b border-border/40">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {filteredDebtors.map((d, i) => {
                        const isHigh = d.diplomaType === 'عالي';
                        return (
                          <tr key={`search-${i}`} className={`hover:bg-primary/4 transition-colors ${i % 2 === 0 ? 'bg-background' : 'bg-muted/10'}`}>
                            <td className="px-3 py-2.5 whitespace-nowrap">
                              <p className="text-[12px] font-bold text-foreground">{d.student_name}</p>
                              {d.student_status !== 'نشط' && <p className="text-[9px] text-amber-600">{d.student_status}</p>}
                            </td>
                            <td className="px-3 py-2.5 text-center whitespace-nowrap">
                              <span className="text-[11px] font-semibold text-foreground">{d.semesterLabel}</span>
                            </td>
                            <td className="px-3 py-2.5 text-center whitespace-nowrap">
                              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${isHigh ? 'bg-blue-100 text-blue-700 border-blue-200' : 'bg-emerald-100 text-emerald-700 border-emerald-200'}`}>{d.diplomaType}</span>
                            </td>
                            <td className="px-3 py-2.5 text-center"><DebtBadge label={d.debtLabel} /></td>
                            <td className="px-3 py-2.5 text-center whitespace-nowrap">
                              <span className="text-[11px] font-semibold text-[#1a3c5e] tabular-nums">{fmtMoney(d.charged)}</span>
                            </td>
                            <td className="px-3 py-2.5 text-center whitespace-nowrap">
                              <span className="text-[11px] font-semibold text-emerald-700 tabular-nums">{fmtMoney(d.paid)}</span>
                            </td>
                            <td className="px-3 py-2.5 text-center whitespace-nowrap">
                              <span className="text-[12px] font-black text-rose-600 tabular-nums">{fmtMoney(d.debt)}</span>
                            </td>
                            <td className="px-3 py-2.5 text-center">
                              <button onClick={() => navigate(`/student/${d.student_id}`)}
                                className="inline-flex items-center gap-1 h-7 px-2 rounded-lg text-[10px] font-semibold bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground transition-all border border-primary/20">
                                <ExternalLink className="w-3 h-3" />
                                <span className="hidden md:inline">ملف</span>
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                )}
              </div>
            )}
            {!debtorSearch.trim() && (
              <p className="text-center text-[11px] text-muted-foreground py-4">اكتب اسم الطالب للبحث في جميع المديونين</p>
            )}
          </div>
        )}

      </div>
      <FinancialAuditDialog open={auditDialogOpen} onOpenChange={setAuditDialogOpen} />
    </MainLayout>
  );
}
