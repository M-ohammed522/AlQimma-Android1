// إعدادات النظام المتقدمة - منظومة معهد القمة
import { useEffect, useState, useCallback } from 'react';
import { normalizeArabicNumerals } from '@/components/ui/numeric-input';
import { useNavigate } from 'react-router-dom';
import {
  Settings, ChevronRight, Lock, Save, Plus, Trash2, Edit2,
  DollarSign, FileImage, BookOpen, Hash, ClipboardList,
  ShieldAlert, AlertTriangle, RefreshCw, Mail, AtSign, Key, Send, BarChart2,
  Download, CheckCircle2, Database, Eye, EyeOff, Archive, FolderArchive, FileCode,
} from 'lucide-react';
import { toast } from 'sonner';
import { downloadFullSystemZip, type ExportProgress } from '@/lib/projectZipExporter';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  getSettings, updateSetting, getSpecializations,
  addSpecialization, updateSpecialization, deleteSpecialization,
  clearAllSystemData, getStudents, getAllReceiptsUnpaged,
} from '@/lib/api';
import type { Specialization } from '@/types/index';
import { SYSTEM_PASSWORD, SETTINGS_KEYS } from '@/types/index';
import DeviceRolesManager from '@/components/settings/DeviceRolesManager';
import { useDeviceRole } from '@/contexts/DeviceRoleContext';

// ── مكوّن بطاقة القسم ──────────────────────────────────────────────────
function SectionCard({
  icon, title, accent = 'blue', children,
}: {
  icon: React.ReactNode;
  title: string;
  accent?: 'blue' | 'emerald' | 'amber' | 'red' | 'purple';
  children: React.ReactNode;
}) {
  const accentMap = {
    blue:    'border-blue-500/20 bg-blue-500/[0.03]',
    emerald: 'border-emerald-500/20 bg-emerald-500/[0.03]',
    amber:   'border-amber-500/20 bg-amber-500/[0.03]',
    red:     'border-destructive/30 bg-destructive/[0.03]',
    purple:  'border-purple-500/20 bg-purple-500/[0.03]',
  };
  const iconMap = {
    blue:    'bg-blue-500/10 text-blue-600',
    emerald: 'bg-emerald-500/10 text-emerald-600',
    amber:   'bg-amber-500/10 text-amber-600',
    red:     'bg-destructive/10 text-destructive',
    purple:  'bg-purple-500/10 text-purple-600',
  };
  return (
    <Card className={`border ${accentMap[accent]} shadow-sm`}>
      <CardHeader className="pb-3 pt-4 px-5">
        <CardTitle className="text-sm font-bold flex items-center gap-2.5">
          <span className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${iconMap[accent]}`}>
            {icon}
          </span>
          {title}
        </CardTitle>
      </CardHeader>
      <Separator className="mx-5 w-auto opacity-60" />
      <CardContent className="px-5 pb-5 pt-4">{children}</CardContent>
    </Card>
  );
}

export default function SystemSettingsPage() {
  const navigate = useNavigate();
  const { currentRole } = useDeviceRole();
  const [unlocked, setUnlocked] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isShaking, setIsShaking] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [settings, setSettings] = useState<Record<string, string>>({});
  const [specs, setSpecs] = useState<Specialization[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  const [feeEdits, setFeeEdits] = useState<Record<string, string>>({});

  // ── بريد إلكتروني ──
  const [emlEnabled,  setEmlEnabled]  = useState(false);
  const [emlTo,       setEmlTo]       = useState('');
  const [emlFrom,     setEmlFrom]     = useState('');
  const [emlPassword, setEmlPassword] = useState('');
  const [emlSaving,   setEmlSaving]   = useState(false);
  const [emlTesting,  setEmlTesting]  = useState(false);

  // ── تخصصات ──
  const [newSpecName, setNewSpecName] = useState('');
  const [newSpecDiploma, setNewSpecDiploma] = useState<'عالي' | 'متوسط'>('عالي');
  const [editingSpec, setEditingSpec] = useState<{ id: number; name: string } | null>(null);

  // ── نسخ احتياطي ──
  const [backingUp, setBackingUp] = useState(false);
  // ── تصدير حزمة المنظومة ZIP ──
  const [zipping, setZipping] = useState(false);
  const [zipProgress, setZipProgress] = useState<ExportProgress | null>(null);

  const handleDownloadSystemZip = async () => {
    setZipping(true);
    setZipProgress({ step: 'بدء تجميع ملفات المنظومة...', percent: 5 });
    try {
      const res = await downloadFullSystemZip((p) => {
        setZipProgress(p);
      });
      toast.success('تم تنزيل حزمة المنظومة الكاملة بنجاح (ZIP)', {
        description: `تم حزم ${res.totalFiles} ملفاً تشمل مجلد src وملف package.json والبيانات`,
        duration: 8000,
      });
    } catch (err) {
      toast.error('حدث خطأ أثناء حزم المنظومة: ' + String(err));
    } finally {
      setZipping(false);
      setZipProgress(null);
    }
  };

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [cfg, specsData] = await Promise.all([getSettings(), getSpecializations()]);
      setSettings(cfg);
      setSpecs(specsData);
      setFeeEdits({
        [SETTINGS_KEYS.HIGH_DIPLOMA_FEE]:              cfg[SETTINGS_KEYS.HIGH_DIPLOMA_FEE]              ?? '600',
        [SETTINGS_KEYS.MID_DIPLOMA_FEE]:               cfg[SETTINGS_KEYS.MID_DIPLOMA_FEE]               ?? '550',
        [SETTINGS_KEYS.EQUIVALENCY_REGISTRATION_FEE]:  cfg[SETTINGS_KEYS.EQUIVALENCY_REGISTRATION_FEE]  ?? '100',
        [SETTINGS_KEYS.EQUIVALENCY_SEMESTER_FEE]:      cfg[SETTINGS_KEYS.EQUIVALENCY_SEMESTER_FEE]      ?? '250',
        [SETTINGS_KEYS.GRADUATION_PROJECT_FEE]:        cfg[SETTINGS_KEYS.GRADUATION_PROJECT_FEE]        ?? '350',
        [SETTINGS_KEYS.REQUIRED_PHOTOS_COUNT]:         cfg[SETTINGS_KEYS.REQUIRED_PHOTOS_COUNT]         ?? '6',
        [SETTINGS_KEYS.RECEIPT_COUNTER_HIGH]:          cfg[SETTINGS_KEYS.RECEIPT_COUNTER_HIGH]          ?? '000000',
        [SETTINGS_KEYS.RECEIPT_COUNTER_MID]:           cfg[SETTINGS_KEYS.RECEIPT_COUNTER_MID]           ?? '000000',
        [SETTINGS_KEYS.SUPPLY_ORDER_COUNTER_HIGH]:     cfg[SETTINGS_KEYS.SUPPLY_ORDER_COUNTER_HIGH]     ?? '0',
        [SETTINGS_KEYS.SUPPLY_ORDER_COUNTER_MID]:      cfg[SETTINGS_KEYS.SUPPLY_ORDER_COUNTER_MID]      ?? '0',
      });
      setEmlEnabled(cfg[SETTINGS_KEYS.EMAIL_ENABLED] === 'true');
      setEmlTo(cfg[SETTINGS_KEYS.EMAIL_TO] ?? '');
      setEmlFrom(cfg[SETTINGS_KEYS.EMAIL_FROM] ?? '');
      setEmlPassword(cfg[SETTINGS_KEYS.EMAIL_PASSWORD] ?? '');
    } catch {
      toast.error('خطأ في تحميل الإعدادات');
    } finally {
      setLoading(false);
    }
  }, []);

  const handleUnlock = () => {
    if (passwordInput === SYSTEM_PASSWORD) {
      setIsSubmitting(true);
      setPasswordError('');
      setTimeout(() => {
        setUnlocked(true);
        setIsSubmitting(false);
        fetchData();
        toast.success('مرحباً بك في لوحة إعدادات النظام');
      }, 250);
    } else {
      setPasswordError('كلمة المرور غير صحيحة');
      setIsShaking(true);
      setTimeout(() => setIsShaking(false), 500);
      toast.error('كلمة المرور غير صحيحة');
    }
  };

  const handleSaveFees = async () => {
    setSaving(true);
    try {
      await Promise.all(Object.entries(feeEdits).map(([key, value]) => updateSetting(key, value)));
      toast.success('تم حفظ إعدادات الرسوم بنجاح');
      fetchData();
    } catch { toast.error('فشل في حفظ الإعدادات'); }
    finally { setSaving(false); }
  };

  const handleResetReceiptCounter = async () => {
    setSaving(true);
    try {
      await Promise.all([
        updateSetting(SETTINGS_KEYS.RECEIPT_COUNTER_HIGH, feeEdits[SETTINGS_KEYS.RECEIPT_COUNTER_HIGH] ?? '000000'),
        updateSetting(SETTINGS_KEYS.RECEIPT_COUNTER_MID,  feeEdits[SETTINGS_KEYS.RECEIPT_COUNTER_MID]  ?? '000000'),
      ]);
      toast.success('تم تحديث عدادَي الإيصالات بنجاح');
      fetchData();
    } catch { toast.error('فشل في تحديث العدادات'); }
    finally { setSaving(false); }
  };

  const handleSaveSupplyOrderCounters = async () => {
    setSaving(true);
    try {
      await Promise.all([
        updateSetting(SETTINGS_KEYS.SUPPLY_ORDER_COUNTER_HIGH, feeEdits[SETTINGS_KEYS.SUPPLY_ORDER_COUNTER_HIGH] ?? '0'),
        updateSetting(SETTINGS_KEYS.SUPPLY_ORDER_COUNTER_MID,  feeEdits[SETTINGS_KEYS.SUPPLY_ORDER_COUNTER_MID]  ?? '0'),
      ]);
      toast.success('تم تحديث عدادات أوامر التوريد بنجاح');
      fetchData();
    } catch { toast.error('فشل في تحديث العدادات'); }
    finally { setSaving(false); }
  };

  const handleSaveEmail = async () => {
    setEmlSaving(true);
    try {
      await Promise.all([
        updateSetting(SETTINGS_KEYS.EMAIL_ENABLED,  emlEnabled ? 'true' : 'false'),
        updateSetting(SETTINGS_KEYS.EMAIL_TO,        emlTo.trim()),
        updateSetting(SETTINGS_KEYS.EMAIL_FROM,      emlFrom.trim()),
        updateSetting(SETTINGS_KEYS.EMAIL_PASSWORD,  emlPassword.trim()),
      ]);
      toast.success('تم حفظ إعدادات البريد الإلكتروني');
    } catch { toast.error('فشل حفظ إعدادات البريد الإلكتروني'); }
    finally { setEmlSaving(false); }
  };

  const handleTestEmail = async () => {
    if (!emlTo || !emlFrom || !emlPassword) { toast.error('أدخل بيانات الإيميل أولاً'); return; }
    setEmlTesting(true);
    try {
      const { supabase } = await import('@/db/supabase');
      const { error } = await supabase.functions.invoke('send-email', {
        body: { type: 'تجربة', message: 'رسالة تجريبية من منظومة معهد القمة ✅' },
      });
      if (error) throw error;
      toast.success('تم إرسال إيميل تجريبي — تحقق من صندوق الوارد');
    } catch (e) { toast.error('فشل الإرسال: ' + String(e)); }
    finally { setEmlTesting(false); }
  };

  const [debtReportSending, setDebtReportSending] = useState(false);
  const handleSendDebtReport = async () => {
    setDebtReportSending(true);
    try {
      const { supabase } = await import('@/db/supabase');
      const { error } = await supabase.functions.invoke('daily-debt-report', { body: {} });
      if (error) throw error;
      toast.success('تم إرسال تقرير المديونية بنجاح');
    } catch (e) { toast.error('فشل الإرسال: ' + String(e)); }
    finally { setDebtReportSending(false); }
  };

  // ── نسخ احتياطي ──────────────────────────────────────────────────────
  const handleBackup = async () => {
    setBackingUp(true);
    try {
      const [studentsRes, receiptsRaw, settingsRaw, specsRaw] = await Promise.all([
        getStudents({ limit: 5000 }),
        getAllReceiptsUnpaged(),
        getSettings(),
        getSpecializations(),
      ]);
      const backup = {
        version: '1.0',
        exported_at: new Date().toISOString(),
        students: studentsRes.data,
        receipts: receiptsRaw,
        settings: settingsRaw,
        specializations: specsRaw,
      };
      const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
      const url  = URL.createObjectURL(blob);
      const date = new Date().toISOString().slice(0, 10);
      const a    = document.createElement('a');
      a.href     = url;
      a.download = `backup-qimma-${date}.json`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success(`تم تصدير النسخة الاحتياطية بنجاح`, {
        description: `${studentsRes.data.length} طالب · ${receiptsRaw.length} إيصال · ${specsRaw.length} تخصص`,
        duration: 6000,
      });
    } catch (e) { toast.error('فشل تصدير النسخة الاحتياطية: ' + String(e)); }
    finally { setBackingUp(false); }
  };

  // ── منطقة الخطر ──
  const [showResetDialog, setShowResetDialog] = useState(false);
  const [resetPassword, setResetPassword]     = useState('');
  const [resetError, setResetError]           = useState('');
  const [resetting, setResetting]             = useState(false);
  const [resetConfirmText, setResetConfirmText] = useState('');

  const handleClearAllData = async () => {
    if (resetPassword !== SYSTEM_PASSWORD) { setResetError('كلمة المرور غير صحيحة'); return; }
    if (resetConfirmText !== 'مسح') { setResetError('اكتب كلمة "مسح" للتأكيد'); return; }
    setResetting(true);
    try {
      await clearAllSystemData();
      toast.success('تم مسح جميع بيانات النظام بنجاح', {
        description: 'الطلاب · الإيصالات · الرسوم · الإشعارات · العدادات — تم تصفير الكل',
        duration: 8000,
      });
      setShowResetDialog(false);
      setResetPassword(''); setResetError(''); setResetConfirmText('');
      navigate('/');
    } catch { toast.error('فشل في مسح البيانات — حاول مرة أخرى'); }
    finally { setResetting(false); }
  };

  const handleAddSpec = async () => {
    if (!newSpecName.trim()) { toast.error('أدخل اسم التخصص'); return; }
    setSaving(true);
    try {
      await addSpecialization(newSpecName.trim(), newSpecDiploma);
      toast.success(`تمت إضافة تخصص ${newSpecName}`);
      setNewSpecName('');
      fetchData();
    } catch { toast.error('فشل في إضافة التخصص'); }
    finally { setSaving(false); }
  };

  const handleUpdateSpec = async () => {
    if (!editingSpec || !editingSpec.name.trim()) return;
    setSaving(true);
    try {
      await updateSpecialization(editingSpec.id, editingSpec.name.trim());
      toast.success('تم تحديث اسم التخصص');
      setEditingSpec(null);
      fetchData();
    } catch { toast.error('فشل في تحديث التخصص'); }
    finally { setSaving(false); }
  };

  const handleDeleteSpec = async (id: number, name: string) => {
    setSaving(true);
    try {
      await deleteSpecialization(id);
      toast.success(`تم حذف تخصص ${name}`);
      fetchData();
    } catch { toast.error('فشل في حذف التخصص'); }
    finally { setSaving(false); }
  };

  // ── شاشة كلمة المرور الاحترافية ─────────────────────────────────────────
  if (!unlocked) {
    return (
      <MainLayout>
        <style>{`
          @keyframes shake-anim {
            0%, 100% { transform: translateX(0); }
            15%, 45%, 75% { transform: translateX(-6px); }
            30%, 60%, 90% { transform: translateX(6px); }
          }
          .shake-active {
            animation: shake-anim 0.5s cubic-bezier(0.36, 0.07, 0.19, 0.97) both;
          }
        `}</style>

        <div className="flex items-center justify-center min-h-[75vh] p-4 py-8" dir="rtl">
          {/* بطاقة إعدادات النظام الاحترافية */}
          <div className={`w-full max-w-sm rounded-3xl border border-border/80 bg-card/95 backdrop-blur-xl shadow-xl shadow-black/5 dark:shadow-black/30 overflow-hidden transition-all duration-300 ${isShaking ? 'shake-active' : ''}`}>
            <div className="p-7 space-y-6">
              {/* أيقونة القفل المركزية والعنوان */}
              <div className="text-center space-y-3.5">
                <div className="w-16 h-16 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center mx-auto shadow-xs">
                  <Lock className="w-7 h-7 text-primary stroke-[2.2]" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-foreground tracking-tight">لوحة إعدادات النظام</h2>
                  <p className="text-xs text-muted-foreground mt-1 font-medium">محمية بكلمة مرور أمنية</p>
                </div>
              </div>

              {/* حقل إدخال كلمة المرور */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-semibold text-foreground/90">
                  <Label className="text-xs font-semibold cursor-pointer">كلمة المرور الأمنية</Label>
                </div>

                <div className="relative flex items-center">
                  <Input
                    type={showPassword ? 'text' : 'password'}
                    placeholder="أدخل الرمز السري"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    autoComplete="one-time-code"
                    value={passwordInput}
                    onChange={e => {
                      setPasswordInput(normalizeArabicNumerals(e.target.value).replace(/\D/g, ''));
                      setPasswordError('');
                    }}
                    onKeyDown={e => e.key === 'Enter' && handleUnlock()}
                    className={`h-12 px-4 pr-4 pl-11 font-mono text-center tracking-widest text-base rounded-xl border transition-all ${
                      passwordError
                        ? 'border-destructive bg-destructive/5 text-destructive focus-visible:ring-destructive'
                        : 'border-border/80 bg-background/60 focus:border-primary focus-visible:ring-primary/20'
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute left-3 w-7 h-7 rounded-lg text-muted-foreground hover:text-foreground flex items-center justify-center transition-colors"
                    title={showPassword ? 'إخفاء الرمز' : 'إظهار الرمز'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>

                {passwordError && (
                  <div className="text-xs text-destructive bg-destructive/10 border border-destructive/20 rounded-xl p-2.5 flex items-center gap-2 animate-in fade-in">
                    <AlertTriangle className="w-4 h-4 shrink-0" />
                    <span>{passwordError}</span>
                  </div>
                )}
              </div>

              {/* زر الدخول */}
              <Button
                onClick={handleUnlock}
                disabled={isSubmitting}
                className="w-full h-12 rounded-xl text-sm font-bold bg-[#1a3c5e] hover:bg-[#15324f] text-white shadow-md shadow-[#1a3c5e]/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>جاري التحقق...</span>
                  </>
                ) : (
                  <>
                    <Lock className="w-4 h-4" />
                    <span>دخول</span>
                  </>
                )}
              </Button>

              {/* رابط العودة للرئيسية */}
              <button
                type="button"
                onClick={() => navigate('/')}
                className="w-full text-xs text-muted-foreground hover:text-foreground flex items-center justify-center gap-1 transition-colors pt-1"
              >
                <ChevronRight className="w-3.5 h-3.5" />
                <span>العودة للرئيسية</span>
              </button>
            </div>
          </div>
        </div>
      </MainLayout>
    );
  }

  // ── الصفحة الرئيسية ────────────────────────────────────────────────────
  return (
    <>
    <MainLayout>
      <div className="space-y-6 max-w-3xl mx-auto pb-10" dir="rtl">

        {/* ── رأس الصفحة ── */}
        <div className="relative overflow-hidden rounded-2xl px-6 py-5 shadow-sm"
          style={{ background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--primary)/0.75) 100%)' }}>
          <div className="absolute inset-0 opacity-[0.06]"
            style={{ backgroundImage: 'radial-gradient(circle,white 1px,transparent 1px)', backgroundSize: '20px 20px' }} />
          <div className="relative flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <button onClick={() => navigate('/')}
                className="w-8 h-8 rounded-xl bg-white/10 border border-white/20 flex items-center justify-center hover:bg-white/25 transition-all shrink-0">
                <ChevronRight className="w-4 h-4 text-white" />
              </button>
              <div>
                <h1 className="text-white font-bold text-base flex items-center gap-2">
                  <Settings className="w-4 h-4" />إعدادات النظام المتقدمة
                </h1>
                <p className="text-white/60 text-[11px] mt-0.5">منظومة معهد القمة للعلوم الطبية والإدارية</p>
              </div>
            </div>
            {/* أزرار تنزيل المنظومة والنسخ الاحتياطي في الترويسة */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleDownloadSystemZip}
                disabled={zipping || backingUp || loading}
                className="flex items-center gap-2 px-3.5 py-2 rounded-xl font-bold text-xs transition-all active:scale-95 disabled:opacity-60 shadow-lg bg-emerald-500/25 hover:bg-emerald-500/35 border border-emerald-400/40 text-emerald-100"
              >
                {zipping ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>جاري إنشاء ZIP ({zipProgress?.percent ?? 0}%)...</span>
                  </>
                ) : (
                  <>
                    <Archive className="w-3.5 h-3.5 text-emerald-300" />
                    <span>تنزيل المنظومة ZIP</span>
                  </>
                )}
              </button>
              <button
                type="button"
                onClick={handleBackup}
                disabled={backingUp || zipping || loading}
                className="hidden sm:flex items-center gap-2 px-3 py-2 rounded-xl font-semibold text-xs transition-all active:scale-95 disabled:opacity-60 shadow-lg bg-white/10 hover:bg-white/20 border border-white/20 text-white"
              >
                {backingUp ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Database className="w-3.5 h-3.5" />}
                <span>قاعدة البيانات JSON</span>
              </button>
            </div>
          </div>
        </div>

        {/* ══ قسم إدارة وظائف وصلاحيات الأجهزة ══ */}
        <DeviceRolesManager />

        {/* ── بطاقة تنزيل ملف المنظومة كامل ZIP والنسخ الاحتياطي ── */}
        <SectionCard icon={<FolderArchive className="w-3.5 h-3.5" />} title="تنزيل حزمة المنظومة الكاملة والنسخ الاحتياطي (ZIP)" accent="purple">
          <div className="space-y-4">
            <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
              <div className="flex-1 space-y-1.5">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-bold text-foreground">تنزيل ملف المنظومة الأصلي كاملاً كملف مضغوط (ZIP)</p>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-primary/10 text-primary border border-primary/20">
                    يشمل src و package.json
                  </span>
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  يقوم بضغط وتحزيم الكود المصدري الأصلي للمشروع كاملاً (مجلد <code className="font-mono bg-muted px-1 rounded text-primary">src/</code> بجميع صفحاته ومكوناته، ملف <code className="font-mono bg-muted px-1 rounded text-primary">package.json</code>، ملفات الإعدادات والأنماط) مدمجاً مع نسخة احتياطية لكافة بيانات قاعدة البيانات ودليل التشغيل المحلي الشامل.
                </p>
                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <span className="flex items-center gap-1 text-[11px] font-semibold text-blue-600 dark:text-blue-400 bg-blue-500/10 border border-blue-500/20 px-2.5 py-0.5 rounded-full">
                    <FileCode className="w-3 h-3" /> مجلد الكود src (أكثر من 110 ملفات)
                  </span>
                  <span className="flex items-center gap-1 text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 bg-indigo-500/10 border border-indigo-500/20 px-2.5 py-0.5 rounded-full">
                    <CheckCircle2 className="w-3 h-3" /> ملف package.json والاعتماديات
                  </span>
                  <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-0.5 rounded-full">
                    <Database className="w-3 h-3" /> بيانات الطلاب والإيصالات (JSON & SQL)
                  </span>
                  <span className="flex items-center gap-1 text-[11px] font-semibold text-purple-600 dark:text-purple-400 bg-purple-500/10 border border-purple-500/20 px-2.5 py-0.5 rounded-full">
                    <CheckCircle2 className="w-3 h-3" /> دليل التشغيل المحلي (README)
                  </span>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-2.5 shrink-0 w-full md:w-auto">
                <Button
                  onClick={handleDownloadSystemZip}
                  disabled={zipping || backingUp || loading}
                  className="w-full sm:w-auto gap-2 bg-gradient-to-r from-blue-600 via-indigo-600 to-primary hover:from-blue-700 hover:to-indigo-700 text-white font-bold shadow-md h-10 px-5 rounded-xl transition-all hover:scale-[1.02] active:scale-[0.98]"
                >
                  {zipping ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>جاري إنشاء وحزم ZIP...</span>
                    </>
                  ) : (
                    <>
                      <Archive className="w-4 h-4" />
                      <span>تنزيل ملف المنظومة كامل ZIP</span>
                    </>
                  )}
                </Button>

                <Button
                  variant="outline"
                  onClick={handleBackup}
                  disabled={backingUp || zipping || loading}
                  className="w-full sm:w-auto gap-2 h-10 px-4 rounded-xl text-xs font-semibold"
                >
                  {backingUp ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>جاري التصدير...</span>
                    </>
                  ) : (
                    <>
                      <Download className="w-3.5 h-3.5" />
                      <span>قاعدة البيانات فقط (JSON)</span>
                    </>
                  )}
                </Button>
              </div>
            </div>

            {/* شريط تقدم تفاعلي مباشر أثناء عملية إنشاء وضغط حزمة ZIP */}
            {zipping && zipProgress && (
              <div className="p-3.5 rounded-xl bg-primary/5 border border-primary/20 space-y-2 animate-in fade-in duration-300">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-foreground flex items-center gap-2">
                    <RefreshCw className="w-3 h-3 animate-spin text-primary" />
                    {zipProgress.step}
                  </span>
                  <span className="font-mono font-bold text-primary">{zipProgress.percent}%</span>
                </div>
                <div className="w-full h-2 rounded-full bg-primary/10 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-blue-500 to-indigo-600 transition-all duration-300 rounded-full"
                    style={{ width: `${zipProgress.percent}%` }}
                  />
                </div>
              </div>
            )}
          </div>
        </SectionCard>

        {/* ── إعدادات الرسوم المالية ── */}
        <SectionCard icon={<DollarSign className="w-3.5 h-3.5" />} title="إعدادات الرسوم المالية" accent="emerald">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              { key: SETTINGS_KEYS.HIGH_DIPLOMA_FEE,             label: 'رسوم الفصل — دبلوم عالي',        unit: 'د.ل' },
              { key: SETTINGS_KEYS.MID_DIPLOMA_FEE,              label: 'رسوم الفصل — دبلوم متوسط',       unit: 'د.ل' },
              { key: SETTINGS_KEYS.EQUIVALENCY_REGISTRATION_FEE, label: 'رسوم تسجيل المعادلة',            unit: 'د.ل' },
              { key: SETTINGS_KEYS.EQUIVALENCY_SEMESTER_FEE,     label: 'رسوم فصل المعادلة',              unit: 'د.ل/فصل' },
              { key: SETTINGS_KEYS.GRADUATION_PROJECT_FEE,       label: 'رسوم مشروع التخرج',              unit: 'د.ل' },
            ].map(field => (
              <div key={field.key} className="space-y-1.5">
                <label className="text-[11px] font-semibold text-muted-foreground">{field.label}</label>
                <div className="relative">
                  <Input
                    type="text" inputMode="decimal"
                    value={feeEdits[field.key] ?? ''}
                    onChange={e => setFeeEdits(p => ({ ...p, [field.key]: e.target.value }))}
                    className="h-9 text-sm font-mono pl-14 bg-muted/30 border-border/50 focus-visible:border-emerald-500/60 focus-visible:ring-emerald-500/20" />
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[10px] font-bold text-muted-foreground/60 pointer-events-none">{field.unit}</span>
                </div>
              </div>
            ))}
            <div className="md:col-span-2 pt-1">
              <Button onClick={handleSaveFees} disabled={saving || loading} className="gap-2 bg-emerald-600 hover:bg-emerald-700 text-white">
                <Save className="w-3.5 h-3.5" />
                {saving ? 'جاري الحفظ...' : 'حفظ إعدادات الرسوم'}
              </Button>
            </div>
          </div>
        </SectionCard>

        {/* ── الأوراق الثبوتية ── */}
        <SectionCard icon={<FileImage className="w-3.5 h-3.5" />} title="الأوراق الثبوتية" accent="blue">
          <div className="flex items-end gap-3 max-w-xs">
            <div className="flex-1 space-y-1.5">
              <label className="text-[11px] font-semibold text-muted-foreground">عدد الصور الشخصية المطلوبة</label>
              <Input
                type="text" inputMode="numeric"
                value={feeEdits[SETTINGS_KEYS.REQUIRED_PHOTOS_COUNT] ?? '6'}
                onChange={e => setFeeEdits(p => ({ ...p, [SETTINGS_KEYS.REQUIRED_PHOTOS_COUNT]: e.target.value.replace(/\D/g, '') }))}
                className="h-9 text-sm font-mono text-center bg-muted/30 border-border/50 w-24" />
            </div>
            <Button size="sm" onClick={async () => {
              setSaving(true);
              try {
                await updateSetting(SETTINGS_KEYS.REQUIRED_PHOTOS_COUNT, feeEdits[SETTINGS_KEYS.REQUIRED_PHOTOS_COUNT] ?? '6');
                toast.success('تم تحديث عدد الصور');
              } catch { toast.error('فشل في التحديث'); }
              finally { setSaving(false); }
            }} disabled={saving} className="gap-1.5 h-9 shrink-0">
              <Save className="w-3.5 h-3.5" />حفظ
            </Button>
          </div>
        </SectionCard>

        {/* ── التخصصات ── */}
        <SectionCard icon={<BookOpen className="w-3.5 h-3.5" />} title="إدارة التخصصات" accent="blue">
          <div className="space-y-4">
            {/* إضافة */}
            <div className="flex flex-col md:flex-row gap-2">
              <Input value={newSpecName} onChange={e => setNewSpecName(e.target.value)}
                placeholder="اسم التخصص الجديد"
                className="text-sm flex-1 h-9 bg-muted/30 border-border/50" />
              <Select value={newSpecDiploma} onValueChange={v => setNewSpecDiploma(v as 'عالي' | 'متوسط')}>
                <SelectTrigger className="text-sm w-full md:w-36 h-9 bg-muted/30 border-border/50">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="عالي">دبلوم عالي</SelectItem>
                  <SelectItem value="متوسط">دبلوم متوسط</SelectItem>
                </SelectContent>
              </Select>
              <Button size="sm" onClick={handleAddSpec} disabled={saving} className="gap-1.5 h-9 shrink-0">
                <Plus className="w-3.5 h-3.5" />إضافة
              </Button>
            </div>
            <Separator />
            {['عالي', 'متوسط'].map(diploma => (
              <div key={diploma} className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${diploma === 'عالي' ? 'bg-blue-500/10 text-blue-700 border border-blue-500/20' : 'bg-emerald-500/10 text-emerald-700 border border-emerald-500/20'}`}>
                    {diploma === 'عالي' ? 'دبلوم عالي' : 'دبلوم متوسط'}
                  </span>
                  <span className="text-[10px] text-muted-foreground">{specs.filter(s => s.diploma_type === diploma).length} تخصص</span>
                </div>
                <div className="space-y-1.5">
                  {specs.filter(s => s.diploma_type === diploma).map(spec => (
                    <div key={spec.id} className="flex items-center gap-2 px-3 py-2 rounded-lg border border-border/50 bg-muted/20 hover:bg-muted/40 transition-colors">
                      {editingSpec?.id === spec.id ? (
                        <>
                          <Input value={editingSpec.name}
                            onChange={e => setEditingSpec(p => p ? { ...p, name: e.target.value } : p)}
                            className="text-sm h-8 flex-1 bg-background" />
                          <Button size="icon" className="h-8 w-8 shrink-0" onClick={handleUpdateSpec} disabled={saving}>
                            <Save className="w-3.5 h-3.5" />
                          </Button>
                          <Button size="icon" variant="ghost" className="h-8 w-8 shrink-0 text-muted-foreground" onClick={() => setEditingSpec(null)}>
                            <AlertTriangle className="w-3 h-3" />
                          </Button>
                        </>
                      ) : (
                        <>
                          <span className="text-sm flex-1 min-w-0 font-medium">{spec.name}</span>
                          <button className="w-7 h-7 rounded-lg flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-primary/10 transition-all"
                            onClick={() => setEditingSpec({ id: spec.id, name: spec.name })}>
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button className="w-7 h-7 rounded-lg flex items-center justify-center text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-all"
                            onClick={() => handleDeleteSpec(spec.id, spec.name)} disabled={saving}>
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </>
                      )}
                    </div>
                  ))}
                  {specs.filter(s => s.diploma_type === diploma).length === 0 && (
                    <p className="text-xs text-muted-foreground/60 px-2 py-1">لا توجد تخصصات مضافة</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </SectionCard>

        {/* ── عدادات الإيصالات ── */}
        <SectionCard icon={<Hash className="w-3.5 h-3.5" />} title="عدادات أرقام الإيصالات" accent="blue">
          <div className="space-y-4">
            <p className="text-xs text-muted-foreground bg-muted/40 rounded-lg px-3 py-2 border border-border/40 leading-relaxed">
              آخر رقم إيصال صادر لكل نوع دبلوم. عدّل الرقم لضبط تسلسل الإيصالات عند الانتقال لدفتر جديد.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                { key: SETTINGS_KEYS.RECEIPT_COUNTER_HIGH, label: 'عداد إيصالات الدبلوم العالي',   color: 'blue'    as const },
                { key: SETTINGS_KEYS.RECEIPT_COUNTER_MID,  label: 'عداد إيصالات الدبلوم المتوسط', color: 'emerald' as const },
              ].map(({ key, label, color }) => {
                const isBlue = color === 'blue';
                return (
                  <div key={key} className={`space-y-2 p-3 rounded-xl border ${isBlue ? 'border-blue-500/20 bg-blue-500/[0.04]' : 'border-emerald-500/20 bg-emerald-500/[0.04]'}`}>
                    <div className="flex items-center justify-between">
                      <label className={`text-xs font-bold ${isBlue ? 'text-blue-700' : 'text-emerald-700'}`}>{label}</label>
                      <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold text-white ${isBlue ? 'bg-blue-600' : 'bg-emerald-600'}`}>{isBlue ? 'عالي' : 'متوسط'}</span>
                    </div>
                    <p className="text-[10px] text-muted-foreground">
                      آخر إيصال: <span className="font-mono font-bold text-foreground">{settings[key] ?? '—'}</span>
                    </p>
                    <Input value={feeEdits[key] ?? '000000'}
                      onChange={e => setFeeEdits(p => ({ ...p, [key]: e.target.value.replace(/\D/g, '') }))}
                      placeholder="000000"
                      className="text-sm font-mono h-9 bg-background/70 border-border/50" />
                    <p className="text-[10px] text-muted-foreground">
                      التالي: <span className={`font-mono font-bold ${isBlue ? 'text-blue-700' : 'text-emerald-700'}`}>
                        {String(parseInt(feeEdits[key] ?? '0') + 1).padStart(6, '0')}
                      </span>
                    </p>
                  </div>
                );
              })}
            </div>
            <Button size="sm" onClick={handleResetReceiptCounter} disabled={saving} className="gap-1.5">
              <Save className="w-3.5 h-3.5" />تطبيق العدادات
            </Button>
          </div>
        </SectionCard>

        {/* ── عدادات أوامر التوريد ── */}
        <SectionCard icon={<ClipboardList className="w-3.5 h-3.5" />} title="عدادات أوامر التوريد" accent="blue">
          <div className="space-y-4">
            <div className="text-xs text-muted-foreground bg-muted/40 rounded-lg px-3 py-2 border border-border/40 leading-relaxed">
              رقم المعاملة = العداد + <span className="font-mono font-bold">00</span> — مثال: العداد <span className="font-mono font-bold">5</span> يُنتج <span className="font-mono font-bold">005</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                { key: SETTINGS_KEYS.SUPPLY_ORDER_COUNTER_HIGH, label: 'عداد الدبلوم العالي',   color: 'blue'    as const },
                { key: SETTINGS_KEYS.SUPPLY_ORDER_COUNTER_MID,  label: 'عداد الدبلوم المتوسط', color: 'emerald' as const },
              ].map(({ key, label, color }) => {
                const isBlue = color === 'blue';
                return (
                  <div key={key} className={`space-y-2 p-3 rounded-xl border ${isBlue ? 'border-blue-500/20 bg-blue-500/[0.04]' : 'border-emerald-500/20 bg-emerald-500/[0.04]'}`}>
                    <div className="flex items-center justify-between">
                      <label className={`text-xs font-bold ${isBlue ? 'text-blue-700' : 'text-emerald-700'}`}>{label}</label>
                      <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold text-white ${isBlue ? 'bg-blue-600' : 'bg-emerald-600'}`}>{isBlue ? 'عالي' : 'متوسط'}</span>
                    </div>
                    <Input type="text" inputMode="numeric"
                      value={feeEdits[key] ?? '0'}
                      onChange={e => setFeeEdits(p => ({ ...p, [key]: e.target.value.replace(/\D/g, '') }))}
                      placeholder="0"
                      className="text-sm font-mono h-9 bg-background/70 border-border/50" />
                    <p className="text-[10px] text-muted-foreground">
                      التالي: <span className={`font-mono font-bold ${isBlue ? 'text-blue-700' : 'text-emerald-700'}`}>
                        {String(parseInt(feeEdits[key] ?? '0') + 1).padStart(3, '0')}
                      </span>
                    </p>
                  </div>
                );
              })}
            </div>
            <Button onClick={handleSaveSupplyOrderCounters} disabled={saving || loading} className="gap-2">
              <Save className="w-3.5 h-3.5" />
              {saving ? 'جاري الحفظ...' : 'حفظ العدادات'}
            </Button>
          </div>
        </SectionCard>

        {/* ── البريد الإلكتروني ── */}
        <SectionCard icon={<Mail className="w-3.5 h-3.5" />} title="إشعارات البريد الإلكتروني" accent="blue">
          <div className="space-y-4">
            <p className="text-xs text-muted-foreground leading-relaxed">
              كل إشعار في المنظومة يُرسَل تلقائياً إلى بريدك عبر Gmail.
              يستلزم <span className="font-semibold text-foreground">App Password</span> من Google (مجاني).
            </p>
            {/* toggle */}
            <div className="flex items-center justify-between px-3 py-2.5 rounded-xl border border-border/50 bg-muted/20">
              <span className="text-sm font-semibold">تفعيل إشعارات الإيميل</span>
              <button onClick={() => setEmlEnabled(p => !p)}
                className={`relative w-11 h-6 rounded-full transition-colors ${emlEnabled ? 'bg-blue-500' : 'bg-muted-foreground/30'}`}>
                <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${emlEnabled ? 'translate-x-5' : 'translate-x-0.5'}`} />
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label className="text-[11px] font-semibold text-muted-foreground flex items-center gap-1"><AtSign className="w-3 h-3" />إيميل الاستقبال</label>
                <Input placeholder="example@gmail.com" value={emlTo} onChange={e => setEmlTo(e.target.value)} dir="ltr" type="email" className="h-9 text-sm bg-muted/30 border-border/50" />
              </div>
              <div className="space-y-1.5">
                <label className="text-[11px] font-semibold text-muted-foreground flex items-center gap-1"><Mail className="w-3 h-3" />Gmail للإرسال</label>
                <Input placeholder="your-gmail@gmail.com" value={emlFrom} onChange={e => setEmlFrom(e.target.value)} dir="ltr" type="email" className="h-9 text-sm bg-muted/30 border-border/50" />
              </div>
            </div>
            <div className="space-y-1.5">
              <label className="text-[11px] font-semibold text-muted-foreground flex items-center gap-1"><Key className="w-3 h-3" />Gmail App Password</label>
              <Input placeholder="xxxx xxxx xxxx xxxx" value={emlPassword} onChange={e => setEmlPassword(e.target.value)} dir="ltr" type="password" className="h-9 font-mono text-sm bg-muted/30 border-border/50" />
              <div className="p-3 rounded-lg bg-blue-500/5 border border-blue-500/20 text-[10px] text-blue-700 dark:text-blue-300 space-y-0.5 leading-relaxed">
                <p className="font-bold mb-1">كيف تحصل على App Password:</p>
                <p>1. Google Account → Security → 2-Step Verification (فعّله)</p>
                <p>2. Google Account → Security → App passwords</p>
                <p>3. اختر "Mail" + "Other" → اكتب "معهد القمة" → Generate</p>
                <p>4. انسخ الكود المكوّن من 16 حرفاً وضعه هنا</p>
              </div>
            </div>
            <div className="flex gap-2 flex-wrap pt-1">
              <Button onClick={handleSaveEmail} disabled={emlSaving} className="gap-2">
                <Save className="w-4 h-4" />{emlSaving ? 'جاري الحفظ...' : 'حفظ الإعدادات'}
              </Button>
              <Button onClick={handleTestEmail} disabled={emlTesting || !emlTo || !emlFrom || !emlPassword} variant="outline" className="gap-2">
                <Send className="w-4 h-4" />{emlTesting ? 'جاري الإرسال...' : 'إيميل تجريبي'}
              </Button>
              <Button onClick={handleSendDebtReport} disabled={debtReportSending || !emlTo || !emlFrom || !emlPassword} variant="outline" className="gap-2 border-amber-400/60 text-amber-700 hover:bg-amber-50/50">
                <BarChart2 className="w-4 h-4" />{debtReportSending ? 'جاري الإرسال...' : 'تقرير المديونية'}
              </Button>
            </div>
          </div>
        </SectionCard>

        {/* ── منطقة الخطر ── */}
        <SectionCard icon={<ShieldAlert className="w-3.5 h-3.5" />} title="منطقة الخطر — مسح بيانات النظام" accent="red">
          <div className="flex flex-col md:flex-row gap-4 items-start md:items-center p-4 rounded-xl border border-destructive/20 bg-destructive/[0.04]">
            <div className="flex items-start gap-3 flex-1">
              <div className="w-9 h-9 rounded-xl bg-destructive/10 flex items-center justify-center shrink-0 mt-0.5">
                <AlertTriangle className="w-4 h-4 text-destructive" />
              </div>
              <div className="space-y-1">
                <p className="text-sm font-bold text-destructive">مسح جميع بيانات المنظومة</p>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  يحذف: الطلاب · الإيصالات · الرسوم · الإشعارات · الملفات المرفقة · العدادات<br />
                  <span className="font-semibold text-emerald-700">لا يمسّ: الأرشيف · إعدادات النظام · التخصصات</span>
                </p>
              </div>
            </div>
            <Button variant="outline"
              onClick={() => { setShowResetDialog(true); setResetPassword(''); setResetError(''); setResetConfirmText(''); }}
              className="gap-2 shrink-0 border-destructive/40 text-destructive hover:bg-destructive hover:text-destructive-foreground h-10">
              <Trash2 className="w-4 h-4" />مسح كل البيانات
            </Button>
          </div>
        </SectionCard>

      </div>
    </MainLayout>

    {/* ── حوار تأكيد المسح ── */}
    {showResetDialog && (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
        <div className="w-full max-w-[calc(100%-2rem)] md:max-w-md bg-card rounded-2xl shadow-2xl border border-destructive/30 p-5 space-y-4" dir="rtl">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-destructive/10 flex items-center justify-center">
              <ShieldAlert className="w-5 h-5 text-destructive" />
            </div>
            <div>
              <h2 className="text-base font-black text-destructive">تأكيد مسح جميع البيانات</h2>
              <p className="text-xs text-muted-foreground">هذا الإجراء لا يمكن التراجع عنه</p>
            </div>
          </div>
          <div className="p-3 rounded-xl bg-destructive/5 border border-destructive/20 text-xs text-destructive/90 leading-relaxed space-y-1">
            <p className="font-bold">سيتم حذف:</p>
            <p>• جميع بيانات الطلاب (نشط / موقوف / خريج في الجدول الرئيسي)</p>
            <p>• جميع الإيصالات وأوامر التوريد</p>
            <p>• جميع رسوم الفصول والإشعارات والملفات المرفقة</p>
            <p className="font-bold text-emerald-700 mt-1">✓ الأرشيف والإعدادات والتخصصات لن تُمسّ</p>
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold">كلمة المرور السرية</label>
            <Input type="password" placeholder="أدخل كلمة المرور" value={resetPassword}
              onChange={e => { setResetPassword(e.target.value); setResetError(''); }}
              className={`h-10 ${resetError && !resetPassword ? 'border-destructive' : ''}`} />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold">اكتب <span className="font-mono text-destructive font-black">مسح</span> للتأكيد</label>
            <Input placeholder='اكتب "مسح" هنا' value={resetConfirmText}
              onChange={e => { setResetConfirmText(e.target.value); setResetError(''); }}
              onKeyDown={e => e.key === 'Enter' && handleClearAllData()}
              className={`h-10 ${resetError && resetConfirmText !== 'مسح' ? 'border-destructive' : ''}`} />
          </div>
          {resetError && (
            <p className="text-xs text-destructive font-bold flex items-center gap-1">
              <AlertTriangle className="w-3.5 h-3.5 shrink-0" />{resetError}
            </p>
          )}
          <div className="flex gap-2 pt-1">
            <button onClick={() => { setShowResetDialog(false); setResetPassword(''); setResetError(''); setResetConfirmText(''); }}
              disabled={resetting}
              className="flex-1 h-10 rounded-xl border border-border text-sm font-semibold text-foreground hover:bg-muted transition-colors">
              إلغاء
            </button>
            <button onClick={handleClearAllData}
              disabled={resetting || !resetPassword || resetConfirmText !== 'مسح'}
              className="flex-1 h-10 rounded-xl bg-destructive text-destructive-foreground text-sm font-bold flex items-center justify-center gap-2 hover:bg-destructive/90 disabled:opacity-50 disabled:cursor-not-allowed transition-colors">
              {resetting ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
              {resetting ? 'جاري المسح...' : 'مسح كل البيانات'}
            </button>
          </div>
        </div>
      </div>
    )}
    </>
  );
}

