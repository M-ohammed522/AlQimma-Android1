// @refresh reset
// صفحة أوامر التوريد - منظومة معهد القمة
import React, { useEffect, useState, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ClipboardList, ChevronRight, Printer, RefreshCw,
  Calendar, BadgeDollarSign, FileDown, Pencil, Trash2,
  FileSpreadsheet, GraduationCap, BookOpen, Save, X, CreditCard, Hash, Scissors,
  ChevronDown, Users, Receipt as ReceiptIcon, AlertTriangle, ExternalLink,
} from 'lucide-react';
import { toast } from 'sonner';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTableLib from 'jspdf-autotable';
const autoTable = (typeof autoTableLib === 'function' ? autoTableLib : (autoTableLib as any).default) as typeof autoTableLib;
import { triggerDownload } from '@/lib/printUtils';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
  AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { getSupplyOrdersByDate, getAllSupplyOrders, deleteSupplyOrder, updateSupplyOrderFull, peekCurrentSupplyOrderNumber, formatSupplyOrderNumber, getSettings, compareReceipts, syncUnassignedReceipts, getUnassignedReceiptsCount } from '@/lib/api';
import { SETTINGS_KEYS, SEMESTER_LABELS } from '@/types/index';
import type { Receipt } from '@/types/index';
import { RefreshButton } from '@/components/ui/RefreshButton';

// نوع الصف الموسّع
export type FullReceipt = Receipt & {
  student_name: string;
  student_national_id: string;
  student_diploma: string;
  student_specialization: string;
  student_phone: string | null;
  payment_method?: string;
};

type PaymentMethod = 'كاش' | 'بطاقة' | 'شيك';
const PAYMENT_METHODS: PaymentMethod[] = ['كاش', 'بطاقة', 'شيك'];

const METHOD_STYLE: Record<PaymentMethod, string> = {
  'كاش':   'bg-emerald-50 text-emerald-700 border-emerald-200',
  'بطاقة': 'bg-blue-50 text-blue-700 border-blue-200',
  'شيك':   'bg-amber-50 text-amber-700 border-amber-200',
};

// استخراج معلومات التخفيض من حقل الملاحظات — مثال: "تخفيض: 600 ← 500 د.ل (سبب)"
function parseDiscountNote(notes: string | null | undefined): string | null {
  if (!notes) return null;
  const idx = notes.indexOf('تخفيض:');
  if (idx === -1) return null;
  return notes.slice(idx).trim();
}

// تاريخ اليوم بصيغة yyyy-mm-dd
function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

// تنسيق التاريخ للعرض
// أسماء الأيام والأشهر بالعربية (ثابتة — تتجاوز مشكلة locale في المتصفح)
const AR_MONTHS = ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
const AR_DAYS   = ['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];

function parseDate(d: string) {
  // إضافة T00:00:00 لتجنب إزاحة المنطقة الزمنية
  return new Date(d.length === 10 ? d + 'T00:00:00' : d);
}
function fmtDate(d: string) {
  const dt = parseDate(d);
  return `${AR_DAYS[dt.getDay()]} ${dt.getDate()} ${AR_MONTHS[dt.getMonth()]} ${dt.getFullYear()}`;
}
function fmtDay(d: string)      { return AR_DAYS[parseDate(d).getDay()]; }
function fmtShortDate(d: string) {
  const dt = parseDate(d);
  return `${dt.getDate()} ${AR_MONTHS[dt.getMonth()]} ${dt.getFullYear()}`;
}

// ── بطاقة إحصاء ──
function StatCard({ icon: Icon, label, value, sub, gradient }: {
  icon: React.ComponentType<{ className?: string }>;
  label: string; value: string; sub?: string; gradient: string;
}) {
  return (
    <div className={`rounded-xl overflow-hidden border shadow-sm ${gradient}`}>
      <div className="p-3 md:p-4">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <p className="text-[10px] md:text-[11px] text-white/70 font-medium leading-tight">{label}</p>
            <p className="text-xl md:text-2xl font-black text-white leading-none mt-1 tabular-nums">{value}</p>
            {sub && <p className="text-[10px] text-white/55 mt-1 truncate">{sub}</p>}
          </div>
          <div className="w-8 h-8 md:w-9 md:h-9 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
            <Icon className="w-4 h-4 text-white" />
          </div>
        </div>
      </div>
    </div>
  );
}

// ── رابط الشعار — v2 ──
const LOGO_URL = 'https://miaoda-conversation-file.s3cdn.medo.dev/user-cim4m3x63pxc/app-f6avantw6h35/20261018/FB_IMG_1780949707596.jpg';

// تنسيق DD/MM/YYYY
function fmtDDMMYYYY(d: string) {
  const dt = parseDate(d);
  const dd = String(dt.getDate()).padStart(2, '0');
  const mm = String(dt.getMonth() + 1).padStart(2, '0');
  return `${dd}/${mm}/${dt.getFullYear()}`;
}

// ── بناء HTML أمر التوريد — تصميم مطابق لنموذج M-on.jpg ──
// يقبل صفاً واحداً أو مصفوفة صفوف لنفس رقم الأمر
function buildSupplyOrderHTML(orderOrRows: FullReceipt | FullReceipt[], autoprint = true): string {
  const rows: FullReceipt[] = Array.isArray(orderOrRows) ? orderOrRows : [orderOrRows];
  const order = rows[0];
  const isHigh  = order.student_diploma === 'عالي';
  const diplLbl = isHigh ? 'الدبلوم العالـي' : 'الدبلوم المتوسط';
  const paidDate = fmtDDMMYYYY(order.paid_at);
  const totalAmount  = rows.reduce((s, r) => s + r.amount, 0);
  const dinarsTotal  = Math.floor(totalAmount);
  const dirhamsTotal = Math.round((totalAmount - dinarsTotal) * 1000);
  const discountNote = parseDiscountNote(order.notes);
  const otherNotes   = order.notes && !order.notes.startsWith('تخفيض:')
    ? order.notes.replace(/تخفيض:[^\n]*/g, '').trim()
    : null;

  // صفوف البيانات — الترتيب: ث | الاسم | دينار | درهم | رقم الإيصال | طريقة الدفع | البيان
  const tableRows = rows.map((r, i) => {
    const d  = Math.floor(r.amount);
    const dr = Math.round((r.amount - d) * 1000);
    return `<tr>
      <td>${i + 1}</td>
      <td class="rtl">${r.student_name}</td>
      <td class="mono">${d.toLocaleString('ar-LY')}</td>
      <td class="mono">${String(dr).padStart(3,'0')}</td>
      <td class="mono">${String(r.receipt_number).padStart(5,'0')}</td>
      <td>${(r as FullReceipt).payment_method ?? 'بطاقة'}</td>
      <td class="rtl">${r.semester_target ?? r.payment_type}</td>
    </tr>`;
  }).join('');

  // صفوف فارغة — نملأ حتى 12 صفاً
  const ROWS_MIN = 12;
  const emptyCount = Math.max(0, ROWS_MIN - rows.length);
  const emptyRows  = Array.from({ length: emptyCount }).map(() =>
    `<tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>`
  ).join('');

  return `<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
<meta charset="utf-8"/>
<title>أمر توريد ${order.supply_order_number}</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap');

/* ─── ضبط A4 الصارم ─── */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

html, body {
  width: 210mm;
  height: 297mm;
  font-family: 'Cairo', Tahoma, Arial, sans-serif;
  direction: rtl;
  background: #fff;
  -webkit-print-color-adjust: exact;
  print-color-adjust: exact;
  font-size: 14px;
  color: #111;
}

/* الصفحة الرئيسية — يملأ A4 تماماً */
.page {
  width: 210mm;
  min-height: 297mm;
  padding: 10mm 12mm 8mm;
  display: flex;
  flex-direction: column;
  background: #fff;
}

/* ── الرأس ── */
.hdr {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  padding-bottom: 6px;
  border-bottom: 2px solid #1a3a6e;
  margin-bottom: 5px;
}
.hdr-logo {
  width: 68px; height: 68px;
  border-radius: 50%;
  overflow: hidden;
  border: 2.5px solid #2563ab;
  flex-shrink: 0;
}
.hdr-logo img { width: 100%; height: 100%; object-fit: cover; }
.hdr-info { flex: 1; text-align: center; }
.hdr-info h1 {
  font-size: 16px;
  font-weight: 900;
  color: #1a3a6e;
  line-height: 1.35;
}
.hdr-info .branch {
  font-size: 11px;
  color: #555;
  margin-top: 3px;
  font-weight: 600;
}
/* عمود يمين خالٍ لموازنة الشعار */
.hdr-spacer { width: 68px; flex-shrink: 0; }

/* ── رقم المعاملة والتاريخ ── */
.meta-bar {
  display: flex;
  justify-content: space-between;
  font-size: 13px;
  font-weight: 700;
  color: #222;
  margin: 6px 0 4px;
  padding: 5px 8px;
  background: #eef3fa;
  border-radius: 4px;
  border: 1px solid #c8d9ee;
}
.meta-bar b { color: #1a3a6e; }

/* ── العنوان الكبير ── */
.main-title {
  text-align: center;
  font-size: 21px;
  font-weight: 900;
  color: #1a3a6e;
  margin: 8px 0 2px;
  letter-spacing: .3px;
}
.sub-title {
  text-align: center;
  font-size: 13px;
  font-weight: 600;
  color: #444;
  margin-bottom: 8px;
}

/* ── يورد إلى / مبلغ وقدره ── */
.info-line {
  font-size: 14px;
  font-weight: 600;
  padding: 5px 0;
  border-bottom: 1px dotted #aaa;
  line-height: 1.7;
}
.info-line b { font-weight: 900; color: #111; margin-left: 4px; }
.info-line.spaced { margin-bottom: 10px; }

/* ── عنوان الجدول ── */
.purpose-title {
  text-align: center;
  font-size: 15px;
  font-weight: 900;
  color: #1a3a6e;
  margin: 6px 0 5px;
}

/* ── الجدول ── */
table {
  width: 100%;
  border-collapse: collapse;
  border: 1.5px solid #2563ab;
  flex: 1;
}
thead tr th {
  background: #2563ab;
  color: #fff;
  font-size: 13px;
  font-weight: 800;
  padding: 7px 5px;
  border: 1px solid #1a4d9a;
  text-align: center;
  white-space: nowrap;
}
thead tr.sub-header th {
  background: #d0dff2;
  color: #1a3a6e;
  font-size: 12px;
  padding: 5px 4px;
  border-color: #2563ab;
}
tbody td {
  border: 1px solid #b0c4dc;
  padding: 6px 6px;
  font-size: 13px;
  text-align: center;
  color: #111;
  height: 26px;
}
tbody td.rtl { text-align: right; padding-right: 8px; font-weight: 700; }
tbody td.mono { font-variant-numeric: tabular-nums; font-weight: 700; }
tbody tr:nth-child(even) td { background: #f5f8fc; }
tr.total-row td {
  background: #dce6f4 !important;
  font-weight: 900;
  font-size: 13px;
  color: #1a3a6e;
  border-color: #2563ab;
  padding: 6px;
}

/* ── التوقيعات ── */
.sigs {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px 20px;
  margin-top: 14px;
}
.sig-box { text-align: center; }
.sig-label {
  font-size: 13px;
  font-weight: 800;
  color: #1a3a6e;
  margin-bottom: 20px;
}
.sig-line {
  border-bottom: 1.5px solid #444;
  margin: 0 10px 3px;
}
.sig-sub { font-size: 11px; color: #777; }

/* ── طباعة ── */
@media print {
  @page { size: A4 portrait; margin: 0; }
  html, body { width: 210mm; height: 297mm; background: #fff; }
  .page {
    width: 210mm;
    min-height: 297mm;
    padding: 8mm 10mm 6mm;
    box-shadow: none;
  }
}
</style>
</head>
<body>
<div class="page">

  <!-- الرأس: شعار في اليمين + اسم المعهد في المنتصف + عمود موازن يسار -->
  <header class="hdr">
    <div class="hdr-logo">
      <img src="${LOGO_URL}" alt="شعار المعهد"/>
    </div>
    <div class="hdr-info">
      <h1>معهد القمة للعلوم الطبية والإدارية</h1>
      <div class="branch">الرئيسي</div>
    </div>
    <div class="hdr-spacer"></div>
  </header>

  <!-- رقم المعاملة + التاريخ -->
  <div class="meta-bar">
    <span>رقم المعاملة :&nbsp;<b>${order.supply_order_number}</b></span>
    <span>الموافق :&nbsp;<b>${paidDate}</b></span>
  </div>

  <!-- العنوان الرئيسي -->
  <div class="main-title">أمـر تـوريـد خـاص بطلبـة ${diplLbl}</div>
  <div class="sub-title">بند رقم ((&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;))</div>

  <!-- يورد إلى -->
  <div class="info-line"><b>يورد إلى :</b> إدارة المعهد</div>

  <!-- مبلغ وقدره -->
  <div class="info-line spaced">
    <b>مبلغ وقدره :</b> ${dinarsTotal.toLocaleString('ar-LY')} دينار ليبي لا غير
    ${discountNote ? `&nbsp;—&nbsp;<span style="font-size:12px;color:#92400e">✂ ${discountNote.replace('تخفيض:','').trim()}</span>` : ''}
    ${otherNotes   ? `&nbsp;—&nbsp;<span style="font-size:12px;color:#0c4a6e">${otherNotes}</span>` : ''}
  </div>

  <!-- وذلك عن غرض -->
  <div class="purpose-title">وذلك عن غـرض</div>

  <!-- الجدول -->
  <table>
    <thead>
      <tr>
        <th rowspan="2" style="width:5%">ث</th>
        <th rowspan="2" style="width:26%">الاسـم رباعـي</th>
        <th colspan="2" style="width:14%">القيمة</th>
        <th rowspan="2" style="width:11%">رقم الإيصال</th>
        <th rowspan="2" style="width:12%">طريقة الدفع</th>
        <th rowspan="2" style="width:32%">البيـان</th>
      </tr>
      <tr class="sub-header">
        <th>دينار</th>
        <th>درهم</th>
      </tr>
    </thead>
    <tbody>
      ${tableRows}
      ${emptyRows}
      <tr class="total-row">
        <td></td>
        <td class="rtl"><b>المجمـوع :</b></td>
        <td class="mono">${dinarsTotal.toLocaleString('ar-LY')}</td>
        <td class="mono">${String(dirhamsTotal).padStart(3,'0')}</td>
        <td></td>
        <td></td>
        <td class="rtl">.....................................</td>
      </tr>
    </tbody>
  </table>

  <!-- التوقيعات الأربعة -->
  <div class="sigs">
    <div class="sig-box">
      <div class="sig-label">إعـداد</div>
      <div class="sig-line"></div>
      <div class="sig-sub">الاسم والتوقيع</div>
    </div>
    <div class="sig-box">
      <div class="sig-label">مراجعـة</div>
      <div class="sig-line"></div>
      <div class="sig-sub">الاسم والتوقيع</div>
    </div>
    <div class="sig-box">
      <div class="sig-label">اعتماد الشؤون الإدارية والمالية</div>
      <div class="sig-line"></div>
      <div class="sig-sub">الاسم والتوقيع والختم</div>
    </div>
    <div class="sig-box">
      <div class="sig-label">اعتماد مدير المعهد</div>
      <div class="sig-line"></div>
      <div class="sig-sub">الاسم والتوقيع والختم</div>
    </div>
  </div>

</div>
${autoprint ? '<script>window.onload=function(){window.print()};<\/script>' : ''}
</body>
</html>`;
}

// ── طباعة أمر توريد — تمرير جميع الصفوف ──
export function printSupplyOrder(rows: FullReceipt | FullReceipt[]) {
  const win = window.open('', '_blank', 'width=740,height=960');
  if (!win) return;
  win.document.write(buildSupplyOrderHTML(rows, true));
  win.document.close();
}

// ── تنزيل أمر توريد كـ PDF — يفتح نافذة جديدة ويطبع مباشرة ──
function downloadSupplyOrderPDF(rows: FullReceipt | FullReceipt[]) {
  const arr: FullReceipt[] = Array.isArray(rows) ? rows : [rows];
  const soNum = arr[0]?.supply_order_number ?? 'order';
  const win = window.open('', '_blank', 'width=740,height=960');
  if (!win) return;
  // autoprint=true بحيث يفتح نافذة الطباعة/الحفظ تلقائياً
  const html = buildSupplyOrderHTML(arr, true).replace(
    `<title>أمر توريد ${soNum}</title>`,
    `<title>امر-توريد-${soNum}</title>`
  );
  win.document.write(html);
  win.document.close();
}

// ── طباعة أمر توريد واحد بالاسم الموحّد (يُستدعى من زر "طباعة الأمر") ──
function printAllOrders(orders: FullReceipt[], _dateStr: string) {
  // نمرر جميع صفوف هذا الأمر لتظهر كلها في الجدول
  if (!orders.length) return;
  printSupplyOrder(orders);
}

// ══════════════════════════════════════════════
// الصفحة الرئيسية
// ══════════════════════════════════════════════
export default function SupplyOrdersPage() {
  const navigate = useNavigate();
  const [selectedDate, setSelectedDate] = useState(todayStr());
  const [showAllDates, setShowAllDates] = useState(true);
  const [orders, setOrders] = useState<FullReceipt[]>([]);
  const [loading, setLoading] = useState(false);
  const [diplomaFilter, setDiplomaFilter] = useState<'all' | 'عالي' | 'متوسط'>('عالي');
  // الأوامر المفتوحة (accordion)
  const [expandedOrders, setExpandedOrders] = useState<Set<string>>(new Set());
  // عدادات أوامر التوريد من الإعدادات
  const [counterHigh, setCounterHigh] = useState(0);
  const [counterMid, setCounterMid] = useState(0);

  // حالة الحذف
  const [deleteTarget, setDeleteTarget] = useState<{ num: string; name: string } | null>(null);
  const [deleting, setDeleting] = useState(false);

  // حالة معاينة أمر التوريد
  const [previewOrder, setPreviewOrder] = useState<typeof grouped[0] | null>(null);

  // حالة التعديل الشاملة
  const [editTarget, setEditTarget] = useState<{
    num: string;
    receiptNumber: string;
    paidAt: string;
    paymentMethod: PaymentMethod;
    semesterTarget: string;
    notes: string;
  } | null>(null);
  const [saving, setSaving] = useState(false);
  const [unassignedCount, setUnassignedCount] = useState(0);
  const [syncing, setSyncing] = useState(false);

  const fetchOrders = useCallback(async (date = selectedDate, allDates = showAllDates) => {
    setLoading(true);
    try {
      const [data, cfg, unassigned] = await Promise.all([
        allDates ? getAllSupplyOrders() : getSupplyOrdersByDate(date),
        getSettings(),
        getUnassignedReceiptsCount(),
      ]);
      setOrders(data as FullReceipt[]);
      setCounterHigh(parseInt(cfg[SETTINGS_KEYS.SUPPLY_ORDER_COUNTER_HIGH] ?? '0'));
      setCounterMid(parseInt(cfg[SETTINGS_KEYS.SUPPLY_ORDER_COUNTER_MID] ?? '0'));
      setUnassignedCount(unassigned);
    } catch { toast.error('خطأ في تحميل أوامر التوريد'); }
    finally { setLoading(false); }
  }, [selectedDate, showAllDates]);

  const handleSyncFinance = async () => {
    setSyncing(true);
    try {
      const res = await syncUnassignedReceipts();
      if (res.synced_count > 0) {
        toast.success(`تمت المزامنة بنجاح: تم ربط وتحديث أوامر التوريد لـ ${res.synced_count} إيصال`);
      } else {
        toast.success('كافة إيصالات مالية الطلاب متزامنة تماماً مع أوامر التوريد');
      }
      await fetchOrders(selectedDate, showAllDates);
    } catch {
      toast.error('حدث خطأ أثناء مزامنة أوامر التوريد');
    } finally {
      setSyncing(false);
    }
  };

  useEffect(() => {
    fetchOrders(selectedDate, showAllDates);
  }, [selectedDate, showAllDates]);

  // أوامر مفلترة
  const filtered = useMemo(() => {
    if (diplomaFilter === 'all') return orders;
    return orders.filter(o => o.student_diploma === diplomaFilter);
  }, [orders, diplomaFilter]);

  // تجميع بحسب رقم الأمر — مرتب من الأحدث إلى الأقدم
  const grouped = useMemo(() => {
    const map = new Map<string, FullReceipt[]>();
    for (const r of filtered) {
      const key = r.supply_order_number ?? '—';
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(r);
    }
    return [...map.entries()]
      .map(([num, rows]) => {
        // ترتيب الصفوف: حسب رقم الإيصال تصاعدياً (ترتيب الإدخال الفعلي)
        const sorted = [...rows].sort((a, b) => {
          const nA = parseInt((a.receipt_number ?? '0').replace(/\D/g, ''), 10) || 0;
          const nB = parseInt((b.receipt_number ?? '0').replace(/\D/g, ''), 10) || 0;
          return nA - nB;
        });
        return {
          supply_order_number: num,
          rows: sorted,
          total: sorted.reduce((s, r) => s + r.amount, 0),
          student_name: sorted[0].student_name,
          student_national_id: sorted[0].student_national_id,
          student_diploma: sorted[0].student_diploma,
          student_specialization: sorted[0].student_specialization,
          receipt_number: sorted[0].receipt_number,
          paid_at: sorted[0].paid_at,
          payment_method: (sorted[0] as FullReceipt).payment_method ?? 'كاش',
        };
      })
      // ترتيب المجموعات: من الأحدث إلى الأقدم بحسب تاريخ الدفع
      .sort((a, b) => new Date(b.paid_at).getTime() - new Date(a.paid_at).getTime());
  }, [filtered]);

  // إحصاءات
  const stats = useMemo(() => {
    const total = filtered.reduce((s, r) => s + r.amount, 0);
    const highOrders = grouped.filter(g => g.student_diploma === 'عالي');
    const midOrders  = grouped.filter(g => g.student_diploma === 'متوسط');
    return { total, ordersCount: grouped.length, highCount: highOrders.length, midCount: midOrders.length };
  }, [filtered, grouped]);

  // رقم المعاملة الحالي من الإعدادات حسب الفلتر المحدد
  const currentOrderNum = useMemo(() => {
    if (diplomaFilter === 'متوسط') return counterMid;
    if (diplomaFilter === 'عالي')  return counterHigh;
    return counterHigh + counterMid; // عند عرض الكل: مجموع العدادين
  }, [diplomaFilter, counterHigh, counterMid]);
  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await deleteSupplyOrder(deleteTarget.num);
      toast.success(`تم حذف أمر التوريد ${deleteTarget.num}`);
      setDeleteTarget(null);
      fetchOrders(selectedDate);
    } catch { toast.error('فشل في حذف أمر التوريد'); }
    finally { setDeleting(false); }
  };

  // معالج حفظ التعديل الشامل
  const handleSaveEdit = async () => {
    if (!editTarget) return;
    setSaving(true);
    try {
      await updateSupplyOrderFull(editTarget.num, {
        receipt_number: editTarget.receiptNumber.trim() || undefined,
        paid_at: editTarget.paidAt ? new Date(editTarget.paidAt).toISOString() : undefined,
        payment_method: editTarget.paymentMethod,
        semester_target: editTarget.semesterTarget.trim() || null,
        notes: editTarget.notes.trim() || null,
      });
      toast.success('تم تحديث بيانات الأمر بنجاح');
      setEditTarget(null);
      fetchOrders(selectedDate);
    } catch { toast.error('فشل في تحديث البيانات'); }
    finally { setSaving(false); }
  };

  // تصدير Excel
  const handleExportExcel = () => {
    const rows = grouped.map((g, i) => ({
      '#': i + 1,
      'رقم المعاملة': g.supply_order_number,
      'اسم الطالب': g.student_name,
      'الرقم الوطني': g.student_national_id,
      'الدبلوم': g.student_diploma,
      'التخصص': g.student_specialization,
      'طريقة الدفع': g.payment_method,
      'رقم الإيصال': g.receipt_number,
      'إجمالي المبلغ': g.total,
    }));
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'أوامر التوريد');
    const wbOut = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    triggerDownload(
      new Blob([wbOut], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }),
      `أوامر-توريد-${selectedDate}.xlsx`
    );
    toast.success('تم تصدير Excel');
  };

  // تصدير PDF
  const handleExportPDF = () => {
    const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
    const cols = ['#', 'رقم المعاملة', 'الطالب', 'الدبلوم', 'التخصص', 'طريقة الدفع', 'رقم الإيصال', 'المبلغ الإجمالي'];
    const rows = grouped.map((g, i) => [
      i + 1, g.supply_order_number, g.student_name,
      `دبلوم ${g.student_diploma}`, g.student_specialization,
      g.payment_method, g.receipt_number, `${g.total.toFixed(2)} د.ل`,
    ]);
    autoTable(doc, {
      head: [cols], body: rows,
      foot: [['', '', '', '', '', '', 'الإجمالي', `${stats.total.toFixed(2)} د.ل`]],
      styles: { fontSize: 8, halign: 'right' },
      headStyles: { fillColor: [26, 60, 94], textColor: 255, fontStyle: 'bold' },
      footStyles: { fillColor: [239, 246, 255], textColor: 26, fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [248, 250, 255] },
      margin: { top: 22 },
      didDrawPage: () => {
        doc.setFontSize(12); doc.setTextColor(26, 60, 94);
        doc.text(`أوامر التوريد — ${fmtShortDate(selectedDate)}`,
          doc.internal.pageSize.width / 2, 13, { align: 'center' });
        doc.setFontSize(8); doc.setTextColor(150);
        doc.text(`${grouped.length} أمر | إجمالي: ${stats.total.toFixed(2)} د.ل`, 10, 19);
      },
    });
    triggerDownload(doc.output('blob'), `أوامر-توريد-${selectedDate}.pdf`);
    toast.success('تم تصدير PDF');
  };

  return (
    <MainLayout>
      <div className="space-y-4">

        {/* ── Dialog معاينة أمر التوريد ── */}
        {previewOrder && (
          <Dialog open={!!previewOrder} onOpenChange={v => !v && setPreviewOrder(null)}>
            <DialogContent
              className="max-w-[calc(100%-1rem)] md:max-w-3xl max-h-[92dvh] overflow-y-auto p-0 [&>button]:hidden"
              dir="rtl">
              {/* رأس الـ Dialog */}
              <div className="sticky top-0 z-10 flex items-center justify-between px-5 py-4 bg-gradient-to-l from-[#1a3c5e] to-[#0f2740] rounded-t-xl">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-white/15 border border-white/20 flex items-center justify-center shrink-0">
                    <ClipboardList className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <p className="text-[10px] text-white/50 font-medium leading-none mb-0.5">أمر توريد</p>
                    <p className="text-lg font-black text-white tracking-widest font-mono leading-none">
                      #{previewOrder.supply_order_number}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => printAllOrders(previewOrder.rows, selectedDate)}
                    className="inline-flex items-center gap-1.5 h-8 px-3 rounded-lg text-[11px] font-semibold bg-white/15 text-white hover:bg-white/25 border border-white/20 transition-all">
                    <Printer className="w-3.5 h-3.5" /> طباعة
                  </button>
                  <button
                    onClick={() => downloadSupplyOrderPDF(previewOrder.rows)}
                    className="inline-flex items-center gap-1.5 h-8 px-3 rounded-lg text-[11px] font-semibold bg-blue-400/20 text-blue-100 hover:bg-blue-400/35 border border-blue-300/20 transition-all">
                    <FileDown className="w-3.5 h-3.5" /> PDF
                  </button>
                  <button
                    onClick={() => setPreviewOrder(null)}
                    className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 border border-white/15 flex items-center justify-center transition-all">
                    <X className="w-4 h-4 text-white" />
                  </button>
                </div>
              </div>

              <div className="p-5 space-y-4">
                {/* بطاقة معلومات الأمر */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {[
                    { label: 'الطالب', value: previewOrder.student_name, icon: <GraduationCap className="w-3.5 h-3.5" /> },
                    { label: 'الدبلوم', value: previewOrder.student_diploma, icon: <BookOpen className="w-3.5 h-3.5" /> },
                    { label: 'التاريخ', value: new Date(previewOrder.paid_at).toLocaleDateString('ar-LY', { dateStyle: 'medium' }), icon: <Calendar className="w-3.5 h-3.5" /> },
                    { label: 'الإجمالي', value: `${previewOrder.total.toFixed(2)} د.ل`, icon: <BadgeDollarSign className="w-3.5 h-3.5" /> },
                  ].map(item => (
                    <div key={item.label} className="bg-[#1a3c5e]/5 border border-[#1a3c5e]/12 rounded-xl p-3">
                      <div className="flex items-center gap-1.5 text-[#1a3c5e]/50 mb-1.5">
                        {item.icon}
                        <span className="text-[10px] font-semibold">{item.label}</span>
                      </div>
                      <p className="text-[13px] font-bold text-[#1a3c5e] truncate">{item.value}</p>
                    </div>
                  ))}
                </div>

                {/* جدول الإيصالات */}
                <div className="rounded-xl overflow-hidden border border-[#1a3c5e]/15">
                  <div className="bg-[#1a3c5e]/6 border-b border-[#1a3c5e]/12 px-4 py-2.5 flex items-center justify-between">
                    <span className="text-[12px] font-bold text-[#1a3c5e]">تفاصيل الإيصالات</span>
                    <span className="text-[11px] text-[#1a3c5e]/50 bg-[#1a3c5e]/8 border border-[#1a3c5e]/12 px-2 py-0.5 rounded-full font-semibold">
                      {previewOrder.rows.length} إيصال
                    </span>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-right min-w-max">
                      <thead>
                        <tr className="border-b border-[#1a3c5e]/10">
                          {['#', 'رقم الإيصال', 'المبلغ', 'طريقة الدفع', 'البيان'].map(h => (
                            <th key={h} className="px-3 py-2.5 text-[11px] font-bold text-[#1a3c5e]/45 whitespace-nowrap first:pr-4">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {previewOrder.rows.map((r, ri) => {
                          const rMethod = ((r as FullReceipt).payment_method ?? 'كاش') as PaymentMethod;
                          const discNote = parseDiscountNote(r.notes);
                          return (
                            <tr key={r.id ?? ri}
                              className={`border-b border-[#1a3c5e]/6 last:border-0 hover:bg-[#1a3c5e]/[0.03] transition-colors ${ri % 2 !== 0 ? 'bg-[#1a3c5e]/[0.02]' : ''}`}>
                              <td className="pr-4 py-3 text-[11px] font-mono text-muted-foreground/35 whitespace-nowrap tabular-nums">{ri + 1}</td>
                              <td className="px-3 py-3 whitespace-nowrap">
                                <div className="inline-flex items-center gap-1 h-6 bg-[#1a3c5e]/8 border border-[#1a3c5e]/15 px-2 rounded-lg">
                                  <ReceiptIcon className="w-3 h-3 text-[#1a3c5e]/50 shrink-0" />
                                  <span className="font-mono text-[12px] font-bold text-[#1a3c5e]">{r.receipt_number}</span>
                                </div>
                              </td>
                              <td className="px-3 py-3 whitespace-nowrap">
                                <div className="inline-flex items-center gap-1">
                                  <span className="text-[14px] font-black font-mono text-[#1a3c5e] tabular-nums">{r.amount.toFixed(2)}</span>
                                  <span className="text-[10px] text-muted-foreground">د.ل</span>
                                </div>
                              </td>
                              <td className="px-3 py-3 whitespace-nowrap">
                                <span className={`inline-flex items-center gap-1 h-6 text-[11px] font-bold px-2 rounded-lg border ${METHOD_STYLE[rMethod] ?? METHOD_STYLE['كاش']}`}>
                                  <CreditCard className="w-3 h-3 shrink-0" /> {rMethod}
                                </span>
                              </td>
                              <td className="px-3 py-3">
                                <div className="flex flex-col gap-1 min-w-[140px]">
                                  <div className="flex items-start gap-1 flex-wrap">
                                    <span className="text-[11px] font-semibold text-foreground/70 bg-muted/35 border border-border/25 px-1.5 py-0.5 rounded whitespace-nowrap">
                                      {r.payment_type}
                                    </span>
                                    {r.semester_target && (
                                      <span className="text-[10px] text-muted-foreground leading-snug break-words">{r.semester_target}</span>
                                    )}
                                  </div>
                                  {discNote && (
                                    <div className="inline-flex items-center gap-1 bg-amber-50 border border-amber-200 rounded px-1.5 py-0.5 w-fit">
                                      <Scissors className="w-2.5 h-2.5 text-amber-600 shrink-0" />
                                      <span className="text-[10px] font-semibold text-amber-700">{discNote.replace('تخفيض:', '').trim()}</span>
                                    </div>
                                  )}
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                  {/* إجمالي */}
                  <div className="flex items-center justify-between px-4 py-3 bg-[#1a3c5e]/6 border-t border-[#1a3c5e]/12">
                    <span className="text-[12px] font-bold text-[#1a3c5e]/60">إجمالي الأمر</span>
                    <div className="inline-flex items-center gap-1.5">
                      <span className="text-[16px] font-black font-mono text-[#1a3c5e] tabular-nums">{previewOrder.total.toFixed(2)}</span>
                      <span className="text-[11px] text-[#1a3c5e]/50">د.ل</span>
                    </div>
                  </div>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}

        {/* ── الترويسة ── */}
        <div className="relative rounded-2xl overflow-hidden" style={{ boxShadow: 'var(--shadow-lg)' }}>
          <div className="absolute inset-0 bg-gradient-to-br from-[#1a3c5e]/95 via-[#1a3c5e]/85 to-blue-700/75" />
          <div className="absolute inset-0 opacity-[0.05]"
            style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '24px 24px' }} />
          <div className="relative px-4 py-3.5 md:px-7 md:py-4">
            {/* صف رئيسي: رجوع + عنوان + أزرار */}
            <div className="flex items-center gap-2 md:gap-3">
              {/* زر رجوع */}
              <button onClick={() => navigate('/')}
                className="w-8 h-8 md:w-9 md:h-9 rounded-xl bg-white/15 border border-white/20 flex items-center justify-center shrink-0 hover:bg-white/25 transition-colors">
                <ChevronRight className="w-4 h-4 text-white" />
              </button>
              {/* أيقونة الصفحة */}
              <div className="w-8 h-8 md:w-9 md:h-9 rounded-xl bg-white/15 border border-white/20 flex items-center justify-center shrink-0">
                <ClipboardList className="w-4 h-4 text-white" />
              </div>
              {/* العنوان */}
              <div className="min-w-0 flex-1">
                <h1 className="text-sm md:text-lg font-bold text-white leading-none">أوامر التوريد</h1>
                <p className="text-white/55 text-[10px] md:text-[11px] mt-0.5 truncate">
                  {loading ? 'جاري التحميل...' : `${stats.ordersCount} أمر — ${stats.total.toFixed(2)} د.ل`}
                </p>
              </div>
              {/* أزرار الإجراءات */}
              <div className="flex items-center gap-1 md:gap-1.5 shrink-0 flex-wrap">
                {/* طباعة - يظهر دائماً */}
                <button onClick={() => printAllOrders(filtered, selectedDate)}
                  disabled={filtered.length === 0}
                  className="inline-flex items-center gap-1 md:gap-1.5 h-8 px-2 md:px-3 rounded-lg text-[11px] font-semibold bg-white/15 text-white border border-white/20 hover:bg-white/25 transition-all disabled:opacity-40">
                  <Printer className="w-3.5 h-3.5 shrink-0" />
                  <span className="hidden md:inline">طباعة الكل</span>
                </button>
                {/* Excel - مخفي على الجوال */}
                <button onClick={handleExportExcel} disabled={grouped.length === 0}
                  className="hidden sm:inline-flex items-center gap-1.5 h-8 px-3 rounded-lg text-[11px] font-semibold bg-emerald-500 text-white hover:bg-emerald-600 transition-all disabled:opacity-40">
                  <FileSpreadsheet className="w-3.5 h-3.5 shrink-0" />
                  <span className="hidden md:inline">Excel</span>
                </button>
                {/* PDF - مخفي على الجوال */}
                <button onClick={handleExportPDF} disabled={grouped.length === 0}
                  className="hidden sm:inline-flex items-center gap-1.5 h-8 px-3 rounded-lg text-[11px] font-semibold bg-red-500 text-white hover:bg-red-600 transition-all disabled:opacity-40">
                  <FileDown className="w-3.5 h-3.5 shrink-0" />
                  <span className="hidden md:inline">PDF</span>
                </button>
                {/* تحديث - يظهر دائماً */}
                <RefreshButton
                  onRefresh={() => fetchOrders(selectedDate)}
                  loading={loading}
                  variant="ghost"
                  iconOnly={false}
                  label="تحديث"
                  className="h-8 px-2 md:px-3 rounded-lg text-[11px] font-semibold"
                />
              </div>
            </div>
            {/* شريط إجراءات إضافي على الجوال: Excel + PDF */}
            <div className="flex items-center gap-2 mt-2.5 sm:hidden">
              <button onClick={handleExportExcel} disabled={grouped.length === 0}
                className="flex-1 inline-flex items-center justify-center gap-1.5 h-8 rounded-lg text-[11px] font-semibold bg-emerald-500 text-white hover:bg-emerald-600 transition-all disabled:opacity-40">
                <FileSpreadsheet className="w-3.5 h-3.5 shrink-0" /> تصدير Excel
              </button>
              <button onClick={handleExportPDF} disabled={grouped.length === 0}
                className="flex-1 inline-flex items-center justify-center gap-1.5 h-8 rounded-lg text-[11px] font-semibold bg-red-500 text-white hover:bg-red-600 transition-all disabled:opacity-40">
                <FileDown className="w-3.5 h-3.5 shrink-0" /> تصدير PDF
              </button>
            </div>
          </div>
        </div>

        {/* ── شريط تنبيه الإيصالات غير المربوطة إن وجدت ── */}
        {unassignedCount > 0 && (
          <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 shadow-sm">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
              <span className="text-xs font-bold text-amber-900 dark:text-amber-200">
                يوجد {unassignedCount} إيصال مسجل في مالية الطلاب بدون أمر توريد. اضغط مزامنة لربطها وإصدار أوامر التوريد فوراً.
              </span>
            </div>
            <button
              onClick={handleSyncFinance}
              disabled={syncing}
              className="inline-flex items-center gap-1.5 h-7 px-3 rounded-lg text-xs font-bold bg-amber-600 text-white hover:bg-amber-700 transition-all shrink-0 shadow-sm">
              <RefreshCw className={`w-3 h-3 ${syncing ? 'animate-spin' : ''}`} />
              مزامنة وإصدار الأوامر الآن
            </button>
          </div>
        )}

        {/* ── اختيار التاريخ والفلتر ── */}
        <Card className="shadow-sm border-border/60">
          <CardContent className="p-3 md:p-4">
            <div className="flex flex-col gap-3">
              {/* صف التاريخ */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-muted-foreground flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5" /> اختر التاريخ
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={e => { setShowAllDates(false); setSelectedDate(e.target.value); }}
                    disabled={showAllDates}
                    className="h-10 rounded-lg border border-border bg-background px-3 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-ring shrink-0 w-[150px] md:w-auto disabled:opacity-50"
                  />
                  {/* زر عرض الكل */}
                  <button
                    onClick={() => setShowAllDates(v => !v)}
                    className={`h-10 px-3 rounded-lg text-[12px] font-bold border transition-all shrink-0 ${
                      showAllDates
                        ? 'bg-[#1a3c5e] text-white border-[#1a3c5e]'
                        : 'bg-background text-muted-foreground border-border hover:border-primary/40'
                    }`}
                  >
                    {showAllDates ? '📋 جميع الأيام' : 'عرض الكل'}
                  </button>
                  <div className="flex-1 min-w-0 flex items-center gap-2 rounded-xl border border-primary/25 bg-primary/5 px-3 h-10">
                    <Calendar className="w-3.5 h-3.5 text-primary shrink-0" />
                    <p className="text-[13px] font-bold text-foreground truncate">
                      {showAllDates ? 'جميع الأيام' : (selectedDate ? fmtDate(selectedDate) : '—')}
                    </p>
                  </div>
                </div>
              </div>
              {/* فلتر الدبلوم */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-muted-foreground flex items-center gap-1.5">
                  <GraduationCap className="w-3.5 h-3.5" /> نوع الدبلوم
                </label>
                <div className="flex gap-1.5">
                  {(['عالي', 'متوسط'] as const).map(v => (
                    <button key={v}
                      onClick={() => setDiplomaFilter(v)}
                      className={`flex-1 h-10 px-3 rounded-lg text-[12px] font-bold border transition-all flex flex-col items-center justify-center leading-none gap-0.5 ${
                        diplomaFilter === v
                          ? v === 'عالي' ? 'bg-blue-600 text-white border-blue-600'
                          :                'bg-emerald-600 text-white border-emerald-600'
                          : 'bg-background text-muted-foreground border-border hover:border-primary/40'
                      }`}>
                      <span>{v === 'عالي' ? 'دبلوم عالي' : 'دبلوم متوسط'}</span>
                      {!loading && (
                        <span className={`text-[10px] font-normal ${diplomaFilter === v ? 'opacity-80' : 'opacity-50'}`}>
                          ({grouped.filter(g => g.student_diploma === v).length})
                        </span>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* شريط المزامنة مع مالية الطلاب — تصميم متناسق وأنيق */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 pt-3 border-t border-border/50">
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span>أوامر التوريد متزامنة ومربوطة مباشرة بمالية الطلاب</span>
                </div>
                <button
                  type="button"
                  onClick={handleSyncFinance}
                  disabled={syncing}
                  title="مزامنة وتحديث أوامر التوريد لجميع إيصالات مالية الطلاب"
                  className="inline-flex items-center justify-center gap-2 h-9 px-3.5 rounded-lg text-xs font-bold bg-amber-500/10 hover:bg-amber-500/20 text-amber-800 dark:text-amber-300 border border-amber-500/30 transition-all shadow-xs active:scale-95 disabled:opacity-50 shrink-0">
                  <RefreshCw className={`w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0 ${syncing ? 'animate-spin' : ''}`} />
                  <span>مزامنة مع مالية الطلاب</span>
                  {unassignedCount > 0 ? (
                    <span className="bg-amber-600 text-white text-[10px] font-black px-1.5 py-0.5 rounded-full">
                      {unassignedCount} إيصال معلق
                    </span>
                  ) : (
                    <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400">
                      ✓ متزامن
                    </span>
                  )}
                </button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* ── بطاقات الإحصاء ── */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <StatCard icon={ClipboardList} label="إجمالي الأوامر" value={`${stats.ordersCount}`} sub="أمر توريد"
            gradient="bg-gradient-to-br from-[#1a3c5e]/85 to-[#1a3c5e] border-[#1a3c5e]/20" />
          <StatCard icon={BadgeDollarSign} label="إجمالي المحصّل" value={`${stats.total.toFixed(0)}`} sub="دينار ليبي"
            gradient="bg-gradient-to-br from-chart-2/80 to-chart-2 border-chart-2/20" />
          <StatCard icon={GraduationCap} label="أوامر عالي" value={`${stats.highCount}`} sub="دبلوم عالي"
            gradient="bg-gradient-to-br from-blue-600/80 to-blue-700 border-blue-600/20" />
          <StatCard icon={BookOpen} label="أوامر متوسط" value={`${stats.midCount}`} sub="دبلوم متوسط"
            gradient="bg-gradient-to-br from-emerald-600/80 to-emerald-700 border-emerald-600/20" />
        </div>

        {/* ── لوحة ملخص اليوم + أزرار فتح/إغلاق الكل ── */}
        {!loading && grouped.length > 0 && (
          <div className="relative rounded-2xl border border-[#1a3c5e]/20 bg-gradient-to-br from-[#1a3c5e] via-[#1e4570] to-[#1a3c5e] shadow-md overflow-hidden">
            <div className="absolute inset-0 opacity-[0.04] pointer-events-none"
              style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '20px 20px' }} />
            <div className="relative px-4 py-3.5 md:px-5 md:py-4 flex flex-col gap-3 md:flex-row md:items-center md:gap-4">
              {/* الصف الأول: آخر معاملة + التاريخ */}
              <div className="flex items-center gap-3 flex-1 min-w-0">
                <div className="flex flex-col items-center justify-center shrink-0 bg-white/10 border border-white/20 rounded-xl px-3 py-2 min-w-[80px]">
                  <span className="text-[10px] text-white/55 font-medium leading-none mb-1">آخر معاملة</span>
                  <span className="font-mono text-[14px] font-black tracking-widest text-white leading-none">
                    {formatSupplyOrderNumber(currentOrderNum)}
                  </span>
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-white font-bold text-sm leading-snug truncate">
                    {fmtDate(selectedDate)}
                  </p>
                  <div className="flex items-center gap-2 mt-1 flex-wrap">
                    <span className="text-[11px] text-white/50">{grouped.length} أمر · {filtered.length} إيصال</span>
                    {stats.highCount > 0 && (
                      <span className="text-[10px] font-bold text-blue-200 bg-blue-500/25 border border-blue-400/30 px-2 py-0.5 rounded-full">
                        عالي: {stats.highCount}
                      </span>
                    )}
                    {stats.midCount > 0 && (
                      <span className="text-[10px] font-bold text-emerald-200 bg-emerald-500/25 border border-emerald-400/30 px-2 py-0.5 rounded-full">
                        متوسط: {stats.midCount}
                      </span>
                    )}
                  </div>
                </div>
              </div>
              {/* الصف الثاني: الإجمالي + أزرار */}
              <div className="flex items-center justify-between gap-3 md:shrink-0">
                <div className="hidden md:block w-px h-10 bg-white/15 shrink-0" />
                <div className="text-right">
                  <p className="text-[10px] text-white/50 font-medium mb-0.5">إجمالي المحصّل</p>
                  <div className="flex items-baseline gap-1">
                    <span className="text-lg md:text-[22px] font-black text-white font-mono leading-none tabular-nums">{stats.total.toFixed(2)}</span>
                    <span className="text-[11px] text-white/55">د.ل</span>
                  </div>
                </div>
                <div className="flex gap-1.5 shrink-0">
                  <button
                    onClick={() => setExpandedOrders(new Set(grouped.map(g => g.supply_order_number)))}
                    className="inline-flex items-center justify-center gap-1 md:gap-1.5 h-8 px-2.5 md:px-3 rounded-lg text-[11px] font-bold bg-white text-[#1a3c5e] hover:bg-white/90 transition-all shadow-sm whitespace-nowrap">
                    <ChevronDown className="w-3.5 h-3.5 shrink-0" />
                    <span className="hidden xs:inline">فتح الكل</span>
                    <span className="xs:hidden">فتح</span>
                  </button>
                  <button
                    onClick={() => setExpandedOrders(new Set())}
                    className="inline-flex items-center justify-center gap-1 md:gap-1.5 h-8 px-2.5 md:px-3 rounded-lg text-[11px] font-bold bg-white/12 text-white border border-white/25 hover:bg-white/22 transition-all whitespace-nowrap">
                    <ChevronDown className="w-3.5 h-3.5 rotate-180 shrink-0" />
                    <span className="hidden xs:inline">إغلاق الكل</span>
                    <span className="xs:hidden">إغلاق</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ── أوامر التوريد — تصميم accordion ── */}
        <div className="space-y-2.5">
          {loading ? (
            <div className="space-y-2.5">
              {Array(4).fill(0).map((_, i) => (
                <div key={i} className="rounded-xl border-2 border-border/35 overflow-hidden">
                  <div className="flex items-center gap-3 px-4 py-3.5">
                    <Skeleton className="h-4 w-4 rounded" />
                    <Skeleton className="h-8 w-24 rounded-lg" />
                    <div className="flex-1 space-y-1.5">
                      <Skeleton className="h-3.5 w-20" />
                      <Skeleton className="h-3 w-36" />
                    </div>
                    <Skeleton className="h-7 w-20 rounded-lg" />
                    <Skeleton className="h-7 w-14 rounded-lg" />
                    <Skeleton className="h-7 w-18 rounded-lg" />
                    <Skeleton className="h-7 w-7 rounded-lg" />
                  </div>
                </div>
              ))}
            </div>
          ) : grouped.length === 0 ? (
            <div className="flex flex-col items-center py-16 gap-3 rounded-xl border-2 border-border/35 bg-card">
              <div className="w-16 h-16 rounded-full bg-muted/40 flex items-center justify-center">
                <ClipboardList className="w-7 h-7 text-muted-foreground/40" />
              </div>
              <p className="text-sm font-medium text-muted-foreground">لا توجد أوامر توريد في هذا التاريخ</p>
              <p className="text-xs text-muted-foreground/60">اختر تاريخاً مختلفاً أو تحقق من وجود مدفوعات مسجلة</p>
            </div>
          ) : (
            grouped.map((g, i) => {
              const isOpen = expandedOrders.has(g.supply_order_number);
              const isHigh = g.student_diploma === 'عالي';
              const toggleOpen = () => setExpandedOrders(prev => {
                const next = new Set(prev);
                if (next.has(g.supply_order_number)) next.delete(g.supply_order_number);
                else next.add(g.supply_order_number);
                return next;
              });

              return (
                <div key={g.supply_order_number}
                  className={`rounded-xl overflow-hidden border-2 transition-colors duration-150
                    ${isOpen ? 'border-[#1a3c5e]/30' : 'border-border/35 hover:border-[#1a3c5e]/20'}`}>

                  {/* ── رأس الأمر ── */}
                  <button
                    type="button"
                    onClick={toggleOpen}
                    className={`w-full text-right flex flex-col md:flex-row md:items-center gap-0 md:gap-3 px-3 md:px-4 transition-colors
                      ${isOpen ? 'bg-[#1a3c5e]/[0.04]' : 'bg-card hover:bg-muted/10'}`}>

                    {/* الصف الأول: رقم المعاملة + التاريخ + سهم موبايل */}
                    <div className="flex items-center gap-2 w-full pt-2.5 pb-1.5 md:py-3 md:flex-1 md:min-w-0">
                      {/* رقم الترتيب — ديسكتوب فقط */}
                      <span className="text-[11px] font-mono text-muted-foreground/35 shrink-0 w-4 text-center select-none tabular-nums hidden md:inline">
                        {i + 1}
                      </span>
                      {/* شارة رقم المعاملة — تفتح Dialog المعاينة */}
                      <div
                        role="button"
                        tabIndex={0}
                        onClick={e => { e.stopPropagation(); setPreviewOrder(g); }}
                        onKeyDown={e => e.key === 'Enter' && (e.stopPropagation(), setPreviewOrder(g))}
                        title="عرض أمر التوريد"
                        className="inline-flex items-center gap-1 h-7 px-2.5 rounded-lg bg-[#1a3c5e] shrink-0 cursor-pointer hover:bg-[#0f2740] hover:scale-105 active:scale-95 transition-all duration-150 shadow-sm hover:shadow-md select-none">
                        <Hash className="w-2.5 h-2.5 text-white/50 shrink-0" />
                        <span className="font-mono text-[12px] font-black tracking-widest text-white">
                          {g.supply_order_number}
                        </span>
                      </div>
                      {/* اليوم والتاريخ */}
                      <div className="flex flex-col justify-center flex-1 min-w-0">
                        <span className="text-[12px] font-bold text-foreground leading-none mb-0.5 truncate">
                          {fmtDay(g.paid_at)}
                        </span>
                        <span className="text-[10px] text-muted-foreground leading-none truncate">
                          {fmtShortDate(g.paid_at)}
                        </span>
                      </div>
                      {/* سهم — موبايل فقط */}
                      <div className="shrink-0 h-6 w-6 rounded-lg flex items-center justify-center border border-border/40 bg-muted/30 text-muted-foreground md:hidden">
                        <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
                      </div>
                    </div>

                    {/* الصف الثاني موبايل / تتمة الصف ديسكتوب */}
                    <div className="flex items-center gap-1.5 pb-2.5 md:pb-0 md:shrink-0 flex-wrap">
                      {/* شارة الدبلوم */}
                      <span className={`shrink-0 h-6 inline-flex items-center text-[10px] font-bold px-2 rounded-lg border whitespace-nowrap
                        ${isHigh ? 'bg-blue-50 text-blue-700 border-blue-200' : 'bg-emerald-50 text-emerald-700 border-emerald-200'}`}>
                        {g.student_diploma}
                      </span>
                      {/* عدد الإيصالات */}
                      <div className="shrink-0 h-6 inline-flex items-center gap-1 text-[10px] font-semibold text-muted-foreground bg-muted/40 border border-border/40 px-2 rounded-lg">
                        <Users className="w-2.5 h-2.5 shrink-0" />
                        <span className="tabular-nums">{g.rows.length}</span>
                      </div>
                      {/* المبلغ */}
                      <div className="shrink-0 h-6 inline-flex items-center gap-1 bg-[#1a3c5e]/6 border border-[#1a3c5e]/15 px-2 rounded-lg">
                        <span className="text-[12px] font-black font-mono text-[#1a3c5e] tabular-nums">{g.total.toFixed(2)}</span>
                        <span className="text-[10px] text-[#1a3c5e]/55">د.ل</span>
                      </div>
                      {/* سهم — ديسكتوب فقط */}
                      <div className="shrink-0 h-6 w-6 rounded-lg hidden md:flex items-center justify-center border border-border/40 bg-muted/30 text-muted-foreground">
                        <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
                      </div>
                    </div>
                  </button>

                  {/* ── جسم الأمر ── */}
                  {isOpen && (
                    <div className="border-t border-[#1a3c5e]/10">
                      <div className="overflow-x-auto">
                        <table className="w-full text-right min-w-max">
                          <thead>
                            <tr className="bg-[#1a3c5e]/[0.04] border-b border-[#1a3c5e]/10">
                              {['#', 'اسم الطالب', 'المبلغ', 'رقم الإيصال', 'طريقة الدفع', 'البيان', 'طباعة'].map(h => (
                                <th key={h} className="px-3 py-2.5 text-[11px] font-bold text-[#1a3c5e]/55 whitespace-nowrap first:pr-4 last:pl-4">{h}</th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {g.rows.map((r, ri) => {
                              const rMethod = ((r as FullReceipt).payment_method ?? 'كاش') as PaymentMethod;
                              const discNote = parseDiscountNote(r.notes);
                              const otherNote = r.notes && !r.notes.startsWith('تخفيض:')
                                ? r.notes.replace(/تخفيض:[^\n]*/g, '').trim()
                                : null;
                              return (
                                <tr key={r.id ?? ri}
                                  className={`border-b border-border/10 last:border-0 hover:bg-[#1a3c5e]/[0.02] transition-colors ${ri % 2 !== 0 ? 'bg-muted/[0.04]' : ''}`}>
                                  <td className="pr-4 py-2.5 text-[11px] font-mono text-muted-foreground/35 whitespace-nowrap tabular-nums">{ri + 1}</td>
                                  <td className="px-3 py-2.5 whitespace-nowrap">
                                    <p className="text-[13px] font-bold text-foreground">{r.student_name}</p>
                                    <p className="text-[10px] font-mono text-muted-foreground/45 mt-0.5">{r.student_national_id}</p>
                                  </td>
                                  <td className="px-3 py-2.5 whitespace-nowrap">
                                    <div className="inline-flex items-center gap-1">
                                      <span className="text-[13px] font-black font-mono text-[#1a3c5e] tabular-nums">{r.amount.toFixed(2)}</span>
                                      <span className="text-[10px] text-muted-foreground">د.ل</span>
                                    </div>
                                  </td>
                                  <td className="px-3 py-2.5 whitespace-nowrap">
                                    <div className="inline-flex items-center gap-1 h-6 bg-muted/35 border border-border/30 px-2 rounded-lg">
                                      <ReceiptIcon className="w-3 h-3 text-muted-foreground/60 shrink-0" />
                                      <span className="font-mono text-[12px] font-semibold text-foreground">{r.receipt_number}</span>
                                    </div>
                                  </td>
                                  <td className="px-3 py-2.5 whitespace-nowrap">
                                    <span className={`inline-flex items-center gap-1 h-6 text-[11px] font-bold px-2 rounded-lg border ${METHOD_STYLE[rMethod] ?? METHOD_STYLE['كاش']}`}>
                                      <CreditCard className="w-3 h-3 shrink-0" />
                                      {rMethod}
                                    </span>
                                  </td>
                                  <td className="px-3 py-2.5">
                                    <div className="flex flex-col gap-1 min-w-[160px] max-w-[220px]">
                                      <div className="flex items-start gap-1 flex-wrap">
                                        <span className="text-[11px] font-semibold text-foreground/70 bg-muted/35 border border-border/25 px-1.5 py-0.5 rounded whitespace-nowrap shrink-0">
                                          {r.payment_type}
                                        </span>
                                        {r.semester_target && (
                                          <span className="text-[10px] text-muted-foreground leading-snug break-words">{r.semester_target}</span>
                                        )}
                                      </div>
                                      {discNote && (
                                        <div className="inline-flex items-start gap-1 bg-amber-50 border border-amber-200 rounded px-1.5 py-0.5 w-fit max-w-full">
                                          <Scissors className="w-2.5 h-2.5 text-amber-600 shrink-0 mt-0.5" />
                                          <span className="text-[10px] font-semibold text-amber-700 break-words leading-snug">
                                            {discNote.replace('تخفيض:', '').trim()}
                                          </span>
                                        </div>
                                      )}
                                      {otherNote && (
                                        <p className="text-[10px] text-muted-foreground/50 break-words leading-snug">{otherNote}</p>
                                      )}
                                    </div>
                                  </td>
                                  <td className="pl-4 py-2.5 whitespace-nowrap">
                                    <div className="flex items-center gap-1">
                                      <button onClick={() => navigate(`/finance?search=${encodeURIComponent(r.student_name)}`)}
                                        title="عرض الملف المالي للطالب"
                                        className="inline-flex items-center gap-1 h-6 px-2 rounded-lg text-[10px] font-semibold bg-primary/10 text-primary border border-primary/20 hover:bg-primary hover:text-white transition-all">
                                        <ExternalLink className="w-3 h-3" /> المالية
                                      </button>
                                      <button onClick={() => printSupplyOrder(r)}
                                        className="inline-flex items-center gap-1 h-6 px-2 rounded-lg text-[10px] font-semibold bg-slate-500/8 text-slate-600 border border-slate-400/15 hover:bg-slate-600 hover:text-white transition-all">
                                        <Printer className="w-3 h-3" /> طباعة
                                      </button>
                                      <button onClick={() => downloadSupplyOrderPDF(r)}
                                        className="inline-flex items-center gap-1 h-6 px-2 rounded-lg text-[10px] font-semibold bg-blue-500/8 text-blue-700 border border-blue-400/20 hover:bg-blue-600 hover:text-white transition-all">
                                        <FileDown className="w-3 h-3" /> PDF
                                      </button>
                                    </div>
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>

                      {/* شريط الإجراءات */}
                      <div className="flex flex-col sm:flex-row sm:items-center gap-2 px-3 py-2.5 border-t border-[#1a3c5e]/10 bg-[#1a3c5e]/[0.03]">
                        <div className="flex items-center gap-2 flex-1 min-w-0">
                          <button onClick={() => printAllOrders(g.rows, selectedDate)}
                            className="inline-flex items-center gap-1.5 h-7 px-3 rounded-lg text-[11px] font-semibold bg-slate-500/8 text-slate-600 hover:bg-slate-600 hover:text-white border border-slate-400/15 transition-all whitespace-nowrap">
                            <Printer className="w-3 h-3" /> طباعة الأمر
                          </button>
                          <button onClick={() => downloadSupplyOrderPDF(g.rows)}
                            className="inline-flex items-center gap-1.5 h-7 px-3 rounded-lg text-[11px] font-semibold bg-blue-500/8 text-blue-700 hover:bg-blue-600 hover:text-white border border-blue-400/20 transition-all whitespace-nowrap">
                            <FileDown className="w-3 h-3" /> تنزيل PDF
                          </button>
                          <button
                            onClick={() => setDeleteTarget({ num: g.supply_order_number, name: g.student_name })}
                            className="inline-flex items-center gap-1.5 h-7 px-3 rounded-lg text-[11px] font-semibold bg-destructive/6 text-destructive hover:bg-destructive hover:text-white border border-destructive/15 transition-all whitespace-nowrap">
                            <Trash2 className="w-3 h-3" /> حذف
                          </button>
                        </div>
                        <div className="inline-flex items-center gap-1 shrink-0">
                          <span className="text-[11px] text-muted-foreground">المجموع:</span>
                          <span className="text-[13px] font-black font-mono text-[#1a3c5e] tabular-nums">{g.total.toFixed(2)}</span>
                          <span className="text-[10px] text-muted-foreground">د.ل</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* ── نافذة تأكيد الحذف ── */}
      <AlertDialog open={!!deleteTarget} onOpenChange={o => { if (!o) setDeleteTarget(null); }}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-destructive">
              <Trash2 className="w-4 h-4" /> حذف أمر التوريد
            </AlertDialogTitle>
            <AlertDialogDescription className="text-right">
              هل أنت متأكد من حذف أمر التوريد{' '}
              <span className="font-mono font-bold text-foreground">{deleteTarget?.num}</span>{' '}
              للطالب <span className="font-bold text-foreground">{deleteTarget?.name}</span>؟
              <br />
              <span className="text-destructive/80 text-xs">سيتم حذف جميع الإيصالات المرتبطة بهذا الأمر ولا يمكن التراجع.</span>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-row-reverse gap-2">
            <AlertDialogAction
              onClick={handleDelete}
              disabled={deleting}
              className="bg-destructive hover:bg-destructive/90 text-destructive-foreground gap-1.5">
              <Trash2 className="w-3.5 h-3.5" />
              {deleting ? 'جاري الحذف...' : 'تأكيد الحذف'}
            </AlertDialogAction>
            <AlertDialogCancel disabled={deleting}>إلغاء</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ── نافذة تعديل شاملة ── */}
      <Dialog open={!!editTarget} onOpenChange={o => { if (!o) setEditTarget(null); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-sm">
              <Pencil className="w-4 h-4 text-amber-600" />
              تعديل بيانات الأمر{' '}
              <span className="font-mono bg-muted px-2 py-0.5 rounded text-sm">{editTarget?.num}</span>
            </DialogTitle>
          </DialogHeader>
          <div className="py-2 space-y-3">
            {/* رقم الإيصال */}
            <div className="space-y-1.5">
              <Label className="text-xs font-normal">رقم الإيصال</Label>
              <Input
                placeholder="أدخل رقم الإيصال..."
                value={editTarget?.receiptNumber ?? ''}
                onChange={e => setEditTarget(p => p ? { ...p, receiptNumber: e.target.value } : p)}
                className="text-right font-mono"
              />
            </div>
            {/* التاريخ */}
            <div className="space-y-1.5">
              <Label className="text-xs font-normal">التاريخ</Label>
              <input
                type="date"
                value={editTarget?.paidAt ?? ''}
                onChange={e => setEditTarget(p => p ? { ...p, paidAt: e.target.value } : p)}
                className="flex h-9 w-full rounded-lg border border-border bg-background px-3 py-1 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
            {/* طريقة الدفع */}
            <div className="space-y-1.5">
              <Label className="text-xs font-normal flex items-center gap-1.5">
                <CreditCard className="w-3 h-3" /> طريقة الدفع
              </Label>
              <div className="flex gap-2">
                {PAYMENT_METHODS.map(m => (
                  <button key={m}
                    onClick={() => setEditTarget(p => p ? { ...p, paymentMethod: m } : p)}
                    className={`flex-1 h-9 rounded-lg text-[12px] font-bold border transition-all ${
                      editTarget?.paymentMethod === m
                        ? METHOD_STYLE[m]
                        : 'bg-background text-muted-foreground border-border hover:border-primary/40'
                    }`}>
                    {m}
                  </button>
                ))}
              </div>
            </div>
            {/* البيان */}
            <div className="space-y-1.5">
              <Label className="text-xs font-normal">البيان</Label>
              <Input
                placeholder="أدخل بيان الأمر..."
                value={editTarget?.semesterTarget ?? ''}
                onChange={e => setEditTarget(p => p ? { ...p, semesterTarget: e.target.value } : p)}
                className="text-right"
              />
            </div>
            {/* الملاحظات */}
            <div className="space-y-1.5">
              <Label className="text-xs font-normal">الملاحظات</Label>
              <Textarea
                rows={2}
                placeholder="أدخل ملاحظات..."
                value={editTarget?.notes ?? ''}
                onChange={e => setEditTarget(p => p ? { ...p, notes: e.target.value } : p)}
                className="resize-none text-sm text-right"
              />
            </div>
          </div>
          <DialogFooter className="flex-row-reverse gap-2">
            <Button onClick={handleSaveEdit} disabled={saving} className="gap-1.5">
              <Save className="w-3.5 h-3.5" />
              {saving ? 'جاري الحفظ...' : 'حفظ التعديلات'}
            </Button>
            <Button variant="outline" onClick={() => setEditTarget(null)} disabled={saving}>
              <X className="w-3.5 h-3.5 ml-1" /> إلغاء
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}

