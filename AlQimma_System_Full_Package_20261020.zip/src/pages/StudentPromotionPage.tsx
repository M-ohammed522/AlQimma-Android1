// صفحة ترحيل الطلاب — منظومة معهد القمة
import { useEffect, useState, useMemo, useCallback } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { motion } from 'motion/react';
import { supabase } from '@/db/supabase';
import {
  ChevronRight, ChevronUp, RefreshCw, Archive,
  GraduationCap, AlertTriangle, CheckCircle2,
  Users, DollarSign, BookOpen, Info,
  PlayCircle, Loader2, ChevronDown, Search,
  UserCheck, ArrowLeft, X, Sparkles, Check,
  FileText,
} from 'lucide-react';
import { toast } from 'sonner';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import {
  AlertDialog,
  AlertDialogContent,
} from '@/components/ui/alert-dialog';
import {
  getStudents, promoteStudent, archiveStudent,
  getSettings, MAX_SEMESTERS, getSemesterCharges,
} from '@/lib/api';
import type { Student, SemesterCharge } from '@/types/index';
import { SEMESTER_LABELS } from '@/types/index';
import { matchStudent } from '@/lib/searchUtils';
import { StudentAvatar } from '@/components/ui/StudentAvatar';
import { PromoteResultDialog } from '@/components/PromoteResultDialog';
import type { PromoteResultItem } from '@/components/PromoteResultDialog';

// الحقول الأساسية الخفيفة اللازمة للترحيل لتسريع التحميل وتوفير الذاكرة
const PROMOTION_FIELDS = 'id,full_name,national_id,registration_number,diploma_type,specialization,current_semester,status,photo_url,total_charged,total_paid,photos_received,photos_required,has_birth_certificate,has_registration_certificate,has_suspended_file';

// ── نتيجة ترحيل طالب واحد ──
type SemesterGroup = {
  semester: number;
  diplomaType: string;
  students: Student[];
  isLastSemester: boolean;
};

function getInitials(name: string) {
  const parts = name.trim().split(/\s+/);
  return parts.length >= 2 ? parts[0][0] + parts[1][0] : parts[0].slice(0, 2);
}

export default function StudentPromotionPage() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const studentIdParam = searchParams.get('studentId');
  const semesterParam = searchParams.get('semester');

  const [students, setStudents]   = useState<Student[]>([]);
  const [loading, setLoading]     = useState(true);
  const [settings, setSettings]   = useState<Record<string, string>>({});

  // الطالب المحدد للترحيل الفردي في البطاقة العلوية
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);

  // نافذة الترحيل التفاعلية والمطابقة لصفحة مالية الطالب
  const [promoteTargetStudent, setPromoteTargetStudent] = useState<Student | null>(null);
  const [promoteModalOpen, setPromoteModalOpen] = useState(false);
  const [promoteStep, setPromoteStep] = useState<'idle' | 'animating' | 'success'>('idle');
  const [promoteProgress, setPromoteProgress] = useState(0);
  const [promoteStatusText, setPromoteStatusText] = useState('');
  const [promoteCharges, setPromoteCharges] = useState<SemesterCharge[]>([]);
  const [loadingPromoteCharges, setLoadingPromoteCharges] = useState(false);

  // حدود العرض لكل مجموعة لمنع تجميد المتصفح وسرعة التمرير
  const [groupLimits, setGroupLimits] = useState<Record<string, number>>({});

  // البحث السريع
  const [searchQuery, setSearchQuery] = useState('');

  // فلتر الفصل الدراسي المصدر: 'all' أو رقم الفصل (1 إلى 6)
  const [semesterFilter, setSemesterFilter] = useState<number | 'all'>('all');

  // حالة الترحيل
  const [promoting, setPromoting]       = useState(false);
  const [progressMax, setProgressMax]   = useState(0);
  const [progressDone, setProgressDone] = useState(0);
  const [results, setResults]           = useState<PromoteResultItem[]>([]);
  const [showResults, setShowResults]   = useState(false);

  // فلتر الدبلوم
  const [diplomaFilter, setDiplomaFilter] = useState<'all' | 'عالي' | 'متوسط'>('all');

  // تجميع الفصول المفتوحة في الواجهة
  const [openGroups, setOpenGroups] = useState<Set<string>>(new Set());

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [{ data: s }, cfg] = await Promise.all([
        getStudents({ status: 'نشط', limit: 12000, fields: PROMOTION_FIELDS }),
        getSettings(),
      ]);
      setStudents(s);
      setSettings(cfg);

      // إذا كان هناك طالب محدد في الرابط (studentId)
      if (studentIdParam) {
        const found = s.find(st => st.id === studentIdParam);
        if (found) {
          setSelectedStudent(found);
          setSemesterFilter(found.current_semester);
          setDiplomaFilter(found.diploma_type as 'عالي' | 'متوسط');
          const groupKey = `${found.diploma_type}__${found.current_semester}`;
          setOpenGroups(new Set([groupKey]));
        }
      } else if (semesterParam) {
        const semNum = parseInt(semesterParam, 10);
        if (!isNaN(semNum) && semNum >= 1 && semNum <= 6) {
          setSemesterFilter(semNum);
        }
      }
    } catch {
      toast.error('فشل تحميل بيانات الطلاب');
    } finally {
      setLoading(false);
    }
  }, [studentIdParam, semesterParam]);

  useEffect(() => { fetchData(); }, [fetchData]);

  // نتائج البحث السريع
  const searchResults = useMemo(() => {
    const q = searchQuery.trim();
    if (!q) return [];
    return students.filter(s => matchStudent(s, q)).slice(0, 8);
  }, [students, searchQuery]);

  // تجميع الطلاب في مجموعات حسب (الدبلوم × الفصل) مع تطبيق الفلاتر
  const groups: SemesterGroup[] = useMemo(() => {
    let filtered = students;
    if (diplomaFilter !== 'all') {
      filtered = filtered.filter(s => s.diploma_type === diplomaFilter);
    }
    if (semesterFilter !== 'all') {
      filtered = filtered.filter(s => s.current_semester === semesterFilter);
    }

    const map = new Map<string, SemesterGroup>();
    for (const s of filtered) {
      const maxSem = MAX_SEMESTERS[s.diploma_type] ?? 6;
      const key = `${s.diploma_type}__${s.current_semester}`;
      if (!map.has(key)) {
        map.set(key, {
          semester: s.current_semester,
          diplomaType: s.diploma_type,
          students: [],
          isLastSemester: s.current_semester >= maxSem,
        });
      }
      map.get(key)!.students.push(s);
    }
    // ترتيب: أولاً بالدبلوم، ثم بالفصل
    return [...map.values()].sort((a, b) => {
      if (a.diplomaType !== b.diplomaType) return a.diplomaType === 'عالي' ? -1 : 1;
      return a.semester - b.semester;
    });
  }, [students, diplomaFilter, semesterFilter]);

  // إحصاءات
  const stats = useMemo(() => {
    const total      = students.length;
    const lastSem    = students.filter(s => s.current_semester >= (MAX_SEMESTERS[s.diploma_type] ?? 6)).length;
    const promotable = total - lastSem;
    const withDebt   = students.filter(s => s.total_charged > s.total_paid).length;
    const high       = students.filter(s => s.diploma_type === 'عالي').length;
    const mid        = students.filter(s => s.diploma_type === 'متوسط').length;
    return { total, lastSem, promotable, withDebt, high, mid };
  }, [students]);

  // ترحيل مجموعة كاملة بسرعة فائقة (معالجة متوازية على دفعات)
  const promoteGroup = async (group: SemesterGroup) => {
    if (group.isLastSemester) return;
    const toPromote = group.students;
    setProgressMax(toPromote.length);
    setProgressDone(0);
    setResults([]);
    setPromoting(true);
    setShowResults(true);

    const localResults: PromoteResultItem[] = [];
    // دفعات متوازية من 6 طلاب لتسريع المعالجة وتقليل زمن الانتظار حتى مع 100+ طالب
    const BATCH_SIZE = 6;
    for (let i = 0; i < toPromote.length; i += BATCH_SIZE) {
      const batch = toPromote.slice(i, i + BATCH_SIZE);
      const batchPromises = batch.map(async (student) => {
        try {
          const missing: string[] = [];
          if ((student.photos_received ?? 0) < (student.photos_required ?? 0))
            missing.push(`${(student.photos_required ?? 0) - (student.photos_received ?? 0)} صور شخصية`);
          if (!student.has_birth_certificate) missing.push('شهادة ميلاد');
          if (!student.has_registration_certificate) missing.push('شهادة التسجيل');
          if (!student.has_suspended_file) missing.push('ملف معلق');

          await promoteStudent(student, settings);
          return {
            student,
            status: 'success' as const,
            message: `تم الترحيل إلى ${SEMESTER_LABELS[student.current_semester + 1] ?? `الفصل ${student.current_semester + 1}`}`,
            newSemester: student.current_semester + 1,
            charges: [],
            missingDocs: missing,
            isArchived: false,
          };
        } catch {
          return {
            student,
            status: 'error' as const,
            message: 'فشل الترحيل — يرجى المحاولة يدوياً',
          };
        }
      });

      const batchResults = await Promise.all(batchPromises);
      localResults.push(...batchResults);
      setProgressDone(localResults.length);
      setResults([...localResults]);
    }
    setPromoting(false);
    await fetchData();
  };

  // ── فتح نافذة الترحيل الفردي التفاعلية (المطابقة لصفحة مالية الطالب) ──
  const handleOpenPromoteModal = async (student: Student) => {
    setPromoteTargetStudent(student);
    setPromoteModalOpen(true);
    setPromoteStep('idle');
    setPromoteProgress(0);
    setPromoteStatusText('');
    setLoadingPromoteCharges(true);
    try {
      const chs = await getSemesterCharges(student.id);
      setPromoteCharges(chs);
    } catch {
      setPromoteCharges([]);
    } finally {
      setLoadingPromoteCharges(false);
    }
  };

  // ── تنفيذ الترحيل من داخل نافذة الترحيل التفاعلية مع الحركات المتطابقة ──
  const handleExecutePromote = async () => {
    if (!promoteTargetStudent) return;
    const student = promoteTargetStudent;
    const maxSem = MAX_SEMESTERS[student.diploma_type] ?? 6;
    const maxChargeSem = promoteCharges
      .filter(c => c.charge_type === 'فصلي')
      .reduce((max, c) => Math.max(max, c.semester_number), 0);
    const currentSemNum = Math.max(student.current_semester, maxChargeSem, 1);
    const targetSemNum = currentSemNum + 1;
    const isAtFinal = currentSemNum >= maxSem;

    setPromoting(true);
    setPromoteStep('animating');
    setPromoteProgress(15);
    setPromoteStatusText('فحص الموقف المالي وتدقيق الرسوم...');

    try {
      await new Promise(r => setTimeout(r, 350));
      setPromoteProgress(45);
      setPromoteStatusText('تجهيز السجل الأكاديمي والقيد...');

      await new Promise(r => setTimeout(r, 400));
      setPromoteProgress(75);
      setPromoteStatusText(isAtFinal ? 'اعتماد التخرج والأرشفة كخريج...' : `إسناد قسط الفصل ${targetSemNum} وترحيل القيد...`);

      if (isAtFinal) {
        const { data: fresh } = await supabase.from('students').select('*').eq('id', student.id).single();
        await archiveStudent(fresh ?? student);
      } else {
        await promoteStudent(student, settings, targetSemNum);
      }

      setPromoteProgress(95);
      setPromoteStatusText('اعتماد السجل وتحديث البيانات...');
      await new Promise(r => setTimeout(r, 300));

      setPromoteProgress(100);
      setPromoteStatusText('اكتمل الترحيل بنجاح!');
      await new Promise(r => setTimeout(r, 200));

      setPromoteStep('success');
      toast.success(isAtFinal ? `تمت أرشفة ${student.full_name} كخريج بنجاح` : `تم ترحيل ${student.full_name} بنجاح!`);

      // تحديث فوري وسريع للذاكرة دون تجميد
      setStudents(prev => prev.map(s => {
        if (s.id !== student.id) return s;
        return {
          ...s,
          current_semester: isAtFinal ? s.current_semester : targetSemNum,
          status: isAtFinal ? ('خريج' as const) : s.status,
        };
      }));
      if (selectedStudent?.id === student.id) {
        setSelectedStudent(prev => prev ? {
          ...prev,
          current_semester: isAtFinal ? prev.current_semester : targetSemNum,
          status: isAtFinal ? ('خريج' as const) : prev.status,
        } : null);
      }
    } catch (err: any) {
      console.error(err);
      toast.error(err?.message || 'فشلت عملية الترحيل، يرجى المحاولة ثانية');
      setPromoteStep('idle');
    } finally {
      setPromoting(false);
    }
  };

  const toggleGroup = (key: string) => {
    setOpenGroups(prev => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key); else next.add(key);
      return next;
    });
  };

  // ── نسبة التقدم ──
  const progressPct = progressMax > 0 ? Math.round((progressDone / progressMax) * 100) : 0;

  return (
    <MainLayout>
      <div className="space-y-4">

        {/* ── الترويسة ── */}
        <div className="relative rounded-2xl overflow-hidden" style={{ boxShadow: 'var(--shadow-lg)' }}>
          <div className="absolute inset-0 bg-gradient-to-br from-indigo-700/90 via-indigo-600/90 to-blue-700/80" />
          <div className="absolute inset-0 opacity-[0.06]"
            style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '24px 24px' }} />
          <div className="relative px-5 py-4 md:px-7 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <button onClick={() => navigate('/')}
                className="w-9 h-9 rounded-xl bg-white/15 border border-white/20 flex items-center justify-center shrink-0 hover:bg-white/25 transition-colors">
                <ChevronRight className="w-4 h-4 text-white" />
              </button>
              <div className="w-10 h-10 rounded-xl bg-white/15 border border-white/20 flex items-center justify-center shrink-0">
                <ChevronUp className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-white">ترحيل الطلاب</h1>
                <p className="text-white/60 text-xs mt-0.5">نقل الطلاب للفصل الأعلى وإضافة رسوم الفصل الجديد</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2 shrink-0">
              <Button size="sm" onClick={fetchData} disabled={loading}
                className="bg-white/15 text-white hover:bg-white/25 border border-white/20 gap-2 h-9 rounded-xl text-[12px] font-semibold">
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} /> تحديث
              </Button>
            </div>
          </div>
        </div>

        {/* ── بطاقات الإحصاءات ── */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: 'إجمالي الطلاب النشطين', value: loading ? '—' : `${stats.total}`, sub: 'طالب نشط', gradient: 'from-indigo-500 to-indigo-700', ring: 'ring-indigo-400/30', Icon: Users },
            { label: 'قابلون للترحيل',        value: loading ? '—' : `${stats.promotable}`, sub: 'طالب', gradient: 'from-emerald-500 to-emerald-700', ring: 'ring-emerald-400/30', Icon: ChevronUp },
            { label: 'في الفصل الأخير',       value: loading ? '—' : `${stats.lastSem}`,   sub: 'طالب', gradient: 'from-amber-400 to-amber-600',    ring: 'ring-amber-400/30',   Icon: Archive },
            { label: 'بديون مستحقة',          value: loading ? '—' : `${stats.withDebt}`,  sub: 'طالب', gradient: 'from-rose-500 to-rose-700',      ring: 'ring-rose-400/30',    Icon: DollarSign },
          ].map(card => (
            <div key={card.label}
              className={`relative rounded-2xl p-4 bg-gradient-to-br ${card.gradient} text-white shadow-md ring-1 ${card.ring} overflow-hidden`}>
              {/* أيقونة الخلفية */}
              <div className="absolute -bottom-2 -left-2 opacity-[0.12]">
                <card.Icon className="w-16 h-16" />
              </div>
              <div className="relative">
                <p className="text-[10px] font-semibold text-white/70 leading-tight tracking-wide uppercase">{card.label}</p>
                {loading
                  ? <div className="h-8 w-12 bg-white/20 rounded-lg mt-2 animate-pulse" />
                  : <p className="text-3xl font-black leading-none mt-1.5 tabular-nums">{card.value}</p>
                }
                <div className="flex items-center gap-1.5 mt-2">
                  <div className="w-1 h-1 rounded-full bg-white/50" />
                  <p className="text-[10px] text-white/60">{card.sub}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* ── قواعد الترحيل ── */}
        <div className="rounded-2xl border border-indigo-200/70 bg-gradient-to-br from-indigo-50/80 to-blue-50/40 dark:from-indigo-500/10 dark:to-blue-500/5 dark:border-indigo-500/20 p-4 shadow-sm">
          <div className="flex items-center gap-2.5 mb-3.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-100 dark:bg-indigo-500/20 flex items-center justify-center shrink-0">
              <Info className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
            </div>
            <div>
              <p className="text-sm font-bold text-indigo-700 dark:text-indigo-300">قواعد وآلية الترحيل</p>
              <p className="text-[10px] text-indigo-500/70 dark:text-indigo-400/60">يُطبَّق هذا النظام على جميع الطلاب بصرف النظر عن حالتهم المالية</p>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {[
              { icon: CheckCircle2,  bg: 'bg-emerald-100 dark:bg-emerald-500/15', ic: 'text-emerald-600', text: 'يُنقل الطالب للفصل الأعلى بصرف النظر عن الوضع المالي' },
              { icon: DollarSign,    bg: 'bg-blue-100 dark:bg-blue-500/15',       ic: 'text-blue-600',    text: 'تُضاف رسوم الفصل الجديد: 600 د.ل (عالي) / 550 د.ل (متوسط)' },
              { icon: AlertTriangle, bg: 'bg-amber-100 dark:bg-amber-500/15',     ic: 'text-amber-600',   text: 'تُرحَّل المديونيات وتُرسل إشعارات للإدارة تلقائياً' },
              { icon: GraduationCap, bg: 'bg-purple-100 dark:bg-purple-500/15',   ic: 'text-purple-600',  text: 'عند الوصول للفصل السادس (عالي): تُضاف رسوم مشروع التخرج (350 د.ل)' },
              { icon: Archive,       bg: 'bg-rose-100 dark:bg-rose-500/15',       ic: 'text-rose-600',    text: 'الطلاب في الفصل الأخير لن يُرحَّلوا — يجب أرشفتهم يدوياً' },
            ].map((rule, i) => (
              <div key={i} className="flex items-start gap-2.5 bg-white/50 dark:bg-white/5 rounded-xl px-3 py-2.5 border border-white/60 dark:border-white/10">
                <div className={`w-6 h-6 rounded-lg ${rule.bg} flex items-center justify-center shrink-0 mt-0.5`}>
                  <rule.icon className={`w-3.5 h-3.5 ${rule.ic}`} />
                </div>
                <p className="text-xs text-foreground/75 leading-relaxed">{rule.text}</p>
              </div>
            ))}
          </div>
        </div>

        {/* ── بطاقة الطالب المحدد للترحيل الفردي (إن وجد) ── */}
        {selectedStudent && (
          <div className="relative rounded-2xl overflow-hidden border-2 border-indigo-500/40 bg-gradient-to-br from-indigo-950/80 via-background to-blue-950/60 p-5 shadow-xl animate-in fade-in zoom-in-95 duration-200">
            <div className="absolute top-0 right-0 left-0 h-1.5 bg-gradient-to-r from-blue-500 via-indigo-400 to-emerald-400" />
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div className="flex items-center gap-4 flex-1 min-w-0">
                <StudentAvatar
                  photoUrl={selectedStudent.photo_url}
                  name={selectedStudent.full_name}
                  size="lg"
                  variant="rounded"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-base font-black text-foreground">{selectedStudent.full_name}</span>
                    <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-400/30">
                      {selectedStudent.diploma_type}
                    </span>
                    <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-muted text-muted-foreground">
                      {selectedStudent.specialization}
                    </span>
                    {selectedStudent.registration_number && (
                      <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30">
                        قيد: #{selectedStudent.registration_number}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    الرقم الوطني: <span className="font-mono text-foreground font-semibold">{selectedStudent.national_id || '—'}</span>
                  </p>
                </div>
              </div>

              {/* زر إلغاء التحديد */}
              <div className="flex items-center gap-2 shrink-0">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setSelectedStudent(null);
                    setSearchParams({});
                  }}
                  className="h-8 px-2.5 text-xs text-muted-foreground hover:text-foreground">
                  <X className="w-3.5 h-3.5 ml-1" /> إلغاء التحديد
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => navigate(`/students/${selectedStudent.id}`)}
                  className="h-8 px-3 text-xs gap-1">
                  الملف الشامل <ArrowLeft className="w-3 h-3" />
                </Button>
              </div>
            </div>

            {/* مسار الترحيل الديناميكي الحقيقي للطالب المحدد */}
            {(() => {
              const maxSem = MAX_SEMESTERS[selectedStudent.diploma_type] ?? 6;
              const isLast = selectedStudent.current_semester >= maxSem;
              const currentLbl = SEMESTER_LABELS[selectedStudent.current_semester] ?? `الفصل ${selectedStudent.current_semester}`;
              const nextLbl = SEMESTER_LABELS[selectedStudent.current_semester + 1] ?? `الفصل ${selectedStudent.current_semester + 1}`;
              const debt = (selectedStudent.total_charged ?? 0) - (selectedStudent.total_paid ?? 0);

              return (
                <div className="mt-4 pt-4 border-t border-border/40">
                  <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
                    {/* مؤشر الفصول الديناميكي */}
                    <div className="flex items-center gap-3 flex-1">
                      {/* الفصل الحالي */}
                      <div className="flex-1 rounded-xl p-3 bg-muted/40 border border-border/60 text-center">
                        <span className="text-[10px] text-muted-foreground block font-bold mb-0.5">الفصل الدراسي الحالي</span>
                        <span className="text-sm md:text-base font-black text-foreground">{currentLbl}</span>
                        <span className="text-[10px] text-muted-foreground/75 block mt-0.5">({selectedStudent.current_semester})</span>
                      </div>

                      {/* سهم الترحيل */}
                      <div className="flex flex-col items-center justify-center shrink-0">
                        <div className="w-9 h-9 rounded-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white flex items-center justify-center shadow-lg shadow-indigo-500/30 animate-pulse">
                          <ChevronUp className="w-5 h-5" />
                        </div>
                        <span className="text-[9px] font-bold text-indigo-400 mt-1">ترحيل تلقائي</span>
                      </div>

                      {/* الفصل التالي المستهدف */}
                      <div className={`flex-1 rounded-xl p-3 border text-center ${
                        isLast
                          ? 'bg-amber-500/10 border-amber-400/40 text-amber-300'
                          : 'bg-emerald-500/10 border-emerald-400/40 text-emerald-300'
                      }`}>
                        <span className="text-[10px] text-muted-foreground block font-bold mb-0.5">
                          {isLast ? 'المسار النهائي' : 'الفصل الدراسي القادم'}
                        </span>
                        <span className="text-sm md:text-base font-black">
                          {isLast ? 'أرشفة كخريج (تخرج نهائي)' : nextLbl}
                        </span>
                        <span className="text-[10px] text-muted-foreground/75 block mt-0.5">
                          {isLast ? '(اكتملت الفصول)' : `(${selectedStudent.current_semester + 1})`}
                        </span>
                      </div>
                    </div>

                    {/* معلومات الرسوم وزر التأكيد الفوري */}
                    <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3 shrink-0">
                      <div className="text-right text-xs space-y-0.5 px-2">
                        {debt > 0 ? (
                          <span className="text-amber-400 font-bold flex items-center gap-1">
                            <AlertTriangle className="w-3.5 h-3.5" /> مديونية سابقة: {debt.toFixed(0)} د.ل
                          </span>
                        ) : (
                          <span className="text-emerald-400 font-bold flex items-center gap-1">
                            <Check className="w-3.5 h-3.5" /> الرسوم السابقة مسددة بالكامل
                          </span>
                        )}
                        {!isLast && (
                          <span className="text-muted-foreground text-[11px] block">
                            تُضاف رسوم {nextLbl}: {selectedStudent.diploma_type === 'عالي' ? '600 د.ل' : '550 د.ل'}
                          </span>
                        )}
                      </div>

                      <Button
                        onClick={() => handleOpenPromoteModal(selectedStudent)}
                        disabled={promoting}
                        className={`h-11 px-5 rounded-xl text-sm font-bold shadow-lg transition-all active:scale-95 ${
                          isLast
                            ? 'bg-amber-600 hover:bg-amber-700 text-white shadow-amber-600/30'
                            : 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-emerald-600/30'
                        }`}>
                        {promoting ? (
                          <>
                            <Loader2 className="w-4 h-4 animate-spin ml-2" />
                            جاري التنفيذ...
                          </>
                        ) : isLast ? (
                          <>
                            <Archive className="w-4 h-4 ml-2" />
                            تأكيد أرشفة الطالب كخريج
                          </>
                        ) : (
                          <>
                            <PlayCircle className="w-4 h-4 ml-2" />
                            تأكيد ترحيل الطالب إلى {nextLbl}
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>
        )}

        {/* ── شريط البحث السريع عن طالب ── */}
        <div className="relative">
          <div className="relative flex items-center">
            <Search className="w-4 h-4 absolute right-3.5 text-muted-foreground pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="ابحث عن طالب بالاسم، الرقم الوطني، أو رقم القيد لترحيله مباشرة..."
              className="w-full h-11 pr-10 pl-10 rounded-2xl bg-muted/40 border border-border/60 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-500 transition-all text-foreground placeholder:text-muted-foreground/60"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute left-3 w-6 h-6 rounded-lg bg-muted flex items-center justify-center text-muted-foreground hover:text-foreground">
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* قائمة نتائج البحث السريع المنسدلة */}
          {searchQuery.trim() && (
            <div className="absolute top-full right-0 left-0 mt-1.5 z-30 bg-card border border-border/80 rounded-2xl shadow-2xl overflow-hidden divide-y divide-border/40 max-h-72 overflow-y-auto">
              {searchResults.length === 0 ? (
                <div className="p-4 text-center text-xs text-muted-foreground font-semibold">
                  لا يوجد طالب مطابق لـ &quot;{searchQuery}&quot;
                </div>
              ) : (
                searchResults.map(st => {
                  const maxSem = MAX_SEMESTERS[st.diploma_type] ?? 6;
                  const isLast = st.current_semester >= maxSem;
                  const curLbl = SEMESTER_LABELS[st.current_semester] ?? `الفصل ${st.current_semester}`;
                  const nxtLbl = SEMESTER_LABELS[st.current_semester + 1] ?? `الفصل ${st.current_semester + 1}`;

                  return (
                    <div
                      key={st.id}
                      onClick={() => {
                        setSelectedStudent(st);
                        setSemesterFilter(st.current_semester);
                        setDiplomaFilter(st.diploma_type as 'عالي' | 'متوسط');
                        setSearchQuery('');
                        handleOpenPromoteModal(st);
                      }}
                      className="p-3 hover:bg-muted/30 cursor-pointer flex items-center justify-between gap-3 transition-colors">
                      <div className="flex items-center gap-3 min-w-0">
                        <StudentAvatar photoUrl={st.photo_url} name={st.full_name} size="sm" variant="rounded" />
                        <div className="min-w-0">
                          <p className="text-xs font-bold text-foreground truncate">{st.full_name}</p>
                          <p className="text-[11px] text-muted-foreground truncate">
                            {st.diploma_type} — {st.specialization} {st.registration_number ? `(قيد #${st.registration_number})` : ''}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <div className="text-right">
                          <span className="text-[11px] font-bold text-foreground block">
                            {curLbl}
                          </span>
                          <span className={`text-[10px] font-bold block ${isLast ? 'text-amber-500' : 'text-emerald-500'}`}>
                            {isLast ? '← الأرشيف' : `← ${nxtLbl}`}
                          </span>
                        </div>
                        <span className="inline-flex items-center justify-center rounded-lg bg-secondary text-secondary-foreground h-7 text-[11px] font-bold px-2.5">
                          تحديد وترحيل
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}
        </div>

        {/* ── شريط اختيار الفصول الديناميكي (من الفصل X إلى X+1) ── */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-foreground flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
              تصفية الطلاب وترحيلهم بحسب الفصل الحالي:
            </span>
            {semesterFilter !== 'all' && (
              <button
                onClick={() => setSemesterFilter('all')}
                className="text-[11px] font-semibold text-indigo-500 hover:underline">
                عرض جميع الفصول
              </button>
            )}
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {/* خيار الكل */}
            <button
              onClick={() => setSemesterFilter('all')}
              className={`h-9 px-3.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all duration-200 border shrink-0 ${
                semesterFilter === 'all'
                  ? 'bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-500/20'
                  : 'bg-muted/40 text-muted-foreground border-border/50 hover:bg-muted hover:text-foreground'
              }`}>
              جميع الفصول ({stats.total})
            </button>

            {/* أزرار الفصول الفردية الديناميكية */}
            {([1, 2, 3, 4, 5, 6] as const).map(sem => {
              const semCount = students.filter(s => s.current_semester === sem).length;
              const isActive = semesterFilter === sem;
              const isFinal = sem === 6;

              return (
                <button
                  key={sem}
                  onClick={() => setSemesterFilter(sem)}
                  className={`relative flex items-center gap-1.5 h-9 px-3.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all duration-200 border shrink-0 ${
                    isActive
                      ? isFinal
                        ? 'bg-amber-600 text-white border-amber-600 shadow-md shadow-amber-600/25'
                        : 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-500/25'
                      : 'bg-muted/40 text-muted-foreground border-border/50 hover:bg-muted hover:text-foreground'
                  }`}>
                  <span>{SEMESTER_LABELS[sem] ?? `الفصل ${sem}`}</span>
                  <span className={`text-[10px] font-black ${isActive ? 'text-white/80' : 'text-indigo-500 dark:text-indigo-400'}`}>
                    {isFinal ? '← تخرج' : `← ${SEMESTER_LABELS[sem + 1] ?? `الفصل ${sem + 1}`}`}
                  </span>
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                    isActive ? 'bg-white/25 text-white' : 'bg-muted text-foreground'
                  }`}>
                    {semCount}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* ── فلتر نوع الدبلوم ── */}
        <div className="flex items-center gap-1.5 bg-muted/50 border border-border/50 rounded-2xl p-1.5 w-fit shadow-sm">
          {([
            { v: 'all',    label: 'الكل',         count: stats.total, activeClass: 'bg-indigo-600 text-white shadow-indigo-500/25', dotClass: '' },
            { v: 'عالي',   label: 'دبلوم عالي',  count: stats.high,  activeClass: 'bg-blue-600 text-white shadow-blue-500/25',   dotClass: 'bg-blue-400' },
            { v: 'متوسط',  label: 'دبلوم متوسط', count: stats.mid,   activeClass: 'bg-emerald-600 text-white shadow-emerald-500/25', dotClass: 'bg-emerald-400' },
          ] as const).map(({ v, label, count, activeClass, dotClass }) => {
            const isActive = diplomaFilter === v;
            return (
              <button key={v}
                onClick={() => setDiplomaFilter(v)}
                className={`relative flex items-center gap-2 h-9 px-4 rounded-xl text-[12px] font-semibold transition-all duration-200 select-none ${
                  isActive
                    ? `${activeClass} shadow-md`
                    : 'text-muted-foreground hover:text-foreground hover:bg-background/70'
                }`}>
                {/* نقطة اللون للدبلوم */}
                {dotClass && (
                  <span className={`w-2 h-2 rounded-full shrink-0 ${isActive ? 'bg-white/80' : dotClass}`} />
                )}
                {label}
                {/* عداد الطلاب */}
                <span className={`inline-flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded-full text-[10px] font-black transition-all ${
                  isActive
                    ? 'bg-white/25 text-white'
                    : 'bg-muted text-muted-foreground'
                }`}>
                  {loading ? '·' : count}
                </span>
              </button>
            );
          })}
        </div>

        {/* ── مجموعات الفصول الديناميكية ── */}
        {loading ? (
          <div className="space-y-3">
            {Array(4).fill(0).map((_, i) => (
              <Card key={i} className="overflow-hidden">
                <div className="p-4 flex items-center gap-3">
                  <Skeleton className="h-10 w-32 rounded-xl" />
                  <div className="flex-1 space-y-1.5">
                    <Skeleton className="h-3 w-24" />
                    <Skeleton className="h-3 w-16" />
                  </div>
                  <Skeleton className="h-9 w-24 rounded-xl" />
                </div>
              </Card>
            ))}
          </div>
        ) : groups.length === 0 ? (
          <div className="flex flex-col items-center py-16 gap-3 rounded-2xl border-2 border-border/35 bg-card text-center p-6">
            <div className="w-14 h-14 rounded-2xl bg-muted flex items-center justify-center">
              <Users className="w-7 h-7 text-muted-foreground/40" />
            </div>
            <p className="text-sm font-semibold text-muted-foreground">
              {semesterFilter !== 'all'
                ? `لا يوجد طلاب نشطون مسجلون في ${SEMESTER_LABELS[semesterFilter]} حالياً`
                : 'لا يوجد طلاب نشطون'}
            </p>
            {semesterFilter !== 'all' && (
              <Button size="sm" variant="outline" onClick={() => setSemesterFilter('all')}>
                إظهار كافة الفصول
              </Button>
            )}
          </div>
        ) : (
          <div className="space-y-3">
            {groups.map(group => {
              const key     = `${group.diplomaType}__${group.semester}`;
              const isOpen  = openGroups.has(key) || selectedStudent?.current_semester === group.semester;
              const isHigh  = group.diplomaType === 'عالي';
              const withDebt = group.students.filter(s => s.total_charged > s.total_paid).length;
              const nextSem  = group.semester + 1;
              const currentLbl = SEMESTER_LABELS[group.semester] ?? `الفصل ${group.semester}`;
              const nextLbl = SEMESTER_LABELS[nextSem] ?? `الفصل ${nextSem}`;

              return (
                <Card key={key} className={`overflow-hidden border-2 transition-colors ${
                  isOpen ? (group.isLastSemester ? 'border-amber-400/40' : 'border-indigo-400/30') : 'border-border/40 hover:border-indigo-300/30'
                }`}>
                  {/* ── رأس المجموعة ── */}
                  <div
                    className={`flex flex-col md:flex-row md:items-center gap-3 p-4 cursor-pointer transition-colors select-none ${
                      isOpen ? 'bg-muted/10' : 'hover:bg-muted/10'
                    }`}
                    onClick={() => toggleGroup(key)}>

                    {/* معلومات الفصل والانتقال الديناميكي */}
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      {/* شارة رقم الفصل */}
                      <div className={`w-12 h-12 rounded-xl flex flex-col items-center justify-center shrink-0 ${
                        group.isLastSemester ? 'bg-amber-500/15 border-2 border-amber-400/40' :
                        isHigh ? 'bg-blue-500/15 border-2 border-blue-400/40' : 'bg-emerald-500/15 border-2 border-emerald-400/40'
                      }`}>
                        <span className={`text-lg font-black leading-none ${
                          group.isLastSemester ? 'text-amber-700' : isHigh ? 'text-blue-700' : 'text-emerald-700'
                        }`}>{group.semester}</span>
                        <span className="text-[8px] font-semibold text-muted-foreground leading-none mt-0.5">فصل</span>
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-sm font-bold text-foreground">
                            {currentLbl}
                          </span>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                            isHigh ? 'bg-blue-50 text-blue-700 border-blue-200' : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          }`}>{group.diplomaType}</span>
                          {group.isLastSemester ? (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-50 text-amber-700 border border-amber-200">
                              فصل أخير (تخرج)
                            </span>
                          ) : (
                            <span className="text-[11px] font-black text-indigo-600 dark:text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded-full border border-indigo-500/20">
                              الترحيل إلى: {nextLbl}
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-3 mt-1 flex-wrap">
                          <span className="text-xs text-muted-foreground flex items-center gap-1 font-semibold">
                            <Users className="w-3 h-3" />{group.students.length} طالب
                          </span>
                          {withDebt > 0 && (
                            <span className="text-xs text-amber-600 flex items-center gap-1 font-semibold">
                              <AlertTriangle className="w-3 h-3" />{withDebt} لديهم ديون
                            </span>
                          )}
                          {!group.isLastSemester && (
                            <span className="text-xs text-muted-foreground/80 flex items-center gap-1">
                              <BookOpen className="w-3 h-3" />
                              رسوم الترحيل: {isHigh ? '600 د.ل' : '550 د.ل'}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* زر الترحيل الجماعي الصريح */}
                    <div className="flex items-center gap-2 w-full md:w-auto justify-between md:justify-end shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-border/30" onClick={e => e.stopPropagation()}>
                      {!group.isLastSemester ? (
                        <button
                          onClick={() => promoteGroup(group)}
                          disabled={promoting}
                          className="flex-1 md:flex-initial inline-flex items-center justify-center gap-2 h-9 px-4 rounded-xl text-[12px] font-bold text-white bg-indigo-600 hover:bg-indigo-700 transition-all disabled:opacity-50 shadow-sm shadow-indigo-500/25 active:scale-95">
                          <PlayCircle className="w-4 h-4 shrink-0" />
                          <span>ترحيل المجموعة إلى {nextLbl} ({group.students.length})</span>
                        </button>
                      ) : (
                        <div className="flex-1 md:flex-initial inline-flex items-center justify-center gap-2 h-9 px-4 rounded-xl text-[12px] font-semibold text-amber-700 bg-amber-50 border border-amber-300/60">
                          <Archive className="w-4 h-4 shrink-0" />
                          <span>يحتاج أرشفة فردية</span>
                        </div>
                      )}
                      {/* سهم التوسيع */}
                      <div className="w-9 h-9 rounded-xl flex items-center justify-center border border-border/60 text-muted-foreground hover:bg-muted transition-all shrink-0">
                        <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
                      </div>
                    </div>
                  </div>

                  {/* ── قائمة الطلاب المتوسّعة مع التقطيع السريع لمنع البطء ── */}
                  <div
                    className="overflow-hidden transition-[grid-template-rows] duration-200 ease-out"
                    style={{ display: 'grid', gridTemplateRows: isOpen ? '1fr' : '0fr' }}>
                    <div className="min-h-0">
                      <div className="border-t border-border/30">
                        {(() => {
                          const limit = groupLimits[key] ?? 30;
                          const visibleStudents = group.students.slice(0, limit);
                          const remainingCount = group.students.length - visibleStudents.length;

                          return (
                            <>
                              <div className="divide-y divide-border/20">
                                {visibleStudents.map(student => {
                                  const studentDebt = student.total_charged - student.total_paid;
                                  const hasDebt     = studentDebt > 0;
                                  const isLast      = student.current_semester >= (MAX_SEMESTERS[student.diploma_type] ?? 6);
                                  const isSelected  = selectedStudent?.id === student.id;

                                  return (
                                    <div
                                      key={student.id}
                                      className={`p-3 md:px-4 md:py-3 transition-colors ${
                                        isSelected ? 'bg-indigo-500/15 border-r-4 border-indigo-500' : 'hover:bg-muted/10'
                                      }`}>
                                      {/* حاوية متجاوبة بالكامل تمنع التداخل أو خروج الأزرار خارج الشاشة على الجوال */}
                                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-2.5">
                                        {/* بيانات الطالب الأساسية */}
                                        <div className="flex items-center gap-3 min-w-0">
                                          <StudentAvatar
                                            photoUrl={student.photo_url}
                                            name={student.full_name}
                                            size="sm"
                                            variant="rounded"
                                          />
                                          <div className="flex-1 min-w-0">
                                            <div className="flex items-center gap-2 flex-wrap">
                                              <span className="text-sm font-bold text-foreground break-words">
                                                {student.full_name}
                                              </span>
                                              {hasDebt ? (
                                                <span className="text-[10px] font-bold text-amber-700 dark:text-amber-400 bg-amber-500/10 border border-amber-300 dark:border-amber-700 px-2 py-0.5 rounded-full whitespace-nowrap">
                                                  دين: {studentDebt.toFixed(0)} د.ل
                                                </span>
                                              ) : (
                                                <span className="text-[10px] font-bold text-emerald-700 dark:text-emerald-400 bg-emerald-500/10 border border-emerald-300 dark:border-emerald-700 px-2 py-0.5 rounded-full whitespace-nowrap">
                                                  مسدد بالكامل
                                                </span>
                                              )}
                                            </div>
                                            <div className="flex items-center gap-2 mt-1 text-[11px] text-muted-foreground flex-wrap">
                                              <span className="bg-muted px-2 py-0.5 rounded text-foreground/80 font-medium">
                                                {student.specialization}
                                              </span>
                                              {student.registration_number && (
                                                <span className="font-mono text-muted-foreground">
                                                  #{student.registration_number}
                                                </span>
                                              )}
                                              <span className="inline-flex items-center gap-1 font-semibold text-indigo-600 dark:text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded">
                                                <span>{currentLbl}</span>
                                                <span className="text-indigo-400">←</span>
                                                <span>{isLast ? 'الأرشيف' : nextLbl}</span>
                                              </span>
                                            </div>
                                          </div>
                                        </div>

                                        {/* أزرار الإجراءات: صف مستقل متناسق على الجوال لمنع انضغاط العناصر */}
                                        <div className="flex items-center gap-2 w-full md:w-auto shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-border/25">
                                          <button
                                            onClick={() => {
                                              setSelectedStudent(student);
                                              window.scrollTo({ top: 0, behavior: 'smooth' });
                                            }}
                                            title="تحديد الطالب واستعراض بطاقة الترحيل الفردية"
                                            className="flex-1 md:flex-initial h-8 px-3 rounded-xl border border-border/70 text-muted-foreground hover:text-foreground text-[11px] font-bold hover:bg-muted transition-all flex items-center justify-center gap-1">
                                            بطاقة الترحيل
                                          </button>

                                          <button
                                            onClick={() => handleOpenPromoteModal(student)}
                                            disabled={promoting}
                                            className={`flex-1 md:flex-initial inline-flex items-center justify-center gap-1.5 h-8 px-4 rounded-xl text-[11px] font-bold transition-all disabled:opacity-50 shrink-0 ${
                                              isLast
                                                ? 'bg-amber-500/15 text-amber-700 border border-amber-400/40 hover:bg-amber-500 hover:text-white active:scale-95'
                                                : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-sm shadow-indigo-500/20 active:scale-95'
                                            }`}>
                                            {isLast ? (
                                              <>
                                                <Archive className="w-3.5 h-3.5 shrink-0" />
                                                <span>أرشفة كخريج</span>
                                              </>
                                            ) : (
                                              <>
                                                <ChevronUp className="w-3.5 h-3.5 shrink-0" />
                                                <span>ترحيل إلى {nextLbl}</span>
                                              </>
                                            )}
                                          </button>
                                        </div>
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>

                              {/* زر عرض المزيد إذا كان عدد طلاب المجموعة كبيراً */}
                              {remainingCount > 0 && (
                                <div className="p-3 bg-muted/20 border-t border-border/30 flex flex-col sm:flex-row items-center justify-between gap-3">
                                  <span className="text-xs text-muted-foreground font-semibold">
                                    يتم عرض أول {visibleStudents.length} من إجمالي {group.students.length} طالب في هذا الفصل
                                  </span>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => setGroupLimits(prev => ({ ...prev, [key]: (prev[key] ?? 30) + 40 }))}
                                    className="h-8 text-xs font-bold border-indigo-400/40 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/30">
                                    عرض المزيد (+40 طالب) — متبقي {remainingCount}
                                  </Button>
                                </div>
                              )}
                            </>
                          );
                        })()}
                      </div>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* ── نافذة نتائج الترحيل الجماعي ── */}
      <PromoteResultDialog
        open={showResults}
        onClose={() => setShowResults(false)}
        promoting={promoting}
        progressDone={progressDone}
        progressMax={progressMax}
        results={results}
      />

      {/* ── نافذة الترحيل الفردي التفاعلية المتطابقة تماماً مع صفحة مالية الطالب ── */}
      <AlertDialog open={promoteModalOpen} onOpenChange={o => {
        if (!o && !promoting) {
          setPromoteModalOpen(false);
          setPromoteStep('idle');
          setPromoteTargetStudent(null);
        }
      }}>
        <AlertDialogContent className="max-w-[calc(100%-1.5rem)] sm:max-w-md p-0 overflow-hidden rounded-2xl shadow-2xl border border-border/60" dir="rtl">
          {promoteTargetStudent && (() => {
            const st = promoteTargetStudent;
            const maxSem = MAX_SEMESTERS[st.diploma_type] ?? 6;
            const maxChargeSem = promoteCharges
              .filter(c => c.charge_type === 'فصلي')
              .reduce((max, c) => Math.max(max, c.semester_number), 0);
            const currentSemesterNum = Math.max(st.current_semester, maxChargeSem, 1);
            const nextSemesterNum = currentSemesterNum + 1;
            const isAtFinalSemester = currentSemesterNum >= maxSem;

            const unpaidCharges = promoteCharges.filter(c => {
              const effective = (c.charge_amount ?? 0) - (c.discount_amount ?? 0);
              return effective > (c.paid_amount ?? 0);
            });
            const totalRemaining = unpaidCharges.reduce((sum, c) => {
              const effective = (c.charge_amount ?? 0) - (c.discount_amount ?? 0);
              return sum + Math.max(0, effective - (c.paid_amount ?? 0));
            }, 0);

            const missingDocs: string[] = [];
            if ((st.photos_received ?? 0) < (st.photos_required ?? 0))
              missingDocs.push(`${(st.photos_required ?? 0) - (st.photos_received ?? 0)} صور شخصية`);
            if (!st.has_birth_certificate) missingDocs.push('شهادة ميلاد');
            if (!st.has_registration_certificate) missingDocs.push('شهادة التسجيل');
            if (!st.has_suspended_file) missingDocs.push('ملف معلق');

            const nextSemFee = st.diploma_type === 'عالي' ? 600 : 550;

            if (promoteStep === 'animating') {
              return (
                <div className="p-6 text-center space-y-6 bg-gradient-to-b from-blue-950/40 via-background to-background">
                  {/* أيقونة المسار المتحركة */}
                  <div className="relative py-4 flex items-center justify-center gap-4">
                    <motion.div
                      initial={{ scale: 0.9, opacity: 0.8 }}
                      animate={{ scale: [0.95, 1.05, 0.95], opacity: 1 }}
                      transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
                      className="px-3.5 py-2.5 rounded-xl bg-blue-500/10 border border-blue-500/30 text-blue-600 dark:text-blue-400 font-bold text-xs">
                      {SEMESTER_LABELS[currentSemesterNum] ?? `الفصل ${currentSemesterNum}`}
                    </motion.div>

                    {/* مؤشر النقل الموجه */}
                    <div className="relative flex items-center justify-center w-14">
                      <motion.div
                        animate={{ x: [-15, 15, -15], opacity: [0.3, 1, 0.3] }}
                        transition={{ repeat: Infinity, duration: 1.5, ease: "easeInOut" }}
                        className="flex items-center text-blue-500">
                        <ArrowLeft className="w-5 h-5 animate-pulse" />
                      </motion.div>
                      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                        <span className="w-2 h-2 rounded-full bg-blue-500 animate-ping" />
                      </div>
                    </div>

                    <motion.div
                      initial={{ scale: 0.9, opacity: 0.8 }}
                      animate={{ scale: [1, 1.08, 1], borderColor: ['rgba(59,130,246,0.3)', 'rgba(16,185,129,0.8)', 'rgba(59,130,246,0.3)'] }}
                      transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
                      className="px-3.5 py-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/40 text-emerald-600 dark:text-emerald-400 font-bold text-xs ring-2 ring-emerald-500/20">
                      {isAtFinalSemester ? 'الأرشيف (خريج)' : (SEMESTER_LABELS[nextSemesterNum] ?? `الفصل ${nextSemesterNum}`)}
                    </motion.div>
                  </div>

                  {/* دائرة التحميل المتقدمة */}
                  <div className="flex flex-col items-center gap-3">
                    <div className="relative w-16 h-16 rounded-full bg-blue-500/10 flex items-center justify-center border border-blue-500/20">
                      <RefreshCw className="w-8 h-8 text-blue-500 animate-spin" />
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ repeat: Infinity, duration: 4, ease: "linear" }}
                        className="absolute inset-[-4px] rounded-full border-2 border-dashed border-blue-400/40 pointer-events-none"
                      />
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-sm font-bold text-foreground">
                        {isAtFinalSemester ? 'جاري اعتماد التخرج والأرشفة...' : 'جاري ترحيل الطالب إلى الفصل الجديد...'}
                      </h4>
                      <p className="text-xs text-blue-500 dark:text-blue-400 font-medium h-5">
                        {promoteStatusText || 'التحقق من البيانات والمطابقة...'}
                      </p>
                    </div>
                  </div>

                  {/* شريط التقدم التفاعلي */}
                  <div className="space-y-1.5 px-2">
                    <div className="flex justify-between text-[11px] text-muted-foreground font-semibold">
                      <span>التقدم</span>
                      <span>{promoteProgress}%</span>
                    </div>
                    <div className="w-full h-2.5 bg-muted rounded-full overflow-hidden p-0.5 border border-border/50">
                      <motion.div
                        className="h-full bg-gradient-to-r from-blue-600 via-indigo-600 to-emerald-500 rounded-full"
                        initial={{ width: '5%' }}
                        animate={{ width: `${promoteProgress}%` }}
                        transition={{ duration: 0.3 }}
                      />
                    </div>
                  </div>
                </div>
              );
            }

            if (promoteStep === 'success') {
              return (
                <div className="p-6 text-center space-y-5 bg-gradient-to-b from-emerald-950/30 via-background to-background">
                  {/* أيقونة النجاح والشرارات */}
                  <div className="relative mx-auto w-16 h-16 rounded-full bg-emerald-500/15 border-2 border-emerald-500/40 flex items-center justify-center">
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: [0, 1.25, 1] }}
                      transition={{ type: "spring", stiffness: 300, damping: 15 }}>
                      <CheckCircle2 className="w-9 h-9 text-emerald-500" />
                    </motion.div>
                    <motion.div
                      initial={{ opacity: 0, scale: 0.5 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="absolute -top-1 -right-1 text-amber-400">
                      <Sparkles className="w-5 h-5 animate-pulse" />
                    </motion.div>
                  </div>

                  <div className="space-y-1">
                    <h3 className="text-base font-black text-foreground">
                      {isAtFinalSemester ? '🎓 تهانينا! تمت الأرشفة بنجاح' : '🎉 تم ترحيل الطالب بنجاح!'}
                    </h3>
                    <p className="text-xs text-muted-foreground">
                      {isAtFinalSemester
                        ? `أصبح الطالب ${st.full_name} مسجلاً كخريج معتمد في الأرشيف`
                        : `أصبح الطالب ${st.full_name} مقيداً رسمياً في ${SEMESTER_LABELS[nextSemesterNum] ?? `الفصل ${nextSemesterNum}`}`}
                    </p>
                  </div>

                  {/* ملخص الإنجاز */}
                  <div className="rounded-xl p-3.5 bg-emerald-50/60 dark:bg-emerald-950/20 border border-emerald-200/60 dark:border-emerald-500/20 text-right space-y-2 text-xs">
                    <div className="flex items-center justify-between py-0.5 border-b border-emerald-200/40 dark:border-emerald-500/10">
                      <span className="text-muted-foreground">اسم الطالب:</span>
                      <span className="font-bold text-foreground">{st.full_name}</span>
                    </div>
                    <div className="flex items-center justify-between py-0.5 border-b border-emerald-200/40 dark:border-emerald-500/10">
                      <span className="text-muted-foreground">رقم القيد:</span>
                      <span className="font-mono font-bold text-foreground">{st.registration_number || 'غير محدد'}</span>
                    </div>
                    <div className="flex items-center justify-between py-0.5 border-b border-emerald-200/40 dark:border-emerald-500/10">
                      <span className="text-muted-foreground">الفصل السابق:</span>
                      <span className="font-bold text-foreground">{SEMESTER_LABELS[currentSemesterNum] ?? `الفصل ${currentSemesterNum}`}</span>
                    </div>
                    <div className="flex items-center justify-between py-0.5">
                      <span className="text-muted-foreground">الفصل الحالي المعتمد:</span>
                      <span className="font-black text-emerald-600 dark:text-emerald-400">
                        {isAtFinalSemester ? 'خريج (أرشيف)' : (SEMESTER_LABELS[nextSemesterNum] ?? `الفصل ${nextSemesterNum}`)}
                      </span>
                    </div>
                  </div>

                  <Button
                    onClick={() => {
                      setPromoteModalOpen(false);
                      setPromoteStep('idle');
                      setPromoteTargetStudent(null);
                      fetchData();
                    }}
                    className="w-full h-11 rounded-xl text-sm font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg shadow-emerald-600/20 transition-all active:scale-95">
                    <Check className="w-4 h-4 ml-2" />
                    تم ومتابعة
                  </Button>
                </div>
              );
            }

            // الحالة الافتراضية 'idle': شاشة المعاينة والتأكيد
            return (
              <>
                {/* رأس النافذة التفاعلية */}
                <div className={`p-4 text-white relative ${
                  isAtFinalSemester
                    ? 'bg-gradient-to-l from-amber-600 via-amber-700 to-amber-800'
                    : 'bg-gradient-to-l from-blue-700 via-indigo-700 to-blue-800'
                }`}>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-white/15 backdrop-blur-sm flex items-center justify-center border border-white/20 shrink-0">
                      {isAtFinalSemester ? (
                        <Archive className="w-5 h-5 text-white" />
                      ) : (
                        <GraduationCap className="w-5 h-5 text-white" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-sm font-bold truncate">
                        {isAtFinalSemester ? 'أرشفة الطالب (تخرج نهائي)' : 'ترحيل الطالب للفصل التالي'}
                      </h3>
                      <p className="text-xs text-white/80 truncate">
                        {st.full_name} ({st.specialization})
                      </p>
                    </div>
                    <button
                      onClick={() => {
                        setPromoteModalOpen(false);
                        setPromoteTargetStudent(null);
                      }}
                      className="w-7 h-7 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center text-white/80 hover:text-white transition-colors">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* محتوى المعاينة والتأكيد المتجاوب مع الهواتف */}
                <div className="p-4 space-y-3.5 max-h-[70vh] overflow-y-auto">
                  {/* بطاقة الانتقال التفاعلية بين الفصول */}
                  <div className="flex items-center justify-between p-3 rounded-xl bg-muted/40 border border-border/60">
                    <div className="text-center flex-1">
                      <p className="text-[10px] text-muted-foreground font-semibold">الفصل الدراسي الحالي</p>
                      <p className="text-xs font-bold text-foreground mt-0.5">
                        {SEMESTER_LABELS[currentSemesterNum] ?? `الفصل ${currentSemesterNum}`}
                      </p>
                    </div>

                    <div className="flex items-center justify-center px-3">
                      <div className="w-7 h-7 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-600 dark:text-blue-400">
                        <ArrowLeft className="w-4 h-4" />
                      </div>
                    </div>

                    <div className="text-center flex-1">
                      <p className="text-[10px] text-muted-foreground font-semibold">
                        {isAtFinalSemester ? 'المسار القادم' : 'الفصل المستهدف'}
                      </p>
                      <p className={`text-xs font-bold mt-0.5 ${isAtFinalSemester ? 'text-amber-600 dark:text-amber-400' : 'text-emerald-600 dark:text-emerald-400'}`}>
                        {isAtFinalSemester ? 'الأرشيف (خريج)' : (SEMESTER_LABELS[nextSemesterNum] ?? `الفصل ${nextSemesterNum}`)}
                      </p>
                    </div>
                  </div>

                  {/* تنبيه إذا كانت هناك فصول سابقة مسددة */}
                  {maxChargeSem > st.current_semester && (
                    <div className="p-2.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/30 border border-indigo-200 dark:border-indigo-800/40 text-xs text-indigo-700 dark:text-indigo-300 flex items-start gap-2">
                      <Info className="w-4 h-4 shrink-0 mt-0.5 text-indigo-500" />
                      <p className="leading-relaxed">
                        الطالب مسدد أو مسجل لرسوم حتى <span className="font-bold">{SEMESTER_LABELS[maxChargeSem] ?? `الفصل ${maxChargeSem}`}</span>، لذلك سيتم ترحيل القيد للفصل التالي له مباشرة دون ازدواجية في الرسوم.
                      </p>
                    </div>
                  )}

                  {/* فحص المديونية الحالية */}
                  {loadingPromoteCharges ? (
                    <div className="p-3 text-center text-xs text-muted-foreground flex items-center justify-center gap-2">
                      <Loader2 className="w-4 h-4 animate-spin text-blue-500" />
                      جاري تدقيق الموقف المالي للطالب...
                    </div>
                  ) : totalRemaining > 0 ? (
                    <div className="p-3 rounded-xl bg-amber-50/80 dark:bg-amber-950/30 border border-amber-200/80 dark:border-amber-800/40 space-y-2">
                      <div className="flex items-center gap-2 text-amber-800 dark:text-amber-300 font-bold text-xs">
                        <AlertTriangle className="w-4 h-4 shrink-0 text-amber-600 dark:text-amber-400" />
                        <span>تنبيه مالي: توجد مديونية سابقة ({totalRemaining.toFixed(0)} د.ل)</span>
                      </div>
                      <div className="space-y-1 text-[11px] text-amber-700/90 dark:text-amber-400/90 pr-6">
                        {unpaidCharges.map(c => {
                          const eff = (c.charge_amount ?? 0) - (c.discount_amount ?? 0);
                          const rem = Math.max(0, eff - (c.paid_amount ?? 0));
                          return (
                            <div key={c.id} className="flex justify-between items-center py-0.5 border-b border-amber-200/40 last:border-0">
                              <span>قسط {SEMESTER_LABELS[c.semester_number] ?? `الفصل ${c.semester_number}`}:</span>
                              <span className="font-mono font-bold">{rem.toFixed(0)} د.ل متبقي</span>
                            </div>
                          );
                        })}
                      </div>
                      {isAtFinalSemester ? (
                        <p className="text-[11px] text-destructive font-bold pt-1">
                          ⛔ لا يمكن أرشفة الطالب كخريج نهائي حتى يتم سداد كامل الأقساط.
                        </p>
                      ) : (
                        <p className="text-[10px] text-amber-600 dark:text-amber-400">
                          * يمكن الترحيل للفصل التالي مع بقاء الديون في ذمة الطالب المالية.
                        </p>
                      )}
                    </div>
                  ) : (
                    <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/40 flex items-center gap-2 text-xs text-emerald-700 dark:text-emerald-300 font-bold">
                      <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
                      <span>الموقف المالي سليم ومسدد بالكامل</span>
                    </div>
                  )}

                  {/* رسوم الفصل الجديد المراد إضافتها */}
                  {!isAtFinalSemester && (
                    <div className="p-3 rounded-xl bg-blue-50/60 dark:bg-blue-950/20 border border-blue-200/60 dark:border-blue-800/30 flex items-center justify-between text-xs">
                      <span className="text-muted-foreground flex items-center gap-1.5 font-medium">
                        <BookOpen className="w-3.5 h-3.5 text-blue-500" />
                        رسوم قيد {SEMESTER_LABELS[nextSemesterNum] ?? `الفصل ${nextSemesterNum}`}:
                      </span>
                      <span className="font-bold text-blue-600 dark:text-blue-400">
                        {nextSemFee} د.ل ({st.diploma_type})
                      </span>
                    </div>
                  )}

                  {/* تنبيه النواقص في المستندات */}
                  {missingDocs.length > 0 && (
                    <div className="p-2.5 rounded-xl bg-muted/60 border border-border/60 text-xs text-muted-foreground space-y-1">
                      <div className="flex items-center gap-1.5 font-semibold text-foreground/80">
                        <FileText className="w-3.5 h-3.5 text-muted-foreground" />
                        <span>نواقص الملف:</span>
                      </div>
                      <p className="text-[11px] text-amber-600 dark:text-amber-400 pr-5">
                        {missingDocs.join(' • ')}
                      </p>
                    </div>
                  )}
                </div>

                {/* أزرار الإجراءات في أسفل النافذة */}
                <div className="p-3.5 bg-muted/20 border-t border-border/50 flex items-center gap-2">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setPromoteModalOpen(false);
                      setPromoteTargetStudent(null);
                    }}
                    disabled={promoting}
                    className="flex-1 h-10 rounded-xl text-xs font-semibold">
                    إلغاء
                  </Button>

                  <Button
                    onClick={handleExecutePromote}
                    disabled={promoting || (isAtFinalSemester && totalRemaining > 0)}
                    className={`flex-1 h-10 rounded-xl text-xs font-bold text-white shadow-sm transition-all active:scale-95 ${
                      isAtFinalSemester
                        ? 'bg-amber-600 hover:bg-amber-700 shadow-amber-600/20'
                        : 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-600/20'
                    }`}>
                    {promoting ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin ml-1.5" />
                        جاري التنفيذ...
                      </>
                    ) : isAtFinalSemester ? (
                      <>
                        <Archive className="w-3.5 h-3.5 ml-1.5" />
                        تأكيد الأرشفة كخريج
                      </>
                    ) : (
                      <>
                        <PlayCircle className="w-3.5 h-3.5 ml-1.5" />
                        تأكيد الترحيل إلى {SEMESTER_LABELS[nextSemesterNum] ?? `الفصل ${nextSemesterNum}`}
                      </>
                    )}
                  </Button>
                </div>
              </>
            );
          })()}
        </AlertDialogContent>
      </AlertDialog>
    </MainLayout>
  );
}
