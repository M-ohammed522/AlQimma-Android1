// صفحة الواتساب — إرسال رسائل فردية وجماعية مع قوالب جاهزة
import { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Search, Send, Users, User, Filter,
  Plus, Edit2, Trash2, CheckCircle2, XCircle, RefreshCw,
  ChevronDown, BookOpen, Phone, History, X, Save,
  CheckCheck, AlertCircle, Sparkles, GraduationCap,
  Zap, Clock, Shield, MessageCircle,
} from 'lucide-react';

// ─── شعار واتساب SVG رسمي ────────────────────────────────────────────────────
function WhatsAppIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
      <circle cx="24" cy="24" r="24" fill="#25D366"/>
      <path
        d="M24.0049 8C15.1697 8 8 15.1623 8 23.9902C8 26.8965 8.77539 29.7217 10.2422 32.2012L8.08594 39.9199L16.0029 37.7988C18.3945 39.1289 21.168 39.9805 24.0049 39.9805C32.8301 39.9805 40 32.8184 40 23.9902C40 15.1719 32.8301 8 24.0049 8ZM24.0049 37.0449C21.4219 37.0449 18.9072 36.2832 16.7666 34.8633L16.2607 34.5547L11.5547 35.7949L12.8105 31.2129L12.4707 30.6758C10.9238 28.457 10.0977 25.7627 10.0977 23.9902C10.0977 16.3232 16.3281 10.0977 24.0049 10.0977C31.6719 10.0977 37.9023 16.3232 37.9023 23.9902C37.9023 31.6572 31.6719 37.0449 24.0049 37.0449Z"
        fill="white" fillOpacity="0.2"
      />
      <path
        d="M33.4893 28.5273C33.0996 28.3301 31.1514 27.3711 30.7959 27.2422C30.4404 27.1035 30.1826 27.0488 29.9199 27.4434C29.6572 27.8379 28.9004 28.7285 28.6719 28.9912C28.4531 29.2539 28.2246 29.2832 27.835 29.0859C25.1553 27.7461 23.3926 26.6992 21.6201 23.6719C21.1426 22.8555 21.9688 22.9004 22.7295 21.3828C22.8584 21.1201 22.7979 20.8965 22.6992 20.6992C22.6006 20.502 21.7598 18.5537 21.4336 17.7129C21.1172 16.8916 20.791 17.0107 20.5479 16.9951C20.3291 16.9805 20.0664 16.9805 19.8037 16.9805C19.541 16.9805 19.1123 17.0791 18.7568 17.4736C18.4014 17.8682 17.3311 18.877 17.3311 20.8252C17.3311 22.7734 18.7959 24.6533 18.9932 24.916C19.1904 25.1787 21.7305 29.0957 25.6475 30.8193C28.0439 31.8564 29.0127 31.9355 30.2529 31.748C31.0186 31.6396 32.6006 30.7393 32.9219 29.7559C33.2432 28.7715 33.2432 27.9307 33.1445 27.7529C33.0557 27.5557 32.793 27.457 32.4033 27.2598L33.4893 28.5273Z"
        fill="white"
      />
    </svg>
  );
}
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
  AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { MainLayout } from '@/components/layouts/MainLayout';
import {
  getStudentsForWhatsapp, getWhatsappTemplates, getWhatsappLog,
  createWhatsappTemplate, updateWhatsappTemplate, deleteWhatsappTemplate,
  logWhatsappMessage,
  type WhatsappTemplate, type WhatsappLog, type DebtFilter,
} from '@/lib/api';
import type { Student } from '@/types';
import { getSpecializations } from '@/lib/api';

// ─── أنواع المديونية ─────────────────────────────────────────────────────────
const DEBT_LABELS: Record<DebtFilter, string> = {
  'الكل':          'الكل',
  'مدين':          'لم يدفع شيئاً',
  'مسدد_جزئي':    'مسدد جزئياً',
  'مسدد_كامل':    'مسدد بالكامل',
};

const DEBT_BADGE: Record<DebtFilter, string> = {
  'الكل':       'bg-muted/80 text-muted-foreground border border-border',
  'مدين':       'bg-red-50 text-red-700 border border-red-200 dark:bg-red-950/40 dark:text-red-400 dark:border-red-800/50',
  'مسدد_جزئي': 'bg-amber-50 text-amber-700 border border-amber-200 dark:bg-amber-950/40 dark:text-amber-400 dark:border-amber-800/50',
  'مسدد_كامل': 'bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-800/50',
};

const DEBT_DOT: Record<DebtFilter, string> = {
  'الكل':       'bg-muted-foreground',
  'مدين':       'bg-red-500',
  'مسدد_جزئي': 'bg-amber-500',
  'مسدد_كامل': 'bg-emerald-500',
};

const DEBT_FILTER_STYLE: Record<DebtFilter, string> = {
  'الكل':       'border-border bg-card text-muted-foreground hover:border-primary/40 hover:bg-primary/5 hover:text-primary',
  'مدين':       'border-border bg-card text-muted-foreground hover:border-red-300 hover:bg-red-50 hover:text-red-700',
  'مسدد_جزئي': 'border-border bg-card text-muted-foreground hover:border-amber-300 hover:bg-amber-50 hover:text-amber-700',
  'مسدد_كامل': 'border-border bg-card text-muted-foreground hover:border-emerald-300 hover:bg-emerald-50 hover:text-emerald-700',
};

const DEBT_FILTER_ACTIVE: Record<DebtFilter, string> = {
  'الكل':       'border-primary bg-primary/10 text-primary shadow-sm',
  'مدين':       'border-red-400 bg-red-50 text-red-700 shadow-sm dark:bg-red-950/40 dark:text-red-400',
  'مسدد_جزئي': 'border-amber-400 bg-amber-50 text-amber-700 shadow-sm dark:bg-amber-950/40 dark:text-amber-400',
  'مسدد_كامل': 'border-emerald-400 bg-emerald-50 text-emerald-700 shadow-sm dark:bg-emerald-950/40 dark:text-emerald-400',
};

function getDebtStatus(s: Student): DebtFilter {
  const debt = (s.total_charged ?? 0) - (s.total_paid ?? 0);
  if (debt <= 0) return 'مسدد_كامل';
  if (s.total_paid > 0) return 'مسدد_جزئي';
  return 'مدين';
}

// ─── استبدال المتغيرات في القالب ─────────────────────────────────────────────
function applyTemplate(body: string, student: Student): string {
  const debt = Math.max(0, (student.total_charged ?? 0) - (student.total_paid ?? 0));
  return body
    .replace(/{{الاسم}}/g, student.full_name)
    .replace(/{{المبلغ_المتبقي}}/g, `${debt.toFixed(2)}`)
    .replace(/{{المبلغ_المدفوع}}/g, `${(student.total_paid ?? 0).toFixed(2)}`)
    .replace(/{{التخصص}}/g, student.specialization ?? '')
    .replace(/{{الدبلوم}}/g, student.diploma_type ?? '')
    .replace(/{{الفصل}}/g, `${student.current_semester ?? 1}`)
    .replace(/{{الرسالة}}/g, '...');
}

// ─── الأحرف الأولى للاسم (Avatar) ────────────────────────────────────────────
const AVATAR_COLORS = [
  { bg: 'rgba(37,211,102,0.15)', color: '#075E54' },
  { bg: 'rgba(59,130,246,0.15)', color: '#1D4ED8' },
  { bg: 'rgba(139,92,246,0.15)', color: '#6D28D9' },
  { bg: 'rgba(245,158,11,0.15)', color: '#B45309' },
  { bg: 'rgba(239,68,68,0.15)',  color: '#B91C1C' },
];
function Initials({ name }: { name: string }) {
  const parts   = name.trim().split(' ');
  const letters = parts.length >= 2 ? parts[0][0] + parts[1][0] : name.slice(0, 2);
  const palette = AVATAR_COLORS[name.charCodeAt(0) % AVATAR_COLORS.length];
  return (
    <div className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0 font-bold text-[12px] select-none"
      style={{ background: palette.bg, color: palette.color, border: `1.5px solid ${palette.color}22` }}>
      {letters}
    </div>
  );
}

// ─── بطاقة طالب محسّنة ───────────────────────────────────────────────────────
function StudentCard({
  student, selected, onToggle,
}: { student: Student; selected: boolean; onToggle: () => void }) {
  const status = getDebtStatus(student);
  const debt   = Math.max(0, (student.total_charged ?? 0) - (student.total_paid ?? 0));

  return (
    <div
      onClick={onToggle}
      className={cn(
        'flex items-center gap-2.5 px-3 py-2.5 rounded-xl border cursor-pointer transition-all duration-200',
        selected
          ? 'shadow-sm'
          : 'border-border/60 bg-card hover:shadow-sm',
      )}
      style={selected ? { borderColor: 'rgba(37,211,102,0.45)', background: 'rgba(37,211,102,0.06)' } : {}}
    >
      {/* checkbox */}
      <Checkbox
        checked={selected}
        onCheckedChange={onToggle}
        onClick={(e) => e.stopPropagation()}
        className="shrink-0"
      />

      {/* avatar */}
      <Initials name={student.full_name} />

      {/* اسم + تخصص — يأخذ كل المساحة */}
      <div className="flex-1 min-w-0">
        <p className="text-[13px] font-semibold text-foreground truncate leading-tight">
          {student.full_name}
        </p>
        <p className="text-[11px] text-muted-foreground truncate mt-0.5">
          {student.diploma_type} · {student.specialization}
        </p>
      </div>

      {/* badge حالة الدفع فقط */}
      <span className={cn(
        'inline-flex items-center gap-1 text-[10px] font-semibold px-1.5 py-0.5 rounded-full shrink-0',
        DEBT_BADGE[status],
      )}>
        <span className={cn('w-1.5 h-1.5 rounded-full', DEBT_DOT[status])} />
        {status === 'مسدد_كامل' ? '✓' : debt > 0 ? `${debt.toFixed(0)}` : '–'}
      </span>

      {/* أيقونة الهاتف */}
      <Phone className={cn('w-3.5 h-3.5 shrink-0', student.phone ? 'text-emerald-500' : 'text-muted-foreground/25')} />
    </div>
  );
}

// ─── الصفحة الرئيسية ─────────────────────────────────────────────────────────
export default function WhatsAppPage() {
  // ── حالة الطلاب
  const [students, setStudents]         = useState<Student[]>([]);
  const [loadingStudents, setLoadingStudents] = useState(false);
  const [selected, setSelected]         = useState<Set<string>>(new Set());

  // ── فلاتر
  const [search, setSearch]             = useState('');
  const [diplomaFilter, setDiplomaFilter] = useState('الكل');
  const [specFilter, setSpecFilter]     = useState('الكل');
  const [debtFilter, setDebtFilter]     = useState<DebtFilter>('الكل');
  const [specializations, setSpecializations] = useState<string[]>([]);

  // ── الرسالة
  const [message, setMessage]           = useState('');
  const [sending, setSending]           = useState(false);

  // ── القوالب
  const [templates, setTemplates]       = useState<WhatsappTemplate[]>([]);
  const [loadingTemplates, setLoadingTemplates] = useState(false);
  const [templateDialog, setTemplateDialog] = useState(false);
  const [editTemplate, setEditTemplate] = useState<WhatsappTemplate | null>(null);
  const [tplName, setTplName]           = useState('');
  const [tplBody, setTplBody]           = useState('');
  const [tplCategory, setTplCategory]   = useState('عام');
  const [savingTemplate, setSavingTemplate] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<WhatsappTemplate | null>(null);
  const [showTemplates, setShowTemplates] = useState(false);

  // ── السجل
  const [log, setLog]                   = useState<WhatsappLog[]>([]);
  const [loadingLog, setLoadingLog]     = useState(false);

  // ── فلترة فورية وتقطيع عرض DOM لتسريع الصفحة القصوى
  const [visibleCount, setVisibleCount] = useState(50);

  // ── تحميل البيانات (خفيف جداً وسريع عبر الحقول المنتقاة)
  const loadStudents = useCallback(async () => {
    setLoadingStudents(true);
    try {
      const data = await getStudentsForWhatsapp({
        diplomaType: diplomaFilter,
        specialization: specFilter,
        debtFilter,
      });
      setStudents(data);
    } catch {
      toast.error('فشل تحميل الطلاب');
    } finally {
      setLoadingStudents(false);
    }
  }, [diplomaFilter, specFilter, debtFilter]);

  const loadTemplates = useCallback(async () => {
    setLoadingTemplates(true);
    try { setTemplates(await getWhatsappTemplates()); }
    catch { toast.error('فشل تحميل القوالب'); }
    finally { setLoadingTemplates(false); }
  }, []);

  const loadLog = useCallback(async () => {
    setLoadingLog(true);
    try { setLog(await getWhatsappLog()); }
    catch { toast.error('فشل تحميل السجل'); }
    finally { setLoadingLog(false); }
  }, []);

  useEffect(() => {
    loadStudents();
  }, [loadStudents]);

  useEffect(() => {
    loadTemplates();
    loadLog();
    (async () => {
      try {
        const specs = await getSpecializations();
        setSpecializations([...new Set(specs.map((s: { name: string }) => s.name))]);
      } catch { /* تجاهل */ }
    })();
  }, [loadTemplates, loadLog]);

  // ── بحث فوري فائق السرعة في الذاكرة (0ms) بدون إرهاق الشبكة
  const filteredStudents = useMemo(() => {
    if (!search.trim()) return students;
    const q = search.trim().toLowerCase();
    return students.filter(s =>
      s.full_name?.toLowerCase().includes(q) ||
      s.phone?.includes(q) ||
      s.national_id?.includes(q) ||
      s.registration_number?.toLowerCase().includes(q)
    );
  }, [students, search]);

  // إعادة ضبط التقطيع عند تغيير البحث أو الفلاتر
  useEffect(() => {
    setVisibleCount(50);
  }, [search, diplomaFilter, specFilter, debtFilter]);

  // نافذة العرض في DOM لتفادي تجميد المتصفح
  const displayedStudents = useMemo(() => {
    return filteredStudents.slice(0, visibleCount);
  }, [filteredStudents, visibleCount]);

  // ── تحديد / إلغاء الكل (يعمل على كامل قائمة الطلاب المفلترة)
  const toggleAll = () => {
    if (selected.size === filteredStudents.length && filteredStudents.length > 0) {
      setSelected(new Set());
    } else {
      setSelected(new Set(filteredStudents.map((s: Student) => s.id)));
    }
  };

  const toggleStudent = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  // ── تطبيق قالب
  const applyTemplateToMessage = (tpl: WhatsappTemplate) => {
    if (selected.size === 1) {
      const s = students.find((st) => st.id === [...selected][0]);
      setMessage(s ? applyTemplate(tpl.body, s) : tpl.body);
    } else {
      setMessage(tpl.body);
    }
    setShowTemplates(false);
    toast.success(`تم تطبيق القالب: ${tpl.name}`);
  };

  // ── إرسال الرسائل
  const handleSend = async () => {
    if (!message.trim()) { toast.error('الرسالة فارغة'); return; }
    const targets = students.filter((s) => selected.has(s.id));
    const withPhone = targets.filter((s) => s.phone);
    if (withPhone.length === 0) {
      toast.error('لا يوجد طلاب محددون أو لديهم أرقام هواتف');
      return;
    }
    setSending(true);
    let ok = 0;
    for (const s of withPhone) {
      try {
        const phone = s.phone!.replace(/\D/g, '');
        const body  = selected.size === 1 ? message : applyTemplate(message, s);
        const encoded = encodeURIComponent(body);
        const url = `https://wa.me/${phone}?text=${encoded}`;
        window.open(url, '_blank', 'noopener,noreferrer');
        await logWhatsappMessage({
          student_id: s.id,
          student_name: s.full_name,
          phone: s.phone!,
          message: body,
          status: 'مُرسَل',
        });
        ok++;
        await new Promise((r) => setTimeout(r, 600));
      } catch {
        toast.error(`فشل إرسال رسالة لـ ${s.full_name}`);
      }
    }
    setSending(false);
    if (ok > 0) {
      toast.success(`تم فتح واتساب لـ ${ok} طالب`);
      loadLog();
    }
  };

  // ── حفظ قالب
  const handleSaveTemplate = async () => {
    if (!tplName.trim() || !tplBody.trim()) {
      toast.error('الاسم والنص مطلوبان');
      return;
    }
    setSavingTemplate(true);
    try {
      if (editTemplate) {
        await updateWhatsappTemplate(editTemplate.id, {
          name: tplName, body: tplBody, category: tplCategory,
        });
        toast.success('تم تحديث القالب');
      } else {
        await createWhatsappTemplate({ name: tplName, body: tplBody, category: tplCategory });
        toast.success('تم إضافة القالب');
      }
      setTemplateDialog(false);
      loadTemplates();
    } catch {
      toast.error('فشل حفظ القالب');
    } finally {
      setSavingTemplate(false);
    }
  };

  const openNewTemplate = () => {
    setEditTemplate(null);
    setTplName(''); setTplBody(''); setTplCategory('عام');
    setTemplateDialog(true);
  };

  const openEditTemplate = (t: WhatsappTemplate) => {
    setEditTemplate(t);
    setTplName(t.name); setTplBody(t.body); setTplCategory(t.category);
    setTemplateDialog(true);
  };

  const handleDeleteTemplate = async () => {
    if (!deleteConfirm) return;
    try {
      await deleteWhatsappTemplate(deleteConfirm.id);
      toast.success('تم حذف القالب');
      setDeleteConfirm(null);
      loadTemplates();
    } catch {
      toast.error('فشل الحذف');
    }
  };

  // ── تجميع القوالب حسب الفئة
  const templatesByCategory = templates.reduce<Record<string, WhatsappTemplate[]>>((acc, t) => {
    (acc[t.category] ??= []).push(t);
    return acc;
  }, {});

  const selectedStudents = students.filter((s) => selected.has(s.id));
  const withPhoneCount   = selectedStudents.filter((s) => s.phone).length;

  // ─────────────────────────────────────────────────────────────────────────────
  // ─────────────────────────────────────────────────────────────────────────────
  return (
    <MainLayout>
      <div className="flex flex-col gap-5 p-4 md:p-6 max-w-7xl mx-auto">

        {/* ══ Hero Header ═══════════════════════════════════════════════════════ */}
        <div className="relative overflow-hidden rounded-2xl shadow-[var(--shadow-lg)]"
          style={{ background: 'linear-gradient(135deg, #075E54 0%, #128C7E 50%, #25D366 100%)' }}>
          {/* نقاط ديكورية */}
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            <div className="absolute -top-20 -left-20 w-72 h-72 rounded-full bg-white/5 blur-3xl" />
            <div className="absolute -bottom-16 -right-16 w-64 h-64 rounded-full bg-white/5 blur-2xl" />
            <div className="absolute top-6 right-1/4 w-40 h-40 rounded-full bg-white/4 blur-2xl" />
            {/* شبكة نقاط خلفية */}
            <svg className="absolute inset-0 w-full h-full opacity-10" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="dots" x="0" y="0" width="24" height="24" patternUnits="userSpaceOnUse">
                  <circle cx="2" cy="2" r="1.5" fill="white"/>
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#dots)"/>
            </svg>
          </div>

          <div className="relative px-5 py-6 md:px-8 md:py-7">
            <div className="flex flex-col md:flex-row md:items-center gap-5">
              {/* الشعار والعنوان */}
              <div className="flex items-center gap-4">
                {/* شعار واتساب */}
                <div className="relative shrink-0">
                  <div className="w-16 h-16 rounded-2xl bg-white/15 border-2 border-white/30 flex items-center justify-center shadow-xl backdrop-blur-sm">
                    <WhatsAppIcon className="w-10 h-10" />
                  </div>
                  {/* نقطة اتصال خضراء */}
                  <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-[#25D366] border-2 border-white flex items-center justify-center">
                    <div className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                  </div>
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-0.5">
                    <h1 className="text-2xl md:text-3xl font-black text-white tracking-tight">
                      رسائل واتساب
                    </h1>
                    <span className="text-[10px] font-bold bg-white/20 text-white border border-white/30 px-2 py-0.5 rounded-full backdrop-blur-sm">
                      WhatsApp
                    </span>
                  </div>
                  <p className="text-sm text-white/70 font-medium">
                    معهد القمة للعلوم الطبية والإدارية · تواصل فوري مع الطلاب فردياً أو جماعياً
                  </p>
                </div>
              </div>

              {/* إحصاءات */}
              <div className="flex gap-3 md:mr-auto flex-wrap">
                {[
                  { icon: Users,      label: 'الطلاب', val: students.length, color: 'from-white/20 to-white/10' },
                  { icon: CheckCheck, label: 'محددون', val: selected.size,   color: 'from-[#25D366]/40 to-[#25D366]/20' },
                  { icon: History,    label: 'مُرسَلة',  val: log.length,     color: 'from-white/20 to-white/10' },
                ].map(({ icon: Icon, label, val, color }) => (
                  <div key={label} className={cn(
                    'flex items-center gap-2.5 rounded-xl px-4 py-3 border border-white/20 backdrop-blur-sm',
                    `bg-gradient-to-br ${color}`,
                  )}>
                    <Icon className="w-4 h-4 text-white/80 shrink-0" />
                    <div>
                      <p className="text-xl font-black text-white tabular-nums leading-none">{val}</p>
                      <p className="text-[10px] text-white/60 leading-none mt-0.5 font-medium">{label}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* أزرار */}
              <div className="flex gap-2 shrink-0">
                <Button variant="ghost" size="sm" onClick={loadStudents} disabled={loadingStudents}
                  className="border border-white/30 text-white hover:bg-white/20 h-9 px-3 backdrop-blur-sm font-semibold">
                  <RefreshCw className={cn('w-3.5 h-3.5 ml-1.5', loadingStudents && 'animate-spin')} />
                  تحديث
                </Button>
                <Button size="sm" onClick={openNewTemplate}
                  className="bg-white text-[#075E54] hover:bg-white/90 h-9 px-4 font-bold shadow-lg">
                  <Plus className="w-3.5 h-3.5 ml-1.5" />
                  قالب جديد
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* ══ شريط الميزات ══════════════════════════════════════════════════════ */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {([
            {
              icon: Zap,
              title: 'إرسال فوري',
              desc: 'يفتح واتساب مباشرة',
              accent: '#F59E0B',
              accentLight: 'rgba(245,158,11,0.10)',
              accentBorder: 'rgba(245,158,11,0.22)',
              iconGrad: 'linear-gradient(135deg,#FEF3C7 0%,#FDE68A 100%)',
            },
            {
              icon: Users,
              title: 'إرسال جماعي',
              desc: 'لمجموعات من الطلاب',
              accent: '#3B82F6',
              accentLight: 'rgba(59,130,246,0.10)',
              accentBorder: 'rgba(59,130,246,0.22)',
              iconGrad: 'linear-gradient(135deg,#DBEAFE 0%,#BFDBFE 100%)',
            },
            {
              icon: Sparkles,
              title: 'قوالب ذكية',
              desc: 'متغيرات تلقائية',
              accent: '#8B5CF6',
              accentLight: 'rgba(139,92,246,0.10)',
              accentBorder: 'rgba(139,92,246,0.22)',
              iconGrad: 'linear-gradient(135deg,#EDE9FE 0%,#DDD6FE 100%)',
            },
            {
              icon: History,
              title: 'سجل كامل',
              desc: 'تتبع كل الرسائل',
              accent: '#10B981',
              accentLight: 'rgba(16,185,129,0.10)',
              accentBorder: 'rgba(16,185,129,0.22)',
              iconGrad: 'linear-gradient(135deg,#D1FAE5 0%,#A7F3D0 100%)',
            },
          ] as const).map(({ icon: Icon, title, desc, accent, accentLight, accentBorder, iconGrad }) => (
            <div
              key={title}
              className="group relative flex flex-col gap-3 rounded-2xl border p-4 bg-card transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md overflow-hidden"
              style={{ borderColor: accentBorder }}
            >
              {/* شريط لوني علوي */}
              <div
                className="absolute top-0 left-0 right-0 h-0.5 rounded-t-2xl"
                style={{ background: `linear-gradient(90deg, ${accent} 0%, transparent 100%)` }}
              />
              {/* أيقونة */}
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 shadow-sm"
                style={{ background: iconGrad }}
              >
                <Icon className="w-5 h-5" style={{ color: accent }} />
              </div>
              {/* نص */}
              <div>
                <p className="text-[13px] font-bold text-foreground leading-snug">{title}</p>
                <p className="text-[11px] text-muted-foreground mt-0.5 leading-snug">{desc}</p>
              </div>
              {/* ظل لوني خلفي */}
              <div
                className="absolute bottom-0 left-0 right-0 h-1/2 rounded-b-2xl pointer-events-none opacity-60"
                style={{ background: `radial-gradient(ellipse at bottom left, ${accentLight} 0%, transparent 70%)` }}
              />
            </div>
          ))}
        </div>

        {/* ══ المحتوى الرئيسي ═══════════════════════════════════════════════════ */}
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-5">

          {/* ── عمود الطلاب ───────────────────────────────────────────────────── */}
          <div className="lg:col-span-2 flex flex-col gap-4">

            {/* بطاقة الفلاتر */}
            <Card className="border-border/70 shadow-[var(--shadow-card)] overflow-hidden">
              {/* رأس البطاقة */}
              <div className="flex items-center gap-2.5 px-4 py-3 border-b border-border/60 bg-muted/30">
                <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                  <Filter className="w-3.5 h-3.5 text-primary" />
                </div>
                <span className="text-[13px] font-bold text-foreground">فلاتر البحث</span>
              </div>
              <div className="px-4 py-4 flex flex-col gap-4">
                {/* حقل البحث */}
                <div className="relative">
                  <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/60 pointer-events-none" />
                  <Input
                    placeholder="ابحث عن طالب بالاسم..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="pr-10 h-10 text-sm rounded-xl border-border/70 bg-background focus-visible:ring-1 focus-visible:ring-primary/40 transition-colors"
                  />
                  {search && (
                    <button onClick={() => setSearch('')}
                      className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 rounded-full bg-muted hover:bg-muted-foreground/20 flex items-center justify-center transition-colors">
                      <X className="w-3 h-3 text-muted-foreground" />
                    </button>
                  )}
                </div>

                {/* فلتري الدبلوم والتخصص */}
                <div className="grid grid-cols-2 gap-2.5">
                  <div className="flex flex-col gap-1.5">
                    <label className="text-[11px] font-bold text-muted-foreground px-0.5">نوع الدبلوم</label>
                    <Select value={diplomaFilter} onValueChange={setDiplomaFilter}>
                      <SelectTrigger className="h-9 text-[12px] rounded-xl border-border/70 bg-background">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="الكل">جميع الدبلومات</SelectItem>
                        <SelectItem value="عالي">دبلوم عالي</SelectItem>
                        <SelectItem value="متوسط">دبلوم متوسط</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <label className="text-[11px] font-bold text-muted-foreground px-0.5">التخصص</label>
                    <Select value={specFilter} onValueChange={setSpecFilter}>
                      <SelectTrigger className="h-9 text-[12px] rounded-xl border-border/70 bg-background">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="الكل">جميع التخصصات</SelectItem>
                        {specializations.map((sp) => <SelectItem key={sp} value={sp}>{sp}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* حالة الدفع */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[11px] font-bold text-muted-foreground px-0.5">حالة الدفع</label>
                  <div className="grid grid-cols-2 gap-2">
                    {(Object.keys(DEBT_LABELS) as DebtFilter[]).map((key) => (
                      <button
                        key={key}
                        onClick={() => setDebtFilter(key)}
                        className={cn(
                          'flex items-center gap-2 px-3 py-2.5 rounded-xl border text-[11px] font-semibold transition-all duration-200',
                          debtFilter === key ? DEBT_FILTER_ACTIVE[key] : DEBT_FILTER_STYLE[key],
                        )}
                      >
                        <span className={cn('w-2 h-2 rounded-full shrink-0', debtFilter === key ? DEBT_DOT[key] : 'bg-muted-foreground/25')} />
                        {DEBT_LABELS[key]}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </Card>

            {/* قائمة الطلاب */}
            <Card className="flex flex-col border-border/70 shadow-[var(--shadow-card)] overflow-hidden" style={{ minHeight: 0 }}>
              {/* رأس */}
              <div className="flex items-center justify-between px-4 py-3 border-b border-border/60 bg-muted/30 shrink-0">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                    <Users className="w-3.5 h-3.5 text-primary" />
                  </div>
                  <span className="text-[13px] font-bold text-foreground">الطلاب</span>
                  <span className="text-[11px] font-bold bg-primary/10 text-primary px-2 py-0.5 rounded-full tabular-nums">{filteredStudents.length}</span>
                </div>
                <button
                  onClick={toggleAll}
                  className="flex items-center gap-1 text-[11px] font-semibold text-primary hover:text-primary/80 transition-colors"
                >
                  {selected.size === filteredStudents.length && filteredStudents.length > 0
                    ? <><X className="w-3 h-3" />إلغاء الكل</>
                    : <><CheckCheck className="w-3 h-3" />تحديد الكل ({filteredStudents.length})</>}
                </button>
              </div>
              {/* شريط التحديد */}
              {selected.size > 0 && (
                <div className="flex items-center gap-2.5 mx-3 my-2 px-3 py-2 rounded-xl border"
                  style={{ background: 'rgba(37,211,102,0.07)', borderColor: 'rgba(37,211,102,0.28)' }}>
                  <WhatsAppIcon className="w-4 h-4 shrink-0" />
                  <span className="text-[11px] font-bold flex-1" style={{ color: '#075E54' }}>
                    {selected.size} طالب محدد
                    {withPhoneCount < selected.size && (
                      <span className="text-amber-600 font-semibold mr-1"> · {withPhoneCount} لديهم هاتف</span>
                    )}
                  </span>
                  <button onClick={() => setSelected(new Set())}
                    className="w-5 h-5 rounded-full flex items-center justify-center hover:bg-black/10 transition-colors">
                    <X className="w-3 h-3" style={{ color: '#075E54' }} />
                  </button>
                </div>
              )}
              {/* القائمة */}
              <CardContent className="px-3 pb-3 pt-2 overflow-y-auto max-h-[430px] min-h-0">
                {loadingStudents ? (
                  <div className="flex flex-col gap-2">
                    {[...Array(5)].map((_, i) => <div key={i} className="h-[60px] rounded-2xl bg-muted animate-pulse" />)}
                  </div>
                ) : filteredStudents.length === 0 ? (
                  <div className="flex flex-col items-center gap-3 py-12 text-center">
                    <div className="w-14 h-14 rounded-2xl bg-muted/60 flex items-center justify-center">
                      <Users className="w-7 h-7 text-muted-foreground/30" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-muted-foreground">لا يوجد طلاب</p>
                      <p className="text-xs text-muted-foreground/60 mt-0.5">جرّب تغيير الفلاتر أو نص البحث</p>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col gap-1.5">
                    {displayedStudents.map((s: Student) => (
                      <StudentCard key={s.id} student={s} selected={selected.has(s.id)} onToggle={() => toggleStudent(s.id)} />
                    ))}
                    {filteredStudents.length > displayedStudents.length && (
                      <button
                        onClick={() => setVisibleCount((prev) => prev + 50)}
                        className="mt-2 w-full py-2.5 px-3 rounded-xl border border-primary/25 bg-primary/5 hover:bg-primary/10 text-primary text-xs font-bold transition-all flex items-center justify-center gap-1.5"
                      >
                        <span>عرض المزيد (+50 طالب)</span>
                        <span className="text-[10px] opacity-70">
                          (معروض {displayedStudents.length} من أصل {filteredStudents.length})
                        </span>
                      </button>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* ── عمود الرسالة والتبويبات ──────────────────────────────────────── */}
          <div className="lg:col-span-3 flex flex-col gap-4">
            <Tabs defaultValue="compose" className="flex flex-col gap-4">
              <TabsList className="w-full h-12 rounded-xl p-1 grid grid-cols-3"
                style={{ background: 'linear-gradient(135deg, #075E54 0%, #128C7E 100%)' }}>
                <TabsTrigger value="compose"
                  className="text-[12px] font-bold rounded-lg gap-1.5 text-white/70 data-[state=active]:text-[#075E54] data-[state=active]:bg-white data-[state=active]:shadow-md transition-all duration-200">
                  <WhatsAppIcon className="w-3.5 h-3.5" />كتابة الرسالة
                </TabsTrigger>
                <TabsTrigger value="templates"
                  className="text-[12px] font-bold rounded-lg gap-1.5 text-white/70 data-[state=active]:text-[#075E54] data-[state=active]:bg-white data-[state=active]:shadow-md transition-all duration-200">
                  <BookOpen className="w-3.5 h-3.5" />القوالب
                </TabsTrigger>
                <TabsTrigger value="history"
                  className="text-[12px] font-bold rounded-lg gap-1.5 text-white/70 data-[state=active]:text-[#075E54] data-[state=active]:bg-white data-[state=active]:shadow-md transition-all duration-200">
                  <History className="w-3.5 h-3.5" />السجل
                </TabsTrigger>
              </TabsList>

              {/* ─ تبويب: كتابة الرسالة ─────────────────────────────────────── */}
              <TabsContent value="compose" className="mt-0 flex flex-col gap-4">
                <Card className="border-border shadow-[var(--shadow-card)] overflow-hidden">
                  <CardHeader className="pb-0 pt-0 px-0">
                    <div className="flex items-center justify-between px-5 py-3.5 border-b border-border/60"
                      style={{ background: 'linear-gradient(135deg, rgba(37,211,102,0.06) 0%, rgba(7,94,84,0.04) 100%)' }}>
                      <CardTitle className="text-[13px] font-bold flex items-center gap-2">
                        <WhatsAppIcon className="w-5 h-5 shrink-0" />
                        <span style={{ color: '#075E54' }}>نص الرسالة</span>
                      </CardTitle>
                      <Button variant="outline" size="sm" onClick={() => setShowTemplates(!showTemplates)}
                        className="h-8 text-[11px] font-bold gap-1.5 border-border hover:border-violet-300 hover:bg-violet-50 hover:text-violet-700 transition-all">
                        <Sparkles className="w-3 h-3 text-violet-500" />
                        قالب جاهز
                        <ChevronDown className={cn('w-3 h-3 transition-transform duration-200', showTemplates && 'rotate-180')} />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="px-5 pb-5 flex flex-col gap-4 pt-4">
                    {showTemplates && (
                      <div className="border border-border/70 rounded-xl overflow-hidden shadow-[var(--shadow-xs)]">
                        <div className="px-3 py-2 bg-muted/40 border-b border-border/50 flex items-center gap-2">
                          <Sparkles className="w-3.5 h-3.5 text-violet-500" />
                          <span className="text-[11px] font-bold text-foreground">اختر قالباً جاهزاً</span>
                        </div>
                        {loadingTemplates ? (
                          <div className="p-4 text-xs text-muted-foreground text-center">جاري التحميل...</div>
                        ) : (
                          Object.entries(templatesByCategory).map(([cat, tpls]) => (
                            <div key={cat}>
                              <div className="px-3 py-1.5 bg-muted/30 text-[9.5px] font-bold text-muted-foreground/60 uppercase tracking-widest">{cat}</div>
                              {tpls.map((t) => (
                                <button key={t.id} onClick={() => applyTemplateToMessage(t)}
                                  className="w-full text-right px-4 py-2.5 hover:bg-primary/6 text-xs text-foreground border-t border-border/40 flex items-center gap-2.5 transition-colors group">
                                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0 group-hover:scale-110 transition-transform" />
                                  <span className="flex-1 font-medium">{t.name}</span>
                                  <span className="text-[10px] text-muted-foreground/50 shrink-0">تطبيق ←</span>
                                </button>
                              ))}
                            </div>
                          ))
                        )}
                      </div>
                    )}
                    <Textarea
                      placeholder={selected.size > 1 ? 'اكتب رسالتك... استخدم {{الاسم}} {{المبلغ_المتبقي}} {{المبلغ_المدفوع}} كمتغيرات تلقائية' : 'اكتب رسالتك هنا...'}
                      value={message} onChange={(e) => setMessage(e.target.value)}
                      rows={8} className="resize-none text-sm leading-relaxed bg-muted/30 border-border/60 focus:bg-card transition-colors" dir="rtl" />
                    {selected.size > 1 && (
                      <div className="flex flex-wrap gap-1.5 p-3 bg-muted/30 rounded-xl border border-border/50">
                        <span className="text-[10px] font-bold text-muted-foreground/70 w-full mb-0.5">انقر لإضافة متغير:</span>
                        {['{{الاسم}}', '{{المبلغ_المتبقي}}', '{{المبلغ_المدفوع}}', '{{التخصص}}', '{{الدبلوم}}'].map((v) => (
                          <button key={v} onClick={() => setMessage((m) => m + v)}
                            className="text-[10px] px-2 py-1 bg-primary/10 text-primary rounded-lg border border-primary/20 hover:bg-primary/20 font-mono font-semibold transition-all hover:scale-105 active:scale-95">
                            {v}
                          </button>
                        ))}
                      </div>
                    )}
                    <div className="flex items-center justify-between">
                      <div className="text-xs text-muted-foreground flex items-center gap-1.5">
                        {selected.size === 0 ? (
                          <><AlertCircle className="w-3.5 h-3.5 text-amber-500" /><span className="text-amber-600 font-medium">حدد طالباً أو أكثر أولاً</span></>
                        ) : (
                          <><div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" /><span className="font-medium text-foreground/70">{selected.size === 1 ? `المرسَل إليه: ${selectedStudents[0]?.full_name}` : `سيُرسَل لـ ${withPhoneCount} طالب`}</span></>
                        )}
                      </div>
                      <span className="text-[10px] font-mono text-muted-foreground/50">{message.length} حرف</span>
                    </div>
                    <Button onClick={handleSend} disabled={sending || selected.size === 0 || !message.trim() || withPhoneCount === 0}
                      className="w-full h-12 text-sm font-bold gap-2.5 text-white shadow-md hover:shadow-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                      style={{ background: sending ? '#128C7E' : 'linear-gradient(135deg, #075E54 0%, #25D366 100%)' }}>
                      {sending
                        ? <RefreshCw className="w-4 h-4 animate-spin" />
                        : <WhatsAppIcon className="w-5 h-5" />
                      }
                      {sending ? 'جاري فتح واتساب...' : selected.size <= 1 ? 'فتح واتساب وإرسال' : `إرسال جماعي لـ ${withPhoneCount} طالب`}
                    </Button>
                    {withPhoneCount < selected.size && selected.size > 0 && (
                      <div className="flex items-center gap-2 p-2.5 bg-amber-50 dark:bg-amber-950/30 border border-amber-200/70 dark:border-amber-800/40 rounded-xl">
                        <AlertCircle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                        <p className="text-[11px] text-amber-700 dark:text-amber-400 font-medium">{selected.size - withPhoneCount} طالب بدون رقم هاتف — سيُتجاهَلون</p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* معاينة الرسائل الجماعية */}
                {selected.size > 1 && message.trim() && (
                  <Card className="border-border/70 shadow-[var(--shadow-card)]">
                    <CardHeader className="pb-2 pt-4 px-5 border-b border-border/50">
                      <CardTitle className="text-[13px] font-bold flex items-center gap-2">
                        <div className="w-6 h-6 rounded-md bg-primary/10 flex items-center justify-center">
                          <User className="w-3.5 h-3.5 text-primary" />
                        </div>
                        معاينة الرسائل
                        <span className="text-[11px] font-normal text-muted-foreground">(أول {Math.min(selectedStudents.length, 3)})</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="px-5 pb-4 pt-3 overflow-y-auto max-h-64">
                      <div className="flex flex-col gap-3">
                        {selectedStudents.slice(0, 3).map((s) => (
                          <div key={s.id} className="rounded-xl bg-muted/40 border border-border/50 p-3">
                            <div className="flex items-center gap-2 mb-2">
                              <Initials name={s.full_name} />
                              <div className="min-w-0">
                                <p className="text-xs font-bold text-foreground truncate">{s.full_name}</p>
                                <p className="text-[10px] text-muted-foreground">{s.phone ?? 'لا يوجد هاتف'}</p>
                              </div>
                              {!s.phone && <Badge className="mr-auto text-[9px] bg-red-50 text-red-600 border border-red-200 px-1.5">لا هاتف</Badge>}
                            </div>
                            <div className="bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200/60 dark:border-emerald-800/40 rounded-lg p-2.5">
                              <p className="text-[11px] text-foreground/80 whitespace-pre-wrap leading-relaxed line-clamp-4">{applyTemplate(message, s)}</p>
                            </div>
                          </div>
                        ))}
                        {selectedStudents.length > 3 && <p className="text-[11px] text-muted-foreground text-center py-1">+ {selectedStudents.length - 3} رسالة أخرى</p>}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              {/* ─ تبويب: القوالب ────────────────────────────────────────────── */}
              <TabsContent value="templates" className="mt-0">
                <Card className="border-border/70 shadow-[var(--shadow-card)] overflow-hidden">
                  {/* رأس */}
                  <div className="flex items-center justify-between px-5 py-3.5 border-b border-border/60 bg-muted/30">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-violet-100 dark:bg-violet-950/50 flex items-center justify-center shrink-0">
                        <Sparkles className="w-3.5 h-3.5 text-violet-600" />
                      </div>
                      <span className="text-[13px] font-bold text-foreground">قوالب الرسائل</span>
                      <span className="text-[11px] font-bold bg-violet-100 dark:bg-violet-950/40 text-violet-700 dark:text-violet-400 px-2 py-0.5 rounded-full tabular-nums">{templates.length}</span>
                    </div>
                    <Button size="sm" onClick={openNewTemplate}
                      className="h-8 text-[11px] font-bold gap-1.5 bg-violet-600 hover:bg-violet-700 text-white shadow-sm">
                      <Plus className="w-3.5 h-3.5" />إضافة قالب
                    </Button>
                  </div>
                  <CardContent className="px-4 pb-4 pt-4">
                    {loadingTemplates ? (
                      <div className="flex flex-col gap-2.5">{[...Array(4)].map((_, i) => <div key={i} className="h-24 rounded-xl bg-muted animate-pulse" />)}</div>
                    ) : templates.length === 0 ? (
                      <div className="flex flex-col items-center gap-3 py-14 text-center">
                        <div className="w-16 h-16 rounded-2xl bg-violet-50 dark:bg-violet-950/30 border border-violet-200/60 flex items-center justify-center">
                          <BookOpen className="w-8 h-8 text-violet-400" />
                        </div>
                        <div>
                          <p className="text-sm font-bold text-foreground">لا توجد قوالب بعد</p>
                          <p className="text-xs text-muted-foreground mt-1">أضف قالبك الأول لتسريع الإرسال</p>
                        </div>
                        <Button size="sm" onClick={openNewTemplate} className="bg-violet-600 hover:bg-violet-700 text-white">
                          <Plus className="w-3.5 h-3.5 ml-1" />إضافة قالب
                        </Button>
                      </div>
                    ) : (
                      <div className="flex flex-col gap-5 overflow-y-auto max-h-[520px]">
                        {Object.entries(templatesByCategory).map(([cat, tpls]) => (
                          <div key={cat}>
                            {/* فاصل الفئة */}
                            <div className="flex items-center gap-2 mb-3">
                              <div className="h-px flex-1 bg-border/60" />
                              <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest px-2">{cat}</span>
                              <div className="h-px flex-1 bg-border/60" />
                            </div>
                            <div className="flex flex-col gap-2.5">
                              {tpls.map((t) => (
                                <div key={t.id}
                                  className="group relative rounded-2xl border border-border/60 bg-card overflow-hidden hover:border-violet-300 dark:hover:border-violet-700 hover:shadow-sm transition-all duration-200">
                                  {/* شريط علوي بنفسجي */}
                                  <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-violet-500 to-violet-300 opacity-0 group-hover:opacity-100 transition-opacity" />
                                  <div className="p-4">
                                    {/* رأس القالب */}
                                    <div className="flex items-center justify-between gap-3 mb-3">
                                      <div className="flex items-center gap-2.5 min-w-0">
                                        <div className="w-8 h-8 rounded-xl bg-violet-50 dark:bg-violet-950/40 border border-violet-200/60 dark:border-violet-800/40 flex items-center justify-center shrink-0">
                                          <Sparkles className="w-4 h-4 text-violet-500" />
                                        </div>
                                        <p className="text-[13px] font-bold text-foreground truncate">{t.name}</p>
                                      </div>
                                      <div className="flex gap-1 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                                        <button title="تطبيق" onClick={() => applyTemplateToMessage(t)}
                                          className="w-7 h-7 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 hover:bg-emerald-100 flex items-center justify-center transition-colors">
                                          <CheckCircle2 className="w-3.5 h-3.5" />
                                        </button>
                                        <button title="تعديل" onClick={() => openEditTemplate(t)}
                                          className="w-7 h-7 rounded-lg bg-blue-50 dark:bg-blue-950/40 text-blue-600 hover:bg-blue-100 flex items-center justify-center transition-colors">
                                          <Edit2 className="w-3.5 h-3.5" />
                                        </button>
                                        <button title="حذف" onClick={() => setDeleteConfirm(t)}
                                          className="w-7 h-7 rounded-lg bg-red-50 dark:bg-red-950/40 text-red-500 hover:bg-red-100 flex items-center justify-center transition-colors">
                                          <Trash2 className="w-3.5 h-3.5" />
                                        </button>
                                      </div>
                                    </div>
                                    {/* نص القالب */}
                                    <p className="text-[11px] text-muted-foreground line-clamp-3 whitespace-pre-wrap leading-relaxed">{t.body}</p>
                                    {/* تذييل */}
                                    <div className="flex items-center justify-between mt-3 pt-3 border-t border-border/40">
                                      <span className="text-[10px] font-semibold bg-muted text-muted-foreground px-2.5 py-1 rounded-full">{t.category}</span>
                                      <button onClick={() => applyTemplateToMessage(t)}
                                        className="flex items-center gap-1 text-[11px] font-bold text-violet-600 hover:text-violet-700 transition-colors">
                                        تطبيق على الرسالة <Send className="w-3 h-3" />
                                      </button>
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* ─ تبويب: السجل ──────────────────────────────────────────────── */}
              <TabsContent value="history" className="mt-0">
                <Card className="border-border/70 shadow-[var(--shadow-card)]">
                  <CardHeader className="pb-3 pt-4 px-5 border-b border-border/50">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-[13px] font-bold flex items-center gap-2">
                        <div className="w-6 h-6 rounded-md bg-primary/10 flex items-center justify-center">
                          <History className="w-3.5 h-3.5 text-primary" />
                        </div>
                        سجل الرسائل
                        <span className="text-[11px] font-semibold bg-muted text-muted-foreground px-2 py-0.5 rounded-full">{log.length}</span>
                      </CardTitle>
                      <Button variant="ghost" size="sm" onClick={loadLog} disabled={loadingLog} className="h-8 text-[11px] font-semibold gap-1.5 hover:bg-muted">
                        <RefreshCw className={cn('w-3.5 h-3.5', loadingLog && 'animate-spin')} />تحديث
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="px-5 pb-5 pt-4">
                    {loadingLog ? (
                      <div className="flex flex-col gap-2">{[...Array(5)].map((_, i) => <div key={i} className="h-20 rounded-xl bg-muted animate-pulse" />)}</div>
                    ) : log.length === 0 ? (
                      <div className="flex flex-col items-center gap-3 py-12 text-center">
                        <div className="w-16 h-16 rounded-2xl bg-muted/60 flex items-center justify-center">
                          <History className="w-8 h-8 text-muted-foreground/25" />
                        </div>
                        <div>
                          <p className="text-sm font-bold text-foreground">لا توجد رسائل بعد</p>
                          <p className="text-xs text-muted-foreground mt-0.5">ستظهر الرسائل المُرسَلة هنا</p>
                        </div>
                      </div>
                    ) : (
                      <div className="flex flex-col gap-2.5 overflow-y-auto max-h-[520px]">
                        {log.map((entry) => (
                          <div key={entry.id} className="border border-border/60 rounded-xl p-4 bg-card hover:border-border transition-colors">
                            <div className="flex items-start justify-between gap-3 mb-2.5">
                              {/* اسم الطالب — يأخذ كل المساحة المتاحة */}
                              <div className="flex items-center gap-2.5 flex-1 min-w-0 overflow-hidden">
                                <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-primary/20 to-primary/10 border border-primary/15 flex items-center justify-center shrink-0">
                                  <User className="w-3.5 h-3.5 text-primary" />
                                </div>
                                <div className="flex-1 min-w-0 overflow-hidden">
                                  <p className="text-[12px] font-bold text-foreground leading-snug break-words">{entry.student_name}</p>
                                  <div className="flex items-center gap-1 mt-0.5">
                                    <Phone className="w-2.5 h-2.5 text-muted-foreground/50 shrink-0" />
                                    <p className="text-[10px] text-muted-foreground font-mono truncate">{entry.phone}</p>
                                  </div>
                                </div>
                              </div>
                              {/* حالة + وقت — عرض ثابت */}
                              <div className="flex flex-col items-end gap-1 shrink-0">
                                <span className="inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 border border-emerald-200/60 dark:border-emerald-800/40 whitespace-nowrap">
                                  <CheckCircle2 className="w-2.5 h-2.5 shrink-0" />{entry.status}
                                </span>
                                <div className="flex items-center gap-1 text-[9.5px] text-muted-foreground/60 whitespace-nowrap">
                                  <Clock className="w-2.5 h-2.5 shrink-0" />
                                  {new Date(entry.sent_at).toLocaleString('ar-LY', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' })}
                                </div>
                              </div>
                            </div>
                            <div className="bg-muted/40 rounded-lg px-3 py-2 border border-border/40">
                              <p className="text-[11px] text-muted-foreground line-clamp-2 whitespace-pre-wrap leading-relaxed">{entry.message}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>

      {/* ══ Dialog: إضافة / تعديل قالب ══════════════════════════════════════════ */}
      <Dialog open={templateDialog} onOpenChange={setTemplateDialog}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-violet-500/15 flex items-center justify-center">
                <BookOpen className="w-4 h-4 text-violet-600" />
              </div>
              {editTemplate ? 'تعديل القالب' : 'قالب جديد'}
            </DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-4 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="flex flex-col gap-1.5">
                <label className="text-[11px] font-bold text-foreground/80 uppercase tracking-wide">اسم القالب *</label>
                <Input placeholder="مثال: تذكير بالرسوم" value={tplName} onChange={(e) => setTplName(e.target.value)} className="h-9 text-sm bg-muted/40" />
              </div>
              <div className="flex flex-col gap-1.5">
                <label className="text-[11px] font-bold text-foreground/80 uppercase tracking-wide">الفئة</label>
                <Select value={tplCategory} onValueChange={setTplCategory}>
                  <SelectTrigger className="h-9 text-sm bg-muted/40"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="عام">عام</SelectItem>
                    <SelectItem value="مالي">مالي</SelectItem>
                    <SelectItem value="أكاديمي">أكاديمي</SelectItem>
                    <SelectItem value="إداري">إداري</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="text-[11px] font-bold text-foreground/80 uppercase tracking-wide">نص الرسالة *</label>
              <Textarea placeholder="اكتب نص القالب..." value={tplBody} onChange={(e) => setTplBody(e.target.value)}
                rows={7} className="resize-none text-sm bg-muted/40" dir="rtl" />
            </div>
            <div className="p-3 bg-muted/30 rounded-xl border border-border/50">
              <p className="text-[10px] font-bold text-muted-foreground/70 mb-2">انقر لإضافة متغير:</p>
              <div className="flex flex-wrap gap-1.5">
                {['{{الاسم}}', '{{المبلغ_المتبقي}}', '{{المبلغ_المدفوع}}', '{{التخصص}}', '{{الدبلوم}}', '{{الرسالة}}'].map((v) => (
                  <button key={v} onClick={() => setTplBody((b) => b + v)}
                    className="text-[10px] px-2 py-1 bg-primary/10 text-primary rounded-lg border border-primary/20 hover:bg-primary/20 font-mono font-semibold transition-all hover:scale-105">
                    {v}
                  </button>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setTemplateDialog(false)} disabled={savingTemplate} className="gap-1.5">
              <XCircle className="w-3.5 h-3.5" />إلغاء
            </Button>
            <Button onClick={handleSaveTemplate} disabled={savingTemplate} className="gap-1.5">
              {savingTemplate ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
              {editTemplate ? 'حفظ التعديلات' : 'إضافة القالب'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ══ AlertDialog: حذف قالب ════════════════════════════════════════════════ */}
      <AlertDialog open={!!deleteConfirm} onOpenChange={(o) => !o && setDeleteConfirm(null)}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-destructive/10 flex items-center justify-center">
                <Trash2 className="w-4 h-4 text-destructive" />
              </div>
              حذف القالب
            </AlertDialogTitle>
            <AlertDialogDescription>
              هل تريد حذف قالب <strong>"{deleteConfirm?.name}"</strong>؟ لا يمكن التراجع عن هذا الإجراء.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteTemplate}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90 gap-1.5">
              <Trash2 className="w-3.5 h-3.5" />حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </MainLayout>
  );
}
