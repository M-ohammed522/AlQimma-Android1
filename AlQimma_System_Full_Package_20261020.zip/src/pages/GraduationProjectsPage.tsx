// صفحة مشاريع التخرج - منظومة معهد القمة
import { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  GraduationCap, DollarSign, PlusCircle, Printer,
  ChevronRight, CheckCircle, AlertTriangle, BookOpen,
} from 'lucide-react';
import { toast } from 'sonner';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import {
  getStudents, getSettings, getNextReceiptNumber,
  getSemesterCharges, createSemesterCharge, processPayment, updateStudent,
} from '@/lib/api';
import type { Student, SemesterCharge } from '@/types/index';
import { SETTINGS_KEYS } from '@/types/index';

interface ProjectStudent extends Student {
  projectCharges: SemesterCharge[];
  projectPaid: number;
  projectTotal: number;
  projectDebt: number;
}

export default function GraduationProjectsPage() {
  const navigate = useNavigate();
  const [students, setStudents] = useState<ProjectStudent[]>([]);
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);

  // حوار الدفعة المالية
  const [paymentTarget, setPaymentTarget] = useState<ProjectStudent | null>(null);
  const [paymentAmount, setPaymentAmount] = useState('');
  const [paymentReceiptNum, setPaymentReceiptNum] = useState('');
  const [paymentNotes, setPaymentNotes] = useState('');
  const [actionLoading, setActionLoading] = useState(false);

  // حوار إضافة بيانات المشروع
  const [projectTarget, setProjectTarget] = useState<ProjectStudent | null>(null);
  const [projectName, setProjectName] = useState('');
  const [projectSummary, setProjectSummary] = useState('');
  const [projectSupervisor, setProjectSupervisor] = useState('');

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [{ data: rawStudents }, cfg] = await Promise.all([
        getStudents({ diplomaType: 'عالي', semester: 6 }),
        getSettings(),
      ]);
      setSettings(cfg);
      const projectFee = parseFloat(cfg[SETTINGS_KEYS.GRADUATION_PROJECT_FEE] ?? '350');

      const enriched: ProjectStudent[] = await Promise.all(
        rawStudents.map(async (s) => {
          const charges = await getSemesterCharges(s.id);
          const projectCharges = charges.filter(c => c.charge_type === 'مشروع تخرج');

          // إن لم تكن رسوم مشروع التخرج مسجلة بعد، نسجلها
          if (projectCharges.length === 0) {
            await createSemesterCharge({
              student_id: s.id,
              semester_number: 6,
              charge_amount: projectFee,
              paid_amount: 0,
              charge_type: 'مشروع تخرج',
              is_cleared: false,
              is_locked: false,
            });
            await updateStudent(s.id, { total_charged: s.total_charged + projectFee });
            const freshCharges = await getSemesterCharges(s.id);
            const freshProject = freshCharges.filter(c => c.charge_type === 'مشروع تخرج');
            const paid = freshProject.reduce((sum, c) => sum + c.paid_amount, 0);
            return { ...s, total_charged: s.total_charged + projectFee, projectCharges: freshProject, projectPaid: paid, projectTotal: projectFee, projectDebt: projectFee - paid };
          }

          const paid = projectCharges.reduce((sum, c) => sum + c.paid_amount, 0);
          const total = projectCharges.reduce((sum, c) => sum + c.charge_amount, 0);
          return { ...s, projectCharges, projectPaid: paid, projectTotal: total, projectDebt: total - paid };
        })
      );
      setStudents(enriched);
    } catch (err) {
      toast.error('خطأ في تحميل بيانات مشاريع التخرج');
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleOpenPayment = async (student: ProjectStudent) => {
    setPaymentTarget(student);
    setPaymentAmount('');
    setPaymentNotes('');
    try {
      const { peekCurrentReceiptNumber } = await import('@/lib/api');
      const num = await peekCurrentReceiptNumber('عالي'); // مشاريع التخرج للدبلوم العالي فقط
      setPaymentReceiptNum(num);
    } catch {
      setPaymentReceiptNum('');
    }
  };

  const handlePayment = async () => {
    if (!paymentTarget) return;
    const amount = parseFloat(paymentAmount);
    if (!amount || amount <= 0) { toast.error('أدخل مبلغاً صحيحاً'); return; }
    setActionLoading(true);
    try {
      // رقم الإيصال يُولَّد داخل processPayment تلقائياً
      await processPayment({
        studentId: paymentTarget.id,
        amount,
        paymentType: 'مشروع تخرج',
        notes: `قسط رسوم مشروع التخرج${paymentNotes ? ' - ' + paymentNotes : ''}`,
      });
      toast.success(`تم تسجيل دفعة ${amount} دينار`);
      setPaymentTarget(null);
      fetchData();
    } catch {
      toast.error('فشل في تسجيل الدفعة');
    } finally {
      setActionLoading(false);
    }
  };

  const handleSaveProject = async () => {
    if (!projectTarget) return;
    setActionLoading(true);
    try {
      await updateStudent(projectTarget.id, {
        project_name: projectName || null,
        project_summary: projectSummary || null,
        project_supervisor: projectSupervisor || null,
      });
      toast.success('تم حفظ بيانات المشروع');
      setProjectTarget(null);
      fetchData();
    } catch {
      toast.error('فشل في حفظ بيانات المشروع');
    } finally {
      setActionLoading(false);
    }
  };

  const handlePrint = () => { window.print(); };

  const projectFee = parseFloat(settings[SETTINGS_KEYS.GRADUATION_PROJECT_FEE] ?? '350');
  const totalDebt = students.reduce((sum, s) => sum + s.projectDebt, 0);

  return (
    <MainLayout>
      <div className="space-y-5">
        {/* رأس الصفحة */}
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" onClick={() => navigate('/')} className="h-8 w-8 text-muted-foreground no-print">
              <ChevronRight className="w-4 h-4" />
            </Button>
            <div>
              <h1 className="text-xl font-bold text-foreground text-balance flex items-center gap-2">
                <GraduationCap className="w-5 h-5 text-primary" /> قائمة طلبة مشاريع التخرج
              </h1>
              <p className="text-xs text-muted-foreground">طلاب الفصل السادس - الدبلوم العالي</p>
            </div>
          </div>
          <Button size="sm" variant="outline" onClick={handlePrint} className="gap-1.5 no-print">
            <Printer className="w-4 h-4" /> طباعة القائمة
          </Button>
        </div>

        {/* رأسية الطباعة */}
        <div className="print-only text-center py-4 border-b border-border mb-4">
          <h2 className="text-xl font-bold">معهد القمة للعلوم الطبية والإدارية</h2>
          <p className="text-sm">قائمة طلبة مشاريع التخرج - الفصل السادس</p>
          <p className="text-xs text-muted-foreground mt-1">
            {new Date().toLocaleDateString('ar-LY', { dateStyle: 'full' })}
          </p>
        </div>

        {/* إحصائيات */}
        <div className="grid grid-cols-3 gap-3 no-print">
          {[
            { label: 'إجمالي الطلاب', value: students.length, color: 'text-primary' },
            { label: 'رسوم المشروع', value: `${projectFee} د.ل`, color: 'text-chart-2' },
            { label: 'مجموع الديون المتبقية', value: `${totalDebt.toFixed(0)} د.ل`, color: 'text-destructive' },
          ].map(s => (
            <Card key={s.label} className="shadow-card">
              <CardContent className="p-3 text-center">
                <p className="text-xs text-muted-foreground">{s.label}</p>
                <p className={`text-lg font-bold ${s.color}`}>{s.value}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* قائمة الطلاب */}
        {loading ? (
          <div className="space-y-3">
            {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28 bg-muted rounded-lg" />)}
          </div>
        ) : students.length === 0 ? (
          <Card className="shadow-card">
            <CardContent className="py-16 text-center text-muted-foreground">
              <GraduationCap className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p className="text-sm">لا يوجد طلاب في الفصل السادس حالياً</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {students.map((student) => (
              <Card key={student.id} className="shadow-card">
                <CardContent className="p-4">
                  <div className="flex flex-col md:flex-row md:items-start gap-4">
                    {/* معلومات الطالب */}
                    <div className="flex-1 min-w-0 space-y-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="text-sm font-semibold text-foreground">{student.full_name}</h3>
                        <Badge variant="outline" className="text-xs px-1.5 py-0">{student.specialization}</Badge>
                        {student.projectDebt <= 0 && (
                          <Badge variant="outline" className="text-xs px-1.5 py-0 text-chart-2 border-chart-2/40">مسدد</Badge>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground font-mono">{student.national_id}</p>

                      {/* بيانات المشروع */}
                      {student.project_name ? (
                        <div className="bg-muted/50 rounded p-2 space-y-1">
                          <p className="text-xs font-medium flex items-center gap-1">
                            <BookOpen className="w-3 h-3 text-primary" /> {student.project_name}
                          </p>
                          {student.project_supervisor && (
                            <p className="text-xs text-muted-foreground">المشرف: {student.project_supervisor}</p>
                          )}
                          {student.project_summary && (
                            <p className="text-xs text-muted-foreground">{student.project_summary}</p>
                          )}
                        </div>
                      ) : (
                        <p className="text-xs text-muted-foreground italic">لم تُحدد بيانات المشروع بعد</p>
                      )}
                    </div>

                    {/* الملخص المالي */}
                    <div className="shrink-0 space-y-2 min-w-[160px]">
                      <div className="grid grid-cols-3 gap-1 text-center bg-muted/50 rounded p-2">
                        <div>
                          <p className="text-xs text-muted-foreground">المستحق</p>
                          <p className="text-xs font-bold">{student.projectTotal.toFixed(0)}</p>
                        </div>
                        <div className="border-x border-border">
                          <p className="text-xs text-muted-foreground">المدفوع</p>
                          <p className="text-xs font-bold text-chart-2">{student.projectPaid.toFixed(0)}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">المتبقي</p>
                          <p className={`text-xs font-bold ${student.projectDebt > 0 ? 'text-destructive' : 'text-chart-2'}`}>
                            {student.projectDebt.toFixed(0)}
                          </p>
                        </div>
                      </div>
                      <div className="flex gap-1.5 no-print">
                        <Button size="sm" variant="outline" className="flex-1 h-8 text-xs gap-1"
                          onClick={() => { setProjectTarget(student); setProjectName(student.project_name ?? ''); setProjectSummary(student.project_summary ?? ''); setProjectSupervisor(student.project_supervisor ?? ''); }}>
                          <PlusCircle className="w-3 h-3" /> مشروع
                        </Button>
                        <Button size="sm" className="flex-1 h-8 text-xs gap-1"
                          onClick={() => handleOpenPayment(student)}>
                          <DollarSign className="w-3 h-3" /> دفعة
                        </Button>
                      </div>
                      <Button size="sm" variant="ghost" className="w-full h-7 text-xs text-muted-foreground no-print"
                        onClick={() => navigate(`/student/${student.id}`)}>
                        عرض الملف الكامل
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* خانات الختم للطباعة */}
        <div className="print-only mt-10 grid grid-cols-2 gap-8">
          <div className="text-center border-t border-border pt-4">
            <p className="text-sm text-muted-foreground">ختم المعهد</p>
          </div>
          <div className="text-center border-t border-border pt-4">
            <p className="text-sm text-muted-foreground">توقيع الإدارة المسؤولة</p>
          </div>
        </div>
      </div>

      {/* حوار الدفعة المالية */}
      <Dialog open={!!paymentTarget} onOpenChange={o => { if (!o) { setPaymentTarget(null); setPaymentAmount(''); setPaymentNotes(''); } }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-primary" /> دفعة رسوم مشروع التخرج
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-muted rounded p-3 space-y-1">
              <p className="text-sm font-medium">{paymentTarget?.full_name}</p>
              <div className="flex items-center gap-4 text-xs text-muted-foreground">
                <span>المستحق: {paymentTarget?.projectTotal.toFixed(0)} د.ل</span>
                <span>المدفوع: {paymentTarget?.projectPaid.toFixed(0)} د.ل</span>
                <span className="text-destructive font-medium">المتبقي: {paymentTarget?.projectDebt.toFixed(0)} د.ل</span>
              </div>
            </div>
            <div className="space-y-1">
              <Label className="text-sm font-normal">رقم الإيصال</Label>
              <Input value={paymentReceiptNum} onChange={e => setPaymentReceiptNum(e.target.value.replace(/\D/g, ''))}
                className="text-sm font-mono" placeholder="000001" />
            </div>
            <div className="space-y-1">
              <Label className="text-sm font-normal">المبلغ المدفوع (دينار)</Label>
              <Input type="text" inputMode="decimal" value={paymentAmount}
                onChange={e => setPaymentAmount(e.target.value)} placeholder="0.00" className="text-sm" />
            </div>
            <div className="space-y-1">
              <Label className="text-sm font-normal">ملاحظات</Label>
              <Input value={paymentNotes} onChange={e => setPaymentNotes(e.target.value)}
                placeholder="بيان إضافي (اختياري)" className="text-sm" />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setPaymentTarget(null)}>إلغاء</Button>
            <Button onClick={handlePayment} disabled={actionLoading}>
              {actionLoading ? 'جاري الحفظ...' : 'حفظ الإيصال'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* حوار إضافة بيانات المشروع */}
      <Dialog open={!!projectTarget} onOpenChange={o => { if (!o) setProjectTarget(null); }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <PlusCircle className="w-5 h-5 text-primary" /> إضافة / تعديل بيانات المشروع
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">{projectTarget?.full_name}</p>
            <Separator />
            <div className="space-y-1">
              <Label className="text-sm font-normal">اسم المشروع / عنوان البحث</Label>
              <Input value={projectName} onChange={e => setProjectName(e.target.value)}
                placeholder="أدخل عنوان المشروع" className="text-sm" />
            </div>
            <div className="space-y-1">
              <Label className="text-sm font-normal">الدكتور المشرف</Label>
              <Input value={projectSupervisor} onChange={e => setProjectSupervisor(e.target.value)}
                placeholder="اسم عضو هيئة التدريس المشرف" className="text-sm" />
            </div>
            <div className="space-y-1">
              <Label className="text-sm font-normal">نبذة عن المشروع</Label>
              <Input value={projectSummary} onChange={e => setProjectSummary(e.target.value)}
                placeholder="ملخص أو فكرة المشروع الأساسية" className="text-sm" />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setProjectTarget(null)}>إلغاء</Button>
            <Button onClick={handleSaveProject} disabled={actionLoading}>
              {actionLoading ? 'جاري الحفظ...' : 'حفظ البيانات'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* رمز للتحقق الصوري */}
      <div className="hidden">
        <CheckCircle />
      </div>
    </MainLayout>
  );
}
