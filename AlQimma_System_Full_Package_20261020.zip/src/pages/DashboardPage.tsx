// لوحة التحكم الرئيسية - منظومة معهد القمة
import React, { useEffect, useState, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Users, GraduationCap, AlertTriangle, DollarSign,
  FolderX,
  FileText, Edit, PauseCircle, PlayCircle, Trash2,
  Bell, Eye, RefreshCw, ChevronUp, UserCheck, UserX,
  TrendingUp, BookOpen, BarChart3, FolderOpen, CheckCheck, Clock,
  LayoutList, LayoutGrid, AlertCircle, Archive, Hash,
} from 'lucide-react';
import { toast } from 'sonner';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import {
  getDashboardStats, getStudents, deleteStudent,
  suspendStudent, activateStudent, promoteStudent, getSettings, getNotifications, markAllNotificationsRead,
  getPendingArchiveStudents, archiveStudent, getSemesterCharges,
  MAX_SEMESTERS, type DashboardStats,
} from '@/lib/api';
import type { Student, Notification } from '@/types/index';
import { SYSTEM_PASSWORD, SEMESTER_LABELS } from '@/types/index';
import { StudentAvatar } from '@/components/ui/StudentAvatar';
import { RefreshButton } from '@/components/ui/RefreshButton';
const ITEMS_PER_PAGE = 20;
const SEARCH_DEBOUNCE = 250;

export default function DashboardPage() {
  const navigate = useNavigate();
  const [stats, setStats] = useState<DashboardStats | null>(() => {
    if (typeof window === 'undefined') return null;
    try {
      const s = sessionStorage.getItem('alqeema_dashboard_stats_cache');
      if (s) {
        const parsed = JSON.parse(s);
        return parsed.data ?? parsed;
      }
    } catch {}
    return null;
  });
  const [students, setStudents] = useState<Student[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(!stats);
  const [loadingMore, setLoadingMore] = useState(false);
  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch]             = useState('');
  const [filterDiploma, setFilterDiploma] = useState('all');
  const [filterStatus, setFilterStatus]   = useState('all');
  const [filterMissingReg, setFilterMissingReg] = useState(false);
  const [page, setPage]                   = useState(0);
  const searchTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const [deleteTarget, setDeleteTarget] = useState<Student | null>(null);
  const [deletePassword, setDeletePassword] = useState('');
  const [deleteError, setDeleteError] = useState('');
  const [promoteTarget, setPromoteTarget] = useState<Student | null>(null);
  const [actionLoading, setActionLoading] = useState(false);
  // وضع العرض: جدول أو شبكة بطاقات
  const [viewMode, setViewMode] = useState<'table' | 'grid'>('table');
  // الأرشفة
  const [pendingArchive, setPendingArchive] = useState<Student[]>(() => {
    if (typeof window === 'undefined') return [];
    try {
      const p = sessionStorage.getItem('alqeema_pending_archive_cache');
      if (p) {
        const parsed = JSON.parse(p);
        return parsed.data ?? parsed;
      }
    } catch {}
    return [];
  });
  const [archivePanelOpen, setArchivePanelOpen] = useState(true);
  const [archiveConfirmStudent, setArchiveConfirmStudent] = useState<Student | null>(null);
  const [archiveBatchConfirm, setArchiveBatchConfirm] = useState(false);
  const [archivingId, setArchivingId] = useState<string | null>(null);
  const [archivingAll, setArchivingAll] = useState(false);
  const [selectedForArchive, setSelectedForArchive] = useState<Set<string>>(new Set());
  const [loadFailed, setLoadFailed] = useState(false);

  // جلب البيانات الأولية (إحصائيات + الصفحة الأولى من الطلاب + إشعارات)
  const fetchInitial = useCallback(async () => {
    if (!stats) setLoading(true);
    setLoadFailed(false);
    try {
      const [statsRes, studentsRes, notifRes, archiveRes] = await Promise.allSettled([
        getDashboardStats(),
        getStudents({
          search: search || undefined,
          diplomaType: filterDiploma !== 'all' ? filterDiploma as 'عالي' | 'متوسط' : undefined,
          status: filterStatus !== 'all' ? filterStatus : undefined,
          missingRegistrationNumber: filterMissingReg ? true : undefined,
          limit: ITEMS_PER_PAGE,
          offset: 0,
        }),
        getNotifications(true),
        getPendingArchiveStudents(),
      ]);
      if (statsRes.status === 'fulfilled')   setStats(statsRes.value);
      if (studentsRes.status === 'fulfilled') {
        setStudents(studentsRes.value.data);
        setTotalCount(studentsRes.value.count);
        setPage(0);
      }
      if (notifRes.status === 'fulfilled') {
        setNotifications(notifRes.value.filter(n => !n.is_read).slice(0, 10));
      }
      if (archiveRes.status === 'fulfilled') setPendingArchive(archiveRes.value);
      if (statsRes.status === 'rejected' || studentsRes.status === 'rejected') {
        setLoadFailed(true);
        toast.error('تعذر جلب البيانات مؤقتاً — جاري محاولة الاستعادة');
      }
    } catch (err) {
      setLoadFailed(true);
      toast.error('خطأ في تحميل البيانات — انقر إعادة المحاولة');
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [search, filterDiploma, filterStatus, filterMissingReg, stats]);

  useEffect(() => { fetchInitial(); }, [fetchInitial]);

  // دالة مساعدة لإعادة تحميل كامل القائمة المعروضة حالياً (بعد حذف / تعديل)
  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [statsRes, studentsRes, notifRes] = await Promise.allSettled([
        getDashboardStats(),
        getStudents({
          search: search || undefined,
          diplomaType: filterDiploma !== 'all' ? filterDiploma as 'عالي' | 'متوسط' : undefined,
          status: filterStatus !== 'all' ? filterStatus : undefined,
          missingRegistrationNumber: filterMissingReg ? true : undefined,
          limit: ITEMS_PER_PAGE * (page + 1),
          offset: 0,
        }),
        getNotifications(),
      ]);
      if (statsRes.status === 'fulfilled')   setStats(statsRes.value);
      if (studentsRes.status === 'fulfilled') {
        setStudents(studentsRes.value.data);
        setTotalCount(studentsRes.value.count);
      }
      if (notifRes.status === 'fulfilled') {
        setNotifications(notifRes.value.filter(n => !n.is_read).slice(0, 10));
      }
    } catch (err) {
      toast.error('خطأ في تحميل البيانات');
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [search, filterDiploma, filterStatus, filterMissingReg, page]);

  // عرض المزيد — يُضيف الصفحة التالية إلى القائمة الحالية
  const handleLoadMore = useCallback(async () => {
    setLoadingMore(true);
    try {
      const nextPage = page + 1;
      const studentsData = await getStudents({
        search: search || undefined,
        diplomaType: filterDiploma !== 'all' ? filterDiploma as 'عالي' | 'متوسط' : undefined,
        status: filterStatus !== 'all' ? filterStatus : undefined,
        missingRegistrationNumber: filterMissingReg ? true : undefined,
        limit: ITEMS_PER_PAGE,
        offset: nextPage * ITEMS_PER_PAGE,
      });
      setStudents(prev => [...prev, ...studentsData.data]);
      setPage(nextPage);
    } catch {
      toast.error('خطأ في تحميل المزيد');
    } finally {
      setLoadingMore(false);
    }
  }, [search, filterDiploma, filterStatus, filterMissingReg, page]);

  const handleDelete = async () => {
    if (!deleteTarget) return;
    if (deletePassword !== SYSTEM_PASSWORD) { setDeleteError('كلمة المرور غير صحيحة'); return; }
    setActionLoading(true);
    try {
      await deleteStudent(deleteTarget.id);
      toast.success(`تم حذف ملف ${deleteTarget.full_name} بنجاح`);
      setDeleteTarget(null); setDeletePassword(''); setDeleteError('');
      fetchData();
    } catch { toast.error('فشل في حذف الملف'); }
    finally { setActionLoading(false); }
  };

  const handleSuspend = async (student: Student) => {
    setActionLoading(true);
    try { await suspendStudent(student.id); toast.success(`تم إيقاف قيد ${student.full_name}`); fetchData(); }
    catch { toast.error('فشل في إيقاف القيد'); }
    finally { setActionLoading(false); }
  };

  const handleActivate = async (student: Student) => {
    setActionLoading(true);
    try { await activateStudent(student.id); toast.success(`تم تنشيط قيد ${student.full_name}`); fetchData(); }
    catch { toast.error('فشل في تنشيط القيد'); }
    finally { setActionLoading(false); }
  };

  const handlePromote = async () => {
    if (!promoteTarget) return;
    setActionLoading(true);
    try {
      const settings = await getSettings();
      const charges = await getSemesterCharges(promoteTarget.id);
      const maxChargeSem = charges
        .filter(c => c.charge_type === 'فصلي')
        .reduce((max, c) => Math.max(max, c.semester_number), 0);
      const activeSem = Math.max(promoteTarget.current_semester, maxChargeSem, 1);
      const targetSem = activeSem + 1;
      const maxSem = MAX_SEMESTERS[promoteTarget.diploma_type] ?? 6;
      if (activeSem >= maxSem) {
        toast.error(`الطالب ${promoteTarget.full_name} في الفصل الأخير — يجب الترحيل من صفحة "ترحيل الطلاب"`);
        setPromoteTarget(null);
        return;
      }
      await promoteStudent(promoteTarget, settings, targetSem);
      toast.success(`تم ترحيل ${promoteTarget.full_name} إلى ${SEMESTER_LABELS[targetSem] ?? `الفصل ${targetSem}`}`);
      setPromoteTarget(null); fetchData();
    } catch (err) { toast.error('فشل في ترحيل الطالب'); console.error(err); }
    finally { setActionLoading(false); }
  };

  const today = new Date().toLocaleDateString('ar-LY', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

  // ── دوال الأرشفة ──
  const handleDashArchiveSingle = async (student: Student) => {
    setArchivingId(student.id);
    try {
      await archiveStudent(student);
      toast.success(`تمت أرشفة ${student.full_name} بنجاح`);
      setPendingArchive(prev => prev.filter(s => s.id !== student.id));
      setSelectedForArchive(prev => { const n = new Set(prev); n.delete(student.id); return n; });
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : 'فشلت الأرشفة');
    } finally {
      setArchivingId(null);
      setArchiveConfirmStudent(null);
    }
  };

  const handleDashArchiveBatch = async (targets: Student[]) => {
    setArchivingAll(true);
    let ok = 0; const failed: string[] = [];
    for (const s of targets) {
      try {
        await archiveStudent(s);
        ok++;
        setPendingArchive(prev => prev.filter(x => x.id !== s.id));
      } catch { failed.push(s.full_name); }
    }
    setArchivingAll(false);
    setArchiveBatchConfirm(false);
    setSelectedForArchive(new Set());
    if (ok > 0) toast.success(`تمت أرشفة ${ok} طالب بنجاح`);
    if (failed.length > 0) toast.error(`فشلت أرشفة: ${failed.join('، ')}`);
  };

  const toggleDashSelect = (id: string) =>
    setSelectedForArchive(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });
  const toggleDashSelectAll = () =>
    setSelectedForArchive(
      selectedForArchive.size === pendingArchive.length ? new Set() : new Set(pendingArchive.map(s => s.id))
    );

  const statCards: { title: string; value: string | number; unit?: string; icon: React.ElementType; gradient: string; iconBg: string; subtitle: string; onClick?: () => void }[] = stats ? [
    {
      title: 'إجمالي الطلاب',
      value: stats.totalStudents,
      icon: Users,
      gradient: 'from-primary/90 to-primary',
      iconBg: 'bg-white/20',
      subtitle: 'إجمالي المسجلين',
    },
    {
      title: 'دبلوم عالي',
      value: stats.highDiplomaStudents,
      icon: GraduationCap,
      gradient: 'from-chart-2/80 to-chart-2',
      iconBg: 'bg-white/20',
      subtitle: 'طالب دبلوم عالي',
    },
    {
      title: 'دبلوم متوسط',
      value: stats.midDiplomaStudents,
      icon: BookOpen,
      gradient: 'from-chart-4/80 to-chart-4',
      iconBg: 'bg-white/20',
      subtitle: 'طالب دبلوم متوسط',
    },
    {
      title: 'نواقص الملفات',
      value: stats.studentsWithMissingDocs,
      icon: FolderX,
      gradient: 'from-destructive/80 to-destructive',
      iconBg: 'bg-white/20',
      subtitle: 'طالب لديه نواقص',
    },
    {
      title: 'بدون رقم قيد',
      value: stats.studentsWithoutRegistrationNumber ?? 0,
      icon: Hash,
      gradient: filterMissingReg ? 'from-amber-700 to-orange-800' : 'from-amber-600/90 to-amber-700',
      iconBg: 'bg-white/20',
      subtitle: 'يتطلب تعيين رقم قيد',
      onClick: () => {
        setFilterMissingReg(p => !p);
        setPage(0);
      },
    },
    {
      title: 'طلاب نشطون',
      value: stats.activeStudents,
      icon: UserCheck,
      gradient: 'from-chart-2/70 to-chart-2/90',
      iconBg: 'bg-white/20',
      subtitle: 'قيد نشط',
    },
    {
      title: 'موقوف قيدهم',
      value: stats.suspendedStudents,
      icon: UserX,
      gradient: 'from-warning/80 to-warning',
      iconBg: 'bg-white/20',
      subtitle: 'قيد موقوف',
    },
    {
      title: 'أرشيف الخريجين',
      value: stats.archivedStudents ?? 0,
      icon: Archive,
      gradient: 'from-[#1a3c5e]/80 to-[#1a3c5e]',
      iconBg: 'bg-white/20',
      subtitle: '+100 ألف طالب مدعوم',
    },
  ] : [];

  return (
    <MainLayout>
      <div className="space-y-4">

        {/* ── ترويسة لوحة التحكم ── */}
        {loadFailed && !loading && (
          <div className="bg-destructive/10 border border-destructive/30 rounded-xl p-4 flex items-center justify-between gap-3 text-destructive animate-in fade-in">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 shrink-0" />
              <span className="text-sm font-semibold">تعذر الاتصال بقاعدة البيانات مؤقتاً (جاري استيقاظ الخادم أو ضعف في الشبكة).</span>
            </div>
            <Button size="sm" variant="outline" onClick={() => fetchInitial()} className="shrink-0 gap-1.5 border-destructive/40 hover:bg-destructive/10">
              <RefreshCw className="w-4 h-4" />
              إعادة المحاولة الآن
            </Button>
          </div>
        )}

        <div className="relative rounded-2xl overflow-hidden shadow-lg border border-primary/20"
          style={{
            background: 'var(--gradient-hero, linear-gradient(135deg, #0e243d 0%, #163659 45%, #1a426d 100%))',
            boxShadow: 'var(--shadow-lg)'
          }}>
          {/* خلفية تدرجية غنية */}
          <div className="absolute inset-0 pointer-events-none"
            style={{ background: 'var(--gradient-hero, linear-gradient(135deg, #0e243d 0%, #163659 45%, #1a426d 100%))' }} />
          {/* طبقة نقاط */}
          <div className="absolute inset-0 opacity-[0.09]"
            style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '22px 22px' }} />
          {/* هوالات ضوئية زخرفية */}
          <div className="absolute -top-16 -right-16 w-48 h-48 bg-white/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-10 -left-10 w-36 h-36 bg-sky-400/15 rounded-full blur-2xl pointer-events-none" />

          <div className="relative px-5 py-5 md:px-7 md:py-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              {/* أيقونة البطاقة */}
              <div className="w-12 h-12 rounded-2xl bg-white/15 border border-white/25 flex items-center justify-center shrink-0 shadow-md">
                <BarChart3 className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl md:text-2xl font-black text-white leading-tight drop-shadow-sm">
                  لوحة التحكم الرئيسية
                </h1>
                <p className="text-white/85 text-xs mt-1 font-semibold">معهد القمة للعلوم الطبية والإدارية</p>
                <p className="text-white/60 text-[11px] mt-0.5">{today}</p>
              </div>
            </div>
            <div className="flex gap-2 no-print shrink-0">
              <Button variant="secondary" size="sm" onClick={() => navigate('/register')}
                className="gap-1.5 font-bold shadow-md h-9 text-xs">
                <ChevronUp className="w-3.5 h-3.5" />
                تسجيل طالب جديد
              </Button>
              <RefreshButton
                onRefresh={fetchData}
                loading={loading}
                variant="white"
                label="تحديث"
              />
            </div>
          </div>
        </div>

        {/* ── بطاقات الإحصائيات ── */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {loading
            ? Array.from({ length: 6 }).map((_, i) => (
                <Skeleton key={i} className="h-28 rounded-xl bg-muted" />
              ))
            : statCards.map((card, i) => {
                const Icon = card.icon;
                return (
                  <div
                    key={card.title}
                    onClick={card.onClick}
                    className={`relative rounded-xl overflow-hidden bg-gradient-to-br ${card.gradient} p-4 ${card.onClick ? 'cursor-pointer hover:scale-[1.02] active:scale-95 transition-all' : 'cursor-default'}`}
                    style={{
                      boxShadow: 'var(--shadow-hover)',
                      animation: `fade-up 0.45s ease-out ${i * 0.07}s both`,
                    }}
                  >
                    {/* دائرة زخرفية */}
                    <div className="absolute -bottom-5 -left-5 w-24 h-24 bg-black/10 rounded-full pointer-events-none" />
                    <div className="absolute -top-3 -right-3 w-16 h-16 bg-white/5 rounded-full pointer-events-none" />

                    <div className="relative flex items-start justify-between gap-2">
                      <div className="min-w-0 flex-1">
                        <p className="text-white/65 text-[11px] font-semibold leading-tight mb-1.5 tracking-wide uppercase">
                          {card.title}
                        </p>
                        <p className="text-white text-[1.6rem] font-black leading-none tabular-nums">
                          {card.value}
                          {card.unit && <span className="text-sm font-normal text-white/65 mr-1.5">{card.unit}</span>}
                        </p>
                        <p className="text-white/45 text-[10.5px] mt-2 leading-tight">{card.subtitle}</p>
                      </div>
                      <div className="w-10 h-10 rounded-xl bg-white/15 border border-white/20 flex items-center justify-center shrink-0 mt-0.5">
                        <Icon className="w-5 h-5 text-white" />
                      </div>
                    </div>
                  </div>
                );
              })}
        </div>

        {/* ── إشعار وتنبيه واضح: طلاب بدون رقم قيد ── */}
        {(stats?.studentsWithoutRegistrationNumber ?? 0) > 0 && (
          <div
            className={`relative rounded-2xl overflow-hidden border-2 transition-all p-4 shadow-md backdrop-blur-sm ${
              filterMissingReg
                ? 'border-amber-600 bg-amber-500/20 shadow-amber-500/20'
                : 'border-amber-500/40 bg-gradient-to-r from-amber-500/15 via-orange-500/10 to-amber-500/5'
            }`}
          >
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="relative w-11 h-11 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center shrink-0 shadow-md shadow-amber-500/30 text-white">
                  <Hash className="w-5 h-5" />
                  <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-red-500 border-2 border-white dark:border-card rounded-full animate-ping" />
                  <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-red-500 border-2 border-white dark:border-card rounded-full" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-sm font-black text-foreground">
                      تنبيه هام: طلاب مسجلون بدون رقم قيد
                    </h3>
                    <Badge className="bg-amber-500 hover:bg-amber-600 text-white font-bold text-[10px] animate-pulse">
                      مطلوب تعيين أرقام القيد
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    يوجد حالياً <strong className="text-amber-600 dark:text-amber-400 font-black">{stats?.studentsWithoutRegistrationNumber}</strong> طالب بحاجة إلى إدخال رقم القيد الأكاديمي لإكمال ملفاتهم وإصدار شهادات التعريف وكشوفات الامتحانات.
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto justify-end">
                <Button
                  size="sm"
                  onClick={() => {
                    setFilterMissingReg(p => !p);
                    setPage(0);
                  }}
                  className={`gap-1.5 text-xs font-bold transition-all shadow-sm ${
                    filterMissingReg
                      ? 'bg-amber-700 text-white hover:bg-amber-800'
                      : 'bg-amber-500 hover:bg-amber-600 text-white'
                  }`}
                >
                  <Hash className="w-3.5 h-3.5" />
                  {filterMissingReg ? 'إلغاء التصفية (عرض الكل)' : `تصفية هؤلاء الطلاب (${stats?.studentsWithoutRegistrationNumber})`}
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* ── التنبيهات والإشعارات ── */}
        {notifications.length > 0 && (
          <Card className="border-border/50 overflow-hidden notif-card" style={{ boxShadow: 'var(--shadow-card)' }}>
            {/* رأس التنبيهات */}
            <div className="relative px-5 py-4 border-b border-border/60 overflow-hidden"
              style={{ background: 'linear-gradient(135deg, hsl(var(--destructive)/0.08) 0%, hsl(var(--destructive)/0.03) 50%, transparent 100%)' }}>
              {/* خلفية نابضة زخرفية */}
              <div className="absolute inset-0 pointer-events-none">
                <div className="absolute top-0 right-0 w-32 h-32 rounded-full opacity-[0.06] animate-notif-blob"
                  style={{ background: 'radial-gradient(circle, hsl(var(--destructive)), transparent 70%)', transform: 'translate(30%, -30%)' }} />
              </div>

              <div className="relative flex items-center justify-between gap-3 flex-wrap">
                <div className="flex items-center gap-3">
                  {/* أيقونة الجرس مع تأثير النبض المزدوج */}
                  <div className="relative shrink-0">
                    {/* حلقات النبض */}
                    <span className="absolute inset-0 rounded-xl bg-destructive/20 animate-ping-slow" />
                    <span className="absolute inset-0 rounded-xl bg-destructive/10 animate-ping-slower" />
                    <div className="relative w-10 h-10 rounded-xl bg-gradient-to-br from-destructive/20 to-destructive/10 border border-destructive/30 flex items-center justify-center shadow-sm">
                      <Bell className="w-4 h-4 text-destructive animate-bell-ring" />
                    </div>
                    {/* عداد الإشعارات */}
                    <span className="absolute -top-2 -left-2 min-w-[20px] h-5 px-1.5 rounded-full bg-destructive text-white text-[10px] font-black flex items-center justify-center shadow-md animate-badge-pop" style={{ boxShadow: '0 0 0 2px hsl(var(--background)), 0 2px 8px hsl(var(--destructive)/0.4)' }}>
                      {notifications.length}
                    </span>
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-black text-foreground">التنبيهات والإشعارات</p>
                      {/* نقطة حية وامضة */}
                      <span className="relative flex h-2 w-2">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-destructive opacity-75" />
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-destructive" />
                      </span>
                    </div>
                    <p className="text-[11px] text-muted-foreground mt-0.5">{notifications.length} إشعار يحتاج مراجعتك</p>
                  </div>
                </div>

                <Button size="sm" variant="outline"
                  className="gap-1.5 h-8 text-xs border-destructive/25 text-destructive hover:bg-destructive hover:text-white hover:border-destructive transition-all font-semibold shadow-sm"
                  onClick={async () => { await markAllNotificationsRead(); setNotifications([]); }}>
                  <CheckCheck className="w-3.5 h-3.5" />
                  تعيين الكل كمقروء
                </Button>
              </div>
            </div>

            {/* قائمة الإشعارات */}
            <CardContent className="p-3 space-y-2">
              {notifications.map((notif, index) => {
                const isDebt    = notif.type === 'ديون_معلقة';
                const isFile    = notif.type === 'نواقص_ملف';
                const isProject = notif.type === 'مشروع_تخرج';

                const IconComponent = isDebt ? DollarSign : isFile ? FolderOpen : isProject ? GraduationCap : AlertTriangle;

                const color = isDebt
                  ? { bg: 'hsl(var(--destructive)/0.06)', border: 'hsl(var(--destructive)/0.2)', icon: 'hsl(var(--destructive))', iconBg: 'hsl(var(--destructive)/0.12)', label: 'text-destructive', dot: 'bg-destructive' }
                  : isFile
                  ? { bg: 'hsl(var(--warning)/0.06)',     border: 'hsl(var(--warning)/0.2)',     icon: 'hsl(var(--warning))',     iconBg: 'hsl(var(--warning)/0.12)',     label: 'text-warning',     dot: 'bg-warning'     }
                  : { bg: 'hsl(var(--chart-4)/0.06)',     border: 'hsl(var(--chart-4)/0.2)',     icon: 'hsl(var(--chart-4))',     iconBg: 'hsl(var(--chart-4)/0.12)',     label: 'text-chart-4',     dot: 'bg-chart-4'     };

                const label    = isDebt ? 'مديونية معلقة' : isFile ? 'نقص ملف' : isProject ? 'مشروع تخرج' : 'تنبيه';
                const timeAgo  = new Date(notif.created_at).toLocaleDateString('ar-LY', { month: 'short', day: 'numeric' });

                return (
                  <div
                    key={notif.id}
                    className="group relative flex items-start gap-3 p-3 rounded-xl border transition-all duration-200 hover:scale-[1.01] hover:shadow-sm cursor-default animate-notif-slide-in"
                    style={{
                      background: color.bg,
                      borderColor: color.border,
                      animationDelay: `${index * 60}ms`,
                      animationFillMode: 'both',
                    }}
                  >
                    {/* أيقونة النوع مع تأثير hover */}
                    <div className="relative shrink-0">
                      <div
                        className="w-9 h-9 rounded-xl flex items-center justify-center transition-transform duration-200 group-hover:scale-110"
                        style={{ background: color.iconBg, color: color.icon }}>
                        <IconComponent className="w-4 h-4" />
                      </div>
                      {/* نقطة نوع صغيرة */}
                      <span className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-card ${color.dot}`} />
                    </div>

                    {/* المحتوى */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <span className={`text-[10px] font-black tracking-wider uppercase ${color.label}`}>{label}</span>
                        {notif.student && (
                          <button
                            onClick={() => navigate(`/student/${notif.student!.id}`)}
                            className={`text-[11px] font-bold underline underline-offset-2 transition-opacity hover:opacity-100 opacity-75 ${color.label}`}>
                            {notif.student.full_name}
                          </button>
                        )}
                      </div>
                      <p className="text-xs font-medium leading-relaxed text-foreground/80">{notif.message}</p>
                    </div>

                    {/* الوقت */}
                    <div className="flex flex-col items-end gap-1 shrink-0">
                      <div className="flex items-center gap-1 opacity-50">
                        <Clock className="w-3 h-3" />
                        <span className="text-[10px] font-medium">{timeAgo}</span>
                      </div>
                      {/* مؤشر "جديد" وامض */}
                      <span className={`text-[9px] font-black px-1.5 py-0.5 rounded-full text-white animate-notif-new-pulse ${isDebt ? 'bg-destructive' : isFile ? 'bg-warning' : 'bg-chart-4'}`}>
                        جديد
                      </span>
                    </div>

                    {/* خط جانبي ملون */}
                    <div
                      className="absolute right-0 top-2 bottom-2 w-0.5 rounded-full"
                      style={{ background: color.icon, opacity: 0.5 }}
                    />
                  </div>
                );
              })}
            </CardContent>
          </Card>
        )}

        {/* ── widget الأرشفة — يظهر فقط عند وجود طلاب ── */}
        {pendingArchive.length > 0 && (
          <div className="animate-in fade-in-0 slide-in-from-top-2 duration-200">
            <div className="rounded-2xl border border-emerald-300/50 dark:border-emerald-600/40 bg-white dark:bg-card shadow-sm overflow-hidden">
              {/* رأس القسم */}
              <button
                onClick={() => setArchivePanelOpen(v => !v)}
                className="w-full flex items-center justify-between px-5 py-3.5 bg-gradient-to-l from-emerald-50/80 to-emerald-100/40 dark:from-emerald-950/60 dark:to-emerald-900/30 hover:from-emerald-100/80 hover:to-emerald-50/60 transition-colors border-b border-emerald-200/50 dark:border-emerald-700/40"
              >
                <div className="flex items-center gap-3">
                  <div className="relative shrink-0">
                    <div className="w-9 h-9 rounded-xl bg-emerald-500 flex items-center justify-center shadow-sm shadow-emerald-300/50">
                      <FolderOpen className="w-[18px] h-[18px] text-white" />
                    </div>
                    <span className="absolute -top-1.5 -left-1.5 min-w-[18px] h-[18px] bg-amber-400 text-white text-[9px] font-black rounded-full flex items-center justify-center px-1 shadow border border-white dark:border-card">
                      {pendingArchive.length}
                    </span>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-foreground leading-tight">طلاب جاهزون للأرشفة</p>
                    <p className="text-[10px] text-muted-foreground mt-0.5">
                      {pendingArchive.length} طالب أكملوا السداد — يمكن أرشفتهم الآن
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {selectedForArchive.size > 0 ? (
                    <button
                      onClick={e => { e.stopPropagation(); setArchiveBatchConfirm(true); }}
                      disabled={archivingAll}
                      className="hidden md:inline-flex items-center gap-1.5 text-[10px] font-bold px-3 py-1.5 rounded-xl bg-emerald-500 text-white hover:bg-emerald-600 active:scale-95 transition-all disabled:opacity-60 shadow-sm"
                    >
                      {archivingAll ? <RefreshCw className="w-3 h-3 animate-spin" /> : <FolderOpen className="w-3 h-3" />}
                      أرشفة المختارين ({selectedForArchive.size})
                    </button>
                  ) : (
                    <button
                      onClick={e => { e.stopPropagation(); setArchiveBatchConfirm(true); }}
                      disabled={archivingAll}
                      className="hidden md:inline-flex items-center gap-1.5 text-[10px] font-bold px-3 py-1.5 rounded-xl bg-emerald-500 text-white hover:bg-emerald-600 active:scale-95 transition-all disabled:opacity-60 shadow-sm"
                    >
                      {archivingAll ? <RefreshCw className="w-3 h-3 animate-spin" /> : <FolderOpen className="w-3 h-3" />}
                      أرشفة الكل
                    </button>
                  )}
                  <ChevronUp
                    className="w-4 h-4 text-emerald-600 dark:text-emerald-400 transition-transform duration-200"
                    style={{ transform: archivePanelOpen ? 'rotate(0deg)' : 'rotate(180deg)' }}
                  />
                </div>
              </button>

              {/* قائمة الطلاب — accordion بـ CSS */}
              <div
                className="overflow-hidden transition-all duration-300"
                style={{ maxHeight: archivePanelOpen ? '2000px' : '0px', opacity: archivePanelOpen ? 1 : 0 }}
              >
                <div className="p-4">
                  {/* شريط تحديد الكل */}
                  <div className="flex items-center justify-between mb-3 gap-2">
                    <button
                      onClick={toggleDashSelectAll}
                      className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-emerald-700 dark:text-emerald-300 hover:underline"
                    >
                      <span
                        className={`inline-flex items-center justify-center rounded border-2 transition-all ${selectedForArchive.size === pendingArchive.length ? 'bg-emerald-500 border-emerald-500' : 'border-emerald-400 bg-white dark:bg-transparent'}`}
                        style={{ width: '16px', height: '16px' }}
                      >
                        {selectedForArchive.size === pendingArchive.length && (
                          <svg viewBox="0 0 12 12" className="w-2.5 h-2.5 text-white fill-current">
                            <path d="M2 6l3 3 5-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none" />
                          </svg>
                        )}
                      </span>
                      {selectedForArchive.size === pendingArchive.length ? 'إلغاء تحديد الكل' : 'تحديد الكل'}
                    </button>
                    {selectedForArchive.size > 0 && (
                      <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold">
                        {selectedForArchive.size} طالب محدد
                      </span>
                    )}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
                    {pendingArchive.map((s) => (
                      <div key={s.id} className="animate-in fade-in-0 duration-200">
                        {/* بطاقة طالب — تدرج ملون احترافي */}
                        {(() => {
                          const isHigh = s.diploma_type === 'عالي';
                          return (
                            <div className={`group relative rounded-2xl overflow-hidden transition-all duration-200
                              ${selectedForArchive.has(s.id)
                                ? 'ring-2 ring-offset-2 ring-emerald-500 shadow-lg scale-[1.01]'
                                : 'hover:shadow-lg hover:scale-[1.01]'
                              }`}
                            >
                              {/* خلفية تدرجية */}
                              <div className={`absolute inset-0 ${isHigh
                                ? 'bg-gradient-to-br from-blue-600 via-blue-500 to-indigo-600'
                                : 'bg-gradient-to-br from-teal-500 via-emerald-500 to-cyan-600'}`}
                              />
                              {/* طبقة نقاط زخرفية */}
                              <div className="absolute inset-0 opacity-[0.07]"
                                style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '16px 16px' }} />
                              <div className="absolute -top-6 -right-6 w-24 h-24 bg-white/10 rounded-full blur-2xl pointer-events-none" />

                              {/* checkbox */}
                              <button
                                onClick={() => toggleDashSelect(s.id)}
                                className={`absolute top-3 left-3 z-10 rounded-md border-2 flex items-center justify-center transition-all
                                  ${selectedForArchive.has(s.id) ? 'bg-white border-white' : 'border-white/60 bg-white/10 hover:bg-white/20'}`}
                                style={{ width: '18px', height: '18px' }}
                              >
                                {selectedForArchive.has(s.id) && (
                                  <svg viewBox="0 0 12 12" style={{ width: '10px', height: '10px' }}>
                                    <path d="M2 6l3 3 5-5" stroke={isHigh ? '#2563eb' : '#10b981'} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" fill="none" />
                                  </svg>
                                )}
                              </button>

                              <div className="relative p-4 flex flex-col gap-3">
                                {/* صورة + اسم */}
                                <div className="flex items-center gap-3">
                                  <div className="shrink-0 rounded-full p-0.5 bg-white/30 shadow-md">
                                    <StudentAvatar name={s.full_name} photoUrl={s.photo_url ?? undefined} size="sm" />
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <p className="text-sm font-black text-white leading-snug break-words drop-shadow-sm">{s.full_name}</p>
                                    <span className="inline-flex items-center gap-1 bg-white/20 border border-white/30 text-white text-[9px] font-bold px-2 py-0.5 rounded-full mt-0.5">
                                      <CheckCheck className="w-2.5 h-2.5" />مكتمل السداد
                                    </span>
                                  </div>
                                </div>
                                {/* badges */}
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <span className="inline-flex items-center gap-1 bg-white/15 border border-white/25 text-white text-[10px] font-semibold px-2 py-1 rounded-lg">
                                    <GraduationCap className="w-3 h-3" />{s.diploma_type}
                                  </span>
                                  <span className="inline-flex items-center gap-1 bg-white/15 border border-white/25 text-white text-[10px] px-2 py-1 rounded-lg truncate max-w-[120px]">
                                    {s.specialization}
                                  </span>
                                  <span className="inline-flex items-center gap-1 bg-white/15 border border-white/25 text-white text-[10px] px-2 py-1 rounded-lg">
                                    <BookOpen className="w-3 h-3" />
                                    {SEMESTER_LABELS[s.current_semester] ?? `الفصل ${s.current_semester}`}
                                  </span>
                                </div>
                                {/* زر أرشفة */}
                                <button
                                  onClick={() => setArchiveConfirmStudent(s)}
                                  disabled={archivingId === s.id}
                                  className="w-full inline-flex items-center justify-center gap-2 text-[11px] font-black py-2 rounded-xl bg-white/90 hover:bg-white active:scale-95 transition-all disabled:opacity-60 shadow-md"
                                  style={{ color: isHigh ? '#1d4ed8' : '#059669' }}
                                >
                                  {archivingId === s.id ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <FolderOpen className="w-3.5 h-3.5" />}
                                  {archivingId === s.id ? 'جارٍ الأرشفة…' : 'أرشفة هذا الطالب'}
                                </button>
                              </div>
                            </div>
                          );
                        })()}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ── جدول متابعة الطلاب ── */}
        <Card className="border-border/50 overflow-hidden" style={{ boxShadow: 'var(--shadow-card)' }}>
          {/* رأس القسم */}
          <div className="px-4 py-3.5 border-b border-border/60"
            style={{ background: 'linear-gradient(to left, hsl(var(--primary)/0.04), transparent)' }}>
            <div className="flex items-center justify-between flex-wrap gap-2 mb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
                  <Users className="w-3.5 h-3.5 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-bold text-foreground">جدول متابعة الطلاب</p>
                  {!loading && totalCount > 0 && (
                    <p className="text-[11px] text-muted-foreground">{totalCount} طالب مسجل</p>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                {/* تبديل وضع العرض */}
                <div className="flex items-center rounded-lg border border-border/60 bg-muted/50 p-0.5 gap-0.5">
                  <button
                    onClick={() => setViewMode('table')}
                    title="عرض جدول"
                    className={`flex items-center justify-center w-7 h-7 rounded-md transition-all ${viewMode === 'table' ? 'bg-primary text-primary-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}>
                    <LayoutList className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setViewMode('grid')}
                    title="عرض شبكة"
                    className={`flex items-center justify-center w-7 h-7 rounded-md transition-all ${viewMode === 'grid' ? 'bg-primary text-primary-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}>
                    <LayoutGrid className="w-3.5 h-3.5" />
                  </button>
                </div>
                <Button size="sm" onClick={() => navigate('/register')}
                  className="gap-1.5 h-8 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold text-xs">
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span className="hidden md:inline">تسجيل طالب جديد</span>
                  <span className="md:hidden">جديد</span>
                </Button>
              </div>
            </div>
            {/* فلاتر البحث */}
            <div className="flex flex-col md:flex-row gap-2">
              <Input
                placeholder="بحث بالاسم أو الرقم الوطني أو رقم القيد..."
                value={searchInput}
                onChange={(e) => {
                  const v = e.target.value;
                  setSearchInput(v);
                  if (searchTimer.current) clearTimeout(searchTimer.current);
                  searchTimer.current = setTimeout(() => { setSearch(v); setPage(0); }, SEARCH_DEBOUNCE);
                }}
                className="flex-1 text-sm h-8"
              />
              <Button
                size="sm"
                variant={filterMissingReg ? 'default' : 'outline'}
                onClick={() => { setFilterMissingReg(p => !p); setPage(0); }}
                className={`h-8 text-xs gap-1.5 shrink-0 ${filterMissingReg ? 'bg-amber-600 hover:bg-amber-700 text-white border-amber-600' : 'border-amber-500/40 text-amber-700 dark:text-amber-400 hover:bg-amber-500/10'}`}
              >
                <Hash className="w-3.5 h-3.5" />
                <span>بدون رقم قيد</span>
                {(stats?.studentsWithoutRegistrationNumber ?? 0) > 0 && (
                  <span className="bg-amber-500 text-white text-[10px] px-1 py-0.2 rounded-full font-bold">
                    {stats?.studentsWithoutRegistrationNumber}
                  </span>
                )}
              </Button>
              <Select value={filterDiploma} onValueChange={(v) => { setFilterDiploma(v); setPage(0); }}>
                <SelectTrigger className="w-full md:w-40 h-8 text-xs">
                  <SelectValue placeholder="نوع الدبلوم" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الدبلومات</SelectItem>
                  <SelectItem value="عالي">دبلوم عالي</SelectItem>
                  <SelectItem value="متوسط">دبلوم متوسط</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterStatus} onValueChange={(v) => { setFilterStatus(v); setPage(0); }}>
                <SelectTrigger className="w-full md:w-36 h-8 text-xs">
                  <SelectValue placeholder="الحالة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الحالات</SelectItem>
                  <SelectItem value="نشط">نشط</SelectItem>
                  <SelectItem value="موقوف قيد">موقوف قيد</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <CardContent className="p-0">
            {loading ? (
              /* هيكل تحميل — يتكيف مع وضع العرض */
              <div className="p-3 space-y-1.5">
                {Array.from({ length: 8 }).map((_, i) => (
                  <Skeleton key={i} className="h-10 w-full bg-muted rounded-lg" />
                ))}
              </div>
            ) : students.length === 0 ? (
              <div className="text-center py-14 text-muted-foreground">
                <div className="w-14 h-14 rounded-2xl bg-muted mx-auto mb-3 flex items-center justify-center">
                  <Users className="w-7 h-7 opacity-30" />
                </div>
                <p className="text-sm font-semibold">لا يوجد طلاب مسجلون</p>
                <p className="text-xs mt-1 opacity-60">جرب تغيير معايير البحث أو أضف طالباً جديداً</p>
              </div>
            ) : viewMode === 'table' ? (
              /* ── وضع الجدول ── */
              <div className="w-full overflow-x-auto">
                <table className="w-full min-w-[640px] border-collapse">
                  <thead>
                    <tr className="border-b border-border/60 bg-muted/40">
                      <th className="text-right text-[11px] font-semibold text-muted-foreground px-3 py-2 whitespace-nowrap">#</th>
                      <th className="text-right text-[11px] font-semibold text-muted-foreground px-3 py-2 whitespace-nowrap">الطالب</th>
                      <th className="text-right text-[11px] font-semibold text-muted-foreground px-3 py-2 whitespace-nowrap">الدبلوم</th>
                      <th className="text-right text-[11px] font-semibold text-muted-foreground px-3 py-2 whitespace-nowrap">الفصل</th>
                      <th className="text-right text-[11px] font-semibold text-muted-foreground px-3 py-2 whitespace-nowrap">الحالة</th>
                      <th className="text-right text-[11px] font-semibold text-muted-foreground px-3 py-2 whitespace-nowrap">المديونية</th>
                      <th className="text-center text-[11px] font-semibold text-muted-foreground px-3 py-2 whitespace-nowrap">إجراءات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {students.map((student, idx) => {
                      const debt = student.total_charged - student.total_paid;
                      const isActive = student.status === 'نشط';
                      const semLabel = SEMESTER_LABELS[student.current_semester] ?? `${student.current_semester}`;
                      return (
                        <tr
                          key={student.id}
                          onClick={() => navigate(`/student/${student.id}`)}
                          className="border-b border-border/40 hover:bg-primary/5 cursor-pointer transition-colors group"
                        >
                          {/* رقم */}
                          <td className="px-3 py-2 whitespace-nowrap">
                            <span className="text-[11px] font-mono text-muted-foreground/50">{idx + 1}</span>
                          </td>
                          {/* الطالب: صورة + اسم + رقم وطني */}
                          <td className="px-3 py-2 whitespace-nowrap">
                            <div className="flex items-center gap-2">
                              <div className="relative shrink-0">
                                <StudentAvatar photoUrl={student.photo_url} name={student.full_name} size="sm" variant="circle" />
                                <span className={`absolute -bottom-0.5 -left-0.5 w-2.5 h-2.5 rounded-full border-2 border-background ${isActive ? 'bg-chart-2' : 'bg-warning'}`} />
                              </div>
                              <div className="min-w-0">
                                <div className="flex items-center gap-1.5">
                                  <p className="text-xs font-semibold text-foreground truncate max-w-[140px]">{student.full_name}</p>
                                  {student.is_equivalency && (
                                    <span className="text-[9px] font-bold text-chart-4 bg-chart-4/10 border border-chart-4/20 px-1 py-0.5 rounded-full shrink-0">معادلة</span>
                                  )}
                                </div>
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <p className="text-[10px] font-mono text-muted-foreground">{student.national_id}</p>
                                  {student.registration_number ? (
                                    <span className="inline-flex items-center gap-0.5 text-[9px] font-mono font-bold text-primary bg-primary/10 border border-primary/25 px-1.5 py-0.2 rounded">
                                      قيد: {student.registration_number}
                                    </span>
                                  ) : (
                                    <span className="inline-flex items-center gap-1 text-[8.5px] font-bold text-amber-600 dark:text-amber-400 bg-amber-500/15 border border-amber-500/30 px-1.5 py-0.2 rounded-full animate-pulse">
                                      <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                                      بدون قيد
                                    </span>
                                  )}
                                </div>
                              </div>
                            </div>
                          </td>
                          {/* الدبلوم + التخصص */}
                          <td className="px-3 py-2 whitespace-nowrap">
                            <div className="flex flex-col gap-0.5">
            <span className={`text-[11px] font-semibold ${student.diploma_type === 'عالي' ? 'text-blue-700 dark:text-blue-400' : 'text-emerald-600 dark:text-emerald-400'}`}>{student.diploma_type}</span>
                              <span className="text-[10px] text-muted-foreground truncate max-w-[100px]">{student.specialization}</span>
                            </div>
                          </td>
                          {/* الفصل */}
                          <td className="px-3 py-2 whitespace-nowrap">
                            <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-primary bg-primary/8 px-2 py-0.5 rounded-md border border-primary/20">
                              <GraduationCap className="w-2.5 h-2.5 shrink-0" />
                              {semLabel}
                            </span>
                          </td>
                          {/* الحالة */}
                          <td className="px-3 py-2 whitespace-nowrap">
                            <span className={`inline-flex items-center gap-1 text-[10.5px] font-bold px-2 py-0.5 rounded-full border ${
                              isActive ? 'bg-chart-2/10 text-chart-2 border-chart-2/25' : 'bg-warning/10 text-warning border-warning/25'
                            }`}>
                              <span className={`w-1.5 h-1.5 rounded-full ${isActive ? 'bg-chart-2' : 'bg-warning'}`} />
                              {student.status}
                            </span>
                          </td>
                          {/* المديونية */}
                          <td className="px-3 py-2 whitespace-nowrap">
                            {debt > 0 ? (
                              <span className="inline-flex items-center gap-1 text-[10.5px] font-bold text-destructive bg-destructive/8 px-2 py-0.5 rounded-full border border-destructive/20">
                                <AlertTriangle className="w-2.5 h-2.5 shrink-0" />
                                {debt.toFixed(0)} د.ل
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 text-[10.5px] font-bold text-chart-2 bg-chart-2/8 px-2 py-0.5 rounded-full border border-chart-2/20">
                                ✓ مسدد
                              </span>
                            )}
                          </td>
                          {/* أزرار الإجراءات */}
                          <td className="px-3 py-2 whitespace-nowrap" onClick={e => e.stopPropagation()}>
                            <div className="flex items-center justify-center gap-1">
                              <button onClick={() => navigate(`/student/${student.id}`)}
                                className="h-7 w-7 rounded-md flex items-center justify-center bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground transition-all border border-primary/20"
                                title="عرض الملف"><Eye className="w-3 h-3" /></button>
                              <button onClick={() => navigate(`/student/${student.id}?edit=true`)}
                                className="h-7 w-7 rounded-md flex items-center justify-center bg-warning/10 text-warning hover:bg-warning hover:text-white transition-all border border-warning/20"
                                title="تعديل"><Edit className="w-3 h-3" /></button>
                              {student.current_semester < 6 && isActive && (
                                <button onClick={() => setPromoteTarget(student)}
                                  className="h-7 w-7 rounded-md flex items-center justify-center bg-chart-2/10 text-chart-2 hover:bg-chart-2 hover:text-white transition-all border border-chart-2/20"
                                  title="ترحيل للفصل التالي"><ChevronUp className="w-3 h-3" /></button>
                              )}
                              {isActive ? (
                                <button onClick={() => handleSuspend(student)} disabled={actionLoading}
                                  className="h-7 w-7 rounded-md flex items-center justify-center bg-warning/10 text-warning hover:bg-warning hover:text-white transition-all border border-warning/20 disabled:opacity-40"
                                  title="إيقاف القيد"><PauseCircle className="w-3 h-3" /></button>
                              ) : (
                                <button onClick={() => handleActivate(student)} disabled={actionLoading}
                                  className="h-7 w-7 rounded-md flex items-center justify-center bg-chart-2/10 text-chart-2 hover:bg-chart-2 hover:text-white transition-all border border-chart-2/20 disabled:opacity-40"
                                  title="تنشيط القيد"><PlayCircle className="w-3 h-3" /></button>
                              )}
                              <button onClick={() => { setDeleteTarget(student); setDeletePassword(''); setDeleteError(''); }}
                                className="h-7 w-7 rounded-md flex items-center justify-center bg-destructive/10 text-destructive hover:bg-destructive hover:text-white transition-all border border-destructive/20"
                                title="حذف"><Trash2 className="w-3 h-3" /></button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            ) : (
              /* ── وضع الشبكة — بطاقات مضغوطة ── */
              <div className="p-3 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-2">
                {students.map((student, idx) => {
                  const debt = student.total_charged - student.total_paid;
                  const isActive = student.status === 'نشط';
                  const semLabel = SEMESTER_LABELS[student.current_semester] ?? `الفصل ${student.current_semester}`;
                  return (
                    <div
                      key={student.id}
                      onClick={() => navigate(`/student/${student.id}`)}
                      className="group flex items-center gap-2.5 rounded-lg border border-border/50 bg-card hover:border-primary/30 hover:shadow-sm transition-all duration-150 cursor-pointer px-3 py-2.5 overflow-hidden"
                    >
                      {/* نقطة الحالة + الصورة */}
                      <div className="relative shrink-0">
                        <StudentAvatar photoUrl={student.photo_url} name={student.full_name} size="sm" variant="circle" />
                        <span className={`absolute -bottom-0.5 -left-0.5 w-2.5 h-2.5 rounded-full border-2 border-card ${isActive ? 'bg-chart-2' : 'bg-warning'}`} />
                      </div>
                      {/* الاسم + معلومات */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 mb-0.5">
                          <p className="text-xs font-bold text-foreground truncate">{student.full_name}</p>
                          {student.is_equivalency && (
                            <span className="text-[9px] font-bold text-chart-4 bg-chart-4/10 border border-chart-4/20 px-1 rounded-full shrink-0">معادلة</span>
                          )}
                        </div>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-[10px] text-muted-foreground font-mono">{student.national_id}</span>
                          {student.registration_number ? (
                            <span className="text-[9px] font-mono font-bold text-primary bg-primary/10 border border-primary/25 px-1.5 py-0.2 rounded">
                              قيد: {student.registration_number}
                            </span>
                          ) : (
                            <span className="text-[8.5px] font-bold text-amber-600 dark:text-amber-400 bg-amber-500/15 border border-amber-500/30 px-1.5 py-0.2 rounded-full animate-pulse">
                              بدون قيد
                            </span>
                          )}
                          <span className="text-[10px] font-semibold text-primary">{semLabel}</span>
                          <span className={`text-[10px] font-semibold ${student.diploma_type === 'عالي' ? 'text-blue-700 dark:text-blue-400' : 'text-emerald-600 dark:text-emerald-400'}`}>{student.diploma_type}</span>
                        </div>
                      </div>
                      {/* المديونية */}
                      <div className="shrink-0 flex flex-col items-end gap-1">
                        {debt > 0 ? (
                          <span className="text-[10px] font-bold text-destructive">{debt.toFixed(0)} د.ل</span>
                        ) : (
                          <span className="text-[10px] font-bold text-chart-2">✓</span>
                        )}
                        {/* أزرار مضغوطة */}
                        <div className="flex items-center gap-1" onClick={e => e.stopPropagation()}>
                          <button onClick={() => navigate(`/student/${student.id}`)}
                            className="h-6 w-6 rounded flex items-center justify-center bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground transition-all"
                            title="عرض"><Eye className="w-2.5 h-2.5" /></button>
                          <button onClick={() => navigate(`/student/${student.id}?edit=true`)}
                            className="h-6 w-6 rounded flex items-center justify-center bg-warning/10 text-warning hover:bg-warning hover:text-white transition-all"
                            title="تعديل"><Edit className="w-2.5 h-2.5" /></button>
                          {student.current_semester < 6 && isActive && (
                            <button onClick={() => setPromoteTarget(student)}
                              className="h-6 w-6 rounded flex items-center justify-center bg-chart-2/10 text-chart-2 hover:bg-chart-2 hover:text-white transition-all"
                              title="ترحيل"><ChevronUp className="w-2.5 h-2.5" /></button>
                          )}
                          <button onClick={() => { setDeleteTarget(student); setDeletePassword(''); setDeleteError(''); }}
                            className="h-6 w-6 rounded flex items-center justify-center bg-destructive/10 text-destructive hover:bg-destructive hover:text-white transition-all"
                            title="حذف"><Trash2 className="w-2.5 h-2.5" /></button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* عرض المزيد */}
            {students.length < totalCount && (
              <div className="flex items-center justify-between px-4 py-2.5 border-t border-border/40 bg-muted/20">
                <p className="text-[11px] text-muted-foreground">
                  يُعرض <span className="font-bold text-foreground">{students.length}</span> من <span className="font-bold text-foreground">{totalCount}</span> طالب
                </p>
                <Button size="sm" variant="outline" onClick={handleLoadMore} disabled={loadingMore}
                  className="h-7 text-xs font-semibold px-4 border-primary/30 text-primary hover:bg-primary hover:text-primary-foreground transition-all">
                  {loadingMore ? (
                    <span className="flex items-center gap-1.5">
                      <span className="w-3 h-3 border-2 border-primary/40 border-t-primary rounded-full animate-spin" />
                      جارٍ التحميل...
                    </span>
                  ) : `عرض المزيد (${totalCount - students.length})`}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* حوار حذف الملف */}
      <Dialog open={!!deleteTarget} onOpenChange={(o) => { if (!o) { setDeleteTarget(null); setDeletePassword(''); setDeleteError(''); } }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-destructive flex items-center gap-2">
              <Trash2 className="w-5 h-5" /> حذف ملف الطالب
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">
              سيتم حذف ملف <strong>{deleteTarget?.full_name}</strong> نهائياً من قاعدة البيانات. هذا الإجراء لا يمكن التراجع عنه.
            </p>
            <div className="space-y-1">
              <Label className="text-sm font-medium">كلمة المرور الأمنية</Label>
              <Input type="password" placeholder="أدخل الرمز السري" value={deletePassword}
                onChange={(e) => { setDeletePassword(e.target.value); setDeleteError(''); }} className="text-sm" />
              {deleteError && <p className="text-xs text-destructive">{deleteError}</p>}
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => { setDeleteTarget(null); setDeletePassword(''); setDeleteError(''); }}>إلغاء</Button>
            <Button variant="destructive" onClick={handleDelete} disabled={actionLoading}>
              {actionLoading ? 'جاري الحذف...' : 'حذف نهائي'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* حوار الترحيل */}
      <AlertDialog open={!!promoteTarget} onOpenChange={(o) => { if (!o) setPromoteTarget(null); }}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <ChevronUp className="w-5 h-5 text-chart-2" /> ترحيل الطالب
            </AlertDialogTitle>
            <AlertDialogDescription>
              سيتم ترحيل الطالب <strong>{promoteTarget?.full_name}</strong> من{' '}
              {SEMESTER_LABELS[promoteTarget?.current_semester ?? 1]} إلى{' '}
              {SEMESTER_LABELS[(promoteTarget?.current_semester ?? 1) + 1]}.
              {(promoteTarget?.total_charged ?? 0) > (promoteTarget?.total_paid ?? 0) && (
                <span className="block mt-1 text-warning font-medium">
                  ⚠️ لديه مديونية معلقة بقيمة {((promoteTarget?.total_charged ?? 0) - (promoteTarget?.total_paid ?? 0)).toFixed(0)} دينار
                </span>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction onClick={handlePromote} disabled={actionLoading}
              className="bg-chart-2 text-white hover:bg-chart-2/90">
              {actionLoading ? 'جاري الترحيل...' : 'تأكيد الترحيل'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ── نوافذ تأكيد الأرشفة ── */}
      {/* فردية */}
      <AlertDialog open={!!archiveConfirmStudent} onOpenChange={o => { if (!o) setArchiveConfirmStudent(null); }}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm">
          <AlertDialogHeader className="gap-3">
            <div className="mx-auto w-14 h-14 rounded-2xl bg-emerald-50 dark:bg-emerald-900/40 border border-emerald-200/60 flex items-center justify-center">
              <FolderOpen className="w-7 h-7 text-emerald-500" />
            </div>
            <AlertDialogTitle className="text-center text-base font-bold">تأكيد الأرشفة</AlertDialogTitle>
            <AlertDialogDescription className="text-center space-y-1">
              <span className="block text-foreground font-bold text-sm">{archiveConfirmStudent?.full_name}</span>
              <span className="block text-muted-foreground text-xs">سيُنقل هذا الطالب إلى الأرشيف بشكل نهائي. لا يمكن التراجع عنه.</span>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="gap-2 flex-col sm:flex-row">
            <AlertDialogCancel disabled={!!archivingId} className="w-full sm:w-auto">إلغاء</AlertDialogCancel>
            <AlertDialogAction
              disabled={!!archivingId}
              onClick={() => { if (archiveConfirmStudent) handleDashArchiveSingle(archiveConfirmStudent); }}
              className="w-full sm:w-auto bg-emerald-500 hover:bg-emerald-600 text-white inline-flex items-center justify-center gap-2"
            >
              {archivingId ? <><RefreshCw className="w-4 h-4 animate-spin" />جارٍ الأرشفة…</> : <><FolderOpen className="w-4 h-4" />تأكيد الأرشفة</>}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* جماعية */}
      <AlertDialog open={archiveBatchConfirm} onOpenChange={o => { if (!o) setArchiveBatchConfirm(false); }}>
        <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <AlertDialogHeader className="gap-3">
            <div className="mx-auto w-14 h-14 rounded-2xl bg-emerald-50 dark:bg-emerald-900/40 border border-emerald-200/60 flex items-center justify-center">
              <FolderOpen className="w-7 h-7 text-emerald-500" />
            </div>
            <AlertDialogTitle className="text-center text-base font-bold">
              {selectedForArchive.size > 0 && selectedForArchive.size < pendingArchive.length
                ? `أرشفة ${selectedForArchive.size} طلاب محددين`
                : `أرشفة جميع الطلاب (${pendingArchive.length})`}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-center text-xs text-muted-foreground">
              سيُنقل هؤلاء الطلاب إلى الأرشيف نهائياً — لا يمكن التراجع عنه.
            </AlertDialogDescription>
          </AlertDialogHeader>
          {/* قائمة الطلاب */}
          <div className="max-h-48 overflow-y-auto rounded-xl border border-emerald-200/60 dark:border-emerald-700/40 divide-y divide-emerald-100/60 dark:divide-emerald-800/40 bg-emerald-50/40 dark:bg-emerald-950/30">
            {(selectedForArchive.size > 0
              ? pendingArchive.filter(s => selectedForArchive.has(s.id))
              : pendingArchive
            ).map(s => (
              <div key={s.id} className="flex items-center gap-2.5 px-3 py-2">
                <StudentAvatar name={s.full_name} photoUrl={s.photo_url ?? undefined} size="xs" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold text-foreground leading-tight">{s.full_name}</p>
                  <p className="text-[10px] text-muted-foreground">{s.diploma_type} · {s.specialization}</p>
                </div>
                <span className="text-[9px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-100 dark:bg-emerald-900/50 px-1.5 py-0.5 rounded-full shrink-0">مكتمل</span>
              </div>
            ))}
          </div>
          <AlertDialogFooter className="gap-2 flex-col sm:flex-row">
            <AlertDialogCancel disabled={archivingAll} className="w-full sm:w-auto">إلغاء</AlertDialogCancel>
            <AlertDialogAction
              disabled={archivingAll}
              onClick={() => {
                const targets = selectedForArchive.size > 0
                  ? pendingArchive.filter(s => selectedForArchive.has(s.id))
                  : pendingArchive;
                handleDashArchiveBatch(targets);
              }}
              className="w-full sm:w-auto bg-emerald-500 hover:bg-emerald-600 text-white inline-flex items-center justify-center gap-2"
            >
              {archivingAll ? <><RefreshCw className="w-4 h-4 animate-spin" />جارٍ الأرشفة…</> : <><FolderOpen className="w-4 h-4" />تأكيد الأرشفة</>}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </MainLayout>
  );
}
