import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type { DeviceRole, DeviceRolePermissions } from '@/types/index';
import { SYSTEM_PASSWORD } from '@/types/index';
import { getDeviceRoles, upsertDeviceRole, deleteDeviceRole } from '@/lib/api';

const DEVICE_ROLE_STORAGE_KEY = 'al_qimma_device_role_id';

// دوال حفظ واسترجاع موثوقة في التخزين المحلي وملفات تعريف الارتباط معاً لضمان عدم فقدان الإعدادات
function getSavedDeviceId(): string | null {
  try {
    const local = localStorage.getItem(DEVICE_ROLE_STORAGE_KEY);
    if (local && local.trim()) return local.trim();
  } catch (e) {
    console.warn('LocalStorage read error:', e);
  }

  try {
    const match = document.cookie.match(new RegExp('(^|;\\s*)' + DEVICE_ROLE_STORAGE_KEY + '=([^;]+)'));
    if (match && match[2]) {
      return decodeURIComponent(match[2]).trim();
    }
  } catch (e) {
    console.warn('Cookie read error:', e);
  }

  return null;
}

function persistDeviceId(roleId: string) {
  try {
    localStorage.setItem(DEVICE_ROLE_STORAGE_KEY, roleId);
  } catch (e) {
    console.warn('LocalStorage write error:', e);
  }

  try {
    const d = new Date();
    d.setTime(d.getTime() + 365 * 24 * 60 * 60 * 1000); // سنة كاملة
    document.cookie = `${DEVICE_ROLE_STORAGE_KEY}=${encodeURIComponent(roleId)};expires=${d.toUTCString()};path=/;SameSite=Lax`;
  } catch (e) {
    console.warn('Cookie write error:', e);
  }
}

function removePersistedDeviceId() {
  try {
    localStorage.removeItem(DEVICE_ROLE_STORAGE_KEY);
  } catch (e) {}

  try {
    document.cookie = `${DEVICE_ROLE_STORAGE_KEY}=;expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;SameSite=Lax`;
  } catch (e) {}
}

// خريطة المسارات إلى أسماء الوحدات البرمجية والصلاحيات
export const PATH_TO_MODULE_MAP: Record<string, string> = {
  '/': 'dashboard',
  '/students': 'students',
  '/finance': 'student_finance',
  '/receipts': 'receipts',
  '/supply-orders': 'supply_orders',
  '/diploma-registry': 'diploma_registry',
  '/financial-report': 'financial_report',
  '/archive': 'archive',
  '/promotion': 'students',
  '/register': 'registration',
  '/projects': 'graduation_projects',
  '/specializations': 'specialization_report',
  '/whatsapp': 'whatsapp',
  '/settings': 'system_settings',
};

interface DeviceRoleContextType {
  currentRoleId: string | null;
  currentRole: DeviceRole | null;
  roles: DeviceRole[];
  loading: boolean;
  isConfigured: boolean;
  can: (module: string, action?: string) => boolean;
  canViewPath: (path: string) => boolean;
  setDeviceRole: (roleId: string, password?: string) => Promise<{ success: boolean; message?: string }>;
  resetDeviceRole: (password: string) => Promise<{ success: boolean; message?: string }>;
  saveRole: (role: {
    id: string;
    name: string;
    description?: string | null;
    permissions: DeviceRolePermissions;
    passcode?: string | null;
    is_active?: boolean;
  }, password?: string) => Promise<{ success: boolean; message?: string }>;
  removeRole: (roleId: string, password?: string) => Promise<{ success: boolean; message?: string }>;
  reloadRoles: () => Promise<void>;
}

const DeviceRoleContext = createContext<DeviceRoleContextType | undefined>(undefined);

const FALLBACK_DEFAULT_ROLES: DeviceRole[] = [
  {
    id: 'general_manager',
    name: 'المدير العام',
    description: 'صلاحيات كاملة وغير مقيدة على كافة أقسام وشاشات وإعدادات المنظومة',
    is_system: true,
    is_active: true,
    passcode: '5224410',
    permissions: { pages: {} as any },
  },
  {
    id: 'admin_finance',
    name: 'مسؤول الشؤون الإدارية والمالية',
    description: 'إدارة المعاملات المالية، الإيصالات، السداد، التقارير المالية، وأذونات الصرف',
    is_system: true,
    is_active: true,
    passcode: '3344',
    permissions: {
      pages: {
        student_finance: { view: true, add_payment: true, print_receipt: true, edit_fees: true },
        receipts: { view: true, print: true },
        supply_orders: { view: true, add: true, edit: true, print: true },
        financial_report: { view: true, print: true, export: true },
        system_settings: { view: true },
      } as any,
    },
  },
  {
    id: 'study_exams',
    name: 'مسؤول الدراسة والامتحانات',
    description: 'متابعة الفصول الدراسية، الترحيل، مشاريع التخرج، وسجلات الدبلوم والتخصصات',
    is_system: true,
    is_active: true,
    passcode: '5566',
    permissions: {
      pages: {
        dashboard: { view: true },
        graduation_projects: { view: true, edit: true, print: true, export: true },
        specialization_report: { view: true, print: true, export: true },
        diploma_registry: { view: true, print: true, export: true },
        system_settings: { view: true },
      } as any,
    },
  },
  {
    id: 'registrar_general',
    name: 'مسؤول المسجل العام',
    description: 'إدارة شؤون الطلاب، التسجيل الجديد، الأرشيف، وأرقام القيد والأوراق الثبوتية',
    is_system: true,
    is_active: true,
    passcode: '1122',
    permissions: {
      pages: {
        students: { view: true, add: true, edit: true, print: true, export: true },
        registration: { view: true, register_student: true },
        student_profile: { view: true, edit: true, manage_reg_num: true, print: true },
        archive: { view: true, restore: true, print: true, export: true },
        whatsapp: { view: true, send: true },
        system_settings: { view: true },
      } as any,
    },
  },
];

export function DeviceRoleProvider({ children }: { children: React.ReactNode }) {
  const [roles, setRoles] = useState<DeviceRole[]>(FALLBACK_DEFAULT_ROLES);
  const [currentRoleId, setCurrentRoleId] = useState<string | null>(() => {
    return getSavedDeviceId();
  });
  const [loading, setLoading] = useState(false);

  const fetchRoles = useCallback(async () => {
    try {
      const data = await getDeviceRoles();
      if (data && data.length > 0) {
        setRoles(data);
      }
    } catch (err) {
      console.error('Failed to load device roles:', err);
    }
  }, []);

  useEffect(() => {
    fetchRoles();
  }, [fetchRoles]);

  // تحديد الوظيفة الحالية
  const currentRole = roles.find(r => r.id === currentRoleId) || null;
  const isConfigured = Boolean(currentRoleId && currentRole);

  // التحقق من الصلاحية
  const can = useCallback((module: string, action: string = 'view'): boolean => {
    // إذا لم يتم تحديد وظيفة بعد أو كان الحساب المدير العام: صلاحية كاملة
    if (!currentRoleId || currentRoleId === 'general_manager') {
      return true;
    }

    if (!currentRole || !currentRole.is_active) {
      return false;
    }

    const pages = currentRole.permissions?.pages;
    if (!pages) return false;

    const modulePerms = pages[module];
    if (!modulePerms) return false;

    return Boolean(modulePerms[action]);
  }, [currentRoleId, currentRole]);

  // التحقق من مسار الصفحة
  const canViewPath = useCallback((path: string): boolean => {
    // صفحة الإعدادات متاحة دائماً لجميع الأجهزة كما طلب المستخدم
    if (path === '/settings') return true;

    // مسارات تفاصيل الطالب: /student/:id
    if (path.startsWith('/student/')) {
      return can('student_profile', 'view') || can('students', 'view');
    }

    const targetModule = PATH_TO_MODULE_MAP[path];
    if (!targetModule) return true;

    return can(targetModule, 'view');
  }, [can]);

  // تعيين وظيفة هذا الجهاز
  const setDeviceRole = useCallback(async (roleId: string, password?: string): Promise<{ success: boolean; message?: string }> => {
    const target = roles.find(r => r.id === roleId);
    if (!target) {
      return { success: false, message: 'الوظيفة المحددة غير موجودة' };
    }

    // التحقق من رمز المرور: يقبل رمز المرور المخصص للوظيفة أو رمز المدير العام الرئيسي
    const p = (password || '').trim();
    const defaultPasscodes: Record<string, string> = {
      admin_finance: '3344',
      study_exams: '5566',
      registrar_general: '1122',
      general_manager: '5224410',
    };
    const expectedPass = (target.passcode || defaultPasscodes[target.id] || (target.id === 'general_manager' ? SYSTEM_PASSWORD : '1234')).trim();
    const isMasterPassword = p === SYSTEM_PASSWORD;
    const isRolePassword = p === expectedPass;

    if (password !== undefined && !isMasterPassword && !isRolePassword) {
      return { success: false, message: `رمز المرور غير صحيح لوظيفة: ${target.name}` };
    }

    persistDeviceId(roleId);
    setCurrentRoleId(roleId);
    return { success: true };
  }, [roles]);

  // إعادة تعيين وظيفة الجهاز
  const resetDeviceRole = useCallback(async (password: string): Promise<{ success: boolean; message?: string }> => {
    const p = (password || '').trim();
    const currentPass = currentRole?.passcode?.trim();
    const isMaster = p === SYSTEM_PASSWORD;
    const isCurrentRolePass = Boolean(currentPass && p === currentPass);

    if (!isMaster && !isCurrentRolePass) {
      return { success: false, message: 'رمز الأمان غير صحيح' };
    }

    removePersistedDeviceId();
    setCurrentRoleId(null);
    return { success: true };
  }, [currentRole]);

  // حفظ وظيفة جديدة أو تعديل صلاحياتها ورمز مرورها
  const saveRole = useCallback(async (
    role: {
      id: string;
      name: string;
      description?: string | null;
      permissions: DeviceRolePermissions;
      passcode?: string | null;
      is_active?: boolean;
    },
    password?: string
  ): Promise<{ success: boolean; message?: string }> => {
    if (password !== SYSTEM_PASSWORD) {
      return { success: false, message: 'رمز الأمان غير صحيح، لا يمكن تعديل الصلاحيات' };
    }

    try {
      await upsertDeviceRole({
        id: role.id,
        name: role.name,
        description: role.description,
        permissions: role.permissions,
        passcode: role.passcode,
        is_active: role.is_active ?? true,
      });
      await fetchRoles();
      return { success: true };
    } catch (err: any) {
      return { success: false, message: err?.message || 'فشل حفظ الوظيفة' };
    }
  }, [fetchRoles]);

  // حذف وظيفة
  const removeRole = useCallback(async (roleId: string, password?: string): Promise<{ success: boolean; message?: string }> => {
    if (password !== SYSTEM_PASSWORD) {
      return { success: false, message: 'رمز الأمان غير صحيح' };
    }

    const target = roles.find(r => r.id === roleId);
    if (target?.is_system) {
      return { success: false, message: 'لا يمكن حذف الوظائف الأساسية للنظام' };
    }

    try {
      await deleteDeviceRole(roleId);
      // إذا كان هذا الجهاز معيناً لهذه الوظيفة المحذوفة، نعيد تعيينه
      if (currentRoleId === roleId) {
        localStorage.removeItem(DEVICE_ROLE_STORAGE_KEY);
        setCurrentRoleId(null);
      }
      await fetchRoles();
      return { success: true };
    } catch (err: any) {
      return { success: false, message: err?.message || 'فشل حذف الوظيفة' };
    }
  }, [roles, currentRoleId, fetchRoles]);

  return (
    <DeviceRoleContext.Provider
      value={{
        currentRoleId,
        currentRole,
        roles,
        loading,
        isConfigured,
        can,
        canViewPath,
        setDeviceRole,
        resetDeviceRole,
        saveRole,
        removeRole,
        reloadRoles: fetchRoles,
      }}
    >
      {children}
    </DeviceRoleContext.Provider>
  );
}

export function useDeviceRole() {
  const context = useContext(DeviceRoleContext);
  if (!context) {
    throw new Error('useDeviceRole must be used within a DeviceRoleProvider');
  }
  return context;
}
