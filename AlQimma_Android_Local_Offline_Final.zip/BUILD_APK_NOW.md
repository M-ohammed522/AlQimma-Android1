# بناء APK — منظومة القمة

هذه النسخة محلية Offline ولا تعتمد على Supabase.

## البناء
1. ارفع محتويات هذا المجلد إلى مستودع GitHub جديد.
2. اجعل الفرع `main`.
3. افتح تبويب Actions.
4. اختر `Build AlQimma Android APK`.
5. اضغط `Run workflow`.
6. بعد نجاح المهمة افتح Artifacts ونزّل `AlQimma-Android-APK`.

لا تحتاج إلى Android Studio على الهاتف؛ GitHub Actions يجهز Node وJava وAndroid SDK ويبني APK.
