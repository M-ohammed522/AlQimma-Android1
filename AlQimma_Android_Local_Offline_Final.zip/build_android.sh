#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
npm install --no-audit --no-fund
npm run build
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug --no-daemon --stacktrace
echo "APK: android/app/build/outputs/apk/debug/app-debug.apk"
