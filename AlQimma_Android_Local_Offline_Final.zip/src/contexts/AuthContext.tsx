import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';

interface LocalUser { id: string; email: string; }
interface AuthContextValue { user: LocalUser | null; loading: boolean; signOut: () => Promise<void>; signIn: (email: string, password: string) => Promise<{success:boolean;message?:string}>; }
const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({children}:{children:ReactNode}) {
  const [user,setUser]=useState<LocalUser|null>(null);
  const [loading,setLoading]=useState(true);
  useEffect(()=>{
    const session=localStorage.getItem('alqimma_local_session');
    if(session) setUser({id:'local-admin',email:'local@alqimma'});
    setLoading(false);
  },[]);
  const signIn=async(email:string,password:string)=>{
    if(!email.trim() || !password) return {success:false,message:'أدخل بيانات الدخول'};
    // الوضع المحلي: كلمة المرور الرئيسية القديمة للمنظومة تكفي، ولا يتم إرسالها لأي خادم.
    if(password.trim()!=='5224410') return {success:false,message:'كلمة المرور غير صحيحة'};
    localStorage.setItem('alqimma_local_session','1'); setUser({id:'local-admin',email:email.trim()}); return {success:true};
  };
  const signOut=async()=>{localStorage.removeItem('alqimma_local_session');setUser(null);};
  return <AuthContext.Provider value={{user,loading,signOut,signIn}}>{children}</AuthContext.Provider>;
}
export function useAuth(){const ctx=useContext(AuthContext);if(!ctx) throw new Error('useAuth يجب أن يُستخدم داخل AuthProvider');return ctx;}
