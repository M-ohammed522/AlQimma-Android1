// قاعدة بيانات محلية بالكامل — تعمل دون إنترنت باستخدام IndexedDB.
// الواجهة تحاكي الجزء المستخدم من Supabase حتى تبقى صفحات المنظومة الأصلية كما هي.

type Row = Record<string, any>;
type Filter = { op: string; column: string; value?: any };

const DB_NAME = 'alqimma_local_v1';
const DB_VERSION = 1;
const META_STORE = '__meta';
const STORAGE_STORE = '__storage';

const DEFAULT_TABLES = [
  'students','specializations','receipts','semester_charges','supply_orders','system_settings',
  'student_files','archived_students','graduation_batches','notifications','whatsapp_templates',
  'whatsapp_log','device_roles'
];

const DEFAULT_SPECIALIZATIONS = [
  ['إدارة أعمال','عالي'],['محاسبة','عالي'],['حاسوب','عالي'],['صيدلة','عالي'],['تمريض','عالي'],['مختبرات','عالي'],['أشعة','عالي'],['تخدير وعناية فائقة','عالي'],['علاج طبيعي','عالي'],
  ['إدارة أعمال','متوسط'],['محاسبة','متوسط'],['حاسوب','متوسط'],['تمريض','متوسط'],
];

const DEFAULT_SETTINGS: Record<string,string> = {
  high_diploma_fee: '', mid_diploma_fee: '', registration_fee: '', equivalency_registration_fee: '',
  equivalency_semester_fee: '', graduation_project_fee: '', required_photos_count: '4',
  receipt_counter: '0', receipt_counter_high: '0', receipt_counter_mid: '0', receipt_prefix: '',
  supply_order_counter_high: '0', supply_order_counter_mid: '0', letter_seq: '0',
  email_enabled: 'false', email_to: '', email_from: '', email_password: '',
};

const DEFAULT_ROLES = [
  { id:'general_manager', name:'المدير العام', description:'صلاحيات كاملة على المنظومة', is_system:true, is_active:true, permissions:{pages:{}}, passcode:'5224410' },
  { id:'admin_finance', name:'مسؤول الشؤون الإدارية والمالية', description:'إدارة المعاملات المالية والتقارير', is_system:true, is_active:true, permissions:{pages:{student_finance:{view:true,add_payment:true,print_receipt:true,edit_fees:true},receipts:{view:true,print:true},supply_orders:{view:true,add:true,edit:true,print:true},financial_report:{view:true,print:true,export:true},system_settings:{view:true}}}, passcode:'3344' },
  { id:'study_exams', name:'مسؤول الدراسة والامتحانات', description:'الدراسة والترحيل ومشاريع التخرج', is_system:true, is_active:true, permissions:{pages:{dashboard:{view:true},graduation_projects:{view:true,edit:true,print:true,export:true},specialization_report:{view:true,print:true,export:true},diploma_registry:{view:true,print:true,export:true},system_settings:{view:true}}}, passcode:'5566' },
  { id:'registrar_general', name:'مسؤول المسجل العام', description:'الطلاب والتسجيل والأرشيف', is_system:true, is_active:true, permissions:{pages:{students:{view:true,add:true,edit:true,print:true,export:true},registration:{view:true,register_student:true},student_profile:{view:true,edit:true,manage_reg_num:true,print:true},archive:{view:true,restore:true,print:true,export:true},whatsapp:{view:true,send:true},system_settings:{view:true}}}, passcode:'1122' },
];

let dbPromise: Promise<IDBDatabase> | null = null;

function openDb(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      for (const table of DEFAULT_TABLES) if (!db.objectStoreNames.contains(table)) db.createObjectStore(table, { keyPath: 'id' });
      if (!db.objectStoreNames.contains(META_STORE)) db.createObjectStore(META_STORE, { keyPath: 'key' });
      if (!db.objectStoreNames.contains(STORAGE_STORE)) db.createObjectStore(STORAGE_STORE, { keyPath: 'path' });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error('تعذر فتح قاعدة البيانات المحلية'));
  });
  return dbPromise;
}

function tx(table: string, mode: IDBTransactionMode) {
  return openDb().then(db => db.transaction(table, mode).objectStore(table));
}

function reqPromise<T = any>(req: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => { req.onsuccess = () => resolve(req.result); req.onerror = () => reject(req.error); });
}

export async function allRows(table: string): Promise<Row[]> {
  const store = await tx(table, 'readonly');
  return (await reqPromise(store.getAll())) as Row[];
}

export async function putRow(table: string, row: Row): Promise<Row> {
  const r = { ...row };
  if (!r.id) r.id = crypto.randomUUID();
  if (!r.created_at) r.created_at = new Date().toISOString();
  r.updated_at ??= new Date().toISOString();
  const store = await tx(table, 'readwrite');
  await reqPromise(store.put(r));
  return r;
}

export async function deleteRow(table: string, id: any): Promise<void> {
  const store = await tx(table, 'readwrite');
  await reqPromise(store.delete(id));
}

export async function clearTable(table: string): Promise<void> {
  const store = await tx(table, 'readwrite');
  await reqPromise(store.clear());
}

export async function initializeLocalDb(): Promise<void> {
  await openDb();
  const specs = await allRows('specializations');
  if (!specs.length) {
    let id = 1;
    for (const [name, diploma_type] of DEFAULT_SPECIALIZATIONS) {
      await putRow('specializations', { id, name, diploma_type, is_active:true, created_at:new Date().toISOString() });
      id++;
    }
  }
  const settings = await allRows('system_settings');
  if (!settings.length) {
    let id = 1;
    for (const [key,value] of Object.entries(DEFAULT_SETTINGS)) await putRow('system_settings',{id:id++,key,value,updated_at:new Date().toISOString()});
  }
  const roles = await allRows('device_roles');
  if (!roles.length) for (const role of DEFAULT_ROLES) await putRow('device_roles', role);
}

function project(row: Row, fields: string): Row {
  if (!fields || fields.trim() === '*') return { ...row };
  const tokens = fields.split(',').map(s => s.trim()).filter(Boolean);
  const out: Row = tokens.includes('*') ? { ...row } : {};
  for (const token of tokens) {
    if (token === '*') continue;
    const nested = token.match(/^(?:(\w+):)?(\w+)\((.*)\)$/s);
    if (nested) { out[nested[1] || nested[2]] = { __join: nested[2], fields: nested[3] }; continue; }
    out[token] = row[token];
  }
  return out;
}

function joinRow(base: Row, field: any, all: Record<string,Row[]>) {
  const joinName = field.__join as string;
  const joinRows = all[joinName] || [];
  let joined: Row | null = null;
  if (joinName === 'students') joined = joinRows.find(r => String(r.id) === String(base.student_id)) || null;
  else if (joinName === 'specializations') joined = joinRows.find(r => String(r.id) === String(base.specialization_id)) || null;
  if (!joined) return null;
  return project(joined, field.fields);
}

class QueryBuilder implements PromiseLike<{data:any; error:any; count?:number}> {
  private filters: Filter[] = [];
  private orGroups: string[][] = [];
  private orders: {column:string; ascending:boolean}[] = [];
  private limitN: number | null = null;
  private rangeStart: number | null = null;
  private rangeEnd: number | null = null;
  private selected = '*';
  private mode: 'select'|'insert'|'update'|'delete'|'upsert' = 'select';
  private payload: any = null;
  private options: any = {};
  private head = false;
  constructor(private table: string) {}
  select(fields='*', options?:any) { this.selected = fields; if(options) {this.options=options; this.head=!!options.head;} return this; }
  insert(payload:any) { this.mode='insert'; this.payload=Array.isArray(payload)?payload:[payload]; return this; }
  update(payload:any) { this.mode='update'; this.payload=payload; return this; }
  upsert(payload:any, options?:any) { this.mode='upsert'; this.payload=Array.isArray(payload)?payload:[payload]; this.options=options||{}; return this; }
  delete() { this.mode='delete'; return this; }
  eq(column:string,value:any){this.filters.push({op:'eq',column,value});return this;}
  ilike(column:string,value:string){this.filters.push({op:'ilike',column,value});return this;}
  in(column:string,values:any[]){this.filters.push({op:'in',column,value:values});return this;}
  or(expression:string){this.orGroups.push(expression.split(',').map(x=>x.trim()).filter(Boolean));return this;}
  neq(column:string,value:any){this.filters.push({op:'neq',column,value});return this;}
  not(column:string,op:string,value:any){this.filters.push({op:'not_'+op,column,value});return this;}
  gte(column:string,value:any){this.filters.push({op:'gte',column,value});return this;}
  lte(column:string,value:any){this.filters.push({op:'lte',column,value});return this;}
  gt(column:string,value:any){this.filters.push({op:'gt',column,value});return this;}
  lt(column:string,value:any){this.filters.push({op:'lt',column,value});return this;}
  is(column:string,value:any){this.filters.push({op:'is',column,value});return this;}
  order(column:string,opts?:any){this.orders.push({column,ascending:opts?.ascending!==false});return this;}
  limit(n:number){this.limitN=n;return this;}
  range(a:number,b:number){this.rangeStart=a;this.rangeEnd=b;return this;}
  single(){(this.options ||= {}).single=true;return this;}
  maybeSingle(){(this.options ||= {}).maybeSingle=true;return this;}
  then<TResult1 = {data:any;error:any;count?:number}, TResult2 = never>(onfulfilled?: ((value:{data:any;error:any;count?:number})=>TResult1|PromiseLike<TResult1>)|null,onrejected?:((reason:any)=>TResult2|PromiseLike<TResult2>)|null): Promise<TResult1|TResult2>{ return this.execute().then(onfulfilled as any,onrejected as any); }
  private async execute(): Promise<{data:any;error:any;count?:number}> {
    try {
      if (this.mode === 'insert') {
        const out=[]; for (const row of this.payload) out.push(await putRow(this.table,row));
        return {data:this.options?.single?out[0]:out,error:null};
      }
      if (this.mode === 'upsert') {
        const all=await allRows(this.table); const keys=(this.options?.onConflict||'id').split(',').map((x:string)=>x.trim()); const out=[];
        for(const row of this.payload){const idx=all.findIndex(a=>keys.every(k=>String(a[k])===String(row[k]))); if(idx>=0){const merged={...all[idx],...row}; await putRow(this.table,merged); out.push(merged);} else out.push(await putRow(this.table,row));}
        return {data:this.options?.single?out[0]:out,error:null};
      }
      let rows=await allRows(this.table);
      const matchesCondition=(r:Row, condition:string):boolean=>{
        const m=condition.match(/^([\w.]+)\.(ilike|eq|is)\.(.*)$/s);
        if(!m) return true;
        const column=m[1]; const op=m[2]; let raw=m[3]; const v=r[column];
        if(op==='ilike'){
          const needle=String(raw).replace(/^%|%$/g,'').toLocaleLowerCase();
          return String(v??'').toLocaleLowerCase().includes(needle);
        }
        if(op==='is') return raw==='null' ? v==null : String(v)===raw;
        return v===raw || String(v??'')===raw;
      };
      rows=rows.filter(r=>{
        const base=this.filters.every(f=>{
          const v=r[f.column];
          switch(f.op){case'eq':return v===f.value;case'neq':return v!==f.value;case'in':return Array.isArray(f.value)&&f.value.some(x=>String(v)===String(x));case'ilike':{const needle=String(f.value).replace(/^%|%$/g,'').toLocaleLowerCase();return String(v??'').toLocaleLowerCase().includes(needle);}case'gte':return v>=f.value;case'lte':return v<=f.value;case'gt':return v>f.value;case'lt':return v<f.value;case'is':return f.value===null?v==null:v===f.value;case'not_is':return f.value===null?v!=null:v!==f.value;default:return true;}
        });
        if(!base) return false;
        return this.orGroups.every(group=>group.some(condition=>matchesCondition(r,condition)));
      });
      if(this.mode==='update'){const out=[];for(const r of rows){const merged={...r,...this.payload,updated_at:this.payload.updated_at||new Date().toISOString()};await putRow(this.table,merged);out.push(merged);}return {data:out,error:null};}
      if(this.mode==='delete'){for(const r of rows) await deleteRow(this.table,r.id);return {data:null,error:null};}
      for(const o of this.orders.slice().reverse()) rows.sort((a,b)=>{const av=a[o.column],bv=b[o.column]; if(av===bv)return 0; const c=av>bv?1:-1;return o.ascending?c:-c;});
      const count=rows.length;
      if(this.rangeStart!==null) rows=rows.slice(this.rangeStart,(this.rangeEnd??this.rangeStart)+1);
      if(this.limitN!==null) rows=rows.slice(0,this.limitN);
      const joins:string[]=[]; const fields=this.selected;
      const joinRegex=/(?:(\w+):)?(\w+)\(([^()]*)\)/g; let m:RegExpExecArray|null; while((m=joinRegex.exec(fields))) joins.push(m[2]);
      const allMap:Record<string,Row[]>={}; for(const j of joins) allMap[j]=await allRows(j);
      const data=rows.map(r=>{const p=project(r,fields);for(const k of Object.keys(p)){const v=p[k];if(v&&v.__join){p[k]=joinRow(r,v,allMap);}}return p;});
      if(this.head) return {data:null,error:null,count};
      if(this.options?.single){if(data.length!==1)return {data:null,error:new Error(data.length?'أكثر من سجل':'لم يتم العثور على سجل')};return {data:data[0],error:null};}
      if(this.options?.maybeSingle){if(data.length>1)return {data:null,error:new Error('أكثر من سجل')};return {data:data[0]??null,error:null};}
      return {data,error:null,count:this.options?.count==='exact'?count:undefined};
    } catch(error:any){return {data:null,error};}
  }
}

async function rpc(name:string,args:any): Promise<{data:any;error:any}> {
  await initializeLocalDb();
  const students=await allRows('students');
  const receipts=await allRows('receipts');
  const charges=await allRows('semester_charges');
  const archived=await allRows('archived_students');
  const specs=await allRows('specializations');
  if(name==='get_next_receipt_number'){
    const key=args?.p_diploma_type==='متوسط'?'receipt_counter_mid':'receipt_counter_high';
    const s=(await new QueryBuilder('system_settings').select('value').eq('key',key).maybeSingle()).data; const n=(parseInt(s?.value||'0')||0)+1;
    await new QueryBuilder('system_settings').update({value:String(n),updated_at:new Date().toISOString()}).eq('key',key); return {data:String(n).padStart(4,'0'),error:null};
  }
  if(name==='get_next_supply_order_number'){
    const key=args?.p_diploma_type==='متوسط'?'supply_order_counter_mid':'supply_order_counter_high'; const s=(await new QueryBuilder('system_settings').select('value').eq('key',key).maybeSingle()).data; const n=(parseInt(s?.value||'0')||0)+1;
    await new QueryBuilder('system_settings').update({value:String(n),updated_at:new Date().toISOString()}).eq('key',key); return {data:String(n).padStart(3,'0'),error:null};
  }
  if(name==='sync_unassigned_receipts') return {data:{synced_count:0},error:null};
  if(name==='get_previous_debts_v2') return {data:[],error:null};
  if(name==='get_dashboard_stats') return {data:{total_students:students.length,active_students:students.filter(s=>s.status==='نشط').length,graduated_students:students.filter(s=>s.status==='خريج').length,total_receipts:receipts.length,total_paid:receipts.reduce((a,r)=>a+Number(r.amount||0),0)},error:null};
  if(name==='get_archive_stats') return {data:{total:archived.length,archived_count:archived.length},error:null};
  if(name==='get_specialization_stats'){
    const map=new Map<string,any>(); for(const s of students){const key=`${s.specialization||'غير محدد'}|${s.diploma_type||''}`;const x=map.get(key)||{specialization:s.specialization||'غير محدد',diploma_type:s.diploma_type,total:0,active:0,graduated:0};x.total++;if(s.status==='نشط')x.active++;if(s.status==='خريج')x.graduated++;map.set(key,x);} return {data:[...map.values()],error:null};
  }
  if(name==='get_student_management_stats') return {data:{total:students.length,active:students.filter(s=>s.status==='نشط').length,graduated:students.filter(s=>s.status==='خريج').length,stopped:students.filter(s=>s.status==='موقوف قيد').length},error:null};
  if(name==='get_pending_archive_students') return {data:students.filter(s=>s.final_paid_at && !s.graduated_at),error:null};
  return {data:null,error:null};
}

function makeStorage(){
  return { from(bucket:string){return { upload: async(path:string,file:any)=>{const store=await tx(STORAGE_STORE,'readwrite');await reqPromise(store.put({path:`${bucket}/${path}`,file,created_at:new Date().toISOString()}));return {data:{path},error:null};}, remove: async(paths:string[])=>{for(const p of paths){const store=await tx(STORAGE_STORE,'readwrite');await reqPromise(store.delete(`${bucket}/${p}`));}return {data:null,error:null};}, getPublicUrl:(path:string)=>({data:{publicUrl:`local-storage://${bucket}/${path}`}}), createSignedUrl:async(path:string)=>({data:{signedUrl:`local-storage://${bucket}/${path}`},error:null})};}}
}

export const localClient:any = {
  from:(table:string)=>new QueryBuilder(table),
  rpc,
  auth:{
    async getSession(){return {data:{session:localStorage.getItem('alqimma_local_session')?{user:{id:'local-admin',email:'local@alqimma'}}:null},error:null};},
    onAuthStateChange(cb:any){const timer=setTimeout(()=>cb('INITIAL_SESSION',localStorage.getItem('alqimma_local_session')?{user:{id:'local-admin',email:'local@alqimma'}}:null),0);return {data:{subscription:{unsubscribe:()=>clearTimeout(timer)}}};},
    async signInWithPassword(){localStorage.setItem('alqimma_local_session','1');return {data:{session:{user:{id:'local-admin',email:'local@alqimma'}}},error:null};},
    async signOut(){localStorage.removeItem('alqimma_local_session');return {error:null};}
  },
  functions:{invoke:async()=>({data:null,error:new Error('هذه الوظيفة غير متاحة في الوضع المحلي دون إنترنت')})},
  storage:makeStorage(),
};

export { QueryBuilder };
