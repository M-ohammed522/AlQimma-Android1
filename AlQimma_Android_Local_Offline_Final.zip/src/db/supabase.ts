// توافق داخلي: لم تعد المنظومة تعتمد على Supabase في النسخة المحلية.
// البيانات محفوظة داخل الجهاز عبر IndexedDB وتعمل دون إنترنت.
import { localClient, initializeLocalDb } from './localDb';
export const supabase = localClient;
void initializeLocalDb();
