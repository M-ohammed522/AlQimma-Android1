import { useState } from 'react';
import type { FormEvent } from 'react';
import { LockKeyhole, Mail, LogIn, Loader2, ShieldCheck } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

export default function LoginPage() {
  const { signIn } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError('');
    if (!email.trim() || !password) {
      setError('يرجى إدخال البريد الإلكتروني وكلمة المرور');
      return;
    }
    setLoading(true);
    const result = await signIn(email.trim(), password);
    setLoading(false);
    if (!result.success) setError(result.message || 'تعذر تسجيل الدخول');
  }

  return (
    <main dir="rtl" className="min-h-screen flex items-center justify-center bg-slate-950 px-4 py-8">
      <div className="w-full max-w-md rounded-3xl border border-emerald-500/20 bg-slate-900 p-7 shadow-2xl">
        <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-500/15 text-emerald-400">
          <ShieldCheck className="h-9 w-9" />
        </div>
        <h1 className="text-center text-2xl font-extrabold text-white">منظومة معهد القمة</h1>
        <p className="mt-2 text-center text-sm text-slate-400">تسجيل الدخول الآمن إلى المنظومة</p>

        <form onSubmit={handleSubmit} className="mt-7 space-y-4">
          <label className="block">
            <span className="mb-2 block text-sm font-semibold text-slate-200">البريد الإلكتروني</span>
            <div className="relative">
              <Mail className="absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-500" />
              <input value={email} onChange={e => setEmail(e.target.value)} type="email" autoComplete="username" dir="ltr"
                className="w-full rounded-xl border border-slate-700 bg-slate-950 py-3 pl-3 pr-11 text-white outline-none focus:border-emerald-500" placeholder="admin@example.com" />
            </div>
          </label>
          <label className="block">
            <span className="mb-2 block text-sm font-semibold text-slate-200">كلمة المرور</span>
            <div className="relative">
              <LockKeyhole className="absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-500" />
              <input value={password} onChange={e => setPassword(e.target.value)} type="password" autoComplete="current-password" dir="ltr"
                className="w-full rounded-xl border border-slate-700 bg-slate-950 py-3 pl-3 pr-11 text-white outline-none focus:border-emerald-500" placeholder="••••••••" />
            </div>
          </label>
          {error && <div className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-300">{error}</div>}
          <button disabled={loading} className="flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-500 py-3 font-bold text-slate-950 transition hover:bg-emerald-400 disabled:opacity-60">
            {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <LogIn className="h-5 w-5" />}
            {loading ? 'جارٍ التحقق...' : 'تسجيل الدخول'}
          </button>
        </form>

        <p className="mt-6 text-center text-xs leading-6 text-slate-500">يجب إنشاء حساب المستخدم من Supabase Auth قبل أول دخول. لا يتم حفظ كلمة المرور داخل التطبيق.</p>
      </div>
    </main>
  );
}
