import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'ly.alqimma.medical.admin',
  appName: 'منظومة معهد القمة',
  webDir: 'dist',
  server: { cleartext: false },
};

export default config;
